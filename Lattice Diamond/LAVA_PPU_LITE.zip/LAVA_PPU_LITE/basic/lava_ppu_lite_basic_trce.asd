[ActiveSupport TRCE]
; Setup Analysis
Fmax_0 = 61.158 MHz (42.955 MHz);
Fmax_1 = 280.899 MHz (21.477 MHz);
Failed = 0 (Total 2);
Clock_ports = 1;
Clock_nets = 4;
; Hold Analysis
Fmax_0 = 0.219 ns (0.000 ns);
Fmax_1 = 0.304 ns (0.000 ns);
Failed = 0 (Total 2);
Clock_ports = 1;
Clock_nets = 4;
