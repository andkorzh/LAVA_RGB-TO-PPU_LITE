[ActiveSupport TRCE]
; Setup Analysis
Fmax_0 = 268.673 MHz (21.477 MHz);
Fmax_1 = 59.308 MHz (42.955 MHz);
Failed = 0 (Total 2);
Clock_ports = 1;
Clock_nets = 3;
; Hold Analysis
Fmax_0 = 0.304 ns (0.000 ns);
Fmax_1 = 0.202 ns (0.000 ns);
Failed = 0 (Total 2);
Clock_ports = 1;
Clock_nets = 3;
