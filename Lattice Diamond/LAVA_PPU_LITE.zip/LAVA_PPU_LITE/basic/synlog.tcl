run_tcl -fg LAVA_PPU_LITE_basic_synplify.tcl
