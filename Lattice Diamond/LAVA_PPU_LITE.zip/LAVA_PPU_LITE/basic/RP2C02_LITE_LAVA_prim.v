// Verilog netlist produced by program LSE :  version Diamond Version 3.5.0.102
// Netlist written on Wed Sep 02 17:41:03 2026
//
// Verilog Description of module RP2C02_LITE_LAVA
//

module RP2C02_LITE_LAVA (MCLK, MODE, DENDY, nRES, P_BUTTON, RnW, 
            nDBE, A, PD, DB, RGB, PA8, PA9, PA10, PA11, PA12, 
            PA13, INT, ALE, nWR, nRD, SYNC, PCLK, SUBCLK, DB_nOE, 
            DB_DIR, PD_DIR, PD_nOE) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(35[8:24])
    input MCLK;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(36[7:11])
    input MODE;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(38[7:11])
    input DENDY;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(39[7:12])
    input nRES;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(40[7:11])
    input P_BUTTON;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(41[7:15])
    input RnW;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(42[7:10])
    input nDBE;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(43[7:11])
    input [2:0]A;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(44[12:13])
    inout [7:0]PD;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(45[12:14])
    inout [7:0]DB;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(47[13:15])
    output [23:0]RGB;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    output PA8;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(49[8:11])
    output PA9;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(50[8:11])
    output PA10;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(51[8:12])
    output PA11;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(52[8:12])
    output PA12;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(53[8:12])
    output PA13;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(54[8:12])
    output INT;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(55[8:11])
    output ALE;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(56[8:11])
    output nWR;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(57[8:11])
    output nRD;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(58[8:11])
    output SYNC;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(59[8:12])
    output PCLK;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(60[8:12])
    output SUBCLK;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(61[8:14])
    output DB_nOE;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(62[8:14])
    output DB_DIR;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(63[8:14])
    output PD_DIR;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(64[8:14])
    output PD_nOE;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(65[8:14])
    
    wire MCLK_c /* synthesis is_clock=1, SET_AS_NETWORK=MCLK_c */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(36[7:11])
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire VSYNC /* synthesis SET_AS_NETWORK=VSYNC, is_clock=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(125[6:11])
    wire Clk2_N_24 /* synthesis is_inv_clock=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(478[5:10])
    
    wire GND_net, VCC_net, MODE_c, DENDY_c, nRES_c, P_BUTTON_c, 
        RnW_c, DB_nOE_c_c, A_c_2, A_c_1, A_c_0, RGB_c_23, RGB_c_22, 
        RGB_c_21, RGB_c_20, RGB_c_19, RGB_c_18, RGB_c_17, RGB_c_16, 
        RGB_c_15, RGB_c_14, RGB_c_13, RGB_c_12, RGB_c_11, RGB_c_10, 
        RGB_c_9, RGB_c_8, RGB_c_7, RGB_c_6, RGB_c_5, RGB_c_4, RGB_c_3, 
        RGB_c_2, RGB_c_1, RGB_c_0, PA8_c_8, PA9_c_9, PA10_c_10, 
        PA11_c_11, PA12_c_12, PA13_c_13, INT_c, ALE_c, nWR_c, nRD_c, 
        SYNC_c, PCLK_c, SUBCLK_c, DB_DIR_c, nPCLK;
    wire [5:0]Hn;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(71[11:13])
    wire [5:0]Hnn;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(72[11:14])
    wire [7:0]DBIN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(73[11:15])
    wire [2:0]EMPH;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(74[11:15])
    wire [7:0]OB;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(75[11:13])
    wire [3:0]OV;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(76[11:13])
    wire [7:0]Vo;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(77[11:13])
    wire [5:0]PIX;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(78[11:14])
    wire [2:0]R2DB;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(79[11:15])
    wire [4:0]THO;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(80[11:14])
    wire [13:0]PAD;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(80[27:30])
    wire [4:0]ZCOL;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(82[11:15])
    wire [4:0]CGA;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(83[11:14])
    wire [2:0]PALSEL;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(84[11:17])
    
    wire W0, W1, R2, W3, W4, R4, W5_1, W5_2, W6_1, W6_2, 
        W7, R7, R_EN, I1_32, OBSEL, BGSEL, O8_16, VBL_EN, B_W, 
        BGCLIP, S_EV, O_HPOS, nEVAL, E_EV, I_OAM2, PAR_O, nVIS, 
        F_NT, F_AT, SC_CNT, nPICTURE, RC, RESCL, BLNK, TSTEP, 
        TH_MUX, TVO1, OMFG, PD_FIFO, SPR0_EV, SPR_OV, SH2, RPIX, 
        P_BUTTON_N_7, MODE_N_21, RnWR, nDBER, CLIPOR, EMP_R, EMP_G, 
        nCLPB_N_130;
    wire [7:0]OB_R;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(642[10:14])
    wire [7:0]D;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(645[11:12])
    
    wire CLIP_OUT, NFO_OUT, N_HB, BLNK_FF, Clk_enable_44, CLIP_B_N_247;
    wire [4:0]W7Q;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(895[10:13])
    
    wire DB_PAR_N_593, PD_DIR_c, XRB_N_606, ALE_N_601;
    wire [3:0]BGC2;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(952[10:14])
    
    wire CLPB_LATCH, PD_SR, SRLOAD, PD_SR_N_683, STEP_N_685, VINV_LATCH_N_896, 
        TAL_LATCH_N_890, DB_out_0, DB_out_1, DB_out_2, DB_out_3, DB_out_4, 
        DB_out_5, DB_out_6, DB_out_7, OMFG_N_973, PD_out_0, PD_out_1, 
        PD_out_2, PD_out_3, PD_out_4, PD_out_5, OMSTEP_1__N_1053, 
        PD_out_6, SPR0HIT_LATCH, PD_out_7;
    wire [4:0]THO_LATCH;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1512[17:26])
    wire [4:0]STEP3;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1512[28:33])
    
    wire Clk_enable_234, DB_PARR, n10678, n996, Clk_enable_220, Clk_enable_43;
    
    VHI i2 (.Z(VCC_net));
    INV i11028 (.A(MCLK_c), .Z(Clk2_N_24));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(36[7:11])
    PIX_MUX MOD_PIX_MUX (.BGC2({BGC2}), .CLPB_LATCH(CLPB_LATCH), .Clk(Clk), 
            .nPCLK(nPCLK), .RESCL(RESCL), .\R2DB[1] (R2DB[1]), .n10678(n10678), 
            .PCLK_c(PCLK_c), .ZCOL({ZCOL}), .THO_LATCH({THO_LATCH[4], 
            Open_0, Open_1, Open_2, THO_LATCH[0]}), .THO({THO}), .STEP3({STEP3[4], 
            Open_3, Open_4, Open_5, Open_6}), .TH_MUX(TH_MUX), .\CGA[3] (CGA[3]), 
            .\CGA[2] (CGA[2]), .\CGA[1] (CGA[1]), .\STEP3[0] (STEP3[0]), 
            .\CGA[0] (CGA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(420[9] 434[2])
    OB RGB_pad_14 (.I(RGB_c_14), .O(RGB[14]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_15 (.I(RGB_c_15), .O(RGB[15]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_16 (.I(RGB_c_16), .O(RGB[16]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_17 (.I(RGB_c_17), .O(RGB[17]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_18 (.I(RGB_c_18), .O(RGB[18]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_19 (.I(RGB_c_19), .O(RGB[19]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_20 (.I(RGB_c_20), .O(RGB[20]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_21 (.I(RGB_c_21), .O(RGB[21]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_22 (.I(RGB_c_22), .O(RGB[22]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_23 (.I(RGB_c_23), .O(RGB[23]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    BB DB_pad_0 (.I(D[0]), .T(R_EN), .B(DB[0]), .O(DB_out_0));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB DB_pad_1 (.I(D[1]), .T(R_EN), .B(DB[1]), .O(DB_out_1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB DB_pad_2 (.I(D[2]), .T(R_EN), .B(DB[2]), .O(DB_out_2));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB DB_pad_3 (.I(D[3]), .T(R_EN), .B(DB[3]), .O(DB_out_3));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB DB_pad_4 (.I(D[4]), .T(R_EN), .B(DB[4]), .O(DB_out_4));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB DB_pad_5 (.I(D[5]), .T(R_EN), .B(DB[5]), .O(DB_out_5));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB DB_pad_6 (.I(D[6]), .T(R_EN), .B(DB[6]), .O(DB_out_6));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB DB_pad_7 (.I(D[7]), .T(R_EN), .B(DB[7]), .O(DB_out_7));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB PD_pad_0 (.I(PAD[0]), .T(PD_DIR_c), .B(PD[0]), .O(PD_out_0));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    BB PD_pad_1 (.I(PAD[1]), .T(PD_DIR_c), .B(PD[1]), .O(PD_out_1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    BB PD_pad_2 (.I(PAD[2]), .T(PD_DIR_c), .B(PD[2]), .O(PD_out_2));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    BB PD_pad_3 (.I(PAD[3]), .T(PD_DIR_c), .B(PD[3]), .O(PD_out_3));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    LOCAL_BUS_CONTROL MOD_LOCAL_BUS_CONTROL (.Clk(Clk), .nPCLK(nPCLK), .DB_PARR(DB_PARR), 
            .PCLK_c(PCLK_c), .DB_PAR_N_593(DB_PAR_N_593), .R7(R7), .W7Q({Open_7, 
            W7Q[3], Open_8, Open_9, Open_10}), .W7(W7), .TH_MUX(TH_MUX), 
            .XRB_N_606(XRB_N_606), .BLNK(BLNK), .PA11_c_11(PA11_c_11), 
            .PA12_c_12(PA12_c_12), .PA8_c_8(PA8_c_8), .PA13_c_13(PA13_c_13), 
            .PA9_c_9(PA9_c_9), .PA10_c_10(PA10_c_10), .\Hn[0] (Hn[0]), 
            .ALE_c(ALE_c), .TSTEP(TSTEP), .\Hnn[0] (Hnn[0]), .PD_DIR_c(PD_DIR_c), 
            .RC(RC), .Clk_enable_234(Clk_enable_234), .\W7Q[1] (W7Q[1]), 
            .nRD_c(nRD_c), .nWR_c(nWR_c), .ALE_N_601(ALE_N_601)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(279[19] 297[2])
    BB PD_pad_4 (.I(PAD[4]), .T(PD_DIR_c), .B(PD[4]), .O(PD_out_4));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    BB PD_pad_5 (.I(PAD[5]), .T(PD_DIR_c), .B(PD[5]), .O(PD_out_5));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    PUR PUR_INST (.PUR(VCC_net));
    defparam PUR_INST.RST_PULSE = 1;
    BB PD_pad_6 (.I(PAD[6]), .T(PD_DIR_c), .B(PD[6]), .O(PD_out_6));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    LUT4 P_BUTTON_I_0_1_lut (.A(P_BUTTON_c), .Z(P_BUTTON_N_7)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(457[1:10])
    defparam P_BUTTON_I_0_1_lut.init = 16'h5555;
    PALETTE_SWITCH PALSEL_2__I_0 (.PALSEL({PALSEL}), .GND_net(GND_net), 
            .VSYNC(VSYNC), .P_BUTTON_N_7(P_BUTTON_N_7), .P_BUTTON_c(P_BUTTON_c)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(455[16] 459[2])
    LUT4 i6887_2_lut (.A(MODE_c), .B(DENDY_c), .Z(MODE_N_21)) /* synthesis lut_function=(A (B)) */ ;
    defparam i6887_2_lut.init = 16'h8888;
    BG_COLOR MOD_BG_COLOR (.TVO1(TVO1), .PCLK_c(PCLK_c), .\Hnn[0] (Hnn[0]), 
            .Clk(Clk), .nPCLK(nPCLK), .PD_SR(PD_SR), .PD_out_0(PD_out_0), 
            .NFO_OUT(NFO_OUT), .STEP_N_685(STEP_N_685), .SRLOAD(SRLOAD), 
            .Clk_enable_43(Clk_enable_43), .RC(RC), .\DBIN[2] (DBIN[2]), 
            .\DBIN[1] (DBIN[1]), .\DBIN[0] (DBIN[0]), .CLPB_LATCH(CLPB_LATCH), 
            .nCLPB_N_130(nCLPB_N_130), .F_AT(F_AT), .\THO[1] (THO[1]), 
            .PD_out_7(PD_out_7), .PD_out_6(PD_out_6), .PD_out_5(PD_out_5), 
            .PD_out_4(PD_out_4), .PD_out_3(PD_out_3), .PD_out_2(PD_out_2), 
            .PD_out_1(PD_out_1), .BGC2({BGC2}), .PD_SR_N_683(PD_SR_N_683)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(300[10] 317[2])
    OBJ_FIFO MOD_OBJ_FIFO (.OB({OB}), .PCLK_c(PCLK_c), .SH2(SH2), .Clk(Clk), 
            .nPCLK(nPCLK), .PAR_O(PAR_O), .Hnn({Hnn}), .PD_FIFO(PD_FIFO), 
            .ZCOL({ZCOL}), .PD_out_7(PD_out_7), .PD_out_0(PD_out_0), .PD_out_6(PD_out_6), 
            .PD_out_1(PD_out_1), .PD_out_5(PD_out_5), .PD_out_2(PD_out_2), 
            .PD_out_4(PD_out_4), .PD_out_3(PD_out_3), .SPR0HIT_LATCH(SPR0HIT_LATCH), 
            .O_HPOS(O_HPOS), .CLIPOR(CLIPOR), .VINV_LATCH_N_896(VINV_LATCH_N_896), 
            .nVIS(nVIS)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(402[10] 417[2])
    BB PD_pad_7 (.I(PAD[7]), .T(PD_DIR_c), .B(PD[7]), .O(PD_out_7));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    IB A_pad_0 (.I(A[0]), .O(A_c_0));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(44[12:13])
    IB A_pad_1 (.I(A[1]), .O(A_c_1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(44[12:13])
    IB A_pad_2 (.I(A[2]), .O(A_c_2));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(44[12:13])
    IB DB_nOE_c_pad (.I(nDBE), .O(DB_nOE_c_c));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(43[7:11])
    IB RnW_pad (.I(RnW), .O(RnW_c));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(42[7:10])
    IB P_BUTTON_pad (.I(P_BUTTON), .O(P_BUTTON_c));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(41[7:15])
    IB nRES_pad (.I(nRES), .O(nRES_c));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(40[7:11])
    IB DENDY_pad (.I(DENDY), .O(DENDY_c));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(39[7:12])
    IB MODE_pad (.I(MODE), .O(MODE_c));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(38[7:11])
    IB MCLK_pad (.I(MCLK), .O(MCLK_c));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(36[7:11])
    OB PD_nOE_pad (.I(GND_net), .O(PD_nOE));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(65[8:14])
    OB PD_DIR_pad (.I(PD_DIR_c), .O(PD_DIR));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(64[8:14])
    OB DB_DIR_pad (.I(DB_DIR_c), .O(DB_DIR));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(63[8:14])
    OB DB_nOE_pad (.I(DB_nOE_c_c), .O(DB_nOE));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(62[8:14])
    OB SUBCLK_pad (.I(SUBCLK_c), .O(SUBCLK));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(61[8:14])
    OB PCLK_pad (.I(PCLK_c), .O(PCLK));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(60[8:12])
    OB SYNC_pad (.I(SYNC_c), .O(SYNC));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(59[8:12])
    OB nRD_pad (.I(nRD_c), .O(nRD));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(58[8:11])
    OB nWR_pad (.I(nWR_c), .O(nWR));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(57[8:11])
    OB ALE_pad (.I(ALE_c), .O(ALE));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(56[8:11])
    OB INT_pad (.I(INT_c), .O(INT));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(55[8:11])
    OB PA13_pad (.I(PA13_c_13), .O(PA13));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(54[8:12])
    OB PA12_pad (.I(PA12_c_12), .O(PA12));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(53[8:12])
    OB PA11_pad (.I(PA11_c_11), .O(PA11));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(52[8:12])
    OB PA10_pad (.I(PA10_c_10), .O(PA10));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(51[8:12])
    OB PA9_pad (.I(PA9_c_9), .O(PA9));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(50[8:11])
    OB PA8_pad (.I(PA8_c_8), .O(PA8));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(49[8:11])
    OB RGB_pad_0 (.I(RGB_c_0), .O(RGB[0]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_1 (.I(RGB_c_1), .O(RGB[1]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_2 (.I(RGB_c_2), .O(RGB[2]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_3 (.I(RGB_c_3), .O(RGB[3]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_4 (.I(RGB_c_4), .O(RGB[4]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_5 (.I(RGB_c_5), .O(RGB[5]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    PALETTE MOD_PALETTE (.RGB_c_7(RGB_c_7), .RGB_c_13(RGB_c_13), .RGB_c_14(RGB_c_14), 
            .RGB_c_15(RGB_c_15), .RGB_c_0(RGB_c_0), .RGB_c_1(RGB_c_1), 
            .RGB_c_2(RGB_c_2), .RGB_c_8(RGB_c_8), .RGB_c_16(RGB_c_16), 
            .RGB_c_9(RGB_c_9), .RGB_c_17(RGB_c_17), .RGB_c_18(RGB_c_18), 
            .RGB_c_19(RGB_c_19), .Clk(Clk), .PCLK_c(PCLK_c), .nPICTURE(nPICTURE), 
            .EMPH({EMPH}), .GND_net(GND_net), .RGB_c_20(RGB_c_20), .RGB_c_10(RGB_c_10), 
            .RGB_c_21(RGB_c_21), .RGB_c_3(RGB_c_3), .RGB_c_22(RGB_c_22), 
            .RGB_c_23(RGB_c_23), .MODE_N_21(MODE_N_21), .EMP_G(EMP_G), 
            .EMP_R(EMP_R), .R7(R7), .TH_MUX(TH_MUX), .RPIX(RPIX), .n996(n996), 
            .RGB_c_4(RGB_c_4), .PIX({PIX}), .RGB_c_5(RGB_c_5), .RGB_c_6(RGB_c_6), 
            .B_W(B_W), .DB_PARR(DB_PARR), .RGB_c_11(RGB_c_11), .\STEP3[4] (STEP3[4]), 
            .\THO_LATCH[4] (THO_LATCH[4]), .\STEP3[0] (STEP3[0]), .\THO_LATCH[0] (THO_LATCH[0]), 
            .\CGA[1] (CGA[1]), .RGB_c_12(RGB_c_12), .PALSEL({PALSEL}), 
            .VCC_net(VCC_net), .\CGA[3] (CGA[3]), .\CGA[2] (CGA[2]), .\CGA[0] (CGA[0]), 
            .\DBIN[5] (DBIN[5]), .\DBIN[4] (DBIN[4]), .\DBIN[3] (DBIN[3]), 
            .\DBIN[2] (DBIN[2]), .\DBIN[1] (DBIN[1]), .\DBIN[0] (DBIN[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(437[9] 453[2])
    OB RGB_pad_6 (.I(RGB_c_6), .O(RGB[6]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_7 (.I(RGB_c_7), .O(RGB[7]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_8 (.I(RGB_c_8), .O(RGB[8]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_9 (.I(RGB_c_9), .O(RGB[9]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_10 (.I(RGB_c_10), .O(RGB[10]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_11 (.I(RGB_c_11), .O(RGB[11]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_12 (.I(RGB_c_12), .O(RGB[12]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_13 (.I(RGB_c_13), .O(RGB[13]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    TIMING_GENERATOR Hn_2__I_0 (.BLNK(BLNK), .Vo({Vo}), .MODE_c(MODE_c), 
            .DENDY_c(DENDY_c), .Clk(Clk), .nPCLK(nPCLK), .S_EV(S_EV), 
            .PCLK_c(PCLK_c), .CLIP_OUT(CLIP_OUT), .O_HPOS(O_HPOS), .nEVAL(nEVAL), 
            .RC(RC), .nRES_c(nRES_c), .RESCL(RESCL), .BGCLIP(BGCLIP), 
            .CLIP_B_N_247(CLIP_B_N_247), .Hnn({Hnn}), .\Hn[0] (Hn[0]), 
            .I_OAM2(I_OAM2), .PAR_O(PAR_O), .N_HB(N_HB), .VSYNC(VSYNC), 
            .NFO_OUT(NFO_OUT), .SRLOAD(SRLOAD), .BLNK_FF(BLNK_FF), .STEP_N_685(STEP_N_685), 
            .E_EV(E_EV), .R2(R2), .nVIS(nVIS), .F_NT(F_NT), .MODE_N_21(MODE_N_21), 
            .\Hn[2] (Hn[2]), .\Hn[1] (Hn[1]), .SYNC_c(SYNC_c), .\R2DB[2] (R2DB[2]), 
            .Clk_enable_220(Clk_enable_220), .VBL_EN(VBL_EN), .INT_c(INT_c), 
            .nPICTURE(nPICTURE), .F_AT(F_AT), .PD_SR(PD_SR)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(235[18] 276[2])
    OBJ_EVAL MOD_OBJ_EVAL (.SPR0_EV(SPR0_EV), .PAR_O(PAR_O), .PCLK_c(PCLK_c), 
            .S_EV(S_EV), .Clk(Clk), .nPCLK(nPCLK), .PD_SR_N_683(PD_SR_N_683), 
            .TAL_LATCH_N_890(TAL_LATCH_N_890), .Vo({Vo}), .OB_R({OB_R}), 
            .GND_net(GND_net), .nVIS(nVIS), .I_OAM2(I_OAM2), .SPR_OV(SPR_OV), 
            .\Hnn[0] (Hnn[0]), .OMSTEP_1__N_1053(OMSTEP_1__N_1053), .OV({OV}), 
            .OMFG_N_973(OMFG_N_973), .OMFG(OMFG), .O8_16(O8_16), .PD_FIFO(PD_FIFO)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(358[10] 376[2])
    LUT4 i1_2_lut (.A(W5_1), .B(RC), .Z(Clk_enable_43)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i1_2_lut.init = 16'heeee;
    READBUSMUX MOD_READBUSMUX (.R2(R2), .R7(R7), .R4(R4), .Clk(Clk), 
            .OB_R({OB_R}), .PCLK_c(PCLK_c), .OB({OB}), .DBIN({DBIN}), 
            .D({D}), .RnWR(RnWR), .nDBER(nDBER), .R_EN(R_EN), .RPIX(RPIX), 
            .R2DB({R2DB}), .XRB_N_606(XRB_N_606), .PIX({PIX}), .Clk_enable_234(Clk_enable_234), 
            .RC(RC), .PD_out_1(PD_out_1), .PD_out_2(PD_out_2), .PD_out_3(PD_out_3), 
            .PD_out_4(PD_out_4), .PD_out_5(PD_out_5), .PD_out_6(PD_out_6), 
            .PD_out_7(PD_out_7), .PD_out_0(PD_out_0)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(216[12] 232[2])
    PLL MOD_PLL (.MCLK_c(MCLK_c), .Clk(Clk), .GND_net(GND_net)) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(152[5] 155[2])
    GSR GSR_INST (.GSR(nRES_c));
    OAM MOD_OAM (.W4(W4), .Clk(Clk), .nPCLK(nPCLK), .nEVAL(nEVAL), .\Hn[0] (Hn[0]), 
        .PCLK_c(PCLK_c), .BLNK(BLNK), .PAR_O(PAR_O), .\Hn[2] (Hn[2]), 
        .\Hnn[0] (Hnn[0]), .OMFG(OMFG), .OMFG_N_973(OMFG_N_973), .OB({OB}), 
        .I_OAM2(I_OAM2), .OMSTEP_1__N_1053(OMSTEP_1__N_1053), .nVIS(nVIS), 
        .SPR_OV(SPR_OV), .SPR0_EV(SPR0_EV), .SPR0HIT_LATCH(SPR0HIT_LATCH), 
        .n10678(n10678), .\R2DB[0] (R2DB[0]), .RESCL(RESCL), .ALE_N_601(ALE_N_601), 
        .VCC_net(VCC_net), .GND_net(GND_net), .DBIN({DBIN}), .W3(W3)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(379[5] 399[2])
    CLK_DIV MOD_CLK_DIV (.MCLK_c(MCLK_c), .SUBCLK_c(SUBCLK_c), .Clk2_N_24(Clk2_N_24), 
            .MODE_c(MODE_c), .DENDY_c(DENDY_c), .PCLK_c(PCLK_c), .nPCLK(nPCLK), 
            .nRES_c(nRES_c), .MODE_N_21(MODE_N_21)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(157[9] 164[2])
    VLO i1 (.Z(GND_net));
    REGISTER_SELECT MOD_REGISTER_SELECT (.DBIN({DBIN}), .Clk(Clk), .DB_out_0(DB_out_0), 
            .GND_net(GND_net), .RnWR(RnWR), .VCC_net(VCC_net), .RnW_c(RnW_c), 
            .nDBER(nDBER), .DB_nOE_c_c(DB_nOE_c_c), .DB_out_7(DB_out_7), 
            .DB_out_6(DB_out_6), .DB_out_5(DB_out_5), .A_c_1(A_c_1), .A_c_0(A_c_0), 
            .DB_out_4(DB_out_4), .R2(R2), .Clk_enable_220(Clk_enable_220), 
            .DB_out_3(DB_out_3), .W6_2(W6_2), .W5_1(W5_1), .RC(RC), 
            .Clk_enable_44(Clk_enable_44), .W6_1(W6_1), .W5_2(W5_2), .DB_out_2(DB_out_2), 
            .DB_out_1(DB_out_1), .W0(W0), .W1(W1), .W3(W3), .R4(R4), 
            .W4(W4), .R7(R7), .W7(W7), .DB_DIR_c(DB_DIR_c), .A_c_2(A_c_2)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(167[17] 187[2])
    TSALL TSALL_INST (.TSALL(GND_net));
    REG2000_2001 MOD_REG2000_2001 (.EMP_R(EMP_R), .EMP_G(EMP_G), .MODE_c(MODE_c), 
            .DENDY_c(DENDY_c), .EMPH({EMPH}), .n996(n996), .Clk(Clk), 
            .nPCLK(nPCLK), .nVIS(nVIS), .CLIP_B_N_247(CLIP_B_N_247), .CLIPOR(CLIPOR), 
            .W1(W1), .nCLPB_N_130(nCLPB_N_130), .CLIP_OUT(CLIP_OUT), .O8_16(O8_16), 
            .BGCLIP(BGCLIP), .DBIN({DBIN}), .I1_32(I1_32), .VBL_EN(VBL_EN), 
            .W0(W0), .OBSEL(OBSEL), .B_W(B_W), .BGSEL(BGSEL), .BLNK_FF(BLNK_FF), 
            .BLNK(BLNK), .N_HB(N_HB), .SC_CNT(SC_CNT), .RC(RC)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(190[14] 213[2])
    PAR_GEN MOD_PAR_GEN (.\PAD[0] (PAD[0]), .Clk(Clk), .PCLK_c(PCLK_c), 
            .GND_net(GND_net), .W6_2(W6_2), .BLNK(BLNK), .DBIN({DBIN}), 
            .BGSEL(BGSEL), .PAR_O(PAR_O), .W5_2(W5_2), .RC(RC), .W6_1(W6_1), 
            .W5_1(W5_1), .THO({THO}), .OBSEL(OBSEL), .O8_16(O8_16), 
            .TVO1(TVO1), .\PAD[1] (PAD[1]), .nPCLK(nPCLK), .OV({OV}), 
            .F_AT(F_AT), .OB({OB}), .E_EV(E_EV), .PD_out_0(PD_out_0), 
            .W0(W0), .TAL_LATCH_N_890(TAL_LATCH_N_890), .VINV_LATCH_N_896(VINV_LATCH_N_896), 
            .SC_CNT(SC_CNT), .F_NT(F_NT), .\Hnn[0] (Hnn[0]), .STEP_N_685(STEP_N_685), 
            .TSTEP(TSTEP), .\Hn[2] (Hn[2]), .Clk_enable_44(Clk_enable_44), 
            .PD_out_7(PD_out_7), .PD_out_6(PD_out_6), .PD_out_5(PD_out_5), 
            .PD_out_4(PD_out_4), .PD_out_3(PD_out_3), .PD_out_2(PD_out_2), 
            .PD_out_1(PD_out_1), .\Hn[1] (Hn[1]), .RESCL(RESCL), .PA12_c_12(PA12_c_12), 
            .PA11_c_11(PA11_c_11), .PA10_c_10(PA10_c_10), .PA9_c_9(PA9_c_9), 
            .PA8_c_8(PA8_c_8), .SH2(SH2), .\PAD[7] (PAD[7]), .\PAD[6] (PAD[6]), 
            .\PAD[5] (PAD[5]), .\PAD[4] (PAD[4]), .\PAD[3] (PAD[3]), .\PAD[2] (PAD[2]), 
            .DB_PAR_N_593(DB_PAR_N_593), .PA13_c_13(PA13_c_13), .I1_32(I1_32), 
            .\W7Q[3] (W7Q[3]), .\W7Q[1] (W7Q[1])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(320[9] 355[2])
    
endmodule
//
// Verilog Description of module PIX_MUX
//

module PIX_MUX (BGC2, CLPB_LATCH, Clk, nPCLK, RESCL, \R2DB[1] , 
            n10678, PCLK_c, ZCOL, THO_LATCH, THO, STEP3, TH_MUX, 
            \CGA[3] , \CGA[2] , \CGA[1] , \STEP3[0] , \CGA[0] ) /* synthesis syn_module_defined=1 */ ;
    input [3:0]BGC2;
    input CLPB_LATCH;
    input Clk;
    input nPCLK;
    input RESCL;
    output \R2DB[1] ;
    input n10678;
    input PCLK_c;
    input [4:0]ZCOL;
    output [4:0]THO_LATCH;
    input [4:0]THO;
    output [4:0]STEP3;
    input TH_MUX;
    output \CGA[3] ;
    output \CGA[2] ;
    output \CGA[1] ;
    output \STEP3[0] ;
    output \CGA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [4:0]ZCOLN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1512[10:15])
    
    wire R2DB6_N_1437, OCOL_N_1442;
    wire [3:0]STEP2_3__N_1426;
    
    wire BGC_LATCH, n10479, ZCOL_LATCH, ZCOL_LATCH_N_1440, OCOLN;
    wire [3:0]STEP2;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1513[10:15])
    wire [4:0]THO_LATCH_c;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1512[17:26])
    wire [4:0]STEP3_c;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1512[28:33])
    
    wire n5073;
    
    LUT4 i10533_3_lut_4_lut (.A(ZCOLN[1]), .B(ZCOLN[0]), .C(ZCOLN[4]), 
         .D(R2DB6_N_1437), .Z(OCOL_N_1442)) /* synthesis lut_function=(!(A (C (D))+!A ((C (D))+!B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1516[15:79])
    defparam i10533_3_lut_4_lut.init = 16'h0eee;
    LUT4 mux_25_i4_4_lut (.A(ZCOLN[3]), .B(BGC2[3]), .C(OCOL_N_1442), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1426[3])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1530[25:53])
    defparam mux_25_i4_4_lut.init = 16'haca0;
    LUT4 mux_25_i3_4_lut (.A(ZCOLN[2]), .B(BGC2[2]), .C(OCOL_N_1442), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1426[2])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1530[25:53])
    defparam mux_25_i3_4_lut.init = 16'haca0;
    LUT4 mux_25_i2_4_lut (.A(ZCOLN[1]), .B(BGC2[1]), .C(OCOL_N_1442), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1426[1])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1530[25:53])
    defparam mux_25_i2_4_lut.init = 16'haca0;
    FD1P3AX BGC_LATCH_46 (.D(R2DB6_N_1437), .SP(nPCLK), .CK(Clk), .Q(BGC_LATCH));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam BGC_LATCH_46.GSR = "DISABLED";
    LUT4 i1_4_lut (.A(RESCL), .B(\R2DB[1] ), .C(R2DB6_N_1437), .D(n10678), 
         .Z(n10479)) /* synthesis lut_function=(!(A+!(B+(C (D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam i1_4_lut.init = 16'h5444;
    FD1P3AX ZCOL_LATCH_47 (.D(ZCOL_LATCH_N_1440), .SP(nPCLK), .CK(Clk), 
            .Q(ZCOL_LATCH));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam ZCOL_LATCH_47.GSR = "DISABLED";
    FD1P3AX OCOLN_48 (.D(OCOL_N_1442), .SP(nPCLK), .CK(Clk), .Q(OCOLN));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam OCOLN_48.GSR = "DISABLED";
    FD1P3AX ZCOLN_i0_i0 (.D(ZCOL[0]), .SP(PCLK_c), .CK(Clk), .Q(ZCOLN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam ZCOLN_i0_i0.GSR = "DISABLED";
    FD1P3AX THO_LATCH_i0_i0 (.D(THO[0]), .SP(PCLK_c), .CK(Clk), .Q(THO_LATCH[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam THO_LATCH_i0_i0.GSR = "DISABLED";
    FD1P3AX STEP2_i0_i0 (.D(STEP2_3__N_1426[0]), .SP(nPCLK), .CK(Clk), 
            .Q(STEP2[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP2_i0_i0.GSR = "DISABLED";
    LUT4 ZCOLN_1__I_0_2_lut (.A(ZCOLN[1]), .B(ZCOLN[0]), .Z(ZCOL_LATCH_N_1440)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1516[19:42])
    defparam ZCOLN_1__I_0_2_lut.init = 16'heeee;
    LUT4 mux_25_i1_4_lut (.A(ZCOLN[0]), .B(BGC2[0]), .C(OCOL_N_1442), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1426[0])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1530[25:53])
    defparam mux_25_i1_4_lut.init = 16'haca0;
    FD1S3AX R2DB6_41 (.D(n10479), .CK(Clk), .Q(\R2DB[1] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam R2DB6_41.GSR = "DISABLED";
    FD1P3AX STEP2_i0_i3 (.D(STEP2_3__N_1426[3]), .SP(nPCLK), .CK(Clk), 
            .Q(STEP2[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP2_i0_i3.GSR = "DISABLED";
    FD1P3AX STEP2_i0_i2 (.D(STEP2_3__N_1426[2]), .SP(nPCLK), .CK(Clk), 
            .Q(STEP2[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP2_i0_i2.GSR = "DISABLED";
    FD1P3AX STEP2_i0_i1 (.D(STEP2_3__N_1426[1]), .SP(nPCLK), .CK(Clk), 
            .Q(STEP2[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP2_i0_i1.GSR = "DISABLED";
    FD1P3AX STEP3_i0_i4 (.D(OCOLN), .SP(PCLK_c), .CK(Clk), .Q(STEP3[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP3_i0_i4.GSR = "DISABLED";
    FD1P3AX THO_LATCH_i0_i4 (.D(THO[4]), .SP(PCLK_c), .CK(Clk), .Q(THO_LATCH[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam THO_LATCH_i0_i4.GSR = "DISABLED";
    FD1P3AX THO_LATCH_i0_i3 (.D(THO[3]), .SP(PCLK_c), .CK(Clk), .Q(THO_LATCH_c[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam THO_LATCH_i0_i3.GSR = "DISABLED";
    FD1P3AX THO_LATCH_i0_i2 (.D(THO[2]), .SP(PCLK_c), .CK(Clk), .Q(THO_LATCH_c[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam THO_LATCH_i0_i2.GSR = "DISABLED";
    FD1P3AX THO_LATCH_i0_i1 (.D(THO[1]), .SP(PCLK_c), .CK(Clk), .Q(THO_LATCH_c[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam THO_LATCH_i0_i1.GSR = "DISABLED";
    FD1P3AX ZCOLN_i0_i4 (.D(ZCOL[4]), .SP(PCLK_c), .CK(Clk), .Q(ZCOLN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam ZCOLN_i0_i4.GSR = "DISABLED";
    FD1P3AX ZCOLN_i0_i3 (.D(ZCOL[3]), .SP(PCLK_c), .CK(Clk), .Q(ZCOLN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam ZCOLN_i0_i3.GSR = "DISABLED";
    FD1P3AX ZCOLN_i0_i2 (.D(ZCOL[2]), .SP(PCLK_c), .CK(Clk), .Q(ZCOLN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam ZCOLN_i0_i2.GSR = "DISABLED";
    FD1P3AX ZCOLN_i0_i1 (.D(ZCOL[1]), .SP(PCLK_c), .CK(Clk), .Q(ZCOLN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam ZCOLN_i0_i1.GSR = "DISABLED";
    LUT4 i2422_3_lut (.A(CLPB_LATCH), .B(BGC2[0]), .C(BGC2[1]), .Z(R2DB6_N_1437)) /* synthesis lut_function=(A (B+(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1523[54:73])
    defparam i2422_3_lut.init = 16'ha8a8;
    FD1P3IX STEP3_i0_i1 (.D(STEP2[1]), .SP(PCLK_c), .CD(n5073), .CK(Clk), 
            .Q(STEP3_c[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP3_i0_i1.GSR = "DISABLED";
    FD1P3IX STEP3_i0_i2 (.D(STEP2[2]), .SP(PCLK_c), .CD(n5073), .CK(Clk), 
            .Q(STEP3_c[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP3_i0_i2.GSR = "DISABLED";
    FD1P3IX STEP3_i0_i3 (.D(STEP2[3]), .SP(PCLK_c), .CD(n5073), .CK(Clk), 
            .Q(STEP3_c[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP3_i0_i3.GSR = "DISABLED";
    LUT4 STEP3_4__I_0_49_i4_3_lut (.A(STEP3_c[3]), .B(THO_LATCH_c[3]), .C(TH_MUX), 
         .Z(\CGA[3] )) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1519[19:55])
    defparam STEP3_4__I_0_49_i4_3_lut.init = 16'hcaca;
    LUT4 STEP3_4__I_0_49_i3_3_lut (.A(STEP3_c[2]), .B(THO_LATCH_c[2]), .C(TH_MUX), 
         .Z(\CGA[2] )) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1519[19:55])
    defparam STEP3_4__I_0_49_i3_3_lut.init = 16'hcaca;
    LUT4 STEP3_4__I_0_49_i2_3_lut (.A(STEP3_c[1]), .B(THO_LATCH_c[1]), .C(TH_MUX), 
         .Z(\CGA[1] )) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1519[19:55])
    defparam STEP3_4__I_0_49_i2_3_lut.init = 16'hcaca;
    LUT4 STEP3_4__I_0_49_i1_3_lut (.A(\STEP3[0] ), .B(THO_LATCH[0]), .C(TH_MUX), 
         .Z(\CGA[0] )) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1519[19:55])
    defparam STEP3_4__I_0_49_i1_3_lut.init = 16'hcaca;
    FD1P3IX STEP3_i0_i0 (.D(STEP2[0]), .SP(PCLK_c), .CD(n5073), .CK(Clk), 
            .Q(\STEP3[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP3_i0_i0.GSR = "DISABLED";
    LUT4 i4604_3_lut (.A(PCLK_c), .B(BGC_LATCH), .C(ZCOL_LATCH), .Z(n5073)) /* synthesis lut_function=(!((B+(C))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam i4604_3_lut.init = 16'h0202;
    
endmodule
//
// Verilog Description of module LOCAL_BUS_CONTROL
//

module LOCAL_BUS_CONTROL (Clk, nPCLK, DB_PARR, PCLK_c, DB_PAR_N_593, 
            R7, W7Q, W7, TH_MUX, XRB_N_606, BLNK, PA11_c_11, PA12_c_12, 
            PA8_c_8, PA13_c_13, PA9_c_9, PA10_c_10, \Hn[0] , ALE_c, 
            TSTEP, \Hnn[0] , PD_DIR_c, RC, Clk_enable_234, \W7Q[1] , 
            nRD_c, nWR_c, ALE_N_601) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    output DB_PARR;
    input PCLK_c;
    output DB_PAR_N_593;
    input R7;
    output [4:0]W7Q;
    input W7;
    output TH_MUX;
    output XRB_N_606;
    input BLNK;
    input PA11_c_11;
    input PA12_c_12;
    input PA8_c_8;
    input PA13_c_13;
    input PA9_c_9;
    input PA10_c_10;
    input \Hn[0] ;
    output ALE_c;
    output TSTEP;
    input \Hnn[0] ;
    output PD_DIR_c;
    input RC;
    output Clk_enable_234;
    output \W7Q[1] ;
    output nRD_c;
    output nWR_c;
    output ALE_N_601;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [4:0]R7Q;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(894[10:13])
    
    wire Clk_enable_33, W7_FF, Clk_enable_8, n4991, n4990, W7Q_3__N_580;
    wire [4:0]W7Q_c;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(895[10:13])
    
    wire W7Q_2__N_583, BLNK_LATCH, n12, R7Q_3__N_568, R7_FF, R7Q_2__N_571, 
        n11457;
    
    FD1P3AX R7Q_i1 (.D(R7Q[0]), .SP(nPCLK), .CK(Clk), .Q(R7Q[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam R7Q_i1.GSR = "DISABLED";
    FD1P3AX DB_PARR_46 (.D(DB_PAR_N_593), .SP(PCLK_c), .CK(Clk), .Q(DB_PARR));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam DB_PARR_46.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(R7), .B(R7Q[3]), .Z(Clk_enable_33)) /* synthesis lut_function=(A+!(B)) */ ;
    defparam i1_2_lut.init = 16'hbbbb;
    FD1P3AX W7_FF_69 (.D(W7Q[3]), .SP(Clk_enable_8), .CK(Clk), .Q(W7_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam W7_FF_69.GSR = "DISABLED";
    LUT4 i4522_2_lut (.A(PCLK_c), .B(W7), .Z(n4991)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam i4522_2_lut.init = 16'h8888;
    LUT4 i4521_2_lut (.A(PCLK_c), .B(R7), .Z(n4990)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam i4521_2_lut.init = 16'h8888;
    LUT4 W7Q_3__I_0_79_1_lut (.A(W7Q[3]), .Z(W7Q_3__N_580)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(917[39:46])
    defparam W7Q_3__I_0_79_1_lut.init = 16'h5555;
    LUT4 W7Q_2__I_0_1_lut (.A(W7Q_c[2]), .Z(W7Q_2__N_583)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(906[50:57])
    defparam W7Q_2__I_0_1_lut.init = 16'h5555;
    LUT4 R7_N_577_I_0_2_lut (.A(R7), .B(TH_MUX), .Z(XRB_N_606)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(905[15:31])
    defparam R7_N_577_I_0_2_lut.init = 16'hdddd;
    FD1P3AX BLNK_LATCH_70 (.D(BLNK), .SP(PCLK_c), .CK(Clk), .Q(BLNK_LATCH));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam BLNK_LATCH_70.GSR = "DISABLED";
    LUT4 i6_4_lut (.A(PA11_c_11), .B(n12), .C(PA12_c_12), .D(PA8_c_8), 
         .Z(TH_MUX)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(899[17:85])
    defparam i6_4_lut.init = 16'h8000;
    LUT4 i5_4_lut (.A(PA13_c_13), .B(PA9_c_9), .C(PA10_c_10), .D(BLNK_LATCH), 
         .Z(n12)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(899[17:85])
    defparam i5_4_lut.init = 16'h8000;
    LUT4 i1_2_lut_adj_453 (.A(W7), .B(W7Q[3]), .Z(Clk_enable_8)) /* synthesis lut_function=(A+!(B)) */ ;
    defparam i1_2_lut_adj_453.init = 16'hbbbb;
    LUT4 R7Q_3__I_0_1_lut (.A(R7Q[3]), .Z(R7Q_3__N_568)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(916[39:46])
    defparam R7Q_3__I_0_1_lut.init = 16'h5555;
    FD1P3AX R7_FF_68 (.D(R7Q[3]), .SP(Clk_enable_33), .CK(Clk), .Q(R7_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam R7_FF_68.GSR = "DISABLED";
    LUT4 R7Q_2__I_0_1_lut (.A(R7Q[2]), .Z(R7Q_2__N_571)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(906[26:33])
    defparam R7Q_2__I_0_1_lut.init = 16'h5555;
    LUT4 i10656_3_lut_4_lut_4_lut (.A(PCLK_c), .B(\Hn[0] ), .C(n11457), 
         .D(BLNK), .Z(ALE_c)) /* synthesis lut_function=(!(A (B (C)+!B (C (D)))+!A (C))) */ ;
    defparam i10656_3_lut_4_lut_4_lut.init = 16'h0f2f;
    LUT4 W7Q_4__bdd_4_lut (.A(W7Q_c[4]), .B(R7Q[4]), .C(R7Q[2]), .D(W7Q_c[2]), 
         .Z(n11457)) /* synthesis lut_function=(A (B+!(C))+!A !(B (D)+!B (C+(D)))) */ ;
    defparam W7Q_4__bdd_4_lut.init = 16'h8acf;
    LUT4 PD_RB_I_0_82_2_lut_3_lut (.A(R7Q[4]), .B(R7Q[2]), .C(DB_PARR), 
         .Z(TSTEP)) /* synthesis lut_function=(A ((C)+!B)+!A (C)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(901[18:38])
    defparam PD_RB_I_0_82_2_lut_3_lut.init = 16'hf2f2;
    LUT4 PD_RB_I_0_3_lut_4_lut (.A(R7Q[4]), .B(R7Q[2]), .C(BLNK), .D(\Hnn[0] ), 
         .Z(PD_DIR_c)) /* synthesis lut_function=(!(A (B (C+!(D)))+!A (C+!(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(901[18:38])
    defparam PD_RB_I_0_3_lut_4_lut.init = 16'h2f22;
    LUT4 i1_2_lut_3_lut (.A(R7Q[4]), .B(R7Q[2]), .C(RC), .Z(Clk_enable_234)) /* synthesis lut_function=(A ((C)+!B)+!A (C)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(901[18:38])
    defparam i1_2_lut_3_lut.init = 16'hf2f2;
    FD1P3AX W7Q_i4 (.D(W7Q_3__N_580), .SP(PCLK_c), .CK(Clk), .Q(W7Q_c[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam W7Q_i4.GSR = "DISABLED";
    FD1P3AX W7Q_i3 (.D(W7Q_2__N_583), .SP(nPCLK), .CK(Clk), .Q(W7Q[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam W7Q_i3.GSR = "DISABLED";
    FD1P3AX W7Q_i2 (.D(\W7Q[1] ), .SP(PCLK_c), .CK(Clk), .Q(W7Q_c[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam W7Q_i2.GSR = "DISABLED";
    FD1P3AX W7Q_i1 (.D(W7Q_c[0]), .SP(nPCLK), .CK(Clk), .Q(\W7Q[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam W7Q_i1.GSR = "DISABLED";
    FD1P3AX R7Q_i4 (.D(R7Q_3__N_568), .SP(PCLK_c), .CK(Clk), .Q(R7Q[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam R7Q_i4.GSR = "DISABLED";
    FD1P3AX R7Q_i3 (.D(R7Q_2__N_571), .SP(nPCLK), .CK(Clk), .Q(R7Q[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam R7Q_i3.GSR = "DISABLED";
    FD1P3AX R7Q_i2 (.D(R7Q[1]), .SP(PCLK_c), .CK(Clk), .Q(R7Q[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam R7Q_i2.GSR = "DISABLED";
    LUT4 i10473_2_lut (.A(W7Q[3]), .B(\W7Q[1] ), .Z(DB_PAR_N_593)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(902[17:38])
    defparam i10473_2_lut.init = 16'h1111;
    LUT4 nRD_I_0_1_lut (.A(PD_DIR_c), .Z(nRD_c)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(904[14:42])
    defparam nRD_I_0_1_lut.init = 16'h5555;
    FD1P3IX W7Q_i0 (.D(W7_FF), .SP(PCLK_c), .CD(n4991), .CK(Clk), .Q(W7Q_c[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam W7Q_i0.GSR = "DISABLED";
    FD1P3IX R7Q_i0 (.D(R7_FF), .SP(PCLK_c), .CD(n4990), .CK(Clk), .Q(R7Q[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam R7Q_i0.GSR = "DISABLED";
    LUT4 DB_PAR_N_593_I_0_2_lut_3_lut (.A(W7Q[3]), .B(\W7Q[1] ), .C(TH_MUX), 
         .Z(nWR_c)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(903[14:30])
    defparam DB_PAR_N_593_I_0_2_lut_3_lut.init = 16'hfefe;
    LUT4 nPCLK_I_0_2_lut_2_lut (.A(PCLK_c), .B(\Hn[0] ), .Z(ALE_N_601)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(906[65:76])
    defparam nPCLK_I_0_2_lut_2_lut.init = 16'hdddd;
    
endmodule
//
// Verilog Description of module PUR
// module not written out since it is a black-box. 
//

//
// Verilog Description of module PALETTE_SWITCH
//

module PALETTE_SWITCH (PALSEL, GND_net, VSYNC, P_BUTTON_N_7, P_BUTTON_c) /* synthesis syn_module_defined=1 */ ;
    output [2:0]PALSEL;
    input GND_net;
    input VSYNC;
    input P_BUTTON_N_7;
    input P_BUTTON_c;
    
    wire TICK /* synthesis SET_AS_NETWORK=\PALSEL_2__I_0/TICK, is_clock=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1705[6:10])
    wire VSYNC /* synthesis SET_AS_NETWORK=VSYNC, is_clock=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(125[6:11])
    wire [2:0]n17;
    
    wire n10164;
    wire [5:0]V_DIV;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1703[10:15])
    wire [5:0]n29;
    
    wire n10165, n10163, FDET, n10, n10136;
    
    FD1S3AX PALSEL_669__i2 (.D(n17[2]), .CK(TICK), .Q(PALSEL[2]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1713[56:69])
    defparam PALSEL_669__i2.GSR = "DISABLED";
    FD1S3AX PALSEL_669__i1 (.D(n17[1]), .CK(TICK), .Q(PALSEL[1]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1713[56:69])
    defparam PALSEL_669__i1.GSR = "DISABLED";
    CCU2D V_DIV_668_add_4_5 (.A0(V_DIV[3]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(V_DIV[4]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n10164), .COUT(n10165), .S0(n29[3]), .S1(n29[4]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam V_DIV_668_add_4_5.INIT0 = 16'hfaaa;
    defparam V_DIV_668_add_4_5.INIT1 = 16'hfaaa;
    defparam V_DIV_668_add_4_5.INJECT1_0 = "NO";
    defparam V_DIV_668_add_4_5.INJECT1_1 = "NO";
    CCU2D V_DIV_668_add_4_3 (.A0(V_DIV[1]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(V_DIV[2]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n10163), .COUT(n10164), .S0(n29[1]), .S1(n29[2]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam V_DIV_668_add_4_3.INIT0 = 16'hfaaa;
    defparam V_DIV_668_add_4_3.INIT1 = 16'hfaaa;
    defparam V_DIV_668_add_4_3.INJECT1_0 = "NO";
    defparam V_DIV_668_add_4_3.INJECT1_1 = "NO";
    CCU2D V_DIV_668_add_4_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(V_DIV[0]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .COUT(n10163), .S1(n29[0]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam V_DIV_668_add_4_1.INIT0 = 16'hF000;
    defparam V_DIV_668_add_4_1.INIT1 = 16'h0555;
    defparam V_DIV_668_add_4_1.INJECT1_0 = "NO";
    defparam V_DIV_668_add_4_1.INJECT1_1 = "NO";
    FD1S3AX V_DIV_668__i0 (.D(n29[0]), .CK(VSYNC), .Q(V_DIV[0])) /* synthesis syn_use_carry_chain=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam V_DIV_668__i0.GSR = "DISABLED";
    FD1S3AX PALSEL_669__i0 (.D(n17[0]), .CK(TICK), .Q(PALSEL[0]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1713[56:69])
    defparam PALSEL_669__i0.GSR = "DISABLED";
    FD1S3AX V_DIV_668__i5 (.D(n29[5]), .CK(VSYNC), .Q(V_DIV[5])) /* synthesis syn_use_carry_chain=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam V_DIV_668__i5.GSR = "DISABLED";
    FD1S3AX V_DIV_668__i4 (.D(n29[4]), .CK(VSYNC), .Q(V_DIV[4])) /* synthesis syn_use_carry_chain=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam V_DIV_668__i4.GSR = "DISABLED";
    FD1S3AX V_DIV_668__i3 (.D(n29[3]), .CK(VSYNC), .Q(V_DIV[3])) /* synthesis syn_use_carry_chain=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam V_DIV_668__i3.GSR = "DISABLED";
    FD1S3AX V_DIV_668__i2 (.D(n29[2]), .CK(VSYNC), .Q(V_DIV[2])) /* synthesis syn_use_carry_chain=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam V_DIV_668__i2.GSR = "DISABLED";
    FD1S3AX V_DIV_668__i1 (.D(n29[1]), .CK(VSYNC), .Q(V_DIV[1])) /* synthesis syn_use_carry_chain=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam V_DIV_668__i1.GSR = "DISABLED";
    FD1S3AX FDET_14 (.D(P_BUTTON_N_7), .CK(TICK), .Q(FDET)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=16, LSE_RCOL=2, LSE_LLINE=455, LSE_RLINE=459 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1711[8] 1714[27])
    defparam FDET_14.GSR = "DISABLED";
    LUT4 i5_3_lut (.A(V_DIV[0]), .B(n10), .C(V_DIV[1]), .Z(TICK)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1706[15:22])
    defparam i5_3_lut.init = 16'h8080;
    LUT4 i4_4_lut (.A(V_DIV[3]), .B(V_DIV[4]), .C(V_DIV[2]), .D(V_DIV[5]), 
         .Z(n10)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1706[15:22])
    defparam i4_4_lut.init = 16'h8000;
    LUT4 i9731_3_lut (.A(PALSEL[2]), .B(PALSEL[1]), .C(n10136), .Z(n17[2])) /* synthesis lut_function=(!(A (B (C))+!A !(B (C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1713[56:69])
    defparam i9731_3_lut.init = 16'h6a6a;
    LUT4 i9718_2_lut_3_lut (.A(P_BUTTON_c), .B(FDET), .C(PALSEL[0]), .Z(n10136)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1713[28:44])
    defparam i9718_2_lut_3_lut.init = 16'h8080;
    LUT4 i9716_2_lut_3_lut (.A(P_BUTTON_c), .B(FDET), .C(PALSEL[0]), .Z(n17[0])) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1713[28:44])
    defparam i9716_2_lut_3_lut.init = 16'h7878;
    LUT4 i9724_2_lut_4_lut (.A(PALSEL[1]), .B(P_BUTTON_c), .C(FDET), .D(PALSEL[0]), 
         .Z(n17[1])) /* synthesis lut_function=(!(A (B (C (D)))+!A !(B (C (D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1713[56:69])
    defparam i9724_2_lut_4_lut.init = 16'h6aaa;
    CCU2D V_DIV_668_add_4_7 (.A0(V_DIV[5]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n10165), .S0(n29[5]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam V_DIV_668_add_4_7.INIT0 = 16'hfaaa;
    defparam V_DIV_668_add_4_7.INIT1 = 16'h0000;
    defparam V_DIV_668_add_4_7.INJECT1_0 = "NO";
    defparam V_DIV_668_add_4_7.INJECT1_1 = "NO";
    
endmodule
//
// Verilog Description of module BG_COLOR
//

module BG_COLOR (TVO1, PCLK_c, \Hnn[0] , Clk, nPCLK, PD_SR, PD_out_0, 
            NFO_OUT, STEP_N_685, SRLOAD, Clk_enable_43, RC, \DBIN[2] , 
            \DBIN[1] , \DBIN[0] , CLPB_LATCH, nCLPB_N_130, F_AT, \THO[1] , 
            PD_out_7, PD_out_6, PD_out_5, PD_out_4, PD_out_3, PD_out_2, 
            PD_out_1, BGC2, PD_SR_N_683) /* synthesis syn_module_defined=1 */ ;
    input TVO1;
    input PCLK_c;
    input \Hnn[0] ;
    input Clk;
    input nPCLK;
    input PD_SR;
    input PD_out_0;
    input NFO_OUT;
    input STEP_N_685;
    input SRLOAD;
    input Clk_enable_43;
    input RC;
    input \DBIN[2] ;
    input \DBIN[1] ;
    input \DBIN[0] ;
    output CLPB_LATCH;
    input nCLPB_N_130;
    input F_AT;
    input \THO[1] ;
    input PD_out_7;
    input PD_out_6;
    input PD_out_5;
    input PD_out_4;
    input PD_out_3;
    input PD_out_2;
    input PD_out_1;
    output [3:0]BGC2;
    output PD_SR_N_683;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]SR0;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(974[10:13])
    wire [2:0]FH;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(953[10:12])
    
    wire n11664;
    wire [7:0]SR2;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(974[20:23])
    
    wire n11763, n11601, n11602, n11603;
    wire [7:0]SR3;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(974[25:28])
    
    wire n11773, n11772, n11775, n11776, F_AT_LATCH, PD_SEL;
    wire [1:0]ATR;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(959[10:13])
    wire [1:0]ATRO;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(960[10:14])
    wire [3:0]BGC1;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(951[10:14])
    wire [3:0]BGC_POS;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(982[11:18])
    wire [7:0]PDTA;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(958[10:14])
    
    wire n11665, n11662, n10726, THO1R;
    wire [7:0]PDAT;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(957[10:14])
    wire [1:0]ATSEL_1__N_676;
    
    wire Clk_enable_219, n11661, n11660, n11634, n11633;
    wire [7:0]SR1;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(974[15:18])
    
    wire n11755, n11756, n11759, n11760, n11762, n11777, n11774, 
        n11764, n11761, STEP2, n11757, n11754, n11753, n11752, 
        n11635, n11663;
    wire [7:0]QP;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QP_adj_1919;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    LUT4 SR0_2__bdd_3_lut (.A(SR0[6]), .B(FH[0]), .C(SR0[7]), .Z(n11664)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR0_2__bdd_3_lut.init = 16'hb8b8;
    LUT4 SR2_2__bdd_3_lut (.A(SR2[6]), .B(FH[0]), .C(SR2[7]), .Z(n11763)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR2_2__bdd_3_lut.init = 16'hb8b8;
    PFUMX i10906 (.BLUT(n11601), .ALUT(n11602), .C0(TVO1), .Z(n11603));
    LUT4 FH_2__bdd_3_lut (.A(SR3[4]), .B(FH[0]), .C(SR3[5]), .Z(n11773)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam FH_2__bdd_3_lut.init = 16'hb8b8;
    LUT4 FH_2__bdd_3_lut_11002 (.A(SR3[0]), .B(SR3[1]), .C(FH[0]), .Z(n11772)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;
    defparam FH_2__bdd_3_lut_11002.init = 16'hacac;
    LUT4 SR3_2__bdd_3_lut_11005 (.A(SR3[2]), .B(SR3[3]), .C(FH[0]), .Z(n11775)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;
    defparam SR3_2__bdd_3_lut_11005.init = 16'hacac;
    LUT4 SR3_2__bdd_3_lut (.A(SR3[6]), .B(FH[0]), .C(SR3[7]), .Z(n11776)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR3_2__bdd_3_lut.init = 16'hb8b8;
    LUT4 PD_SR_N_683_I_0_129_2_lut_3_lut (.A(PCLK_c), .B(\Hnn[0] ), .C(F_AT_LATCH), 
         .Z(PD_SEL)) /* synthesis lut_function=(!(A+!(B (C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(964[17:42])
    defparam PD_SR_N_683_I_0_129_2_lut_3_lut.init = 16'h4040;
    FD1P3AX ATR_i0_i0 (.D(ATRO[0]), .SP(PCLK_c), .CK(Clk), .Q(ATR[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam ATR_i0_i0.GSR = "DISABLED";
    FD1P3AX BGC1_i0_i0 (.D(BGC_POS[0]), .SP(nPCLK), .CK(Clk), .Q(BGC1[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC1_i0_i0.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i0 (.D(PD_out_0), .SP(PD_SR), .CK(Clk), .Q(PDTA[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i0.GSR = "DISABLED";
    L6MUX21 i10940 (.D0(n11665), .D1(n11662), .SD(FH[1]), .Z(BGC_POS[0]));
    LUT4 i10546_2_lut_3_lut_4_lut (.A(PCLK_c), .B(NFO_OUT), .C(STEP_N_685), 
         .D(SRLOAD), .Z(n10726)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;
    defparam i10546_2_lut_3_lut_4_lut.init = 16'h0001;
    LUT4 i1_2_lut_3_lut (.A(TVO1), .B(THO1R), .C(PDAT[5]), .Z(ATSEL_1__N_676[1])) /* synthesis lut_function=(!((B+!(C))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(971[76:103])
    defparam i1_2_lut_3_lut.init = 16'h2020;
    LUT4 i1_2_lut_3_lut_adj_452 (.A(TVO1), .B(THO1R), .C(PDAT[4]), .Z(ATSEL_1__N_676[0])) /* synthesis lut_function=(!((B+!(C))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(971[76:103])
    defparam i1_2_lut_3_lut_adj_452.init = 16'h2020;
    LUT4 i1_2_lut_3_lut_4_lut (.A(PCLK_c), .B(NFO_OUT), .C(STEP_N_685), 
         .D(SRLOAD), .Z(Clk_enable_219)) /* synthesis lut_function=(A (D)+!A (B (D)+!B ((D)+!C))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hff01;
    LUT4 FH_2__bdd_3_lut_10977 (.A(SR0[4]), .B(FH[0]), .C(SR0[5]), .Z(n11661)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam FH_2__bdd_3_lut_10977.init = 16'hb8b8;
    LUT4 FH_2__bdd_3_lut_10934 (.A(SR0[0]), .B(SR0[1]), .C(FH[0]), .Z(n11660)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;
    defparam FH_2__bdd_3_lut_10934.init = 16'hacac;
    FD1P3IX FH__i2 (.D(\DBIN[2] ), .SP(Clk_enable_43), .CD(RC), .CK(Clk), 
            .Q(FH[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam FH__i2.GSR = "DISABLED";
    FD1P3IX FH__i1 (.D(\DBIN[1] ), .SP(Clk_enable_43), .CD(RC), .CK(Clk), 
            .Q(FH[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam FH__i1.GSR = "DISABLED";
    LUT4 i4523_4_lut_then_3_lut (.A(SRLOAD), .B(THO1R), .C(PDAT[6]), .Z(n11634)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam i4523_4_lut_then_3_lut.init = 16'h8080;
    LUT4 i4523_4_lut_else_3_lut (.A(SRLOAD), .B(THO1R), .C(PDAT[2]), .D(PDAT[0]), 
         .Z(n11633)) /* synthesis lut_function=(A (B (C)+!B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam i4523_4_lut_else_3_lut.init = 16'ha280;
    FD1P3IX FH__i0 (.D(\DBIN[0] ), .SP(Clk_enable_43), .CD(RC), .CK(Clk), 
            .Q(FH[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam FH__i0.GSR = "DISABLED";
    LUT4 SR1_2__bdd_3_lut_10981 (.A(SR1[2]), .B(SR1[3]), .C(FH[0]), .Z(n11755)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;
    defparam SR1_2__bdd_3_lut_10981.init = 16'hacac;
    LUT4 SR1_2__bdd_3_lut (.A(SR1[6]), .B(FH[0]), .C(SR1[7]), .Z(n11756)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR1_2__bdd_3_lut.init = 16'hb8b8;
    FD1P3AX CLPB_LATCH_111 (.D(nCLPB_N_130), .SP(PCLK_c), .CK(Clk), .Q(CLPB_LATCH));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam CLPB_LATCH_111.GSR = "DISABLED";
    FD1P3AX F_AT_LATCH_112 (.D(F_AT), .SP(PCLK_c), .CK(Clk), .Q(F_AT_LATCH));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam F_AT_LATCH_112.GSR = "DISABLED";
    FD1P3JX ATRO_i0_i1 (.D(ATSEL_1__N_676[1]), .SP(SRLOAD), .PD(n11603), 
            .CK(Clk), .Q(ATRO[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam ATRO_i0_i1.GSR = "DISABLED";
    FD1P3AX THO1R_113 (.D(\THO[1] ), .SP(PCLK_c), .CK(Clk), .Q(THO1R));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam THO1R_113.GSR = "DISABLED";
    LUT4 FH_2__bdd_3_lut_10987 (.A(SR2[0]), .B(SR2[1]), .C(FH[0]), .Z(n11759)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;
    defparam FH_2__bdd_3_lut_10987.init = 16'hacac;
    FD1P3AX PDTA_i0_i7 (.D(PD_out_7), .SP(PD_SR), .CK(Clk), .Q(PDTA[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i7.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i6 (.D(PD_out_6), .SP(PD_SR), .CK(Clk), .Q(PDTA[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i6.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i5 (.D(PD_out_5), .SP(PD_SR), .CK(Clk), .Q(PDTA[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i5.GSR = "DISABLED";
    LUT4 FH_2__bdd_3_lut_11001 (.A(SR2[4]), .B(FH[0]), .C(SR2[5]), .Z(n11760)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam FH_2__bdd_3_lut_11001.init = 16'hb8b8;
    FD1P3AX PDTA_i0_i4 (.D(PD_out_4), .SP(PD_SR), .CK(Clk), .Q(PDTA[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i4.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i3 (.D(PD_out_3), .SP(PD_SR), .CK(Clk), .Q(PDTA[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i3.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i2 (.D(PD_out_2), .SP(PD_SR), .CK(Clk), .Q(PDTA[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i2.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i1 (.D(PD_out_1), .SP(PD_SR), .CK(Clk), .Q(PDTA[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i1.GSR = "DISABLED";
    FD1P3AX BGC1_i0_i3 (.D(BGC_POS[3]), .SP(nPCLK), .CK(Clk), .Q(BGC1[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC1_i0_i3.GSR = "DISABLED";
    FD1P3AX BGC1_i0_i2 (.D(BGC_POS[2]), .SP(nPCLK), .CK(Clk), .Q(BGC1[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC1_i0_i2.GSR = "DISABLED";
    FD1P3AX BGC1_i0_i1 (.D(BGC_POS[1]), .SP(nPCLK), .CK(Clk), .Q(BGC1[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC1_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_i0_i1 (.D(ATRO[1]), .SP(PCLK_c), .CK(Clk), .Q(ATR[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam ATR_i0_i1.GSR = "DISABLED";
    FD1P3AX BGC2_i0_i0 (.D(BGC1[0]), .SP(PCLK_c), .CK(Clk), .Q(BGC2[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC2_i0_i0.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i0 (.D(PD_out_0), .SP(PD_SEL), .CK(Clk), .Q(PDAT[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i0.GSR = "DISABLED";
    LUT4 SR2_2__bdd_3_lut_10990 (.A(SR2[2]), .B(SR2[3]), .C(FH[0]), .Z(n11762)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;
    defparam SR2_2__bdd_3_lut_10990.init = 16'hacac;
    L6MUX21 i11008 (.D0(n11777), .D1(n11774), .SD(FH[1]), .Z(BGC_POS[3]));
    PFUMX i11006 (.BLUT(n11776), .ALUT(n11775), .C0(FH[2]), .Z(n11777));
    PFUMX i11003 (.BLUT(n11773), .ALUT(n11772), .C0(FH[2]), .Z(n11774));
    L6MUX21 i10993 (.D0(n11764), .D1(n11761), .SD(FH[1]), .Z(BGC_POS[2]));
    PFUMX i10991 (.BLUT(n11763), .ALUT(n11762), .C0(FH[2]), .Z(n11764));
    PFUMX i10988 (.BLUT(n11760), .ALUT(n11759), .C0(FH[2]), .Z(n11761));
    LUT4 i10480_2_lut (.A(PCLK_c), .B(NFO_OUT), .Z(STEP2)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i10480_2_lut.init = 16'h1111;
    FD1P3AX BGC2_i0_i1 (.D(BGC1[1]), .SP(PCLK_c), .CK(Clk), .Q(BGC2[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC2_i0_i1.GSR = "DISABLED";
    L6MUX21 i10984 (.D0(n11757), .D1(n11754), .SD(FH[1]), .Z(BGC_POS[1]));
    FD1P3AX BGC2_i0_i2 (.D(BGC1[2]), .SP(PCLK_c), .CK(Clk), .Q(BGC2[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC2_i0_i2.GSR = "DISABLED";
    FD1P3AX BGC2_i0_i3 (.D(BGC1[3]), .SP(PCLK_c), .CK(Clk), .Q(BGC2[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC2_i0_i3.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i1 (.D(PD_out_1), .SP(PD_SEL), .CK(Clk), .Q(PDAT[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i1.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i2 (.D(PD_out_2), .SP(PD_SEL), .CK(Clk), .Q(PDAT[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i2.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i3 (.D(PD_out_3), .SP(PD_SEL), .CK(Clk), .Q(PDAT[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i3.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i4 (.D(PD_out_4), .SP(PD_SEL), .CK(Clk), .Q(PDAT[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i4.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i5 (.D(PD_out_5), .SP(PD_SEL), .CK(Clk), .Q(PDAT[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i5.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i6 (.D(PD_out_6), .SP(PD_SEL), .CK(Clk), .Q(PDAT[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i6.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i7 (.D(PD_out_7), .SP(PD_SEL), .CK(Clk), .Q(PDAT[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i7.GSR = "DISABLED";
    PFUMX i10982 (.BLUT(n11756), .ALUT(n11755), .C0(FH[2]), .Z(n11757));
    PFUMX i10979 (.BLUT(n11753), .ALUT(n11752), .C0(FH[2]), .Z(n11754));
    PFUMX i10927 (.BLUT(n11633), .ALUT(n11634), .C0(TVO1), .Z(n11635));
    PFUMX i10938 (.BLUT(n11664), .ALUT(n11663), .C0(FH[2]), .Z(n11665));
    LUT4 i4616_4_lut_then_3_lut (.A(SRLOAD), .B(THO1R), .C(PDAT[7]), .Z(n11602)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam i4616_4_lut_then_3_lut.init = 16'h8080;
    FD1P3JX ATRO_i0_i0 (.D(ATSEL_1__N_676[0]), .SP(SRLOAD), .PD(n11635), 
            .CK(Clk), .Q(ATRO[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam ATRO_i0_i0.GSR = "DISABLED";
    LUT4 FH_2__bdd_3_lut_10978 (.A(SR1[0]), .B(SR1[1]), .C(FH[0]), .Z(n11752)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;
    defparam FH_2__bdd_3_lut_10978.init = 16'hacac;
    LUT4 nPCLK_I_0_130_2_lut_2_lut (.A(PCLK_c), .B(\Hnn[0] ), .Z(PD_SR_N_683)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(965[17:29])
    defparam nPCLK_I_0_130_2_lut_2_lut.init = 16'h4444;
    LUT4 SR0_2__bdd_3_lut_10937 (.A(SR0[2]), .B(SR0[3]), .C(FH[0]), .Z(n11663)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;
    defparam SR0_2__bdd_3_lut_10937.init = 16'hacac;
    LUT4 i4616_4_lut_else_3_lut (.A(SRLOAD), .B(THO1R), .C(PDAT[3]), .D(PDAT[1]), 
         .Z(n11601)) /* synthesis lut_function=(A (B (C)+!B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam i4616_4_lut_else_3_lut.init = 16'ha280;
    LUT4 FH_2__bdd_3_lut_10986 (.A(SR1[4]), .B(FH[0]), .C(SR1[5]), .Z(n11753)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam FH_2__bdd_3_lut_10986.init = 16'hb8b8;
    PFUMX i10935 (.BLUT(n11661), .ALUT(n11660), .C0(FH[2]), .Z(n11662));
    SHIFTREG_U105 SREG_TB (.PD_out_1(PD_out_1), .SRLOAD(SRLOAD), .PD_out_2(PD_out_2), 
            .PD_out_3(PD_out_3), .PD_out_4(PD_out_4), .PD_out_5(PD_out_5), 
            .PD_out_6(PD_out_6), .PD_out_7(PD_out_7), .Clk(Clk), .PCLK_c(PCLK_c), 
            .QTB(QP[7]), .Clk_enable_219(Clk_enable_219), .n10726(n10726), 
            .PD_out_0(PD_out_0)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(977[10:81])
    SHIFTREG_U106 SREG_TA (.PDTA({PDTA}), .SRLOAD(SRLOAD), .Clk(Clk), 
            .PCLK_c(PCLK_c), .Clk_enable_219(Clk_enable_219), .QTA(QP_adj_1919[7]), 
            .n10726(n10726)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(976[10:81])
    SHIFTREG_U107 SREG_FS3 (.SR3({SR3}), .Clk(Clk), .PCLK_c(PCLK_c), .STEP2(STEP2), 
            .\ATR[1] (ATR[1])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(981[10:81])
    SHIFTREG_U108 SREG_FS2 (.SR2({SR2}), .Clk(Clk), .PCLK_c(PCLK_c), .STEP2(STEP2), 
            .\ATR[0] (ATR[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(980[10:81])
    SHIFTREG_U109 SREG_FS1 (.SR1({SR1}), .Clk(Clk), .PCLK_c(PCLK_c), .STEP2(STEP2), 
            .QTB(QP[7])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(979[10:81])
    SHIFTREG_U110 SREG_FS0 (.SR0({SR0}), .Clk(Clk), .PCLK_c(PCLK_c), .STEP2(STEP2), 
            .QTA(QP_adj_1919[7])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(978[10:81])
    
endmodule
//
// Verilog Description of module SHIFTREG_U105
//

module SHIFTREG_U105 (PD_out_1, SRLOAD, PD_out_2, PD_out_3, PD_out_4, 
            PD_out_5, PD_out_6, PD_out_7, Clk, PCLK_c, QTB, Clk_enable_219, 
            n10726, PD_out_0) /* synthesis syn_module_defined=1 */ ;
    input PD_out_1;
    input SRLOAD;
    input PD_out_2;
    input PD_out_3;
    input PD_out_4;
    input PD_out_5;
    input PD_out_6;
    input PD_out_7;
    input Clk;
    input PCLK_c;
    output QTB;
    input Clk_enable_219;
    input n10726;
    input PD_out_0;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QP;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3268, n3270, n3272, n3274, n3276, n3278, n3280;
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    LUT4 i2816_3_lut (.A(QP[0]), .B(PD_out_1), .C(SRLOAD), .Z(n3268)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i2816_3_lut.init = 16'hcaca;
    LUT4 i2818_3_lut (.A(QP[1]), .B(PD_out_2), .C(SRLOAD), .Z(n3270)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i2818_3_lut.init = 16'hcaca;
    LUT4 i2820_3_lut (.A(QP[2]), .B(PD_out_3), .C(SRLOAD), .Z(n3272)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i2820_3_lut.init = 16'hcaca;
    LUT4 i2822_3_lut (.A(QP[3]), .B(PD_out_4), .C(SRLOAD), .Z(n3274)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i2822_3_lut.init = 16'hcaca;
    LUT4 i2824_3_lut (.A(QP[4]), .B(PD_out_5), .C(SRLOAD), .Z(n3276)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i2824_3_lut.init = 16'hcaca;
    LUT4 i2826_3_lut (.A(QP[5]), .B(PD_out_6), .C(SRLOAD), .Z(n3278)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i2826_3_lut.init = 16'hcaca;
    LUT4 i2828_3_lut (.A(QP[6]), .B(PD_out_7), .C(SRLOAD), .Z(n3280)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i2828_3_lut.init = 16'hcaca;
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(PCLK_c), .CK(Clk), .Q(QP[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(PCLK_c), .CK(Clk), .Q(QP[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(PCLK_c), .CK(Clk), .Q(QP[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(PCLK_c), .CK(Clk), .Q(QP[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(PCLK_c), .CK(Clk), .Q(QP[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(PCLK_c), .CK(Clk), .Q(QP[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(PCLK_c), .CK(Clk), .Q(QP[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(PCLK_c), .CK(Clk), .Q(QTB)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3268), .SP(Clk_enable_219), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3270), .SP(Clk_enable_219), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3272), .SP(Clk_enable_219), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3274), .SP(Clk_enable_219), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3276), .SP(Clk_enable_219), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3278), .SP(Clk_enable_219), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3280), .SP(Clk_enable_219), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3JX QS_IN_i0_i0 (.D(PD_out_0), .SP(Clk_enable_219), .PD(n10726), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U106
//

module SHIFTREG_U106 (PDTA, SRLOAD, Clk, PCLK_c, Clk_enable_219, QTA, 
            n10726) /* synthesis syn_module_defined=1 */ ;
    input [7:0]PDTA;
    input SRLOAD;
    input Clk;
    input PCLK_c;
    input Clk_enable_219;
    output QTA;
    input n10726;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QP;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3282, n3284, n3286, n3288, n3290, n3292, n3294;
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    LUT4 i2830_3_lut (.A(QP[0]), .B(PDTA[1]), .C(SRLOAD), .Z(n3282)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i2830_3_lut.init = 16'hcaca;
    LUT4 i2832_3_lut (.A(QP[1]), .B(PDTA[2]), .C(SRLOAD), .Z(n3284)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i2832_3_lut.init = 16'hcaca;
    LUT4 i2834_3_lut (.A(QP[2]), .B(PDTA[3]), .C(SRLOAD), .Z(n3286)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i2834_3_lut.init = 16'hcaca;
    LUT4 i2836_3_lut (.A(QP[3]), .B(PDTA[4]), .C(SRLOAD), .Z(n3288)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i2836_3_lut.init = 16'hcaca;
    LUT4 i2838_3_lut (.A(QP[4]), .B(PDTA[5]), .C(SRLOAD), .Z(n3290)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i2838_3_lut.init = 16'hcaca;
    LUT4 i2840_3_lut (.A(QP[5]), .B(PDTA[6]), .C(SRLOAD), .Z(n3292)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i2840_3_lut.init = 16'hcaca;
    LUT4 i2842_3_lut (.A(QP[6]), .B(PDTA[7]), .C(SRLOAD), .Z(n3294)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i2842_3_lut.init = 16'hcaca;
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(PCLK_c), .CK(Clk), .Q(QP[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3282), .SP(Clk_enable_219), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3284), .SP(Clk_enable_219), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3286), .SP(Clk_enable_219), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3288), .SP(Clk_enable_219), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3290), .SP(Clk_enable_219), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3292), .SP(Clk_enable_219), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3294), .SP(Clk_enable_219), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(PCLK_c), .CK(Clk), .Q(QP[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(PCLK_c), .CK(Clk), .Q(QP[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(PCLK_c), .CK(Clk), .Q(QP[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(PCLK_c), .CK(Clk), .Q(QP[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(PCLK_c), .CK(Clk), .Q(QP[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(PCLK_c), .CK(Clk), .Q(QP[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(PCLK_c), .CK(Clk), .Q(QTA)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3JX QS_IN_i0_i0 (.D(PDTA[0]), .SP(Clk_enable_219), .PD(n10726), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U107
//

module SHIFTREG_U107 (SR3, Clk, PCLK_c, STEP2, \ATR[1] ) /* synthesis syn_module_defined=1 */ ;
    output [7:0]SR3;
    input Clk;
    input PCLK_c;
    input STEP2;
    input \ATR[1] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(PCLK_c), .CK(Clk), .Q(SR3[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i0 (.D(\ATR[1] ), .SP(STEP2), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(PCLK_c), .CK(Clk), .Q(SR3[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(PCLK_c), .CK(Clk), .Q(SR3[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(PCLK_c), .CK(Clk), .Q(SR3[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(PCLK_c), .CK(Clk), .Q(SR3[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(PCLK_c), .CK(Clk), .Q(SR3[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(PCLK_c), .CK(Clk), .Q(SR3[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(PCLK_c), .CK(Clk), .Q(SR3[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(SR3[0]), .SP(STEP2), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(SR3[1]), .SP(STEP2), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(SR3[2]), .SP(STEP2), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(SR3[3]), .SP(STEP2), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(SR3[4]), .SP(STEP2), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(SR3[5]), .SP(STEP2), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(SR3[6]), .SP(STEP2), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U108
//

module SHIFTREG_U108 (SR2, Clk, PCLK_c, STEP2, \ATR[0] ) /* synthesis syn_module_defined=1 */ ;
    output [7:0]SR2;
    input Clk;
    input PCLK_c;
    input STEP2;
    input \ATR[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(PCLK_c), .CK(Clk), .Q(SR2[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i0 (.D(\ATR[0] ), .SP(STEP2), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(PCLK_c), .CK(Clk), .Q(SR2[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(PCLK_c), .CK(Clk), .Q(SR2[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(PCLK_c), .CK(Clk), .Q(SR2[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(PCLK_c), .CK(Clk), .Q(SR2[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(PCLK_c), .CK(Clk), .Q(SR2[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(PCLK_c), .CK(Clk), .Q(SR2[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(PCLK_c), .CK(Clk), .Q(SR2[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(SR2[0]), .SP(STEP2), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(SR2[1]), .SP(STEP2), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(SR2[2]), .SP(STEP2), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(SR2[3]), .SP(STEP2), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(SR2[4]), .SP(STEP2), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(SR2[5]), .SP(STEP2), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(SR2[6]), .SP(STEP2), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U109
//

module SHIFTREG_U109 (SR1, Clk, PCLK_c, STEP2, QTB) /* synthesis syn_module_defined=1 */ ;
    output [7:0]SR1;
    input Clk;
    input PCLK_c;
    input STEP2;
    input QTB;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(PCLK_c), .CK(Clk), .Q(SR1[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i0 (.D(QTB), .SP(STEP2), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(PCLK_c), .CK(Clk), .Q(SR1[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(PCLK_c), .CK(Clk), .Q(SR1[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(PCLK_c), .CK(Clk), .Q(SR1[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(PCLK_c), .CK(Clk), .Q(SR1[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(PCLK_c), .CK(Clk), .Q(SR1[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(PCLK_c), .CK(Clk), .Q(SR1[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(PCLK_c), .CK(Clk), .Q(SR1[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(SR1[0]), .SP(STEP2), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(SR1[1]), .SP(STEP2), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(SR1[2]), .SP(STEP2), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(SR1[3]), .SP(STEP2), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(SR1[4]), .SP(STEP2), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(SR1[5]), .SP(STEP2), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(SR1[6]), .SP(STEP2), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U110
//

module SHIFTREG_U110 (SR0, Clk, PCLK_c, STEP2, QTA) /* synthesis syn_module_defined=1 */ ;
    output [7:0]SR0;
    input Clk;
    input PCLK_c;
    input STEP2;
    input QTA;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(PCLK_c), .CK(Clk), .Q(SR0[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i0 (.D(QTA), .SP(STEP2), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(PCLK_c), .CK(Clk), .Q(SR0[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(PCLK_c), .CK(Clk), .Q(SR0[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(PCLK_c), .CK(Clk), .Q(SR0[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(PCLK_c), .CK(Clk), .Q(SR0[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(PCLK_c), .CK(Clk), .Q(SR0[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(PCLK_c), .CK(Clk), .Q(SR0[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(PCLK_c), .CK(Clk), .Q(SR0[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(SR0[0]), .SP(STEP2), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(SR0[1]), .SP(STEP2), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(SR0[2]), .SP(STEP2), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(SR0[3]), .SP(STEP2), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(SR0[4]), .SP(STEP2), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(SR0[5]), .SP(STEP2), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(SR0[6]), .SP(STEP2), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module OBJ_FIFO
//

module OBJ_FIFO (OB, PCLK_c, SH2, Clk, nPCLK, PAR_O, Hnn, PD_FIFO, 
            ZCOL, PD_out_7, PD_out_0, PD_out_6, PD_out_1, PD_out_5, 
            PD_out_2, PD_out_4, PD_out_3, SPR0HIT_LATCH, O_HPOS, CLIPOR, 
            VINV_LATCH_N_896, nVIS) /* synthesis syn_module_defined=1 */ ;
    input [7:0]OB;
    input PCLK_c;
    output SH2;
    input Clk;
    input nPCLK;
    input PAR_O;
    input [5:0]Hnn;
    input PD_FIFO;
    output [4:0]ZCOL;
    input PD_out_7;
    input PD_out_0;
    input PD_out_6;
    input PD_out_1;
    input PD_out_5;
    input PD_out_2;
    input PD_out_4;
    input PD_out_3;
    output SPR0HIT_LATCH;
    input O_HPOS;
    input CLIPOR;
    input VINV_LATCH_N_896;
    input nVIS;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire EN_7__N_1225;
    wire [7:0]SEL_LATCH;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1328[10:19])
    
    wire CNT1, n2947, CNT1_adj_1724, n2955, SH3, ZH_FF, CNT_7__N_1392, 
        COL1_7__N_1253;
    wire [7:0]SDATA;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1346[11:16])
    wire [7:0]QP;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3222, ATR_IN7_2__N_1368, CNT1_adj_1725, n2951;
    wire [2:0]ATR6;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1331[46:50])
    wire [2:0]ATR_IN6;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1330[64:71])
    
    wire CNT1_adj_1726, n2953;
    wire [2:0]ATR5;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1331[40:44])
    wire [2:0]ATR_IN5;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1330[55:62])
    
    wire ATR_IN6_2__N_1367, ATR_IN5_2__N_1366, CNT1_adj_1727, n2959, 
        CNT1_adj_1728, n2957;
    wire [2:0]ATR4;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1331[34:38])
    wire [2:0]ATR_IN4;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1330[46:53])
    wire [2:0]ATR3;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1331[28:32])
    wire [2:0]ATR_IN3;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1330[37:44])
    wire [2:0]ATR2;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1331[22:26])
    wire [2:0]ATR_IN2;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1330[28:35])
    wire [2:0]ATR1;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1331[16:20])
    wire [2:0]ATR_IN1;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1330[19:26])
    wire [2:0]ATR0;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1331[10:14])
    wire [2:0]ATR_IN0;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1330[10:17])
    
    wire CNT1_adj_1729, n2949, n3224, ATR_IN4_2__N_1365, ATR_IN3_2__N_1364, 
        n3220, COL0_7__N_1237;
    wire [7:0]QP_adj_1904;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3178, CNT1_adj_1731, n3007, CNT1_adj_1732, n2945, n3182, 
        ATR_IN2_2__N_1363, ATR_IN1_2__N_1362, n3218;
    wire [7:0]QP_adj_1905;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3196, n3176, SH3_N_1382, SH5_N_1386, n3216, SH7;
    wire [7:0]EN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1336[11:13])
    
    wire n5053, n3214, n3174, CNT1_adj_1737, n2832, n3212, CNT1_adj_1738, 
        n2854, CNT1_adj_1739, n2858, CNT1_adj_1740, n2856, CNT1_adj_1741, 
        n2852, CNT1_adj_1742, n2836, CNT1_adj_1743, n2838, CNT1_adj_1744, 
        n2834, SH5, n5047;
    wire [7:0]QP_adj_1906;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3056;
    wire [7:0]PD_LATCH;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1328[21:29])
    
    wire Clk_enable_204, Clk_enable_207, n11298, n2761, n5055, n3044, 
        Clk_enable_203, n3046, n3048, n3050, n3052, n3172, CNT1_adj_1752, 
        n2860, n3054, MIRR_LATCH;
    wire [7:0]MIRR_MUX;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1333[11:19])
    
    wire n2763, n11278, ATR_IN0_2__N_1360, CNT1_adj_1754, n2864;
    wire [7:0]QP_adj_1907;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3142, CNT1_adj_1756, n2862, n5057, CNT1_adj_1757, n2870;
    wire [7:0]QP_adj_1908;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3070, CNT1_adj_1759, n2866, CNT1_adj_1760, n2927, CNT1_adj_1761, 
        n2925, CNT1_adj_1762, n2910, n3144, n3154, Clk_enable_202, 
        CNT1_adj_1765, n2973, n3058, Clk_enable_201, n7554, n4206, 
        n10737, SPR_4__N_1297, n3060, n10417, n4209, n3062, n5059, 
        Clk_enable_200, SPR_6__N_1274, n11459, n10657, n5061, n7490, 
        n4172, n7584, SPR_3__N_1307, n3068, n3066, n3064, n3146;
    wire [7:0]QP_adj_1909;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3082;
    wire [7:0]QP_adj_1910;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3236, n3238, n3234, n3232, n3230, ZH_FF_adj_1779, CNT_7__N_1392_adj_1780, 
        n3084, n3228, n3226, n3080, ZH_FF_adj_1785, CNT_7__N_1392_adj_1786, 
        n3078, n5079, n3076;
    wire [7:0]QP_adj_1911;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3250, n3252, ZH_FF_adj_1791, CNT_7__N_1392_adj_1792, n3150, 
        n3074, n3072, CNT1_adj_1796, n2876, SH2_N_1373, n5051, n3148;
    wire [7:0]QP_adj_1912;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3094, n3248, n3098, n3092, n3090, n7400, Clk_enable_205, 
        n5031, Clk_enable_215, n3246, n3088;
    wire [7:0]QP_adj_1913;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3122, n3086, n11388, n2771, n11284, n3244, n3242, n2773;
    wire [4:0]n326;
    wire [7:0]QP_adj_1914;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3136, n3240, n5033, Clk_enable_214;
    wire [7:0]SPR;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1367[11:14])
    
    wire n3096;
    wire [2:0]ATR7;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1331[52:56])
    wire [2:0]ATR_IN7;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1330[73:80])
    wire [2:0]ZPOS;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1329[10:14])
    wire [7:0]QP_adj_1915;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3108, n3112, n3126, CNT1_adj_1815, n2814, n3106, CNT1_adj_1817, 
        n2828, n3104, n3102, n3120, CNT1_adj_1821, n2820, ZH_FF_adj_1822, 
        CNT_7__N_1392_adj_1823, Clk_enable_62, CNT1_adj_1824, n2824, 
        CNT1_adj_1825, n2822, n3118, CNT1_adj_1827, n2818, CNT1_adj_1828, 
        n2816, CNT1_adj_1829, n2826, ZH_FF_adj_1830, CNT_7__N_1392_adj_1831, 
        n3100, CNT1_adj_1833, n2812, CNT1_adj_1834, n2902, CNT1_adj_1835, 
        n3024, CNT1_adj_1836, n2808, n3140, n3152, CNT1_adj_1839, 
        n3022, n3110, CNT1_adj_1841, n3005, n1993, n11322;
    wire [7:0]COL0;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1348[10:14])
    
    wire CNT1_adj_1842, n2874, n11292, n11295, n5035, CNT1_adj_1843, 
        n2810, n11304, Clk_enable_213, n7376, SEL_LATCH_7__N_1345, 
        n5108, SEL_LATCH_7__N_1343, n3116, n5037, n7588, SEL_LATCH_7__N_1349, 
        Clk_enable_212, SEL_LATCH_7__N_1353, ZH_FF_adj_1845, CNT_7__N_1392_adj_1846, 
        n11400, n11281, n5039, Clk_enable_211, n5041, Clk_enable_210, 
        n3114;
    wire [7:0]QP_adj_1916;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3254, n3266, n3256, n3124, n3258, n3260, n3262, n3264, 
        n3134, SPR_7__N_1261, CNT1_adj_1857, n2929, CNT1_adj_1858, 
        n2937, CNT1_adj_1859, n2939, n3132, CNT1_adj_1861, n2941, 
        CNT1_adj_1862, n2943, CNT1_adj_1863, n2931, CNT1_adj_1864, 
        n2933, CNT1_adj_1865, n2935, CNT1_adj_1866, n3030;
    wire [7:0]COL1;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1348[16:20])
    
    wire n11412, n3130, CNT1_adj_1868, n2963, CNT1_adj_1869, n3026, 
        n11310, CNT1_adj_1870, n2965, CNT1_adj_1871, n2967, n10749, 
        CNT1_adj_1872, n3019, n3128, CNT1_adj_1874, n2969, CNT1_adj_1875, 
        n2878, CNT1_adj_1876, n2971, CNT1_adj_1877, n2904, n11316, 
        n11289, n11286, n3138, CNT1_adj_1879, n2983;
    wire [7:0]QP_adj_1917;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3164, n3170, n3168, n3162, n3190, n3160, n3158, n3156, 
        n3166, n3180, n3184, n5043, n3188, n3194, Clk_enable_209, 
        n5049, Clk_enable_206, CNT1_adj_1893, n2975, n5045;
    wire [7:0]QP_adj_1918;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n3208, Clk_enable_208, n3210, n3206, n3204, n3202, n3200, 
        n3198, CNT1_adj_1901, n2961, n3192, n3186, n3374, Clk_enable_52, 
        n3403, Clk_enable_51, n3423, Clk_enable_50, n3427, Clk_enable_49, 
        Clk_enable_48, n3428, Clk_enable_47, n3429, n3430, Clk_enable_55;
    
    LUT4 i2500_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[1]), .C(OB[1]), 
         .D(CNT1), .Z(n2947)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i2500_3_lut_4_lut.init = 16'hf780;
    LUT4 i2508_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[1]), .C(OB[5]), 
         .D(CNT1_adj_1724), .Z(n2955)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i2508_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[0]), 
         .D(ZH_FF), .Z(CNT_7__N_1392)) /* synthesis lut_function=(A (B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i1_3_lut_4_lut_4_lut.init = 16'hd580;
    LUT4 i2770_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[1]), .C(SDATA[6]), 
         .D(QP[5]), .Z(n3222)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1353[53:80])
    defparam i2770_3_lut_4_lut.init = 16'hf780;
    LUT4 ATR_IN0_2__N_1361_I_0_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[7]), 
         .Z(ATR_IN7_2__N_1368)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1425[14:39])
    defparam ATR_IN0_2__N_1361_I_0_2_lut_3_lut.init = 16'h8080;
    LUT4 i2504_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[1]), .C(OB[3]), 
         .D(CNT1_adj_1725), .Z(n2951)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i2504_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR6_i0_i2 (.D(ATR_IN6[2]), .SP(nPCLK), .CK(Clk), .Q(ATR6[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR6_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR6_i0_i1 (.D(ATR_IN6[1]), .SP(nPCLK), .CK(Clk), .Q(ATR6[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR6_i0_i1.GSR = "DISABLED";
    LUT4 i2506_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[1]), .C(OB[4]), 
         .D(CNT1_adj_1726), .Z(n2953)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i2506_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR5_i0_i2 (.D(ATR_IN5[2]), .SP(nPCLK), .CK(Clk), .Q(ATR5[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR5_i0_i2.GSR = "DISABLED";
    LUT4 ATR_IN0_2__N_1361_I_0_361_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[6]), 
         .Z(ATR_IN6_2__N_1367)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1424[14:39])
    defparam ATR_IN0_2__N_1361_I_0_361_2_lut_3_lut.init = 16'h8080;
    LUT4 ATR_IN0_2__N_1361_I_0_360_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[5]), 
         .Z(ATR_IN5_2__N_1366)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1423[14:39])
    defparam ATR_IN0_2__N_1361_I_0_360_2_lut_3_lut.init = 16'h8080;
    LUT4 i2512_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[1]), .C(OB[7]), 
         .D(CNT1_adj_1727), .Z(n2959)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i2512_3_lut_4_lut.init = 16'hf780;
    LUT4 i2510_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[1]), .C(OB[6]), 
         .D(CNT1_adj_1728), .Z(n2957)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i2510_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR5_i0_i1 (.D(ATR_IN5[1]), .SP(nPCLK), .CK(Clk), .Q(ATR5[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR5_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR4_i0_i2 (.D(ATR_IN4[2]), .SP(nPCLK), .CK(Clk), .Q(ATR4[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR4_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR4_i0_i1 (.D(ATR_IN4[1]), .SP(nPCLK), .CK(Clk), .Q(ATR4[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR4_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR3_i0_i2 (.D(ATR_IN3[2]), .SP(nPCLK), .CK(Clk), .Q(ATR3[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR3_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR3_i0_i1 (.D(ATR_IN3[1]), .SP(nPCLK), .CK(Clk), .Q(ATR3[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR3_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR2_i0_i2 (.D(ATR_IN2[2]), .SP(nPCLK), .CK(Clk), .Q(ATR2[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR2_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR2_i0_i1 (.D(ATR_IN2[1]), .SP(nPCLK), .CK(Clk), .Q(ATR2[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR2_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR1_i0_i2 (.D(ATR_IN1[2]), .SP(nPCLK), .CK(Clk), .Q(ATR1[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR1_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR1_i0_i1 (.D(ATR_IN1[1]), .SP(nPCLK), .CK(Clk), .Q(ATR1[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR1_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR0_i0_i2 (.D(ATR_IN0[2]), .SP(nPCLK), .CK(Clk), .Q(ATR0[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR0_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR0_i0_i1 (.D(ATR_IN0[1]), .SP(nPCLK), .CK(Clk), .Q(ATR0[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR0_i0_i1.GSR = "DISABLED";
    LUT4 i2502_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[1]), .C(OB[2]), 
         .D(CNT1_adj_1729), .Z(n2949)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i2502_3_lut_4_lut.init = 16'hf780;
    LUT4 i2772_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[1]), .C(SDATA[7]), 
         .D(QP[6]), .Z(n3224)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1353[53:80])
    defparam i2772_3_lut_4_lut.init = 16'hf780;
    LUT4 ATR_IN0_2__N_1361_I_0_359_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[4]), 
         .Z(ATR_IN4_2__N_1365)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1422[14:39])
    defparam ATR_IN0_2__N_1361_I_0_359_2_lut_3_lut.init = 16'h8080;
    LUT4 ATR_IN0_2__N_1361_I_0_358_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[3]), 
         .Z(ATR_IN3_2__N_1364)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1421[14:39])
    defparam ATR_IN0_2__N_1361_I_0_358_2_lut_3_lut.init = 16'h8080;
    LUT4 i2768_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[1]), .C(SDATA[5]), 
         .D(QP[4]), .Z(n3220)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1353[53:80])
    defparam i2768_3_lut_4_lut.init = 16'hf780;
    LUT4 i2726_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[3]), .C(SDATA[5]), 
         .D(QP_adj_1904[4]), .Z(n3178)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i2726_3_lut_4_lut.init = 16'hf780;
    LUT4 i2560_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[7]), .C(OB[6]), 
         .D(CNT1_adj_1731), .Z(n3007)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i2560_3_lut_4_lut.init = 16'hf780;
    LUT4 i2498_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[1]), .C(OB[0]), 
         .D(CNT1_adj_1732), .Z(n2945)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i2498_3_lut_4_lut.init = 16'hf780;
    LUT4 i2730_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[3]), .C(SDATA[7]), 
         .D(QP_adj_1904[6]), .Z(n3182)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i2730_3_lut_4_lut.init = 16'hf780;
    LUT4 ATR_IN0_2__N_1361_I_0_357_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[2]), 
         .Z(ATR_IN2_2__N_1363)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1420[14:39])
    defparam ATR_IN0_2__N_1361_I_0_357_2_lut_3_lut.init = 16'h8080;
    LUT4 ATR_IN0_2__N_1361_I_0_356_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[1]), 
         .Z(ATR_IN1_2__N_1362)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1419[14:39])
    defparam ATR_IN0_2__N_1361_I_0_356_2_lut_3_lut.init = 16'h8080;
    LUT4 i2766_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[1]), .C(SDATA[4]), 
         .D(QP[3]), .Z(n3218)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1353[53:80])
    defparam i2766_3_lut_4_lut.init = 16'hf780;
    LUT4 i2744_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[2]), .C(SDATA[7]), 
         .D(QP_adj_1905[6]), .Z(n3196)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1355[53:80])
    defparam i2744_3_lut_4_lut.init = 16'hf780;
    LUT4 i2724_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[3]), .C(SDATA[4]), 
         .D(QP_adj_1904[3]), .Z(n3176)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i2724_3_lut_4_lut.init = 16'hf780;
    LUT4 SH3_I_369_2_lut_3_lut (.A(PAR_O), .B(Hnn[0]), .C(Hnn[1]), .Z(SH3_N_1382)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1395[18:33])
    defparam SH3_I_369_2_lut_3_lut.init = 16'h8080;
    LUT4 SH3_N_1383_I_0_2_lut_3_lut (.A(PAR_O), .B(Hnn[0]), .C(Hnn[1]), 
         .Z(SH5_N_1386)) /* synthesis lut_function=(!(((C)+!B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1395[18:33])
    defparam SH3_N_1383_I_0_2_lut_3_lut.init = 16'h0808;
    LUT4 i2764_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[1]), .C(SDATA[3]), 
         .D(QP[2]), .Z(n3216)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1353[53:80])
    defparam i2764_3_lut_4_lut.init = 16'hf780;
    LUT4 i4584_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH7), .C(SEL_LATCH[5]), 
         .D(EN[5]), .Z(n5053)) /* synthesis lut_function=(!((B (C+!(D))+!B !(D))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i4584_2_lut_3_lut_4_lut_4_lut.init = 16'h2a00;
    LUT4 i2762_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[1]), .C(SDATA[2]), 
         .D(QP[1]), .Z(n3214)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1353[53:80])
    defparam i2762_3_lut_4_lut.init = 16'hf780;
    LUT4 i2722_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[3]), .C(SDATA[3]), 
         .D(QP_adj_1904[2]), .Z(n3174)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i2722_3_lut_4_lut.init = 16'hf780;
    LUT4 i2388_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[4]), .C(OB[0]), 
         .D(CNT1_adj_1737), .Z(n2832)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i2388_3_lut_4_lut.init = 16'hf780;
    LUT4 i2760_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[1]), .C(SDATA[1]), 
         .D(QP[0]), .Z(n3212)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1353[53:80])
    defparam i2760_3_lut_4_lut.init = 16'hf780;
    LUT4 i2409_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[4]), .C(OB[5]), 
         .D(CNT1_adj_1738), .Z(n2854)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i2409_3_lut_4_lut.init = 16'hf780;
    LUT4 i2413_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[4]), .C(OB[7]), 
         .D(CNT1_adj_1739), .Z(n2858)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i2413_3_lut_4_lut.init = 16'hf780;
    LUT4 i2411_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[4]), .C(OB[6]), 
         .D(CNT1_adj_1740), .Z(n2856)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i2411_3_lut_4_lut.init = 16'hf780;
    LUT4 i2407_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[4]), .C(OB[4]), 
         .D(CNT1_adj_1741), .Z(n2852)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i2407_3_lut_4_lut.init = 16'hf780;
    LUT4 i2392_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[4]), .C(OB[2]), 
         .D(CNT1_adj_1742), .Z(n2836)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i2392_3_lut_4_lut.init = 16'hf780;
    LUT4 i2394_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[4]), .C(OB[3]), 
         .D(CNT1_adj_1743), .Z(n2838)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i2394_3_lut_4_lut.init = 16'hf780;
    LUT4 i2390_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[4]), .C(OB[1]), 
         .D(CNT1_adj_1744), .Z(n2834)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i2390_3_lut_4_lut.init = 16'hf780;
    LUT4 i4578_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[4]), 
         .D(EN[4]), .Z(n5047)) /* synthesis lut_function=(!((B (C+!(D))+!B !(D))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i4578_2_lut_3_lut_4_lut_4_lut.init = 16'h2a00;
    LUT4 i2604_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[7]), .C(SDATA[7]), 
         .D(QP_adj_1906[6]), .Z(n3056)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1365[53:80])
    defparam i2604_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_FIFO_I_0_i1_2_lut (.A(PD_FIFO), .B(PD_LATCH[0]), .Z(SDATA[0])) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i1_2_lut.init = 16'h8888;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH7), .C(SEL_LATCH[5]), 
         .D(EN[5]), .Z(Clk_enable_204)) /* synthesis lut_function=(A (B (C+(D))+!B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i1_2_lut_3_lut_4_lut_4_lut.init = 16'haa80;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_433 (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[4]), 
         .D(EN[4]), .Z(Clk_enable_207)) /* synthesis lut_function=(A (B (C+(D))+!B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_433.init = 16'haa80;
    LUT4 n11298_bdd_4_lut (.A(n11298), .B(ATR1[2]), .C(ATR0[2]), .D(n2761), 
         .Z(ZCOL[4])) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11298_bdd_4_lut.init = 16'haad8;
    LUT4 i4586_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[6]), 
         .D(EN[6]), .Z(n5055)) /* synthesis lut_function=(!((B (C+!(D))+!B !(D))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i4586_2_lut_3_lut_4_lut_4_lut.init = 16'h2a00;
    LUT4 i2592_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[7]), .C(SDATA[1]), 
         .D(QP_adj_1906[0]), .Z(n3044)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1365[53:80])
    defparam i2592_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_434 (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[6]), 
         .D(EN[6]), .Z(Clk_enable_203)) /* synthesis lut_function=(A (B (C+(D))+!B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_434.init = 16'haa80;
    LUT4 i2594_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[7]), .C(SDATA[2]), 
         .D(QP_adj_1906[1]), .Z(n3046)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1365[53:80])
    defparam i2594_3_lut_4_lut.init = 16'hf780;
    LUT4 i2596_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[7]), .C(SDATA[3]), 
         .D(QP_adj_1906[2]), .Z(n3048)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1365[53:80])
    defparam i2596_3_lut_4_lut.init = 16'hf780;
    LUT4 i2598_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[7]), .C(SDATA[4]), 
         .D(QP_adj_1906[3]), .Z(n3050)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1365[53:80])
    defparam i2598_3_lut_4_lut.init = 16'hf780;
    LUT4 i2600_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[7]), .C(SDATA[5]), 
         .D(QP_adj_1906[4]), .Z(n3052)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1365[53:80])
    defparam i2600_3_lut_4_lut.init = 16'hf780;
    LUT4 i2720_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[3]), .C(SDATA[2]), 
         .D(QP_adj_1904[1]), .Z(n3172)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i2720_3_lut_4_lut.init = 16'hf780;
    LUT4 i2415_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[3]), .C(OB[0]), 
         .D(CNT1_adj_1752), .Z(n2860)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i2415_3_lut_4_lut.init = 16'hf780;
    LUT4 i2602_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[7]), .C(SDATA[6]), 
         .D(QP_adj_1906[5]), .Z(n3054)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1365[53:80])
    defparam i2602_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_7__I_0_i8_3_lut (.A(PD_out_7), .B(PD_out_0), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i8_3_lut.init = 16'hcaca;
    FD1P3AX PD_LATCH_i0_i7 (.D(MIRR_MUX[7]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i7.GSR = "DISABLED";
    LUT4 n2763_bdd_4_lut_10743 (.A(n2763), .B(ATR2[2]), .C(n11278), .D(n2761), 
         .Z(n11298)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2763_bdd_4_lut_10743.init = 16'he4aa;
    FD1P3AX PD_LATCH_i0_i6 (.D(MIRR_MUX[6]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i6.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i5 (.D(MIRR_MUX[5]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i5.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i4 (.D(MIRR_MUX[4]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i4.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i3 (.D(MIRR_MUX[3]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i3.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i2 (.D(MIRR_MUX[2]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i2.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i1 (.D(MIRR_MUX[1]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN0_i0_i2 (.D(OB[5]), .SP(ATR_IN0_2__N_1360), .CK(Clk), 
            .Q(ATR_IN0[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN0_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN0_i0_i1 (.D(OB[1]), .SP(ATR_IN0_2__N_1360), .CK(Clk), 
            .Q(ATR_IN0[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN0_i0_i1.GSR = "DISABLED";
    LUT4 i2419_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[3]), .C(OB[2]), 
         .D(CNT1_adj_1754), .Z(n2864)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i2419_3_lut_4_lut.init = 16'hf780;
    LUT4 i2690_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[4]), .C(SDATA[1]), 
         .D(QP_adj_1907[0]), .Z(n3142)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i2690_3_lut_4_lut.init = 16'hf780;
    LUT4 i2417_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[3]), .C(OB[1]), 
         .D(CNT1_adj_1756), .Z(n2862)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i2417_3_lut_4_lut.init = 16'hf780;
    LUT4 i4588_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[6]), .C(SEL_LATCH[6]), 
         .D(SH7), .Z(n5057)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i4588_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i2424_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[3]), .C(OB[4]), 
         .D(CNT1_adj_1757), .Z(n2870)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i2424_3_lut_4_lut.init = 16'hf780;
    LUT4 i2618_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[7]), .C(SDATA[7]), 
         .D(QP_adj_1908[6]), .Z(n3070)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i2618_3_lut_4_lut.init = 16'hf780;
    LUT4 i2421_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[3]), .C(OB[3]), 
         .D(CNT1_adj_1759), .Z(n2866)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i2421_3_lut_4_lut.init = 16'hf780;
    LUT4 i2480_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[3]), .C(OB[7]), 
         .D(CNT1_adj_1760), .Z(n2927)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i2480_3_lut_4_lut.init = 16'hf780;
    LUT4 i2478_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[3]), .C(OB[6]), 
         .D(CNT1_adj_1761), .Z(n2925)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i2478_3_lut_4_lut.init = 16'hf780;
    LUT4 i2463_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[3]), .C(OB[5]), 
         .D(CNT1_adj_1762), .Z(n2910)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i2463_3_lut_4_lut.init = 16'hf780;
    LUT4 i2692_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[4]), .C(SDATA[2]), 
         .D(QP_adj_1907[1]), .Z(n3144)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i2692_3_lut_4_lut.init = 16'hf780;
    LUT4 i2702_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[4]), .C(SDATA[7]), 
         .D(QP_adj_1907[6]), .Z(n3154)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i2702_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_435 (.A(PCLK_c), .B(EN[6]), .C(SEL_LATCH[6]), 
         .D(SH7), .Z(Clk_enable_202)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_435.init = 16'ha888;
    LUT4 i2526_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[0]), .C(OB[6]), 
         .D(CNT1_adj_1765), .Z(n2973)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i2526_3_lut_4_lut.init = 16'hf780;
    LUT4 i2606_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[7]), .C(SDATA[1]), 
         .D(QP_adj_1908[0]), .Z(n3058)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i2606_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_7__I_0_i7_3_lut (.A(PD_out_6), .B(PD_out_1), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i7_3_lut.init = 16'hcaca;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_436 (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[7]), 
         .D(EN[7]), .Z(Clk_enable_201)) /* synthesis lut_function=(A (B (C+(D))+!B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_436.init = 16'haa80;
    LUT4 PD_7__I_0_i6_3_lut (.A(PD_out_5), .B(PD_out_2), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i6_3_lut.init = 16'hcaca;
    LUT4 i1_2_lut_3_lut (.A(n7554), .B(n4206), .C(n10737), .Z(SPR_4__N_1297)) /* synthesis lut_function=(A+(B+!(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1372[18:96])
    defparam i1_2_lut_3_lut.init = 16'hefef;
    LUT4 i2608_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[7]), .C(SDATA[2]), 
         .D(QP_adj_1908[1]), .Z(n3060)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i2608_3_lut_4_lut.init = 16'hf780;
    LUT4 i2_3_lut_4_lut (.A(n7554), .B(n4206), .C(n10737), .D(n10417), 
         .Z(n4209)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1372[18:96])
    defparam i2_3_lut_4_lut.init = 16'hfffe;
    LUT4 i2610_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[7]), .C(SDATA[3]), 
         .D(QP_adj_1908[2]), .Z(n3062)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i2610_3_lut_4_lut.init = 16'hf780;
    LUT4 i4590_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[7]), 
         .D(EN[7]), .Z(n5059)) /* synthesis lut_function=(!((B (C+!(D))+!B !(D))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i4590_2_lut_3_lut_4_lut_4_lut.init = 16'h2a00;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_437 (.A(PCLK_c), .B(EN[7]), .C(SEL_LATCH[7]), 
         .D(SH7), .Z(Clk_enable_200)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_437.init = 16'ha888;
    LUT4 SPR_6__N_1274_bdd_4_lut (.A(SPR_6__N_1274), .B(n4206), .C(EN[7]), 
         .D(n11459), .Z(n10657)) /* synthesis lut_function=(!((B+!(C (D)))+!A)) */ ;
    defparam SPR_6__N_1274_bdd_4_lut.init = 16'h2000;
    LUT4 i4592_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[7]), .C(SEL_LATCH[7]), 
         .D(SH7), .Z(n5061)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i4592_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 PD_7__I_0_i5_3_lut (.A(PD_out_4), .B(PD_out_3), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i5_3_lut.init = 16'hcaca;
    LUT4 i2_4_lut_4_lut (.A(n7490), .B(n4172), .C(n7584), .D(n7554), 
         .Z(SPR_3__N_1307)) /* synthesis lut_function=(A (B+!(D))+!A (B+(C+!(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1370[18:78])
    defparam i2_4_lut_4_lut.init = 16'hdcff;
    LUT4 i2616_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[7]), .C(SDATA[6]), 
         .D(QP_adj_1908[5]), .Z(n3068)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i2616_3_lut_4_lut.init = 16'hf780;
    LUT4 i2614_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[7]), .C(SDATA[5]), 
         .D(QP_adj_1908[4]), .Z(n3066)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i2614_3_lut_4_lut.init = 16'hf780;
    LUT4 i2612_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[7]), .C(SDATA[4]), 
         .D(QP_adj_1908[3]), .Z(n3064)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i2612_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_7__I_0_i4_3_lut (.A(PD_out_3), .B(PD_out_4), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i4_3_lut.init = 16'hcaca;
    LUT4 i2694_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[4]), .C(SDATA[3]), 
         .D(QP_adj_1907[2]), .Z(n3146)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i2694_3_lut_4_lut.init = 16'hf780;
    LUT4 i2630_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[6]), .C(SDATA[6]), 
         .D(QP_adj_1909[5]), .Z(n3082)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1363[53:80])
    defparam i2630_3_lut_4_lut.init = 16'hf780;
    LUT4 i2784_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[1]), .C(SDATA[6]), 
         .D(QP_adj_1910[5]), .Z(n3236)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i2784_3_lut_4_lut.init = 16'hf780;
    LUT4 i2786_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[1]), .C(SDATA[7]), 
         .D(QP_adj_1910[6]), .Z(n3238)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i2786_3_lut_4_lut.init = 16'hf780;
    LUT4 i2782_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[1]), .C(SDATA[5]), 
         .D(QP_adj_1910[4]), .Z(n3234)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i2782_3_lut_4_lut.init = 16'hf780;
    LUT4 i2780_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[1]), .C(SDATA[4]), 
         .D(QP_adj_1910[3]), .Z(n3232)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i2780_3_lut_4_lut.init = 16'hf780;
    LUT4 i2778_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[1]), .C(SDATA[3]), 
         .D(QP_adj_1910[2]), .Z(n3230)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i2778_3_lut_4_lut.init = 16'hf780;
    LUT4 i1287_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[4]), 
         .D(ZH_FF_adj_1779), .Z(CNT_7__N_1392_adj_1780)) /* synthesis lut_function=(A (B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i1287_3_lut_4_lut_4_lut.init = 16'hd580;
    LUT4 i2632_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[6]), .C(SDATA[7]), 
         .D(QP_adj_1909[6]), .Z(n3084)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1363[53:80])
    defparam i2632_3_lut_4_lut.init = 16'hf780;
    LUT4 i2776_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[1]), .C(SDATA[2]), 
         .D(QP_adj_1910[1]), .Z(n3228)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i2776_3_lut_4_lut.init = 16'hf780;
    LUT4 i2774_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[1]), .C(SDATA[1]), 
         .D(QP_adj_1910[0]), .Z(n3226)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i2774_3_lut_4_lut.init = 16'hf780;
    LUT4 i2628_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[6]), .C(SDATA[5]), 
         .D(QP_adj_1909[4]), .Z(n3080)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1363[53:80])
    defparam i2628_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_3_lut_4_lut_4_lut_adj_438 (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[1]), 
         .D(ZH_FF_adj_1785), .Z(CNT_7__N_1392_adj_1786)) /* synthesis lut_function=(A (B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i1_3_lut_4_lut_4_lut_adj_438.init = 16'hd580;
    LUT4 i2626_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[6]), .C(SDATA[4]), 
         .D(QP_adj_1909[3]), .Z(n3078)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1363[53:80])
    defparam i2626_3_lut_4_lut.init = 16'hf780;
    LUT4 i4610_2_lut_2_lut (.A(PCLK_c), .B(Hnn[5]), .Z(n5079)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam i4610_2_lut_2_lut.init = 16'h4444;
    LUT4 i2624_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[6]), .C(SDATA[3]), 
         .D(QP_adj_1909[2]), .Z(n3076)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1363[53:80])
    defparam i2624_3_lut_4_lut.init = 16'hf780;
    LUT4 i2798_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[0]), .C(SDATA[6]), 
         .D(QP_adj_1911[5]), .Z(n3250)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1351[53:80])
    defparam i2798_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_7__I_0_i3_3_lut (.A(PD_out_2), .B(PD_out_5), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i3_3_lut.init = 16'hcaca;
    LUT4 i2800_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[0]), .C(SDATA[7]), 
         .D(QP_adj_1911[6]), .Z(n3252)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1351[53:80])
    defparam i2800_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_3_lut_4_lut_4_lut_adj_439 (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[2]), 
         .D(ZH_FF_adj_1791), .Z(CNT_7__N_1392_adj_1792)) /* synthesis lut_function=(A (B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i1_3_lut_4_lut_4_lut_adj_439.init = 16'hd580;
    LUT4 i2698_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[4]), .C(SDATA[5]), 
         .D(QP_adj_1907[4]), .Z(n3150)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i2698_3_lut_4_lut.init = 16'hf780;
    LUT4 i2622_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[6]), .C(SDATA[2]), 
         .D(QP_adj_1909[1]), .Z(n3074)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1363[53:80])
    defparam i2622_3_lut_4_lut.init = 16'hf780;
    LUT4 i2620_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[6]), .C(SDATA[1]), 
         .D(QP_adj_1909[0]), .Z(n3072)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1363[53:80])
    defparam i2620_3_lut_4_lut.init = 16'hf780;
    LUT4 i2430_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[7]), .C(OB[2]), 
         .D(CNT1_adj_1796), .Z(n2876)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i2430_3_lut_4_lut.init = 16'hf780;
    LUT4 i2_3_lut (.A(Hnn[1]), .B(Hnn[0]), .C(PAR_O), .Z(SH2_N_1373)) /* synthesis lut_function=(!((B+!(C))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1394[18:43])
    defparam i2_3_lut.init = 16'h2020;
    LUT4 i4582_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[5]), 
         .D(EN[5]), .Z(n5051)) /* synthesis lut_function=(!((B (C+!(D))+!B !(D))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i4582_2_lut_3_lut_4_lut_4_lut.init = 16'h2a00;
    LUT4 i2696_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[4]), .C(SDATA[4]), 
         .D(QP_adj_1907[3]), .Z(n3148)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i2696_3_lut_4_lut.init = 16'hf780;
    LUT4 i2642_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[6]), .C(SDATA[5]), 
         .D(QP_adj_1912[4]), .Z(n3094)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i2642_3_lut_4_lut.init = 16'hf780;
    LUT4 i2796_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[0]), .C(SDATA[5]), 
         .D(QP_adj_1911[4]), .Z(n3248)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1351[53:80])
    defparam i2796_3_lut_4_lut.init = 16'hf780;
    LUT4 i2646_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[6]), .C(SDATA[7]), 
         .D(QP_adj_1912[6]), .Z(n3098)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i2646_3_lut_4_lut.init = 16'hf780;
    LUT4 i2640_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[6]), .C(SDATA[4]), 
         .D(QP_adj_1912[3]), .Z(n3092)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i2640_3_lut_4_lut.init = 16'hf780;
    LUT4 i2638_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[6]), .C(SDATA[3]), 
         .D(QP_adj_1912[2]), .Z(n3090)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i2638_3_lut_4_lut.init = 16'hf780;
    LUT4 i10543_2_lut (.A(Hnn[2]), .B(PCLK_c), .Z(n7400)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i10543_2_lut.init = 16'h1111;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_440 (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[5]), 
         .D(EN[5]), .Z(Clk_enable_205)) /* synthesis lut_function=(A (B (C+(D))+!B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_440.init = 16'haa80;
    LUT4 i4562_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[0]), 
         .D(EN[0]), .Z(n5031)) /* synthesis lut_function=(!((B (C+!(D))+!B !(D))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i4562_2_lut_3_lut_4_lut_4_lut.init = 16'h2a00;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_441 (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[0]), 
         .D(EN[0]), .Z(Clk_enable_215)) /* synthesis lut_function=(A (B (C+(D))+!B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_441.init = 16'haa80;
    LUT4 i2794_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[0]), .C(SDATA[4]), 
         .D(QP_adj_1911[3]), .Z(n3246)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1351[53:80])
    defparam i2794_3_lut_4_lut.init = 16'hf780;
    LUT4 i2636_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[6]), .C(SDATA[2]), 
         .D(QP_adj_1912[1]), .Z(n3088)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i2636_3_lut_4_lut.init = 16'hf780;
    LUT4 i2670_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[5]), .C(SDATA[5]), 
         .D(QP_adj_1913[4]), .Z(n3122)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i2670_3_lut_4_lut.init = 16'hf780;
    LUT4 i2634_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[6]), .C(SDATA[1]), 
         .D(QP_adj_1912[0]), .Z(n3086)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i2634_3_lut_4_lut.init = 16'hf780;
    LUT4 n11388_bdd_4_lut (.A(n11388), .B(ATR4[0]), .C(ATR3[0]), .D(n2771), 
         .Z(n11284)) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11388_bdd_4_lut.init = 16'haad8;
    LUT4 i2792_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[0]), .C(SDATA[3]), 
         .D(QP_adj_1911[2]), .Z(n3244)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1351[53:80])
    defparam i2792_3_lut_4_lut.init = 16'hf780;
    LUT4 i2790_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[0]), .C(SDATA[2]), 
         .D(QP_adj_1911[1]), .Z(n3242)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1351[53:80])
    defparam i2790_3_lut_4_lut.init = 16'hf780;
    LUT4 n2773_bdd_4_lut_10821 (.A(n2773), .B(ATR5[0]), .C(n326[2]), .D(n2771), 
         .Z(n11388)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2773_bdd_4_lut_10821.init = 16'he4aa;
    LUT4 i2684_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[4]), .C(SDATA[5]), 
         .D(QP_adj_1914[4]), .Z(n3136)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1359[53:80])
    defparam i2684_3_lut_4_lut.init = 16'hf780;
    LUT4 i2788_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[0]), .C(SDATA[1]), 
         .D(QP_adj_1911[0]), .Z(n3240)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1351[53:80])
    defparam i2788_3_lut_4_lut.init = 16'hf780;
    LUT4 i4564_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[0]), .C(SEL_LATCH[0]), 
         .D(SH7), .Z(n5033)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i4564_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_442 (.A(PCLK_c), .B(EN[0]), .C(SEL_LATCH[0]), 
         .D(SH7), .Z(Clk_enable_214)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_442.init = 16'ha888;
    FD1P3AX ATR_IN0_i0_i0 (.D(OB[0]), .SP(ATR_IN0_2__N_1360), .CK(Clk), 
            .Q(ATR_IN0[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN0_i0_i0.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i0 (.D(MIRR_MUX[0]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i0.GSR = "DISABLED";
    FD1P3AX SPR0HIT_LATCH_277 (.D(SPR[0]), .SP(PCLK_c), .CK(Clk), .Q(SPR0HIT_LATCH));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SPR0HIT_LATCH_277.GSR = "DISABLED";
    FD1P3AX ATR0_i0_i0 (.D(ATR_IN0[0]), .SP(nPCLK), .CK(Clk), .Q(ATR0[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR0_i0_i0.GSR = "DISABLED";
    LUT4 i2644_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[6]), .C(SDATA[6]), 
         .D(QP_adj_1912[5]), .Z(n3096)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i2644_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR1_i0_i0 (.D(ATR_IN1[0]), .SP(nPCLK), .CK(Clk), .Q(ATR1[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR1_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR2_i0_i0 (.D(ATR_IN2[0]), .SP(nPCLK), .CK(Clk), .Q(ATR2[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR2_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR3_i0_i0 (.D(ATR_IN3[0]), .SP(nPCLK), .CK(Clk), .Q(ATR3[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR3_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR4_i0_i0 (.D(ATR_IN4[0]), .SP(nPCLK), .CK(Clk), .Q(ATR4[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR4_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR5_i0_i0 (.D(ATR_IN5[0]), .SP(nPCLK), .CK(Clk), .Q(ATR5[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR5_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR6_i0_i0 (.D(ATR_IN6[0]), .SP(nPCLK), .CK(Clk), .Q(ATR6[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR6_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR7_i0_i0 (.D(ATR_IN7[0]), .SP(nPCLK), .CK(Clk), .Q(ATR7[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR7_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN1_i0_i0 (.D(OB[0]), .SP(ATR_IN1_2__N_1362), .CK(Clk), 
            .Q(ATR_IN1[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN1_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN2_i0_i0 (.D(OB[0]), .SP(ATR_IN2_2__N_1363), .CK(Clk), 
            .Q(ATR_IN2[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN2_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN3_i0_i0 (.D(OB[0]), .SP(ATR_IN3_2__N_1364), .CK(Clk), 
            .Q(ATR_IN3[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN3_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN4_i0_i0 (.D(OB[0]), .SP(ATR_IN4_2__N_1365), .CK(Clk), 
            .Q(ATR_IN4[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN4_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN5_i0_i0 (.D(OB[0]), .SP(ATR_IN5_2__N_1366), .CK(Clk), 
            .Q(ATR_IN5[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN5_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN6_i0_i0 (.D(OB[0]), .SP(ATR_IN6_2__N_1367), .CK(Clk), 
            .Q(ATR_IN6[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN6_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN7_i0_i0 (.D(OB[0]), .SP(ATR_IN7_2__N_1368), .CK(Clk), 
            .Q(ATR_IN7[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN7_i0_i0.GSR = "DISABLED";
    FD1P3AX ZPOS_i0 (.D(O_HPOS), .SP(nPCLK), .CK(Clk), .Q(ZPOS[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ZPOS_i0.GSR = "DISABLED";
    LUT4 i2656_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[5]), .C(SDATA[5]), 
         .D(QP_adj_1915[4]), .Z(n3108)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i2656_3_lut_4_lut.init = 16'hf780;
    LUT4 i2660_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[5]), .C(SDATA[7]), 
         .D(QP_adj_1915[6]), .Z(n3112)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i2660_3_lut_4_lut.init = 16'hf780;
    LUT4 i2674_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[5]), .C(SDATA[7]), 
         .D(QP_adj_1913[6]), .Z(n3126)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i2674_3_lut_4_lut.init = 16'hf780;
    LUT4 i2371_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[5]), .C(OB[0]), 
         .D(CNT1_adj_1815), .Z(n2814)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i2371_3_lut_4_lut.init = 16'hf780;
    LUT4 i2654_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[5]), .C(SDATA[4]), 
         .D(QP_adj_1915[3]), .Z(n3106)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i2654_3_lut_4_lut.init = 16'hf780;
    LUT4 i2385_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[5]), .C(OB[7]), 
         .D(CNT1_adj_1817), .Z(n2828)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i2385_3_lut_4_lut.init = 16'hf780;
    LUT4 i2652_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[5]), .C(SDATA[3]), 
         .D(QP_adj_1915[2]), .Z(n3104)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i2652_3_lut_4_lut.init = 16'hf780;
    LUT4 i2650_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[5]), .C(SDATA[2]), 
         .D(QP_adj_1915[1]), .Z(n3102)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i2650_3_lut_4_lut.init = 16'hf780;
    LUT4 i2668_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[5]), .C(SDATA[4]), 
         .D(QP_adj_1913[3]), .Z(n3120)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i2668_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_7__I_0_i2_3_lut (.A(PD_out_1), .B(PD_out_6), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i2_3_lut.init = 16'hcaca;
    LUT4 i2377_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[5]), .C(OB[3]), 
         .D(CNT1_adj_1821), .Z(n2820)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i2377_3_lut_4_lut.init = 16'hf780;
    LUT4 i10594_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[6]), 
         .D(ZH_FF_adj_1822), .Z(CNT_7__N_1392_adj_1823)) /* synthesis lut_function=(!(A (B (C))+!A (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i10594_2_lut_3_lut_4_lut_4_lut.init = 16'h2a7f;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_443 (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[6]), 
         .D(ZH_FF_adj_1822), .Z(Clk_enable_62)) /* synthesis lut_function=(A (B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_443.init = 16'hd580;
    LUT4 i2381_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[5]), .C(OB[5]), 
         .D(CNT1_adj_1824), .Z(n2824)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i2381_3_lut_4_lut.init = 16'hf780;
    LUT4 i2379_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[5]), .C(OB[4]), 
         .D(CNT1_adj_1825), .Z(n2822)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i2379_3_lut_4_lut.init = 16'hf780;
    LUT4 i2666_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[5]), .C(SDATA[3]), 
         .D(QP_adj_1913[2]), .Z(n3118)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i2666_3_lut_4_lut.init = 16'hf780;
    LUT4 i2375_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[5]), .C(OB[2]), 
         .D(CNT1_adj_1827), .Z(n2818)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i2375_3_lut_4_lut.init = 16'hf780;
    LUT4 i2373_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[5]), .C(OB[1]), 
         .D(CNT1_adj_1828), .Z(n2816)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i2373_3_lut_4_lut.init = 16'hf780;
    LUT4 i2383_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[5]), .C(OB[6]), 
         .D(CNT1_adj_1829), .Z(n2826)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i2383_3_lut_4_lut.init = 16'hf780;
    LUT4 i1335_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[5]), 
         .D(ZH_FF_adj_1830), .Z(CNT_7__N_1392_adj_1831)) /* synthesis lut_function=(A (B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i1335_3_lut_4_lut_4_lut.init = 16'hd580;
    LUT4 i2648_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[5]), .C(SDATA[1]), 
         .D(QP_adj_1915[0]), .Z(n3100)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i2648_3_lut_4_lut.init = 16'hf780;
    LUT4 i2369_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[6]), .C(OB[7]), 
         .D(CNT1_adj_1833), .Z(n2812)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i2369_3_lut_4_lut.init = 16'hf780;
    LUT4 i2455_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[6]), .C(OB[2]), 
         .D(CNT1_adj_1834), .Z(n2902)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i2455_3_lut_4_lut.init = 16'hf780;
    LUT4 i2577_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[6]), .C(OB[0]), 
         .D(CNT1_adj_1835), .Z(n3024)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i2577_3_lut_4_lut.init = 16'hf780;
    LUT4 i2365_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[6]), .C(OB[5]), 
         .D(CNT1_adj_1836), .Z(n2808)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i2365_3_lut_4_lut.init = 16'hf780;
    LUT4 i2688_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[4]), .C(SDATA[7]), 
         .D(QP_adj_1914[6]), .Z(n3140)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1359[53:80])
    defparam i2688_3_lut_4_lut.init = 16'hf780;
    LUT4 i2700_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[4]), .C(SDATA[6]), 
         .D(QP_adj_1907[5]), .Z(n3152)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i2700_3_lut_4_lut.init = 16'hf780;
    LUT4 i2575_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[6]), .C(OB[4]), 
         .D(CNT1_adj_1839), .Z(n3022)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i2575_3_lut_4_lut.init = 16'hf780;
    LUT4 i2658_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[5]), .C(SDATA[6]), 
         .D(QP_adj_1915[5]), .Z(n3110)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i2658_3_lut_4_lut.init = 16'hf780;
    LUT4 i2558_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[6]), .C(OB[3]), 
         .D(CNT1_adj_1841), .Z(n3005)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i2558_3_lut_4_lut.init = 16'hf780;
    LUT4 i1616_2_lut_2_lut (.A(Hnn[2]), .B(PCLK_c), .Z(n1993)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam i1616_2_lut_2_lut.init = 16'h2222;
    LUT4 n11322_bdd_4_lut (.A(n11322), .B(COL0[1]), .C(COL0[0]), .D(n2761), 
         .Z(ZCOL[0])) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11322_bdd_4_lut.init = 16'haad8;
    LUT4 i2428_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[6]), .C(OB[1]), 
         .D(CNT1_adj_1842), .Z(n2874)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i2428_3_lut_4_lut.init = 16'hf780;
    LUT4 n11292_bdd_4_lut (.A(n11292), .B(COL0[4]), .C(COL0[3]), .D(n2771), 
         .Z(n11295)) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11292_bdd_4_lut.init = 16'haad8;
    LUT4 i4566_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[1]), 
         .D(EN[1]), .Z(n5035)) /* synthesis lut_function=(!((B (C+!(D))+!B !(D))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i4566_2_lut_3_lut_4_lut_4_lut.init = 16'h2a00;
    LUT4 i2367_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[6]), .C(OB[6]), 
         .D(CNT1_adj_1843), .Z(n2810)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i2367_3_lut_4_lut.init = 16'hf780;
    LUT4 n11304_bdd_4_lut (.A(n11304), .B(ATR1[1]), .C(ATR0[1]), .D(n2761), 
         .Z(ZCOL[3])) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11304_bdd_4_lut.init = 16'haad8;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_444 (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[1]), 
         .D(EN[1]), .Z(Clk_enable_213)) /* synthesis lut_function=(A (B (C+(D))+!B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_444.init = 16'haa80;
    LUT4 PD_7__I_0_i1_3_lut (.A(PD_out_0), .B(PD_out_7), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i1_3_lut.init = 16'hcaca;
    LUT4 i7085_2_lut (.A(CLIPOR), .B(n7376), .Z(SPR[0])) /* synthesis lut_function=(A (B)) */ ;
    defparam i7085_2_lut.init = 16'h8888;
    LUT4 PD_FIFO_I_0_i2_2_lut (.A(PD_FIFO), .B(PD_LATCH[1]), .Z(SDATA[1])) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i2_2_lut.init = 16'h8888;
    LUT4 SEL_LATCH_7__I_362_2_lut (.A(Hnn[3]), .B(Hnn[4]), .Z(SEL_LATCH_7__N_1345)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1404[26:43])
    defparam SEL_LATCH_7__I_362_2_lut.init = 16'h4444;
    FD1P3IX SEL_LATCH_i0_i7 (.D(SEL_LATCH_7__N_1343), .SP(nPCLK), .CD(n5108), 
            .CK(Clk), .Q(SEL_LATCH[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i7.GSR = "DISABLED";
    LUT4 i2664_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[5]), .C(SDATA[2]), 
         .D(QP_adj_1913[1]), .Z(n3116)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i2664_3_lut_4_lut.init = 16'hf780;
    LUT4 PCLK_I_0_310_2_lut (.A(PCLK_c), .B(SH5), .Z(COL0_7__N_1237)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1350[54:64])
    defparam PCLK_I_0_310_2_lut.init = 16'h8888;
    LUT4 n2773_bdd_4_lut_10811 (.A(n2773), .B(COL0[5]), .C(n326[0]), .D(n2771), 
         .Z(n11292)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2773_bdd_4_lut_10811.init = 16'he4aa;
    LUT4 i4568_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[1]), .C(SEL_LATCH[1]), 
         .D(SH7), .Z(n5037)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i4568_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    FD1P3IX SEL_LATCH_i0_i6 (.D(SEL_LATCH_7__N_1345), .SP(nPCLK), .CD(n5108), 
            .CK(Clk), .Q(SEL_LATCH[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i6.GSR = "DISABLED";
    LUT4 SPR_6__N_1274_bdd_4_lut_10847 (.A(n10737), .B(n7490), .C(n7588), 
         .D(n7554), .Z(n11459)) /* synthesis lut_function=(!(A+(B (D)+!B (C+(D))))) */ ;
    defparam SPR_6__N_1274_bdd_4_lut_10847.init = 16'h0045;
    LUT4 PD_FIFO_I_0_i3_2_lut (.A(PD_FIFO), .B(PD_LATCH[2]), .Z(SDATA[2])) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i3_2_lut.init = 16'h8888;
    FD1P3IX SEL_LATCH_i0_i5 (.D(SEL_LATCH_7__N_1349), .SP(nPCLK), .CD(n5108), 
            .CK(Clk), .Q(SEL_LATCH[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i5.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_445 (.A(PCLK_c), .B(EN[1]), .C(SEL_LATCH[1]), 
         .D(SH7), .Z(Clk_enable_212)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_445.init = 16'ha888;
    FD1P3IX SEL_LATCH_i0_i4 (.D(SEL_LATCH_7__N_1353), .SP(nPCLK), .CD(n5108), 
            .CK(Clk), .Q(SEL_LATCH[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i4.GSR = "DISABLED";
    LUT4 PD_FIFO_I_0_i4_2_lut (.A(PD_FIFO), .B(PD_LATCH[3]), .Z(SDATA[3])) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i4_2_lut.init = 16'h8888;
    FD1P3IX SEL_LATCH_i0_i3 (.D(SEL_LATCH_7__N_1343), .SP(nPCLK), .CD(n5079), 
            .CK(Clk), .Q(SEL_LATCH[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i3.GSR = "DISABLED";
    FD1P3IX SEL_LATCH_i0_i2 (.D(SEL_LATCH_7__N_1345), .SP(nPCLK), .CD(n5079), 
            .CK(Clk), .Q(SEL_LATCH[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i2.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(n7490), .B(CLIPOR), .C(n7376), .D(n7584), 
         .Z(n4206)) /* synthesis lut_function=(A+((C+(D))+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1370[18:78])
    defparam i1_2_lut_3_lut_4_lut.init = 16'hfffb;
    FD1P3IX SEL_LATCH_i0_i1 (.D(SEL_LATCH_7__N_1349), .SP(nPCLK), .CD(n5079), 
            .CK(Clk), .Q(SEL_LATCH[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i1.GSR = "DISABLED";
    LUT4 n2763_bdd_4_lut (.A(n2763), .B(COL0[2]), .C(n11295), .D(n2761), 
         .Z(n11322)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2763_bdd_4_lut.init = 16'he4aa;
    LUT4 i1239_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[3]), 
         .D(ZH_FF_adj_1845), .Z(CNT_7__N_1392_adj_1846)) /* synthesis lut_function=(A (B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i1239_3_lut_4_lut_4_lut.init = 16'hd580;
    LUT4 n11400_bdd_4_lut (.A(n11400), .B(ATR4[1]), .C(ATR3[1]), .D(n2771), 
         .Z(n11281)) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11400_bdd_4_lut.init = 16'haad8;
    LUT4 i4570_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[2]), 
         .D(EN[2]), .Z(n5039)) /* synthesis lut_function=(!((B (C+!(D))+!B !(D))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i4570_2_lut_3_lut_4_lut_4_lut.init = 16'h2a00;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_446 (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[2]), 
         .D(EN[2]), .Z(Clk_enable_211)) /* synthesis lut_function=(A (B (C+(D))+!B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_446.init = 16'haa80;
    LUT4 n2773_bdd_4_lut_10831 (.A(n2773), .B(ATR5[1]), .C(n326[3]), .D(n2771), 
         .Z(n11400)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2773_bdd_4_lut_10831.init = 16'he4aa;
    LUT4 PD_FIFO_I_0_i5_2_lut (.A(PD_FIFO), .B(PD_LATCH[4]), .Z(SDATA[4])) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i5_2_lut.init = 16'h8888;
    LUT4 PD_FIFO_I_0_i6_2_lut (.A(PD_FIFO), .B(PD_LATCH[5]), .Z(SDATA[5])) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i6_2_lut.init = 16'h8888;
    LUT4 PD_FIFO_I_0_i7_2_lut (.A(PD_FIFO), .B(PD_LATCH[6]), .Z(SDATA[6])) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i7_2_lut.init = 16'h8888;
    LUT4 i4572_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[2]), .C(SEL_LATCH[2]), 
         .D(SH7), .Z(n5041)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i4572_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_447 (.A(PCLK_c), .B(EN[2]), .C(SEL_LATCH[2]), 
         .D(SH7), .Z(Clk_enable_210)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_447.init = 16'ha888;
    LUT4 i2662_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[5]), .C(SDATA[1]), 
         .D(QP_adj_1913[0]), .Z(n3114)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i2662_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_FIFO_I_0_i8_2_lut (.A(PD_FIFO), .B(PD_LATCH[7]), .Z(SDATA[7])) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i8_2_lut.init = 16'h8888;
    LUT4 i2802_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[0]), .C(SDATA[1]), 
         .D(QP_adj_1916[0]), .Z(n3254)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i2802_3_lut_4_lut.init = 16'hf780;
    LUT4 i2814_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[0]), .C(SDATA[7]), 
         .D(QP_adj_1916[6]), .Z(n3266)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i2814_3_lut_4_lut.init = 16'hf780;
    LUT4 i2804_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[0]), .C(SDATA[2]), 
         .D(QP_adj_1916[1]), .Z(n3256)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i2804_3_lut_4_lut.init = 16'hf780;
    LUT4 i2672_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[5]), .C(SDATA[6]), 
         .D(QP_adj_1913[5]), .Z(n3124)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i2672_3_lut_4_lut.init = 16'hf780;
    LUT4 i2806_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[0]), .C(SDATA[3]), 
         .D(QP_adj_1916[2]), .Z(n3258)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i2806_3_lut_4_lut.init = 16'hf780;
    LUT4 i2808_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[0]), .C(SDATA[4]), 
         .D(QP_adj_1916[3]), .Z(n3260)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i2808_3_lut_4_lut.init = 16'hf780;
    LUT4 i2810_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[0]), .C(SDATA[5]), 
         .D(QP_adj_1916[4]), .Z(n3262)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i2810_3_lut_4_lut.init = 16'hf780;
    LUT4 PCLK_I_0_355_2_lut (.A(PCLK_c), .B(SH7), .Z(COL1_7__N_1253)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1351[54:64])
    defparam PCLK_I_0_355_2_lut.init = 16'h8888;
    LUT4 i2812_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[0]), .C(SDATA[6]), 
         .D(QP_adj_1916[5]), .Z(n3264)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i2812_3_lut_4_lut.init = 16'hf780;
    LUT4 i2682_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[4]), .C(SDATA[4]), 
         .D(QP_adj_1914[3]), .Z(n3134)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1359[53:80])
    defparam i2682_3_lut_4_lut.init = 16'hf780;
    LUT4 n2763_bdd_4_lut_10748 (.A(n2763), .B(ATR2[1]), .C(n11281), .D(n2761), 
         .Z(n11304)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2763_bdd_4_lut_10748.init = 16'he4aa;
    LUT4 Hnn_3__I_0_2_lut (.A(Hnn[3]), .B(Hnn[4]), .Z(SEL_LATCH_7__N_1349)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1403[27:43])
    defparam Hnn_3__I_0_2_lut.init = 16'h2222;
    LUT4 mux_154_i5_4_lut (.A(ATR6[2]), .B(ATR7[2]), .C(SPR_6__N_1274), 
         .D(SPR_7__N_1261), .Z(n326[4])) /* synthesis lut_function=(!(A (B (C (D))+!B (C))+!A (((D)+!C)+!B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1383[20] 1385[28])
    defparam mux_154_i5_4_lut.init = 16'h0aca;
    LUT4 i2482_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[2]), .C(OB[0]), 
         .D(CNT1_adj_1857), .Z(n2929)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i2482_3_lut_4_lut.init = 16'hf780;
    LUT4 i2490_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[2]), .C(OB[4]), 
         .D(CNT1_adj_1858), .Z(n2937)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i2490_3_lut_4_lut.init = 16'hf780;
    LUT4 i2337_4_lut (.A(SPR_3__N_1307), .B(n7588), .C(n4206), .D(SPR_4__N_1297), 
         .Z(n2773)) /* synthesis lut_function=(A ((C+!(D))+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1367[11:14])
    defparam i2337_4_lut.init = 16'ha2aa;
    LUT4 i2492_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[2]), .C(OB[5]), 
         .D(CNT1_adj_1859), .Z(n2939)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i2492_3_lut_4_lut.init = 16'hf780;
    LUT4 i2335_2_lut (.A(SPR_3__N_1307), .B(SPR_4__N_1297), .Z(n2771)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1367[11:14])
    defparam i2335_2_lut.init = 16'h8888;
    FD1P3AX MIRR_LATCH_292 (.D(OB[6]), .SP(VINV_LATCH_N_896), .CK(Clk), 
            .Q(MIRR_LATCH));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam MIRR_LATCH_292.GSR = "DISABLED";
    LUT4 i2680_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[4]), .C(SDATA[3]), 
         .D(QP_adj_1914[2]), .Z(n3132)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1359[53:80])
    defparam i2680_3_lut_4_lut.init = 16'hf780;
    LUT4 i2494_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[2]), .C(OB[6]), 
         .D(CNT1_adj_1861), .Z(n2941)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i2494_3_lut_4_lut.init = 16'hf780;
    LUT4 i2496_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[2]), .C(OB[7]), 
         .D(CNT1_adj_1862), .Z(n2943)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i2496_3_lut_4_lut.init = 16'hf780;
    LUT4 i2484_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[2]), .C(OB[1]), 
         .D(CNT1_adj_1863), .Z(n2931)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i2484_3_lut_4_lut.init = 16'hf780;
    LUT4 i2486_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[2]), .C(OB[2]), 
         .D(CNT1_adj_1864), .Z(n2933)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i2486_3_lut_4_lut.init = 16'hf780;
    LUT4 i2488_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[2]), .C(OB[3]), 
         .D(CNT1_adj_1865), .Z(n2935)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i2488_3_lut_4_lut.init = 16'hf780;
    LUT4 i2583_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[7]), .C(OB[1]), 
         .D(CNT1_adj_1866), .Z(n3030)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i2583_3_lut_4_lut.init = 16'hf780;
    LUT4 i7142_3_lut (.A(COL0[5]), .B(EN[5]), .C(COL1[5]), .Z(n7588)) /* synthesis lut_function=(A (B)+!A (B (C))) */ ;
    defparam i7142_3_lut.init = 16'hc8c8;
    LUT4 i7138_3_lut (.A(EN[2]), .B(COL0[2]), .C(COL1[2]), .Z(n7584)) /* synthesis lut_function=(A (B+(C))) */ ;
    defparam i7138_3_lut.init = 16'ha8a8;
    LUT4 n11412_bdd_4_lut (.A(n11412), .B(ATR4[2]), .C(ATR3[2]), .D(n2771), 
         .Z(n11278)) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11412_bdd_4_lut.init = 16'haad8;
    LUT4 n2773_bdd_4_lut (.A(n2773), .B(ATR5[2]), .C(n326[4]), .D(n2771), 
         .Z(n11412)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2773_bdd_4_lut.init = 16'he4aa;
    LUT4 i2678_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[4]), .C(SDATA[2]), 
         .D(QP_adj_1914[1]), .Z(n3130)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1359[53:80])
    defparam i2678_3_lut_4_lut.init = 16'hf780;
    LUT4 i7046_3_lut (.A(COL0[1]), .B(EN[1]), .C(COL1[1]), .Z(n7490)) /* synthesis lut_function=(A (B)+!A (B (C))) */ ;
    defparam i7046_3_lut.init = 16'hc8c8;
    LUT4 i1_2_lut (.A(CLIPOR), .B(n7376), .Z(n4172)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1371[18:87])
    defparam i1_2_lut.init = 16'hdddd;
    LUT4 i10527_2_lut (.A(Hnn[3]), .B(Hnn[4]), .Z(SEL_LATCH_7__N_1353)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i10527_2_lut.init = 16'h1111;
    LUT4 i6932_3_lut (.A(COL0[0]), .B(EN[0]), .C(COL1[0]), .Z(n7376)) /* synthesis lut_function=(A (B)+!A (B (C))) */ ;
    defparam i6932_3_lut.init = 16'hc8c8;
    LUT4 i2516_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[0]), .C(OB[1]), 
         .D(CNT1_adj_1868), .Z(n2963)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i2516_3_lut_4_lut.init = 16'hf780;
    LUT4 i2579_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[7]), .C(OB[0]), 
         .D(CNT1_adj_1869), .Z(n3026)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i2579_3_lut_4_lut.init = 16'hf780;
    LUT4 n11310_bdd_4_lut (.A(n11310), .B(ATR1[0]), .C(ATR0[0]), .D(n2761), 
         .Z(ZCOL[2])) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11310_bdd_4_lut.init = 16'haad8;
    LUT4 i10288_3_lut (.A(COL0[4]), .B(EN[4]), .C(COL1[4]), .Z(n10737)) /* synthesis lut_function=(A (B)+!A (B (C))) */ ;
    defparam i10288_3_lut.init = 16'hc8c8;
    LUT4 i2518_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[0]), .C(OB[2]), 
         .D(CNT1_adj_1870), .Z(n2965)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i2518_3_lut_4_lut.init = 16'hf780;
    LUT4 i2_4_lut (.A(COL0[3]), .B(EN[3]), .C(COL1[3]), .D(n7490), .Z(n7554)) /* synthesis lut_function=(!(A ((D)+!B)+!A (((D)+!C)+!B))) */ ;
    defparam i2_4_lut.init = 16'h00c8;
    LUT4 i2520_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[0]), .C(OB[3]), 
         .D(CNT1_adj_1871), .Z(n2967)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i2520_3_lut_4_lut.init = 16'hf780;
    LUT4 n2763_bdd_4_lut_10753 (.A(n2763), .B(ATR2[0]), .C(n11284), .D(n2761), 
         .Z(n11310)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2763_bdd_4_lut_10753.init = 16'he4aa;
    LUT4 i1_4_lut (.A(n4209), .B(COL0[6]), .C(EN[6]), .D(COL1[6]), .Z(SPR_6__N_1274)) /* synthesis lut_function=(A+!(B (C)+!B (C (D)))) */ ;
    defparam i1_4_lut.init = 16'hafbf;
    LUT4 i3_4_lut (.A(EN[7]), .B(SPR_6__N_1274), .C(n4209), .D(n10749), 
         .Z(SPR_7__N_1261)) /* synthesis lut_function=(((C+!(D))+!B)+!A) */ ;
    defparam i3_4_lut.init = 16'hf7ff;
    LUT4 i2572_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[7]), .C(OB[7]), 
         .D(CNT1_adj_1872), .Z(n3019)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i2572_3_lut_4_lut.init = 16'hf780;
    LUT4 i10300_2_lut (.A(COL0[7]), .B(COL1[7]), .Z(n10749)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i10300_2_lut.init = 16'heeee;
    LUT4 i2676_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[4]), .C(SDATA[1]), 
         .D(QP_adj_1914[0]), .Z(n3128)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1359[53:80])
    defparam i2676_3_lut_4_lut.init = 16'hf780;
    LUT4 i2522_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[0]), .C(OB[4]), 
         .D(CNT1_adj_1874), .Z(n2969)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i2522_3_lut_4_lut.init = 16'hf780;
    LUT4 i2432_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[7]), .C(OB[3]), 
         .D(CNT1_adj_1875), .Z(n2878)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i2432_3_lut_4_lut.init = 16'hf780;
    LUT4 i2_3_lut_adj_448 (.A(n7490), .B(n7588), .C(n7554), .Z(n10417)) /* synthesis lut_function=(!(A+((C)+!B))) */ ;
    defparam i2_3_lut_adj_448.init = 16'h0404;
    FD1P3AX ZPOS_i2 (.D(ZPOS[1]), .SP(nPCLK), .CK(Clk), .Q(ZPOS[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ZPOS_i2.GSR = "DISABLED";
    FD1P3AX ZPOS_i1 (.D(ZPOS[0]), .SP(PCLK_c), .CK(Clk), .Q(ZPOS[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ZPOS_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN7_i0_i2 (.D(OB[5]), .SP(ATR_IN7_2__N_1368), .CK(Clk), 
            .Q(ATR_IN7[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN7_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN7_i0_i1 (.D(OB[1]), .SP(ATR_IN7_2__N_1368), .CK(Clk), 
            .Q(ATR_IN7[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN7_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN6_i0_i2 (.D(OB[5]), .SP(ATR_IN6_2__N_1367), .CK(Clk), 
            .Q(ATR_IN6[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN6_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN6_i0_i1 (.D(OB[1]), .SP(ATR_IN6_2__N_1367), .CK(Clk), 
            .Q(ATR_IN6[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN6_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN5_i0_i2 (.D(OB[5]), .SP(ATR_IN5_2__N_1366), .CK(Clk), 
            .Q(ATR_IN5[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN5_i0_i2.GSR = "DISABLED";
    FD1P3IX SEL_LATCH_i0_i0 (.D(SEL_LATCH_7__N_1353), .SP(nPCLK), .CD(n5079), 
            .CK(Clk), .Q(SEL_LATCH[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN5_i0_i1 (.D(OB[1]), .SP(ATR_IN5_2__N_1366), .CK(Clk), 
            .Q(ATR_IN5[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN5_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN4_i0_i2 (.D(OB[5]), .SP(ATR_IN4_2__N_1365), .CK(Clk), 
            .Q(ATR_IN4[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN4_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN4_i0_i1 (.D(OB[1]), .SP(ATR_IN4_2__N_1365), .CK(Clk), 
            .Q(ATR_IN4[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN4_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN3_i0_i2 (.D(OB[5]), .SP(ATR_IN3_2__N_1364), .CK(Clk), 
            .Q(ATR_IN3[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN3_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN3_i0_i1 (.D(OB[1]), .SP(ATR_IN3_2__N_1364), .CK(Clk), 
            .Q(ATR_IN3[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN3_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN2_i0_i2 (.D(OB[5]), .SP(ATR_IN2_2__N_1363), .CK(Clk), 
            .Q(ATR_IN2[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN2_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN2_i0_i1 (.D(OB[1]), .SP(ATR_IN2_2__N_1363), .CK(Clk), 
            .Q(ATR_IN2[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN2_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN1_i0_i2 (.D(OB[5]), .SP(ATR_IN1_2__N_1362), .CK(Clk), 
            .Q(ATR_IN1[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN1_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN1_i0_i1 (.D(OB[1]), .SP(ATR_IN1_2__N_1362), .CK(Clk), 
            .Q(ATR_IN1[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN1_i0_i1.GSR = "DISABLED";
    LUT4 i2524_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[0]), .C(OB[5]), 
         .D(CNT1_adj_1876), .Z(n2971)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i2524_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR7_i0_i2 (.D(ATR_IN7[2]), .SP(nPCLK), .CK(Clk), .Q(ATR7[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR7_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR7_i0_i1 (.D(ATR_IN7[1]), .SP(nPCLK), .CK(Clk), .Q(ATR7[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR7_i0_i1.GSR = "DISABLED";
    LUT4 mux_154_i4_4_lut (.A(ATR6[1]), .B(ATR7[1]), .C(SPR_6__N_1274), 
         .D(SPR_7__N_1261), .Z(n326[3])) /* synthesis lut_function=(!(A (B (C (D))+!B (C))+!A (((D)+!C)+!B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1383[20] 1385[28])
    defparam mux_154_i4_4_lut.init = 16'h0aca;
    LUT4 i2457_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[7]), .C(OB[4]), 
         .D(CNT1_adj_1877), .Z(n2904)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i2457_3_lut_4_lut.init = 16'hf780;
    LUT4 n11316_bdd_4_lut (.A(n11316), .B(COL1[1]), .C(COL1[0]), .D(n2761), 
         .Z(ZCOL[1])) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11316_bdd_4_lut.init = 16'haad8;
    LUT4 mux_154_i3_4_lut (.A(ATR6[0]), .B(ATR7[0]), .C(SPR_6__N_1274), 
         .D(SPR_7__N_1261), .Z(n326[2])) /* synthesis lut_function=(!(A (B (C (D))+!B (C))+!A (((D)+!C)+!B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1383[20] 1385[28])
    defparam mux_154_i3_4_lut.init = 16'h0aca;
    LUT4 PCLK_I_0_308_2_lut (.A(PCLK_c), .B(SH3), .Z(EN_7__N_1225)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1337[52:62])
    defparam PCLK_I_0_308_2_lut.init = 16'h8888;
    LUT4 n2763_bdd_4_lut_10758 (.A(n2763), .B(COL1[2]), .C(n11289), .D(n2761), 
         .Z(n11316)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2763_bdd_4_lut_10758.init = 16'he4aa;
    LUT4 n11286_bdd_4_lut (.A(n11286), .B(COL1[4]), .C(COL1[3]), .D(n2771), 
         .Z(n11289)) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11286_bdd_4_lut.init = 16'haad8;
    LUT4 mux_154_i2_4_lut (.A(COL1[6]), .B(COL1[7]), .C(SPR_6__N_1274), 
         .D(n10657), .Z(n326[1])) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1383[20] 1385[28])
    defparam mux_154_i2_4_lut.init = 16'hca0a;
    LUT4 i2686_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[4]), .C(SDATA[6]), 
         .D(QP_adj_1914[5]), .Z(n3138)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1359[53:80])
    defparam i2686_3_lut_4_lut.init = 16'hf780;
    LUT4 i2536_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[7]), .C(OB[5]), 
         .D(CNT1_adj_1879), .Z(n2983)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i2536_3_lut_4_lut.init = 16'hf780;
    LUT4 i2712_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[3]), .C(SDATA[5]), 
         .D(QP_adj_1917[4]), .Z(n3164)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1357[53:80])
    defparam i2712_3_lut_4_lut.init = 16'hf780;
    LUT4 i2718_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[3]), .C(SDATA[1]), 
         .D(QP_adj_1904[0]), .Z(n3170)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i2718_3_lut_4_lut.init = 16'hf780;
    FD1P3IX SH2_278 (.D(SH2_N_1373), .SP(nPCLK), .CD(n1993), .CK(Clk), 
            .Q(SH2));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SH2_278.GSR = "DISABLED";
    FD1P3IX SH3_279 (.D(SH3_N_1382), .SP(nPCLK), .CD(n1993), .CK(Clk), 
            .Q(SH3));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SH3_279.GSR = "DISABLED";
    FD1P3IX SH5_280 (.D(SH5_N_1386), .SP(nPCLK), .CD(n7400), .CK(Clk), 
            .Q(SH5));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SH5_280.GSR = "DISABLED";
    LUT4 i2716_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[3]), .C(SDATA[7]), 
         .D(QP_adj_1917[6]), .Z(n3168)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1357[53:80])
    defparam i2716_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_154_i1_4_lut (.A(COL0[6]), .B(COL0[7]), .C(SPR_6__N_1274), 
         .D(n10657), .Z(n326[0])) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1383[20] 1385[28])
    defparam mux_154_i1_4_lut.init = 16'hca0a;
    LUT4 i10476_4_lut (.A(CLIPOR), .B(n7584), .C(n7376), .D(n7490), 
         .Z(n2763)) /* synthesis lut_function=(!(A (B (C+!(D))+!B (C)))) */ ;
    defparam i10476_4_lut.init = 16'h5f57;
    LUT4 i2710_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[3]), .C(SDATA[4]), 
         .D(QP_adj_1917[3]), .Z(n3162)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1357[53:80])
    defparam i2710_3_lut_4_lut.init = 16'hf780;
    LUT4 i2738_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[2]), .C(SDATA[4]), 
         .D(QP_adj_1905[3]), .Z(n3190)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1355[53:80])
    defparam i2738_3_lut_4_lut.init = 16'hf780;
    LUT4 i2708_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[3]), .C(SDATA[3]), 
         .D(QP_adj_1917[2]), .Z(n3160)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1357[53:80])
    defparam i2708_3_lut_4_lut.init = 16'hf780;
    LUT4 i2706_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[3]), .C(SDATA[2]), 
         .D(QP_adj_1917[1]), .Z(n3158)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1357[53:80])
    defparam i2706_3_lut_4_lut.init = 16'hf780;
    LUT4 i10483_3_lut (.A(CLIPOR), .B(n7376), .C(n7490), .Z(n2761)) /* synthesis lut_function=(!(A (B+(C)))) */ ;
    defparam i10483_3_lut.init = 16'h5757;
    LUT4 i2704_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[3]), .C(SDATA[1]), 
         .D(QP_adj_1917[0]), .Z(n3156)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1357[53:80])
    defparam i2704_3_lut_4_lut.init = 16'hf780;
    LUT4 i2714_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[3]), .C(SDATA[6]), 
         .D(QP_adj_1917[5]), .Z(n3166)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1357[53:80])
    defparam i2714_3_lut_4_lut.init = 16'hf780;
    LUT4 i2728_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[3]), .C(SDATA[6]), 
         .D(QP_adj_1904[5]), .Z(n3180)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i2728_3_lut_4_lut.init = 16'hf780;
    LUT4 i2732_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[2]), .C(SDATA[1]), 
         .D(QP_adj_1905[0]), .Z(n3184)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1355[53:80])
    defparam i2732_3_lut_4_lut.init = 16'hf780;
    LUT4 i4574_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[3]), 
         .D(EN[3]), .Z(n5043)) /* synthesis lut_function=(!((B (C+!(D))+!B !(D))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i4574_2_lut_3_lut_4_lut_4_lut.init = 16'h2a00;
    LUT4 i2736_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[2]), .C(SDATA[3]), 
         .D(QP_adj_1905[2]), .Z(n3188)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1355[53:80])
    defparam i2736_3_lut_4_lut.init = 16'hf780;
    FD1P3IX SH7_281 (.D(SH3_N_1382), .SP(nPCLK), .CD(n7400), .CK(Clk), 
            .Q(SH7));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SH7_281.GSR = "DISABLED";
    LUT4 i2742_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[2]), .C(SDATA[6]), 
         .D(QP_adj_1905[5]), .Z(n3194)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1355[53:80])
    defparam i2742_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_449 (.A(PCLK_c), .B(SH5), .C(SEL_LATCH[3]), 
         .D(EN[3]), .Z(Clk_enable_209)) /* synthesis lut_function=(A (B (C+(D))+!B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_449.init = 16'haa80;
    LUT4 i10671_2_lut (.A(PCLK_c), .B(Hnn[5]), .Z(n5108)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i10671_2_lut.init = 16'h1111;
    LUT4 n2773_bdd_4_lut_10734 (.A(n2773), .B(COL1[5]), .C(n326[1]), .D(n2771), 
         .Z(n11286)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2773_bdd_4_lut_10734.init = 16'he4aa;
    LUT4 Hnn_3__I_0_353_2_lut (.A(Hnn[3]), .B(Hnn[4]), .Z(SEL_LATCH_7__N_1343)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1405[27:43])
    defparam Hnn_3__I_0_353_2_lut.init = 16'h8888;
    LUT4 i4580_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[4]), .C(SEL_LATCH[4]), 
         .D(SH7), .Z(n5049)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i4580_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_450 (.A(PCLK_c), .B(EN[4]), .C(SEL_LATCH[4]), 
         .D(SH7), .Z(Clk_enable_206)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_450.init = 16'ha888;
    LUT4 i2528_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[0]), .C(OB[7]), 
         .D(CNT1_adj_1893), .Z(n2975)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i2528_3_lut_4_lut.init = 16'hf780;
    LUT4 i4576_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[3]), .C(SEL_LATCH[3]), 
         .D(SH7), .Z(n5045)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i4576_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i2756_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[2]), .C(SDATA[6]), 
         .D(QP_adj_1918[5]), .Z(n3208)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i2756_3_lut_4_lut.init = 16'hf780;
    LUT4 ATR_IN0_2__I_365_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[0]), 
         .Z(ATR_IN0_2__N_1360)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1418[14:39])
    defparam ATR_IN0_2__I_365_2_lut_3_lut.init = 16'h8080;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_451 (.A(PCLK_c), .B(EN[3]), .C(SEL_LATCH[3]), 
         .D(SH7), .Z(Clk_enable_208)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_451.init = 16'ha888;
    LUT4 i2758_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[2]), .C(SDATA[7]), 
         .D(QP_adj_1918[6]), .Z(n3210)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i2758_3_lut_4_lut.init = 16'hf780;
    LUT4 i2754_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[2]), .C(SDATA[5]), 
         .D(QP_adj_1918[4]), .Z(n3206)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i2754_3_lut_4_lut.init = 16'hf780;
    LUT4 i2752_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[2]), .C(SDATA[4]), 
         .D(QP_adj_1918[3]), .Z(n3204)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i2752_3_lut_4_lut.init = 16'hf780;
    LUT4 i2750_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[2]), .C(SDATA[3]), 
         .D(QP_adj_1918[2]), .Z(n3202)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i2750_3_lut_4_lut.init = 16'hf780;
    LUT4 i2748_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[2]), .C(SDATA[2]), 
         .D(QP_adj_1918[1]), .Z(n3200)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i2748_3_lut_4_lut.init = 16'hf780;
    LUT4 i2746_3_lut_4_lut (.A(COL0_7__N_1237), .B(SEL_LATCH[2]), .C(SDATA[1]), 
         .D(QP_adj_1918[0]), .Z(n3198)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i2746_3_lut_4_lut.init = 16'hf780;
    LUT4 i2514_3_lut_4_lut (.A(EN_7__N_1225), .B(SEL_LATCH[0]), .C(OB[0]), 
         .D(CNT1_adj_1901), .Z(n2961)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i2514_3_lut_4_lut.init = 16'hf780;
    LUT4 i2740_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[2]), .C(SDATA[5]), 
         .D(QP_adj_1905[4]), .Z(n3192)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1355[53:80])
    defparam i2740_3_lut_4_lut.init = 16'hf780;
    LUT4 i2734_3_lut_4_lut (.A(COL1_7__N_1253), .B(SEL_LATCH[2]), .C(SDATA[2]), 
         .D(QP_adj_1905[1]), .Z(n3186)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1355[53:80])
    defparam i2734_3_lut_4_lut.init = 16'hf780;
    FIFO_HPOSCNT EN_7__I_0_330 (.PCLK_c(PCLK_c), .n3374(n3374), .\EN[7] (EN[7]), 
            .Clk(Clk), .nPCLK(nPCLK), .Clk_enable_52(Clk_enable_52), .nVIS(nVIS), 
            .\SEL_LATCH[7] (SEL_LATCH[7]), .SH3(SH3), .CNT1(CNT1_adj_1731), 
            .n3007(n3007), .CNT1_adj_64(CNT1_adj_1879), .n2983(n2983), 
            .CNT1_adj_65(CNT1_adj_1877), .n2904(n2904), .n2878(n2878), 
            .CNT1_adj_66(CNT1_adj_1875), .n2876(n2876), .CNT1_adj_67(CNT1_adj_1796), 
            .CNT1_adj_68(CNT1_adj_1866), .n3030(n3030), .CNT1_adj_69(CNT1_adj_1869), 
            .n3026(n3026), .CNT1_adj_70(CNT1_adj_1872), .n3019(n3019)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1344[14:103])
    FIFO_HPOSCNT_U78 EN_6__I_0_333 (.\EN[6] (EN[6]), .Clk(Clk), .nPCLK(nPCLK), 
            .PCLK_c(PCLK_c), .n3403(n3403), .nVIS(nVIS), .ZH_FF(ZH_FF_adj_1822), 
            .Clk_enable_51(Clk_enable_51), .CNT1(CNT1_adj_1843), .CNT_7__N_1392(CNT_7__N_1392_adj_1823), 
            .Clk_enable_62(Clk_enable_62), .n2810(n2810), .CNT1_adj_56(CNT1_adj_1836), 
            .n2808(n2808), .CNT1_adj_57(CNT1_adj_1839), .n3022(n3022), 
            .CNT1_adj_58(CNT1_adj_1841), .n3005(n3005), .CNT1_adj_59(CNT1_adj_1834), 
            .n2902(n2902), .n2874(n2874), .CNT1_adj_60(CNT1_adj_1842), 
            .CNT1_adj_61(CNT1_adj_1835), .n3024(n3024), .CNT1_adj_62(CNT1_adj_1833), 
            .n2812(n2812)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1343[14:103])
    FIFO_HPOSCNT_U79 EN_5__I_0_336 (.\EN[5] (EN[5]), .Clk(Clk), .nPCLK(nPCLK), 
            .CNT_7__N_1392(CNT_7__N_1392_adj_1831), .PCLK_c(PCLK_c), .n3423(n3423), 
            .nVIS(nVIS), .ZH_FF(ZH_FF_adj_1830), .Clk_enable_50(Clk_enable_50), 
            .n2826(n2826), .CNT1(CNT1_adj_1829), .CNT1_adj_48(CNT1_adj_1824), 
            .n2824(n2824), .CNT1_adj_49(CNT1_adj_1825), .n2822(n2822), 
            .CNT1_adj_50(CNT1_adj_1821), .n2820(n2820), .CNT1_adj_51(CNT1_adj_1827), 
            .n2818(n2818), .CNT1_adj_52(CNT1_adj_1828), .n2816(n2816), 
            .CNT1_adj_53(CNT1_adj_1815), .n2814(n2814), .CNT1_adj_54(CNT1_adj_1817), 
            .n2828(n2828)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1342[14:103])
    FIFO_HPOSCNT_U80 EN_4__I_0_339 (.PCLK_c(PCLK_c), .n3427(n3427), .\EN[4] (EN[4]), 
            .Clk(Clk), .nPCLK(nPCLK), .ZH_FF(ZH_FF_adj_1779), .Clk_enable_49(Clk_enable_49), 
            .CNT_7__N_1392(CNT_7__N_1392_adj_1780), .nVIS(nVIS), .CNT1(CNT1_adj_1740), 
            .n2856(n2856), .CNT1_adj_40(CNT1_adj_1738), .n2854(n2854), 
            .CNT1_adj_41(CNT1_adj_1741), .n2852(n2852), .CNT1_adj_42(CNT1_adj_1743), 
            .n2838(n2838), .CNT1_adj_43(CNT1_adj_1742), .n2836(n2836), 
            .CNT1_adj_44(CNT1_adj_1744), .n2834(n2834), .CNT1_adj_45(CNT1_adj_1737), 
            .n2832(n2832), .CNT1_adj_46(CNT1_adj_1739), .n2858(n2858)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1341[14:103])
    FIFO_HPOSCNT_U81 EN_3__I_0_342 (.\EN[3] (EN[3]), .Clk(Clk), .nPCLK(nPCLK), 
            .ZH_FF(ZH_FF_adj_1845), .Clk_enable_48(Clk_enable_48), .CNT_7__N_1392(CNT_7__N_1392_adj_1846), 
            .nVIS(nVIS), .PCLK_c(PCLK_c), .n3428(n3428), .CNT1(CNT1_adj_1761), 
            .n2925(n2925), .CNT1_adj_32(CNT1_adj_1762), .n2910(n2910), 
            .n2870(n2870), .CNT1_adj_33(CNT1_adj_1757), .CNT1_adj_34(CNT1_adj_1759), 
            .n2866(n2866), .n2864(n2864), .CNT1_adj_35(CNT1_adj_1754), 
            .CNT1_adj_36(CNT1_adj_1756), .n2862(n2862), .CNT1_adj_37(CNT1_adj_1752), 
            .n2860(n2860), .CNT1_adj_38(CNT1_adj_1760), .n2927(n2927)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1340[14:103])
    FIFO_HPOSCNT_U82 EN_2__I_0_345 (.CNT_7__N_1392(CNT_7__N_1392_adj_1792), 
            .\EN[2] (EN[2]), .Clk(Clk), .nPCLK(nPCLK), .ZH_FF(ZH_FF_adj_1791), 
            .Clk_enable_47(Clk_enable_47), .nVIS(nVIS), .PCLK_c(PCLK_c), 
            .n3429(n3429), .CNT1(CNT1_adj_1861), .n2941(n2941), .CNT1_adj_24(CNT1_adj_1859), 
            .n2939(n2939), .CNT1_adj_25(CNT1_adj_1858), .n2937(n2937), 
            .CNT1_adj_26(CNT1_adj_1865), .n2935(n2935), .CNT1_adj_27(CNT1_adj_1864), 
            .n2933(n2933), .CNT1_adj_28(CNT1_adj_1863), .n2931(n2931), 
            .CNT1_adj_29(CNT1_adj_1857), .n2929(n2929), .CNT1_adj_30(CNT1_adj_1862), 
            .n2943(n2943)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1339[14:103])
    FIFO_HPOSCNT_U83 EN_1__I_0_348 (.nVIS(nVIS), .ZH_FF(ZH_FF_adj_1785), 
            .\EN[1] (EN[1]), .Clk(Clk), .nPCLK(nPCLK), .PCLK_c(PCLK_c), 
            .n3430(n3430), .CNT_7__N_1392(CNT_7__N_1392_adj_1786), .Clk_enable_55(Clk_enable_55), 
            .CNT1(CNT1_adj_1728), .n2957(n2957), .CNT1_adj_16(CNT1_adj_1724), 
            .n2955(n2955), .CNT1_adj_17(CNT1_adj_1726), .n2953(n2953), 
            .CNT1_adj_18(CNT1_adj_1725), .n2951(n2951), .CNT1_adj_19(CNT1_adj_1729), 
            .n2949(n2949), .CNT1_adj_20(CNT1), .n2947(n2947), .CNT1_adj_21(CNT1_adj_1732), 
            .n2945(n2945), .CNT1_adj_22(CNT1_adj_1727), .n2959(n2959)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1338[14:103])
    FIFO_HPOSCNT_U84 EN_0__I_0_351 (.\EN[0] (EN[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .CNT_7__N_1392(CNT_7__N_1392), .nVIS(nVIS), .ZH_FF(ZH_FF), 
            .PCLK_c(PCLK_c), .\ZPOS[2] (ZPOS[2]), .n3403(n3403), .Clk_enable_51(Clk_enable_51), 
            .n3374(n3374), .Clk_enable_52(Clk_enable_52), .n3423(n3423), 
            .Clk_enable_50(Clk_enable_50), .n3427(n3427), .Clk_enable_49(Clk_enable_49), 
            .n3428(n3428), .Clk_enable_48(Clk_enable_48), .n3429(n3429), 
            .Clk_enable_47(Clk_enable_47), .n3430(n3430), .Clk_enable_55(Clk_enable_55), 
            .CNT1(CNT1_adj_1765), .n2973(n2973), .CNT1_adj_8(CNT1_adj_1876), 
            .n2971(n2971), .CNT1_adj_9(CNT1_adj_1874), .n2969(n2969), 
            .CNT1_adj_10(CNT1_adj_1871), .n2967(n2967), .CNT1_adj_11(CNT1_adj_1870), 
            .n2965(n2965), .CNT1_adj_12(CNT1_adj_1868), .n2963(n2963), 
            .CNT1_adj_13(CNT1_adj_1901), .n2961(n2961), .CNT1_adj_14(CNT1_adj_1893), 
            .n2975(n2975)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1337[14:103])
    SHIFTREG COL1_7__I_0 (.\QP[0] (QP_adj_1906[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .\QP[1] (QP_adj_1906[1]), .\QP[2] (QP_adj_1906[2]), .\QP[3] (QP_adj_1906[3]), 
            .\QP[4] (QP_adj_1906[4]), .\QP[5] (QP_adj_1906[5]), .\QP[6] (QP_adj_1906[6]), 
            .\COL1[7] (COL1[7]), .Clk_enable_200(Clk_enable_200), .n3044(n3044), 
            .n3046(n3046), .n3048(n3048), .n3050(n3050), .n3052(n3052), 
            .n3054(n3054), .n3056(n3056), .n5061(n5061), .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1365[10:105])
    SHIFTREG_U85 COL1_6__I_0 (.\QP[0] (QP_adj_1909[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .\QP[1] (QP_adj_1909[1]), .\QP[2] (QP_adj_1909[2]), .\QP[3] (QP_adj_1909[3]), 
            .\QP[4] (QP_adj_1909[4]), .\QP[5] (QP_adj_1909[5]), .\QP[6] (QP_adj_1909[6]), 
            .\COL1[6] (COL1[6]), .Clk_enable_202(Clk_enable_202), .n3072(n3072), 
            .n3074(n3074), .n3076(n3076), .n3078(n3078), .n3080(n3080), 
            .n3082(n3082), .n3084(n3084), .n5057(n5057), .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1363[10:105])
    SHIFTREG_U86 COL1_5__I_0 (.\QP[0] (QP_adj_1915[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .\QP[1] (QP_adj_1915[1]), .\QP[2] (QP_adj_1915[2]), .\QP[3] (QP_adj_1915[3]), 
            .\QP[4] (QP_adj_1915[4]), .\QP[5] (QP_adj_1915[5]), .\QP[6] (QP_adj_1915[6]), 
            .\COL1[5] (COL1[5]), .Clk_enable_204(Clk_enable_204), .n3100(n3100), 
            .n3102(n3102), .n3104(n3104), .n3106(n3106), .n3108(n3108), 
            .n3110(n3110), .n3112(n3112), .n5053(n5053), .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1361[10:105])
    SHIFTREG_U87 COL1_4__I_0 (.\QP[0] (QP_adj_1914[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .\QP[1] (QP_adj_1914[1]), .\QP[2] (QP_adj_1914[2]), .\QP[3] (QP_adj_1914[3]), 
            .\QP[4] (QP_adj_1914[4]), .\QP[5] (QP_adj_1914[5]), .\QP[6] (QP_adj_1914[6]), 
            .\COL1[4] (COL1[4]), .Clk_enable_206(Clk_enable_206), .n3128(n3128), 
            .n3130(n3130), .n3132(n3132), .n3134(n3134), .n3136(n3136), 
            .n3138(n3138), .n3140(n3140), .n5049(n5049), .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1359[10:105])
    SHIFTREG_U88 COL1_3__I_0 (.\QP[0] (QP_adj_1917[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .\QP[1] (QP_adj_1917[1]), .\QP[2] (QP_adj_1917[2]), .\QP[3] (QP_adj_1917[3]), 
            .\QP[4] (QP_adj_1917[4]), .\QP[5] (QP_adj_1917[5]), .\QP[6] (QP_adj_1917[6]), 
            .\COL1[3] (COL1[3]), .Clk_enable_208(Clk_enable_208), .n3156(n3156), 
            .n3158(n3158), .n3160(n3160), .n3162(n3162), .n3164(n3164), 
            .n3166(n3166), .n3168(n3168), .n5045(n5045), .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1357[10:105])
    SHIFTREG_U89 COL1_2__I_0 (.\QP[0] (QP_adj_1905[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .\QP[1] (QP_adj_1905[1]), .\QP[2] (QP_adj_1905[2]), .\QP[3] (QP_adj_1905[3]), 
            .\QP[4] (QP_adj_1905[4]), .\QP[5] (QP_adj_1905[5]), .\QP[6] (QP_adj_1905[6]), 
            .\COL1[2] (COL1[2]), .Clk_enable_210(Clk_enable_210), .n3184(n3184), 
            .n3186(n3186), .n3188(n3188), .n3190(n3190), .n3192(n3192), 
            .n3194(n3194), .n3196(n3196), .n5041(n5041), .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1355[10:105])
    SHIFTREG_U90 COL1_1__I_0 (.\QP[0] (QP[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .\QP[1] (QP[1]), .\QP[2] (QP[2]), .\QP[3] (QP[3]), .\QP[4] (QP[4]), 
            .\QP[5] (QP[5]), .\QP[6] (QP[6]), .\COL1[1] (COL1[1]), .Clk_enable_212(Clk_enable_212), 
            .n3212(n3212), .n3214(n3214), .n3216(n3216), .n3218(n3218), 
            .n3220(n3220), .n3222(n3222), .n3224(n3224), .n5037(n5037), 
            .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1353[10:105])
    SHIFTREG_U91 COL1_0__I_0 (.\QP[0] (QP_adj_1911[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .\QP[1] (QP_adj_1911[1]), .\QP[2] (QP_adj_1911[2]), .\QP[3] (QP_adj_1911[3]), 
            .\QP[4] (QP_adj_1911[4]), .\QP[5] (QP_adj_1911[5]), .\QP[6] (QP_adj_1911[6]), 
            .\COL1[0] (COL1[0]), .Clk_enable_214(Clk_enable_214), .n3240(n3240), 
            .n3242(n3242), .n3244(n3244), .n3246(n3246), .n3248(n3248), 
            .n3250(n3250), .n3252(n3252), .n5033(n5033), .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1351[10:105])
    SHIFTREG_U92 COL0_7__I_0_331 (.\QP[0] (QP_adj_1908[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .\QP[1] (QP_adj_1908[1]), .\QP[2] (QP_adj_1908[2]), .\QP[3] (QP_adj_1908[3]), 
            .\QP[4] (QP_adj_1908[4]), .\QP[5] (QP_adj_1908[5]), .\QP[6] (QP_adj_1908[6]), 
            .\COL0[7] (COL0[7]), .Clk_enable_201(Clk_enable_201), .n3058(n3058), 
            .n3060(n3060), .n3062(n3062), .n3064(n3064), .n3066(n3066), 
            .n3068(n3068), .n3070(n3070), .n5059(n5059), .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1364[10:105])
    SHIFTREG_U93 COL0_6__I_0_334 (.\QP[0] (QP_adj_1912[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .\QP[1] (QP_adj_1912[1]), .\QP[2] (QP_adj_1912[2]), .\QP[3] (QP_adj_1912[3]), 
            .\QP[4] (QP_adj_1912[4]), .\QP[5] (QP_adj_1912[5]), .\QP[6] (QP_adj_1912[6]), 
            .\COL0[6] (COL0[6]), .Clk_enable_203(Clk_enable_203), .n3086(n3086), 
            .n3088(n3088), .n3090(n3090), .n3092(n3092), .n3094(n3094), 
            .n3096(n3096), .n3098(n3098), .n5055(n5055), .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1362[10:105])
    SHIFTREG_U94 COL0_5__I_0_337 (.\QP[0] (QP_adj_1913[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .\QP[1] (QP_adj_1913[1]), .\QP[2] (QP_adj_1913[2]), .\QP[3] (QP_adj_1913[3]), 
            .\QP[4] (QP_adj_1913[4]), .\QP[5] (QP_adj_1913[5]), .\QP[6] (QP_adj_1913[6]), 
            .\COL0[5] (COL0[5]), .Clk_enable_205(Clk_enable_205), .n3114(n3114), 
            .n3116(n3116), .n3118(n3118), .n3120(n3120), .n3122(n3122), 
            .n3124(n3124), .n3126(n3126), .n5051(n5051), .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1360[10:105])
    SHIFTREG_U95 COL0_4__I_0_340 (.\QP[0] (QP_adj_1907[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .\QP[1] (QP_adj_1907[1]), .\QP[2] (QP_adj_1907[2]), .\QP[3] (QP_adj_1907[3]), 
            .\QP[4] (QP_adj_1907[4]), .\QP[5] (QP_adj_1907[5]), .\QP[6] (QP_adj_1907[6]), 
            .\COL0[4] (COL0[4]), .Clk_enable_207(Clk_enable_207), .n3142(n3142), 
            .n3144(n3144), .n3146(n3146), .n3148(n3148), .n3150(n3150), 
            .n3152(n3152), .n3154(n3154), .n5047(n5047), .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1358[10:105])
    SHIFTREG_U96 COL0_3__I_0_343 (.\QP[0] (QP_adj_1904[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .\QP[1] (QP_adj_1904[1]), .\QP[2] (QP_adj_1904[2]), .\QP[3] (QP_adj_1904[3]), 
            .\QP[4] (QP_adj_1904[4]), .\QP[5] (QP_adj_1904[5]), .\QP[6] (QP_adj_1904[6]), 
            .\COL0[3] (COL0[3]), .Clk_enable_209(Clk_enable_209), .n3170(n3170), 
            .n3172(n3172), .n3174(n3174), .n3176(n3176), .n3178(n3178), 
            .n3180(n3180), .n3182(n3182), .n5043(n5043), .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1356[10:105])
    SHIFTREG_U97 COL0_2__I_0_346 (.\QP[0] (QP_adj_1918[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .\QP[1] (QP_adj_1918[1]), .\QP[2] (QP_adj_1918[2]), .\QP[3] (QP_adj_1918[3]), 
            .\QP[4] (QP_adj_1918[4]), .\QP[5] (QP_adj_1918[5]), .\QP[6] (QP_adj_1918[6]), 
            .\COL0[2] (COL0[2]), .Clk_enable_211(Clk_enable_211), .n3198(n3198), 
            .n3200(n3200), .n3202(n3202), .n3204(n3204), .n3206(n3206), 
            .n3208(n3208), .n3210(n3210), .n5039(n5039), .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1354[10:105])
    SHIFTREG_U98 COL0_1__I_0_349 (.\QP[0] (QP_adj_1910[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .\QP[1] (QP_adj_1910[1]), .\QP[2] (QP_adj_1910[2]), .\QP[3] (QP_adj_1910[3]), 
            .\QP[4] (QP_adj_1910[4]), .\QP[5] (QP_adj_1910[5]), .\QP[6] (QP_adj_1910[6]), 
            .\COL0[1] (COL0[1]), .Clk_enable_213(Clk_enable_213), .n3226(n3226), 
            .n3228(n3228), .n3230(n3230), .n3232(n3232), .n3234(n3234), 
            .n3236(n3236), .n3238(n3238), .n5035(n5035), .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1352[10:105])
    SHIFTREG_U99 COL0_0__I_0_352 (.\QP[0] (QP_adj_1916[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_215(Clk_enable_215), .n3254(n3254), .n3256(n3256), 
            .n3258(n3258), .n3260(n3260), .n3262(n3262), .n3264(n3264), 
            .n3266(n3266), .\QP[1] (QP_adj_1916[1]), .\QP[2] (QP_adj_1916[2]), 
            .\QP[3] (QP_adj_1916[3]), .\QP[4] (QP_adj_1916[4]), .\QP[5] (QP_adj_1916[5]), 
            .\QP[6] (QP_adj_1916[6]), .\COL0[0] (COL0[0]), .n5031(n5031), 
            .\SDATA[0] (SDATA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1350[10:105])
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT
//

module FIFO_HPOSCNT (PCLK_c, n3374, \EN[7] , Clk, nPCLK, Clk_enable_52, 
            nVIS, \SEL_LATCH[7] , SH3, CNT1, n3007, CNT1_adj_64, 
            n2983, CNT1_adj_65, n2904, n2878, CNT1_adj_66, n2876, 
            CNT1_adj_67, CNT1_adj_68, n3030, CNT1_adj_69, n3026, CNT1_adj_70, 
            n3019) /* synthesis syn_module_defined=1 */ ;
    input PCLK_c;
    output n3374;
    output \EN[7] ;
    input Clk;
    input nPCLK;
    input Clk_enable_52;
    input nVIS;
    input \SEL_LATCH[7] ;
    input SH3;
    output CNT1;
    input n3007;
    output CNT1_adj_64;
    input n2983;
    output CNT1_adj_65;
    input n2904;
    input n2878;
    output CNT1_adj_66;
    input n2876;
    output CNT1_adj_67;
    output CNT1_adj_68;
    input n3030;
    output CNT1_adj_69;
    input n3026;
    output CNT1_adj_70;
    input n3019;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire ZH_FF_N_1401;
    wire [7:0]CNT;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire n14, n10, EN_N_1395, ZH_FF, Clk_enable_61, CNT_7__N_1392, 
        n7618, CNT1_N_565, n7654, CNT1_N_565_adj_1718, CNT1_N_565_adj_1720;
    
    LUT4 i10624_2_lut (.A(PCLK_c), .B(n3374), .Z(ZH_FF_N_1401)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam i10624_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3374)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(nPCLK), .CK(Clk), .Q(\EN[7] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    FD1P3AX ZH_FF_36 (.D(ZH_FF_N_1401), .SP(Clk_enable_52), .CK(Clk), 
            .Q(ZH_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    LUT4 i10603_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i10603_2_lut.init = 16'h1111;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(ZH_FF), .C(\SEL_LATCH[7] ), 
         .D(SH3), .Z(Clk_enable_61)) /* synthesis lut_function=(A (C (D))+!A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1449[16:33])
    defparam i1_2_lut_3_lut_4_lut_4_lut.init = 16'he444;
    LUT4 i10600_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(ZH_FF), .C(\SEL_LATCH[7] ), 
         .D(SH3), .Z(CNT_7__N_1392)) /* synthesis lut_function=(!(A (C (D))+!A (B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1449[16:33])
    defparam i10600_2_lut_3_lut_4_lut_4_lut.init = 16'h1bbb;
    COUNTER FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[6] (CNT[6]), .Clk_enable_61(Clk_enable_61), .n3007(n3007), 
            .\CNT[4] (CNT[4]), .n7618(n7618), .\CNT[5] (CNT[5])) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U0 FIFOCNT_5 (.CNT1(CNT1_adj_64), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565), .\CNT[5] (CNT[5]), .Clk_enable_61(Clk_enable_61), 
            .n2983(n2983)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U1 FIFOCNT_4 (.CNT1(CNT1_adj_65), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[4] (CNT[4]), .n7618(n7618), .Clk_enable_61(Clk_enable_61), 
            .n2904(n2904), .\CNT[5] (CNT[5]), .n7654(n7654), .CNT1_N_565(CNT1_N_565)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U2 FIFOCNT_3 (.\CNT[3] (CNT[3]), .Clk(Clk), .Clk_enable_61(Clk_enable_61), 
            .n2878(n2878), .CNT1(CNT1_adj_66), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1718)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U3 FIFOCNT_2 (.\CNT[2] (CNT[2]), .Clk(Clk), .Clk_enable_61(Clk_enable_61), 
            .n2876(n2876), .CNT1(CNT1_adj_67), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1720)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U4 FIFOCNT_1 (.CNT1(CNT1_adj_68), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .\CNT[2] (CNT[2]), .CNT1_N_565(CNT1_N_565_adj_1720), 
            .\CNT[3] (CNT[3]), .n7618(n7618), .CNT1_N_565_adj_63(CNT1_N_565_adj_1718), 
            .Clk_enable_61(Clk_enable_61), .n3030(n3030)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U5 FIFOCNT_0 (.CNT1(CNT1_adj_69), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[0] (CNT[0]), .Clk_enable_61(Clk_enable_61), .n3026(n3026)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U6 CNT_7__I_0_39 (.\CNT[7] (CNT[7]), .\CNT[6] (CNT[6]), .n7654(n7654), 
            .CNT1(CNT1_adj_70), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .Clk_enable_61(Clk_enable_61), .n3019(n3019)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER
//

module COUNTER (CNT1, Clk, CNT_7__N_1392, \CNT[6] , Clk_enable_61, 
            n3007, \CNT[4] , n7618, \CNT[5] ) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[6] ;
    input Clk_enable_61;
    input n3007;
    input \CNT[4] ;
    input n7618;
    input \CNT[5] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n3007), .SP(Clk_enable_61), .CK(Clk), .Q(\CNT[6] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_4_lut (.A(\CNT[6] ), .B(\CNT[4] ), .C(n7618), .D(\CNT[5] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(A (B+(C+(D)))+!A !(B+(C+(D)))) */ ;
    defparam i1_2_lut_4_lut.init = 16'haaa9;
    
endmodule
//
// Verilog Description of module COUNTER_U0
//

module COUNTER_U0 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[5] , 
            Clk_enable_61, n2983) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[5] ;
    input Clk_enable_61;
    input n2983;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2983), .SP(Clk_enable_61), .CK(Clk), .Q(\CNT[5] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U1
//

module COUNTER_U1 (CNT1, Clk, CNT_7__N_1392, \CNT[4] , n7618, Clk_enable_61, 
            n2904, \CNT[5] , n7654, CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[4] ;
    input n7618;
    input Clk_enable_61;
    input n2904;
    input \CNT[5] ;
    output n7654;
    output CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[4] ), .B(n7618), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    FD1P3AX CNT_14 (.D(n2904), .SP(Clk_enable_61), .CK(Clk), .Q(\CNT[4] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i7208_2_lut_3_lut (.A(\CNT[4] ), .B(n7618), .C(\CNT[5] ), .Z(n7654)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7208_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[4] ), .B(n7618), .C(\CNT[5] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    
endmodule
//
// Verilog Description of module COUNTER_U2
//

module COUNTER_U2 (\CNT[3] , Clk, Clk_enable_61, n2878, CNT1, CNT_7__N_1392, 
            CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    output \CNT[3] ;
    input Clk;
    input Clk_enable_61;
    input n2878;
    output CNT1;
    input CNT_7__N_1392;
    input CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT_14 (.D(n2878), .SP(Clk_enable_61), .CK(Clk), .Q(\CNT[3] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U3
//

module COUNTER_U3 (\CNT[2] , Clk, Clk_enable_61, n2876, CNT1, CNT_7__N_1392, 
            CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input Clk;
    input Clk_enable_61;
    input n2876;
    output CNT1;
    input CNT_7__N_1392;
    input CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT_14 (.D(n2876), .SP(Clk_enable_61), .CK(Clk), .Q(\CNT[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U4
//

module COUNTER_U4 (CNT1, Clk, CNT_7__N_1392, \CNT[1] , \CNT[0] , \CNT[2] , 
            CNT1_N_565, \CNT[3] , n7618, CNT1_N_565_adj_63, Clk_enable_61, 
            n3030) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[1] ;
    input \CNT[0] ;
    input \CNT[2] ;
    output CNT1_N_565;
    input \CNT[3] ;
    output n7618;
    output CNT1_N_565_adj_63;
    input Clk_enable_61;
    input n3030;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i7172_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n7618)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i7172_2_lut_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_565_adj_63)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT_14 (.D(n3030), .SP(Clk_enable_61), .CK(Clk), .Q(\CNT[1] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U5
//

module COUNTER_U5 (CNT1, Clk, CNT_7__N_1392, \CNT[0] , Clk_enable_61, 
            n3026) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[0] ;
    input Clk_enable_61;
    input n3026;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n3026), .SP(Clk_enable_61), .CK(Clk), .Q(\CNT[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module COUNTER_U6
//

module COUNTER_U6 (\CNT[7] , \CNT[6] , n7654, CNT1, Clk, CNT_7__N_1392, 
            Clk_enable_61, n3019) /* synthesis syn_module_defined=1 */ ;
    output \CNT[7] ;
    input \CNT[6] ;
    input n7654;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input Clk_enable_61;
    input n3019;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565;
    
    LUT4 i1_3_lut (.A(\CNT[7] ), .B(\CNT[6] ), .C(n7654), .Z(CNT1_N_565)) /* synthesis lut_function=(A (B+(C))+!A !(B+(C))) */ ;
    defparam i1_3_lut.init = 16'ha9a9;
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n3019), .SP(Clk_enable_61), .CK(Clk), .Q(\CNT[7] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U78
//

module FIFO_HPOSCNT_U78 (\EN[6] , Clk, nPCLK, PCLK_c, n3403, nVIS, 
            ZH_FF, Clk_enable_51, CNT1, CNT_7__N_1392, Clk_enable_62, 
            n2810, CNT1_adj_56, n2808, CNT1_adj_57, n3022, CNT1_adj_58, 
            n3005, CNT1_adj_59, n2902, n2874, CNT1_adj_60, CNT1_adj_61, 
            n3024, CNT1_adj_62, n2812) /* synthesis syn_module_defined=1 */ ;
    output \EN[6] ;
    input Clk;
    input nPCLK;
    input PCLK_c;
    output n3403;
    input nVIS;
    output ZH_FF;
    input Clk_enable_51;
    output CNT1;
    input CNT_7__N_1392;
    input Clk_enable_62;
    input n2810;
    output CNT1_adj_56;
    input n2808;
    output CNT1_adj_57;
    input n3022;
    output CNT1_adj_58;
    input n3005;
    output CNT1_adj_59;
    input n2902;
    input n2874;
    output CNT1_adj_60;
    output CNT1_adj_61;
    input n3024;
    output CNT1_adj_62;
    input n2812;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire EN_N_1395, ZH_FF_N_1401;
    wire [7:0]CNT;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire n14, n10, CNT1_N_565, n7636, CNT1_N_565_adj_1703, CNT1_N_565_adj_1705, 
        n7576, CNT1_N_565_adj_1708;
    
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(nPCLK), .CK(Clk), .Q(\EN[6] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 i10627_2_lut (.A(PCLK_c), .B(n3403), .Z(ZH_FF_N_1401)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam i10627_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3403)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 i10598_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i10598_2_lut.init = 16'h1111;
    FD1P3AX ZH_FF_36 (.D(ZH_FF_N_1401), .SP(Clk_enable_51), .CK(Clk), 
            .Q(ZH_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    COUNTER_U7 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565), .\CNT[6] (CNT[6]), .Clk_enable_62(Clk_enable_62), 
            .n2810(n2810)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U8 FIFOCNT_5 (.CNT1(CNT1_adj_56), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[5] (CNT[5]), .Clk_enable_62(Clk_enable_62), .n2808(n2808), 
            .n7636(n7636), .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_565(CNT1_N_565_adj_1703), 
            .CNT1_N_565_adj_55(CNT1_N_565)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U9 FIFOCNT_4 (.CNT1(CNT1_adj_57), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1705), .\CNT[4] (CNT[4]), .Clk_enable_62(Clk_enable_62), 
            .n3022(n3022)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U10 FIFOCNT_3 (.CNT1(CNT1_adj_58), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[3] (CNT[3]), .Clk_enable_62(Clk_enable_62), .n3005(n3005), 
            .n7576(n7576), .\CNT[4] (CNT[4]), .n7636(n7636), .CNT1_N_565(CNT1_N_565_adj_1705)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U11 FIFOCNT_2 (.CNT1(CNT1_adj_59), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1708), .\CNT[2] (CNT[2]), .Clk_enable_62(Clk_enable_62), 
            .n2902(n2902)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U12 FIFOCNT_1 (.\CNT[1] (CNT[1]), .Clk(Clk), .Clk_enable_62(Clk_enable_62), 
            .n2874(n2874), .\CNT[0] (CNT[0]), .\CNT[2] (CNT[2]), .n7576(n7576), 
            .CNT1_N_565(CNT1_N_565_adj_1708), .CNT1(CNT1_adj_60), .CNT_7__N_1392(CNT_7__N_1392)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U13 FIFOCNT_0 (.CNT1(CNT1_adj_61), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[0] (CNT[0]), .Clk_enable_62(Clk_enable_62), .n3024(n3024)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U14 CNT_7__I_0_39 (.CNT1(CNT1_adj_62), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1703), .\CNT[7] (CNT[7]), .Clk_enable_62(Clk_enable_62), 
            .n2812(n2812)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U7
//

module COUNTER_U7 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[6] , 
            Clk_enable_62, n2810) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[6] ;
    input Clk_enable_62;
    input n2810;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2810), .SP(Clk_enable_62), .CK(Clk), .Q(\CNT[6] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U8
//

module COUNTER_U8 (CNT1, Clk, CNT_7__N_1392, \CNT[5] , Clk_enable_62, 
            n2808, n7636, \CNT[6] , \CNT[7] , CNT1_N_565, CNT1_N_565_adj_55) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[5] ;
    input Clk_enable_62;
    input n2808;
    input n7636;
    input \CNT[6] ;
    input \CNT[7] ;
    output CNT1_N_565;
    output CNT1_N_565_adj_55;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2808), .SP(Clk_enable_62), .CK(Clk), .Q(\CNT[5] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[5] ), .B(n7636), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n7636), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    LUT4 i1_2_lut_3_lut (.A(\CNT[5] ), .B(n7636), .C(\CNT[6] ), .Z(CNT1_N_565_adj_55)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    
endmodule
//
// Verilog Description of module COUNTER_U9
//

module COUNTER_U9 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[4] , 
            Clk_enable_62, n3022) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[4] ;
    input Clk_enable_62;
    input n3022;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n3022), .SP(Clk_enable_62), .CK(Clk), .Q(\CNT[4] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U10
//

module COUNTER_U10 (CNT1, Clk, CNT_7__N_1392, \CNT[3] , Clk_enable_62, 
            n3005, n7576, \CNT[4] , n7636, CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[3] ;
    input Clk_enable_62;
    input n3005;
    input n7576;
    input \CNT[4] ;
    output n7636;
    output CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n3005), .SP(Clk_enable_62), .CK(Clk), .Q(\CNT[3] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i7190_2_lut_3_lut (.A(\CNT[3] ), .B(n7576), .C(\CNT[4] ), .Z(n7636)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7190_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[3] ), .B(n7576), .C(\CNT[4] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i1_2_lut (.A(\CNT[3] ), .B(n7576), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U11
//

module COUNTER_U11 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[2] , 
            Clk_enable_62, n2902) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[2] ;
    input Clk_enable_62;
    input n2902;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2902), .SP(Clk_enable_62), .CK(Clk), .Q(\CNT[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U12
//

module COUNTER_U12 (\CNT[1] , Clk, Clk_enable_62, n2874, \CNT[0] , 
            \CNT[2] , n7576, CNT1_N_565, CNT1, CNT_7__N_1392) /* synthesis syn_module_defined=1 */ ;
    output \CNT[1] ;
    input Clk;
    input Clk_enable_62;
    input n2874;
    input \CNT[0] ;
    input \CNT[2] ;
    output n7576;
    output CNT1_N_565;
    output CNT1;
    input CNT_7__N_1392;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_adj_1698;
    
    FD1P3AX CNT_14 (.D(n2874), .SP(Clk_enable_62), .CK(Clk), .Q(\CNT[1] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i7130_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n7576)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7130_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1698), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_adj_1698)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U13
//

module COUNTER_U13 (CNT1, Clk, CNT_7__N_1392, \CNT[0] , Clk_enable_62, 
            n3024) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[0] ;
    input Clk_enable_62;
    input n3024;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n3024), .SP(Clk_enable_62), .CK(Clk), .Q(\CNT[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module COUNTER_U14
//

module COUNTER_U14 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[7] , 
            Clk_enable_62, n2812) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[7] ;
    input Clk_enable_62;
    input n2812;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2812), .SP(Clk_enable_62), .CK(Clk), .Q(\CNT[7] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U79
//

module FIFO_HPOSCNT_U79 (\EN[5] , Clk, nPCLK, CNT_7__N_1392, PCLK_c, 
            n3423, nVIS, ZH_FF, Clk_enable_50, n2826, CNT1, CNT1_adj_48, 
            n2824, CNT1_adj_49, n2822, CNT1_adj_50, n2820, CNT1_adj_51, 
            n2818, CNT1_adj_52, n2816, CNT1_adj_53, n2814, CNT1_adj_54, 
            n2828) /* synthesis syn_module_defined=1 */ ;
    output \EN[5] ;
    input Clk;
    input nPCLK;
    input CNT_7__N_1392;
    input PCLK_c;
    output n3423;
    input nVIS;
    output ZH_FF;
    input Clk_enable_50;
    input n2826;
    output CNT1;
    output CNT1_adj_48;
    input n2824;
    output CNT1_adj_49;
    input n2822;
    output CNT1_adj_50;
    input n2820;
    output CNT1_adj_51;
    input n2818;
    output CNT1_adj_52;
    input n2816;
    output CNT1_adj_53;
    input n2814;
    output CNT1_adj_54;
    input n2828;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire EN_N_1395, CNT_7__N_1391, ZH_FF_N_1401;
    wire [7:0]CNT;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire n14, n10, CNT1_N_565, n7634, CNT1_N_565_adj_1689, CNT1_N_565_adj_1691, 
        n7574, CNT1_N_565_adj_1694;
    
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(nPCLK), .CK(Clk), .Q(\EN[5] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 CNT_7__I_371_1_lut (.A(CNT_7__N_1392), .Z(CNT_7__N_1391)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[28:42])
    defparam CNT_7__I_371_1_lut.init = 16'h5555;
    LUT4 i10630_2_lut (.A(PCLK_c), .B(n3423), .Z(ZH_FF_N_1401)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam i10630_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3423)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 i10588_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i10588_2_lut.init = 16'h1111;
    FD1P3AX ZH_FF_36 (.D(ZH_FF_N_1401), .SP(Clk_enable_50), .CK(Clk), 
            .Q(ZH_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    COUNTER_U15 FIFOCNT_6 (.\CNT[6] (CNT[6]), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2826(n2826), .CNT1(CNT1), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U16 FIFOCNT_5 (.CNT1(CNT1_adj_48), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .\CNT[5] (CNT[5]), .CNT_7__N_1392(CNT_7__N_1392), .n2824(n2824), 
            .n7634(n7634), .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_565(CNT1_N_565_adj_1689), 
            .CNT1_N_565_adj_47(CNT1_N_565)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U17 FIFOCNT_4 (.CNT1(CNT1_adj_49), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1691), .\CNT[4] (CNT[4]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2822(n2822)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U18 FIFOCNT_3 (.CNT1(CNT1_adj_50), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .\CNT[3] (CNT[3]), .CNT_7__N_1392(CNT_7__N_1392), .n2820(n2820), 
            .n7574(n7574), .\CNT[4] (CNT[4]), .CNT1_N_565(CNT1_N_565_adj_1691), 
            .n7634(n7634)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U19 FIFOCNT_2 (.CNT1(CNT1_adj_51), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1694), .\CNT[2] (CNT[2]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2818(n2818)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U20 FIFOCNT_1 (.CNT1(CNT1_adj_52), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .\CNT[1] (CNT[1]), .CNT_7__N_1392(CNT_7__N_1392), .n2816(n2816), 
            .\CNT[0] (CNT[0]), .\CNT[2] (CNT[2]), .n7574(n7574), .CNT1_N_565(CNT1_N_565_adj_1694)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U21 FIFOCNT_0 (.\CNT[0] (CNT[0]), .CNT1(CNT1_adj_53), .Clk(Clk), 
            .CNT_7__N_1391(CNT_7__N_1391), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2814(n2814)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U22 CNT_7__I_0_39 (.CNT1(CNT1_adj_54), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1689), .\CNT[7] (CNT[7]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2828(n2828)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U15
//

module COUNTER_U15 (\CNT[6] , Clk, CNT_7__N_1392, n2826, CNT1, CNT_7__N_1391, 
            CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    output \CNT[6] ;
    input Clk;
    input CNT_7__N_1392;
    input n2826;
    output CNT1;
    input CNT_7__N_1391;
    input CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT_14 (.D(n2826), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[6] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U16
//

module COUNTER_U16 (CNT1, Clk, CNT_7__N_1391, \CNT[5] , CNT_7__N_1392, 
            n2824, n7634, \CNT[6] , \CNT[7] , CNT1_N_565, CNT1_N_565_adj_47) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    output \CNT[5] ;
    input CNT_7__N_1392;
    input n2824;
    input n7634;
    input \CNT[6] ;
    input \CNT[7] ;
    output CNT1_N_565;
    output CNT1_N_565_adj_47;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2824), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[5] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[5] ), .B(n7634), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n7634), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    LUT4 i1_2_lut_3_lut (.A(\CNT[5] ), .B(n7634), .C(\CNT[6] ), .Z(CNT1_N_565_adj_47)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    
endmodule
//
// Verilog Description of module COUNTER_U17
//

module COUNTER_U17 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[4] , 
            CNT_7__N_1392, n2822) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[4] ;
    input CNT_7__N_1392;
    input n2822;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2822), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[4] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U18
//

module COUNTER_U18 (CNT1, Clk, CNT_7__N_1391, \CNT[3] , CNT_7__N_1392, 
            n2820, n7574, \CNT[4] , CNT1_N_565, n7634) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    output \CNT[3] ;
    input CNT_7__N_1392;
    input n2820;
    input n7574;
    input \CNT[4] ;
    output CNT1_N_565;
    output n7634;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2820), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[3] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut (.A(\CNT[3] ), .B(n7574), .C(\CNT[4] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i7188_2_lut_3_lut (.A(\CNT[3] ), .B(n7574), .C(\CNT[4] ), .Z(n7634)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7188_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut (.A(\CNT[3] ), .B(n7574), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U19
//

module COUNTER_U19 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[2] , 
            CNT_7__N_1392, n2818) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[2] ;
    input CNT_7__N_1392;
    input n2818;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2818), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U20
//

module COUNTER_U20 (CNT1, Clk, CNT_7__N_1391, \CNT[1] , CNT_7__N_1392, 
            n2816, \CNT[0] , \CNT[2] , n7574, CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    output \CNT[1] ;
    input CNT_7__N_1392;
    input n2816;
    input \CNT[0] ;
    input \CNT[2] ;
    output n7574;
    output CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2816), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[1] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i7128_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n7574)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7128_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U21
//

module COUNTER_U21 (\CNT[0] , CNT1, Clk, CNT_7__N_1391, CNT_7__N_1392, 
            n2814) /* synthesis syn_module_defined=1 */ ;
    output \CNT[0] ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2814;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2814), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U22
//

module COUNTER_U22 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[7] , 
            CNT_7__N_1392, n2828) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[7] ;
    input CNT_7__N_1392;
    input n2828;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2828), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[7] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U80
//

module FIFO_HPOSCNT_U80 (PCLK_c, n3427, \EN[4] , Clk, nPCLK, ZH_FF, 
            Clk_enable_49, CNT_7__N_1392, nVIS, CNT1, n2856, CNT1_adj_40, 
            n2854, CNT1_adj_41, n2852, CNT1_adj_42, n2838, CNT1_adj_43, 
            n2836, CNT1_adj_44, n2834, CNT1_adj_45, n2832, CNT1_adj_46, 
            n2858) /* synthesis syn_module_defined=1 */ ;
    input PCLK_c;
    output n3427;
    output \EN[4] ;
    input Clk;
    input nPCLK;
    output ZH_FF;
    input Clk_enable_49;
    input CNT_7__N_1392;
    input nVIS;
    output CNT1;
    input n2856;
    output CNT1_adj_40;
    input n2854;
    output CNT1_adj_41;
    input n2852;
    output CNT1_adj_42;
    input n2838;
    output CNT1_adj_43;
    input n2836;
    output CNT1_adj_44;
    input n2834;
    output CNT1_adj_45;
    input n2832;
    output CNT1_adj_46;
    input n2858;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire ZH_FF_N_1401;
    wire [7:0]CNT;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire n14, n10, EN_N_1395, CNT_7__N_1391, CNT1_N_565, n7632, 
        CNT1_N_565_adj_1675, CNT1_N_565_adj_1677, n7572, CNT1_N_565_adj_1680;
    
    LUT4 i10634_2_lut (.A(PCLK_c), .B(n3427), .Z(ZH_FF_N_1401)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam i10634_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3427)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(nPCLK), .CK(Clk), .Q(\EN[4] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    FD1P3AX ZH_FF_36 (.D(ZH_FF_N_1401), .SP(Clk_enable_49), .CK(Clk), 
            .Q(ZH_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    LUT4 CNT_7__I_371_1_lut (.A(CNT_7__N_1392), .Z(CNT_7__N_1391)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[28:42])
    defparam CNT_7__I_371_1_lut.init = 16'h5555;
    LUT4 i10584_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i10584_2_lut.init = 16'h1111;
    COUNTER_U23 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565), .\CNT[6] (CNT[6]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2856(n2856)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U24 FIFOCNT_5 (.CNT1(CNT1_adj_40), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .\CNT[5] (CNT[5]), .CNT_7__N_1392(CNT_7__N_1392), .n2854(n2854), 
            .n7632(n7632), .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_565(CNT1_N_565_adj_1675), 
            .CNT1_N_565_adj_39(CNT1_N_565)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U25 FIFOCNT_4 (.CNT1(CNT1_adj_41), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1677), .\CNT[4] (CNT[4]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2852(n2852)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U26 FIFOCNT_3 (.\CNT[3] (CNT[3]), .n7572(n7572), .\CNT[4] (CNT[4]), 
            .n7632(n7632), .CNT1_N_565(CNT1_N_565_adj_1677), .CNT1(CNT1_adj_42), 
            .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2838(n2838)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U27 FIFOCNT_2 (.CNT1(CNT1_adj_43), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1680), .\CNT[2] (CNT[2]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2836(n2836)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U28 FIFOCNT_1 (.\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .\CNT[2] (CNT[2]), 
            .n7572(n7572), .CNT1_N_565(CNT1_N_565_adj_1680), .CNT1(CNT1_adj_44), 
            .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2834(n2834)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U29 FIFOCNT_0 (.CNT1(CNT1_adj_45), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .\CNT[0] (CNT[0]), .CNT_7__N_1392(CNT_7__N_1392), .n2832(n2832)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U30 CNT_7__I_0_39 (.CNT1(CNT1_adj_46), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1675), .\CNT[7] (CNT[7]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2858(n2858)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U23
//

module COUNTER_U23 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[6] , 
            CNT_7__N_1392, n2856) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[6] ;
    input CNT_7__N_1392;
    input n2856;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2856), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[6] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U24
//

module COUNTER_U24 (CNT1, Clk, CNT_7__N_1391, \CNT[5] , CNT_7__N_1392, 
            n2854, n7632, \CNT[6] , \CNT[7] , CNT1_N_565, CNT1_N_565_adj_39) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    output \CNT[5] ;
    input CNT_7__N_1392;
    input n2854;
    input n7632;
    input \CNT[6] ;
    input \CNT[7] ;
    output CNT1_N_565;
    output CNT1_N_565_adj_39;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2854), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[5] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[5] ), .B(n7632), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n7632), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    LUT4 i1_2_lut_3_lut (.A(\CNT[5] ), .B(n7632), .C(\CNT[6] ), .Z(CNT1_N_565_adj_39)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    
endmodule
//
// Verilog Description of module COUNTER_U25
//

module COUNTER_U25 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[4] , 
            CNT_7__N_1392, n2852) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[4] ;
    input CNT_7__N_1392;
    input n2852;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2852), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[4] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U26
//

module COUNTER_U26 (\CNT[3] , n7572, \CNT[4] , n7632, CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1391, CNT_7__N_1392, n2838) /* synthesis syn_module_defined=1 */ ;
    output \CNT[3] ;
    input n7572;
    input \CNT[4] ;
    output n7632;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2838;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_adj_1671;
    
    LUT4 i7186_2_lut_3_lut (.A(\CNT[3] ), .B(n7572), .C(\CNT[4] ), .Z(n7632)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7186_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[3] ), .B(n7572), .C(\CNT[4] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1671), .SP(CNT_7__N_1391), .CK(Clk), 
            .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2838), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[3] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[3] ), .B(n7572), .Z(CNT1_N_565_adj_1671)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U27
//

module COUNTER_U27 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[2] , 
            CNT_7__N_1392, n2836) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[2] ;
    input CNT_7__N_1392;
    input n2836;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2836), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U28
//

module COUNTER_U28 (\CNT[1] , \CNT[0] , \CNT[2] , n7572, CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1391, CNT_7__N_1392, n2834) /* synthesis syn_module_defined=1 */ ;
    output \CNT[1] ;
    input \CNT[0] ;
    input \CNT[2] ;
    output n7572;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2834;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_adj_1670;
    
    LUT4 i7126_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n7572)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7126_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_adj_1670)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1670), .SP(CNT_7__N_1391), .CK(Clk), 
            .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2834), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[1] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U29
//

module COUNTER_U29 (CNT1, Clk, CNT_7__N_1391, \CNT[0] , CNT_7__N_1392, 
            n2832) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    output \CNT[0] ;
    input CNT_7__N_1392;
    input n2832;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2832), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module COUNTER_U30
//

module COUNTER_U30 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[7] , 
            CNT_7__N_1392, n2858) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[7] ;
    input CNT_7__N_1392;
    input n2858;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2858), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[7] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U81
//

module FIFO_HPOSCNT_U81 (\EN[3] , Clk, nPCLK, ZH_FF, Clk_enable_48, 
            CNT_7__N_1392, nVIS, PCLK_c, n3428, CNT1, n2925, CNT1_adj_32, 
            n2910, n2870, CNT1_adj_33, CNT1_adj_34, n2866, n2864, 
            CNT1_adj_35, CNT1_adj_36, n2862, CNT1_adj_37, n2860, CNT1_adj_38, 
            n2927) /* synthesis syn_module_defined=1 */ ;
    output \EN[3] ;
    input Clk;
    input nPCLK;
    output ZH_FF;
    input Clk_enable_48;
    input CNT_7__N_1392;
    input nVIS;
    input PCLK_c;
    output n3428;
    output CNT1;
    input n2925;
    output CNT1_adj_32;
    input n2910;
    input n2870;
    output CNT1_adj_33;
    output CNT1_adj_34;
    input n2866;
    input n2864;
    output CNT1_adj_35;
    output CNT1_adj_36;
    input n2862;
    output CNT1_adj_37;
    input n2860;
    output CNT1_adj_38;
    input n2927;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire EN_N_1395, ZH_FF_N_1401, CNT_7__N_1391;
    wire [7:0]CNT;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire n14, n10, CNT1_N_565, n7630, CNT1_N_565_adj_1660, CNT1_N_565_adj_1663, 
        n7570, CNT1_N_565_adj_1666;
    
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(nPCLK), .CK(Clk), .Q(\EN[3] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    FD1P3AX ZH_FF_36 (.D(ZH_FF_N_1401), .SP(Clk_enable_48), .CK(Clk), 
            .Q(ZH_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    LUT4 CNT_7__I_371_1_lut (.A(CNT_7__N_1392), .Z(CNT_7__N_1391)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[28:42])
    defparam CNT_7__I_371_1_lut.init = 16'h5555;
    LUT4 i10581_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i10581_2_lut.init = 16'h1111;
    LUT4 i10637_2_lut (.A(PCLK_c), .B(n3428), .Z(ZH_FF_N_1401)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam i10637_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3428)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    COUNTER_U31 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565), .\CNT[6] (CNT[6]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2925(n2925)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U32 FIFOCNT_5 (.\CNT[5] (CNT[5]), .n7630(n7630), .\CNT[6] (CNT[6]), 
            .\CNT[7] (CNT[7]), .CNT1_N_565(CNT1_N_565_adj_1660), .CNT1_N_565_adj_31(CNT1_N_565), 
            .CNT1(CNT1_adj_32), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT_7__N_1392(CNT_7__N_1392), .n2910(n2910)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U33 FIFOCNT_4 (.\CNT[4] (CNT[4]), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2870(n2870), .CNT1(CNT1_adj_33), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1663)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U34 FIFOCNT_3 (.CNT1(CNT1_adj_34), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .\CNT[3] (CNT[3]), .n7570(n7570), .\CNT[4] (CNT[4]), .n7630(n7630), 
            .CNT1_N_565(CNT1_N_565_adj_1663), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2866(n2866)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U35 FIFOCNT_2 (.\CNT[2] (CNT[2]), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2864(n2864), .CNT1(CNT1_adj_35), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1666)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U36 FIFOCNT_1 (.CNT1(CNT1_adj_36), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .\CNT[1] (CNT[1]), .CNT_7__N_1392(CNT_7__N_1392), .n2862(n2862), 
            .\CNT[0] (CNT[0]), .\CNT[2] (CNT[2]), .n7570(n7570), .CNT1_N_565(CNT1_N_565_adj_1666)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U37 FIFOCNT_0 (.CNT1(CNT1_adj_37), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .\CNT[0] (CNT[0]), .CNT_7__N_1392(CNT_7__N_1392), .n2860(n2860)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U38 CNT_7__I_0_39 (.CNT1(CNT1_adj_38), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1660), .\CNT[7] (CNT[7]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2927(n2927)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U31
//

module COUNTER_U31 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[6] , 
            CNT_7__N_1392, n2925) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[6] ;
    input CNT_7__N_1392;
    input n2925;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2925), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[6] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U32
//

module COUNTER_U32 (\CNT[5] , n7630, \CNT[6] , \CNT[7] , CNT1_N_565, 
            CNT1_N_565_adj_31, CNT1, Clk, CNT_7__N_1391, CNT_7__N_1392, 
            n2910) /* synthesis syn_module_defined=1 */ ;
    output \CNT[5] ;
    input n7630;
    input \CNT[6] ;
    input \CNT[7] ;
    output CNT1_N_565;
    output CNT1_N_565_adj_31;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2910;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    LUT4 i1_2_lut (.A(\CNT[5] ), .B(n7630), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n7630), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    LUT4 i1_2_lut_3_lut (.A(\CNT[5] ), .B(n7630), .C(\CNT[6] ), .Z(CNT1_N_565_adj_31)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2910), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[5] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U33
//

module COUNTER_U33 (\CNT[4] , Clk, CNT_7__N_1392, n2870, CNT1, CNT_7__N_1391, 
            CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    output \CNT[4] ;
    input Clk;
    input CNT_7__N_1392;
    input n2870;
    output CNT1;
    input CNT_7__N_1391;
    input CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT_14 (.D(n2870), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[4] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U34
//

module COUNTER_U34 (CNT1, Clk, CNT_7__N_1391, \CNT[3] , n7570, \CNT[4] , 
            n7630, CNT1_N_565, CNT_7__N_1392, n2866) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    output \CNT[3] ;
    input n7570;
    input \CNT[4] ;
    output n7630;
    output CNT1_N_565;
    input CNT_7__N_1392;
    input n2866;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[3] ), .B(n7570), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i7184_2_lut_3_lut (.A(\CNT[3] ), .B(n7570), .C(\CNT[4] ), .Z(n7630)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7184_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[3] ), .B(n7570), .C(\CNT[4] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    FD1P3AX CNT_14 (.D(n2866), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[3] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U35
//

module COUNTER_U35 (\CNT[2] , Clk, CNT_7__N_1392, n2864, CNT1, CNT_7__N_1391, 
            CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input Clk;
    input CNT_7__N_1392;
    input n2864;
    output CNT1;
    input CNT_7__N_1391;
    input CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT_14 (.D(n2864), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U36
//

module COUNTER_U36 (CNT1, Clk, CNT_7__N_1391, \CNT[1] , CNT_7__N_1392, 
            n2862, \CNT[0] , \CNT[2] , n7570, CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    output \CNT[1] ;
    input CNT_7__N_1392;
    input n2862;
    input \CNT[0] ;
    input \CNT[2] ;
    output n7570;
    output CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2862), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[1] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i7124_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n7570)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7124_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U37
//

module COUNTER_U37 (CNT1, Clk, CNT_7__N_1391, \CNT[0] , CNT_7__N_1392, 
            n2860) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    output \CNT[0] ;
    input CNT_7__N_1392;
    input n2860;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2860), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module COUNTER_U38
//

module COUNTER_U38 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[7] , 
            CNT_7__N_1392, n2927) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[7] ;
    input CNT_7__N_1392;
    input n2927;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2927), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[7] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U82
//

module FIFO_HPOSCNT_U82 (CNT_7__N_1392, \EN[2] , Clk, nPCLK, ZH_FF, 
            Clk_enable_47, nVIS, PCLK_c, n3429, CNT1, n2941, CNT1_adj_24, 
            n2939, CNT1_adj_25, n2937, CNT1_adj_26, n2935, CNT1_adj_27, 
            n2933, CNT1_adj_28, n2931, CNT1_adj_29, n2929, CNT1_adj_30, 
            n2943) /* synthesis syn_module_defined=1 */ ;
    input CNT_7__N_1392;
    output \EN[2] ;
    input Clk;
    input nPCLK;
    output ZH_FF;
    input Clk_enable_47;
    input nVIS;
    input PCLK_c;
    output n3429;
    output CNT1;
    input n2941;
    output CNT1_adj_24;
    input n2939;
    output CNT1_adj_25;
    input n2937;
    output CNT1_adj_26;
    input n2935;
    output CNT1_adj_27;
    input n2933;
    output CNT1_adj_28;
    input n2931;
    output CNT1_adj_29;
    input n2929;
    output CNT1_adj_30;
    input n2943;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_7__N_1391, EN_N_1395, ZH_FF_N_1401;
    wire [7:0]CNT;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire n14, n10, CNT1_N_565, n7628, CNT1_N_565_adj_1646, CNT1_N_565_adj_1649, 
        n7568, CNT1_N_565_adj_1652;
    
    LUT4 CNT_7__I_371_1_lut (.A(CNT_7__N_1392), .Z(CNT_7__N_1391)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[28:42])
    defparam CNT_7__I_371_1_lut.init = 16'h5555;
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(nPCLK), .CK(Clk), .Q(\EN[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    FD1P3AX ZH_FF_36 (.D(ZH_FF_N_1401), .SP(Clk_enable_47), .CK(Clk), 
            .Q(ZH_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    LUT4 i10577_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i10577_2_lut.init = 16'h1111;
    LUT4 i10640_2_lut (.A(PCLK_c), .B(n3429), .Z(ZH_FF_N_1401)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam i10640_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3429)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    COUNTER_U39 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565), .\CNT[6] (CNT[6]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2941(n2941)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U40 FIFOCNT_5 (.\CNT[5] (CNT[5]), .n7628(n7628), .\CNT[6] (CNT[6]), 
            .\CNT[7] (CNT[7]), .CNT1_N_565(CNT1_N_565_adj_1646), .CNT1_N_565_adj_23(CNT1_N_565), 
            .CNT1(CNT1_adj_24), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT_7__N_1392(CNT_7__N_1392), .n2939(n2939)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U41 FIFOCNT_4 (.CNT1(CNT1_adj_25), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1649), .\CNT[4] (CNT[4]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2937(n2937)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U42 FIFOCNT_3 (.\CNT[3] (CNT[3]), .n7568(n7568), .\CNT[4] (CNT[4]), 
            .n7628(n7628), .CNT1_N_565(CNT1_N_565_adj_1649), .CNT1(CNT1_adj_26), 
            .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2935(n2935)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U43 FIFOCNT_2 (.CNT1(CNT1_adj_27), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1652), .\CNT[2] (CNT[2]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2933(n2933)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U44 FIFOCNT_1 (.\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .\CNT[2] (CNT[2]), 
            .n7568(n7568), .CNT1_N_565(CNT1_N_565_adj_1652), .CNT1(CNT1_adj_28), 
            .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2931(n2931)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U45 FIFOCNT_0 (.\CNT[0] (CNT[0]), .CNT1(CNT1_adj_29), .Clk(Clk), 
            .CNT_7__N_1391(CNT_7__N_1391), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2929(n2929)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U46 CNT_7__I_0_39 (.CNT1(CNT1_adj_30), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1646), .\CNT[7] (CNT[7]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2943(n2943)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U39
//

module COUNTER_U39 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[6] , 
            CNT_7__N_1392, n2941) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[6] ;
    input CNT_7__N_1392;
    input n2941;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2941), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[6] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U40
//

module COUNTER_U40 (\CNT[5] , n7628, \CNT[6] , \CNT[7] , CNT1_N_565, 
            CNT1_N_565_adj_23, CNT1, Clk, CNT_7__N_1391, CNT_7__N_1392, 
            n2939) /* synthesis syn_module_defined=1 */ ;
    output \CNT[5] ;
    input n7628;
    input \CNT[6] ;
    input \CNT[7] ;
    output CNT1_N_565;
    output CNT1_N_565_adj_23;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2939;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    LUT4 i1_2_lut (.A(\CNT[5] ), .B(n7628), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n7628), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    LUT4 i1_2_lut_3_lut (.A(\CNT[5] ), .B(n7628), .C(\CNT[6] ), .Z(CNT1_N_565_adj_23)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2939), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[5] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U41
//

module COUNTER_U41 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[4] , 
            CNT_7__N_1392, n2937) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[4] ;
    input CNT_7__N_1392;
    input n2937;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2937), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[4] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U42
//

module COUNTER_U42 (\CNT[3] , n7568, \CNT[4] , n7628, CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1391, CNT_7__N_1392, n2935) /* synthesis syn_module_defined=1 */ ;
    output \CNT[3] ;
    input n7568;
    input \CNT[4] ;
    output n7628;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2935;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    LUT4 i1_2_lut (.A(\CNT[3] ), .B(n7568), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i7182_2_lut_3_lut (.A(\CNT[3] ), .B(n7568), .C(\CNT[4] ), .Z(n7628)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7182_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[3] ), .B(n7568), .C(\CNT[4] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2935), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[3] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U43
//

module COUNTER_U43 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[2] , 
            CNT_7__N_1392, n2933) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[2] ;
    input CNT_7__N_1392;
    input n2933;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2933), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U44
//

module COUNTER_U44 (\CNT[1] , \CNT[0] , \CNT[2] , n7568, CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1391, CNT_7__N_1392, n2931) /* synthesis syn_module_defined=1 */ ;
    output \CNT[1] ;
    input \CNT[0] ;
    input \CNT[2] ;
    output n7568;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2931;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i7122_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n7568)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7122_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2931), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[1] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U45
//

module COUNTER_U45 (\CNT[0] , CNT1, Clk, CNT_7__N_1391, CNT_7__N_1392, 
            n2929) /* synthesis syn_module_defined=1 */ ;
    output \CNT[0] ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2929;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2929), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U46
//

module COUNTER_U46 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[7] , 
            CNT_7__N_1392, n2943) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[7] ;
    input CNT_7__N_1392;
    input n2943;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2943), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[7] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U83
//

module FIFO_HPOSCNT_U83 (nVIS, ZH_FF, \EN[1] , Clk, nPCLK, PCLK_c, 
            n3430, CNT_7__N_1392, Clk_enable_55, CNT1, n2957, CNT1_adj_16, 
            n2955, CNT1_adj_17, n2953, CNT1_adj_18, n2951, CNT1_adj_19, 
            n2949, CNT1_adj_20, n2947, CNT1_adj_21, n2945, CNT1_adj_22, 
            n2959) /* synthesis syn_module_defined=1 */ ;
    input nVIS;
    output ZH_FF;
    output \EN[1] ;
    input Clk;
    input nPCLK;
    input PCLK_c;
    output n3430;
    input CNT_7__N_1392;
    input Clk_enable_55;
    output CNT1;
    input n2957;
    output CNT1_adj_16;
    input n2955;
    output CNT1_adj_17;
    input n2953;
    output CNT1_adj_18;
    input n2951;
    output CNT1_adj_19;
    input n2949;
    output CNT1_adj_20;
    input n2947;
    output CNT1_adj_21;
    input n2945;
    output CNT1_adj_22;
    input n2959;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire EN_N_1395, ZH_FF_N_1401;
    wire [7:0]CNT;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire n14, n10, CNT_7__N_1391, CNT1_N_565, n7626, CNT1_N_565_adj_1632, 
        CNT1_N_565_adj_1635, n7566, CNT1_N_565_adj_1638;
    
    LUT4 i10574_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i10574_2_lut.init = 16'h1111;
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(nPCLK), .CK(Clk), .Q(\EN[1] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 i10562_2_lut (.A(PCLK_c), .B(n3430), .Z(ZH_FF_N_1401)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1456[15:36])
    defparam i10562_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3430)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 CNT_7__I_371_1_lut (.A(CNT_7__N_1392), .Z(CNT_7__N_1391)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[28:42])
    defparam CNT_7__I_371_1_lut.init = 16'h5555;
    FD1P3AX ZH_FF_36 (.D(ZH_FF_N_1401), .SP(Clk_enable_55), .CK(Clk), 
            .Q(ZH_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    COUNTER_U47 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565), .\CNT[6] (CNT[6]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2957(n2957)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U48 FIFOCNT_5 (.\CNT[5] (CNT[5]), .n7626(n7626), .\CNT[6] (CNT[6]), 
            .\CNT[7] (CNT[7]), .CNT1_N_565(CNT1_N_565_adj_1632), .CNT1_N_565_adj_15(CNT1_N_565), 
            .CNT1(CNT1_adj_16), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT_7__N_1392(CNT_7__N_1392), .n2955(n2955)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U49 FIFOCNT_4 (.CNT1(CNT1_adj_17), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1635), .\CNT[4] (CNT[4]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2953(n2953)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U50 FIFOCNT_3 (.\CNT[3] (CNT[3]), .n7566(n7566), .\CNT[4] (CNT[4]), 
            .n7626(n7626), .CNT1_N_565(CNT1_N_565_adj_1635), .CNT1(CNT1_adj_18), 
            .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2951(n2951)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U51 FIFOCNT_2 (.CNT1(CNT1_adj_19), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1638), .\CNT[2] (CNT[2]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2949(n2949)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U52 FIFOCNT_1 (.\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .CNT1(CNT1_adj_20), 
            .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2947(n2947), .\CNT[2] (CNT[2]), .n7566(n7566), .CNT1_N_565(CNT1_N_565_adj_1638)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U53 FIFOCNT_0 (.\CNT[0] (CNT[0]), .CNT1(CNT1_adj_21), .Clk(Clk), 
            .CNT_7__N_1391(CNT_7__N_1391), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2945(n2945)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U54 CNT_7__I_0_39 (.CNT1(CNT1_adj_22), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1632), .\CNT[7] (CNT[7]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2959(n2959)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U47
//

module COUNTER_U47 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[6] , 
            CNT_7__N_1392, n2957) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[6] ;
    input CNT_7__N_1392;
    input n2957;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2957), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[6] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U48
//

module COUNTER_U48 (\CNT[5] , n7626, \CNT[6] , \CNT[7] , CNT1_N_565, 
            CNT1_N_565_adj_15, CNT1, Clk, CNT_7__N_1391, CNT_7__N_1392, 
            n2955) /* synthesis syn_module_defined=1 */ ;
    output \CNT[5] ;
    input n7626;
    input \CNT[6] ;
    input \CNT[7] ;
    output CNT1_N_565;
    output CNT1_N_565_adj_15;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2955;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_adj_1631;
    
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n7626), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    LUT4 i1_2_lut_3_lut (.A(\CNT[5] ), .B(n7626), .C(\CNT[6] ), .Z(CNT1_N_565_adj_15)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i1_2_lut (.A(\CNT[5] ), .B(n7626), .Z(CNT1_N_565_adj_1631)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1631), .SP(CNT_7__N_1391), .CK(Clk), 
            .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2955), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[5] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U49
//

module COUNTER_U49 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[4] , 
            CNT_7__N_1392, n2953) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[4] ;
    input CNT_7__N_1392;
    input n2953;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2953), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[4] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U50
//

module COUNTER_U50 (\CNT[3] , n7566, \CNT[4] , n7626, CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1391, CNT_7__N_1392, n2951) /* synthesis syn_module_defined=1 */ ;
    output \CNT[3] ;
    input n7566;
    input \CNT[4] ;
    output n7626;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2951;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_adj_1629;
    
    LUT4 i7180_2_lut_3_lut (.A(\CNT[3] ), .B(n7566), .C(\CNT[4] ), .Z(n7626)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7180_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[3] ), .B(n7566), .C(\CNT[4] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i1_2_lut (.A(\CNT[3] ), .B(n7566), .Z(CNT1_N_565_adj_1629)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1629), .SP(CNT_7__N_1391), .CK(Clk), 
            .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2951), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[3] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U51
//

module COUNTER_U51 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[2] , 
            CNT_7__N_1392, n2949) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[2] ;
    input CNT_7__N_1392;
    input n2949;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2949), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U52
//

module COUNTER_U52 (\CNT[1] , \CNT[0] , CNT1, Clk, CNT_7__N_1391, 
            CNT_7__N_1392, n2947, \CNT[2] , n7566, CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    output \CNT[1] ;
    input \CNT[0] ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2947;
    input \CNT[2] ;
    output n7566;
    output CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2947), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[1] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i7120_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n7566)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7120_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    
endmodule
//
// Verilog Description of module COUNTER_U53
//

module COUNTER_U53 (\CNT[0] , CNT1, Clk, CNT_7__N_1391, CNT_7__N_1392, 
            n2945) /* synthesis syn_module_defined=1 */ ;
    output \CNT[0] ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2945;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2945), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U54
//

module COUNTER_U54 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[7] , 
            CNT_7__N_1392, n2959) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[7] ;
    input CNT_7__N_1392;
    input n2959;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2959), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[7] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U84
//

module FIFO_HPOSCNT_U84 (\EN[0] , Clk, nPCLK, CNT_7__N_1392, nVIS, 
            ZH_FF, PCLK_c, \ZPOS[2] , n3403, Clk_enable_51, n3374, 
            Clk_enable_52, n3423, Clk_enable_50, n3427, Clk_enable_49, 
            n3428, Clk_enable_48, n3429, Clk_enable_47, n3430, Clk_enable_55, 
            CNT1, n2973, CNT1_adj_8, n2971, CNT1_adj_9, n2969, CNT1_adj_10, 
            n2967, CNT1_adj_11, n2965, CNT1_adj_12, n2963, CNT1_adj_13, 
            n2961, CNT1_adj_14, n2975) /* synthesis syn_module_defined=1 */ ;
    output \EN[0] ;
    input Clk;
    input nPCLK;
    input CNT_7__N_1392;
    input nVIS;
    output ZH_FF;
    input PCLK_c;
    input \ZPOS[2] ;
    input n3403;
    output Clk_enable_51;
    input n3374;
    output Clk_enable_52;
    input n3423;
    output Clk_enable_50;
    input n3427;
    output Clk_enable_49;
    input n3428;
    output Clk_enable_48;
    input n3429;
    output Clk_enable_47;
    input n3430;
    output Clk_enable_55;
    output CNT1;
    input n2973;
    output CNT1_adj_8;
    input n2971;
    output CNT1_adj_9;
    input n2969;
    output CNT1_adj_10;
    input n2967;
    output CNT1_adj_11;
    input n2965;
    output CNT1_adj_12;
    input n2963;
    output CNT1_adj_13;
    input n2961;
    output CNT1_adj_14;
    input n2975;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire EN_N_1395, CNT_7__N_1391, n3431, Clk_enable_54, ZH_FF_N_1401;
    wire [7:0]CNT;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire n14, n10, CNT1_N_565, n7624, CNT1_N_565_adj_1618, CNT1_N_565_adj_1621, 
        n7564, CNT1_N_565_adj_1624;
    
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(nPCLK), .CK(Clk), .Q(\EN[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 CNT_7__I_371_1_lut (.A(CNT_7__N_1392), .Z(CNT_7__N_1391)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[28:42])
    defparam CNT_7__I_371_1_lut.init = 16'h5555;
    LUT4 i10570_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i10570_2_lut.init = 16'h1111;
    LUT4 i1_3_lut_4_lut_3_lut (.A(PCLK_c), .B(\ZPOS[2] ), .C(n3403), .Z(Clk_enable_51)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut.init = 16'h8a8a;
    LUT4 i1_3_lut_4_lut_3_lut_adj_426 (.A(PCLK_c), .B(\ZPOS[2] ), .C(n3374), 
         .Z(Clk_enable_52)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut_adj_426.init = 16'h8a8a;
    LUT4 i1_3_lut_4_lut_3_lut_adj_427 (.A(PCLK_c), .B(\ZPOS[2] ), .C(n3423), 
         .Z(Clk_enable_50)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut_adj_427.init = 16'h8a8a;
    LUT4 i1_3_lut_4_lut_3_lut_adj_428 (.A(PCLK_c), .B(\ZPOS[2] ), .C(n3427), 
         .Z(Clk_enable_49)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut_adj_428.init = 16'h8a8a;
    LUT4 i1_3_lut_4_lut_3_lut_adj_429 (.A(PCLK_c), .B(\ZPOS[2] ), .C(n3428), 
         .Z(Clk_enable_48)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut_adj_429.init = 16'h8a8a;
    LUT4 i1_3_lut_4_lut_3_lut_adj_430 (.A(PCLK_c), .B(\ZPOS[2] ), .C(n3429), 
         .Z(Clk_enable_47)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut_adj_430.init = 16'h8a8a;
    LUT4 i1_3_lut_4_lut_3_lut_adj_431 (.A(PCLK_c), .B(\ZPOS[2] ), .C(n3430), 
         .Z(Clk_enable_55)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut_adj_431.init = 16'h8a8a;
    LUT4 i1_3_lut_4_lut_3_lut_adj_432 (.A(PCLK_c), .B(\ZPOS[2] ), .C(n3431), 
         .Z(Clk_enable_54)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut_adj_432.init = 16'h8a8a;
    LUT4 i10559_2_lut (.A(PCLK_c), .B(n3431), .Z(ZH_FF_N_1401)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1456[15:36])
    defparam i10559_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3431)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    FD1P3AX ZH_FF_36 (.D(ZH_FF_N_1401), .SP(Clk_enable_54), .CK(Clk), 
            .Q(ZH_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    COUNTER_U55 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565), .\CNT[6] (CNT[6]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2973(n2973)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U56 FIFOCNT_5 (.\CNT[5] (CNT[5]), .n7624(n7624), .\CNT[6] (CNT[6]), 
            .\CNT[7] (CNT[7]), .CNT1_N_565(CNT1_N_565_adj_1618), .CNT1_N_565_adj_7(CNT1_N_565), 
            .CNT1(CNT1_adj_8), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT_7__N_1392(CNT_7__N_1392), .n2971(n2971)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U57 FIFOCNT_4 (.CNT1(CNT1_adj_9), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1621), .\CNT[4] (CNT[4]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2969(n2969)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U58 FIFOCNT_3 (.\CNT[3] (CNT[3]), .n7564(n7564), .\CNT[4] (CNT[4]), 
            .n7624(n7624), .CNT1_N_565(CNT1_N_565_adj_1621), .CNT1(CNT1_adj_10), 
            .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2967(n2967)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U59 FIFOCNT_2 (.CNT1(CNT1_adj_11), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1624), .\CNT[2] (CNT[2]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2965(n2965)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U60 FIFOCNT_1 (.\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .CNT1(CNT1_adj_12), 
            .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2963(n2963), .\CNT[2] (CNT[2]), .n7564(n7564), .CNT1_N_565(CNT1_N_565_adj_1624)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U61 FIFOCNT_0 (.\CNT[0] (CNT[0]), .CNT1(CNT1_adj_13), .Clk(Clk), 
            .CNT_7__N_1391(CNT_7__N_1391), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2961(n2961)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U62 CNT_7__I_0_39 (.CNT1(CNT1_adj_14), .Clk(Clk), .CNT_7__N_1391(CNT_7__N_1391), 
            .CNT1_N_565(CNT1_N_565_adj_1618), .\CNT[7] (CNT[7]), .CNT_7__N_1392(CNT_7__N_1392), 
            .n2975(n2975)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U55
//

module COUNTER_U55 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[6] , 
            CNT_7__N_1392, n2973) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[6] ;
    input CNT_7__N_1392;
    input n2973;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2973), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[6] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U56
//

module COUNTER_U56 (\CNT[5] , n7624, \CNT[6] , \CNT[7] , CNT1_N_565, 
            CNT1_N_565_adj_7, CNT1, Clk, CNT_7__N_1391, CNT_7__N_1392, 
            n2971) /* synthesis syn_module_defined=1 */ ;
    output \CNT[5] ;
    input n7624;
    input \CNT[6] ;
    input \CNT[7] ;
    output CNT1_N_565;
    output CNT1_N_565_adj_7;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2971;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_adj_1617;
    
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n7624), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    LUT4 i1_2_lut_3_lut (.A(\CNT[5] ), .B(n7624), .C(\CNT[6] ), .Z(CNT1_N_565_adj_7)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1617), .SP(CNT_7__N_1391), .CK(Clk), 
            .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2971), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[5] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[5] ), .B(n7624), .Z(CNT1_N_565_adj_1617)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U57
//

module COUNTER_U57 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[4] , 
            CNT_7__N_1392, n2969) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[4] ;
    input CNT_7__N_1392;
    input n2969;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2969), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[4] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U58
//

module COUNTER_U58 (\CNT[3] , n7564, \CNT[4] , n7624, CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1391, CNT_7__N_1392, n2967) /* synthesis syn_module_defined=1 */ ;
    output \CNT[3] ;
    input n7564;
    input \CNT[4] ;
    output n7624;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2967;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_adj_1615;
    
    LUT4 i7178_2_lut_3_lut (.A(\CNT[3] ), .B(n7564), .C(\CNT[4] ), .Z(n7624)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7178_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[3] ), .B(n7564), .C(\CNT[4] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1615), .SP(CNT_7__N_1391), .CK(Clk), 
            .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2967), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[3] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[3] ), .B(n7564), .Z(CNT1_N_565_adj_1615)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U59
//

module COUNTER_U59 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[2] , 
            CNT_7__N_1392, n2965) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[2] ;
    input CNT_7__N_1392;
    input n2965;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2965), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U60
//

module COUNTER_U60 (\CNT[1] , \CNT[0] , CNT1, Clk, CNT_7__N_1391, 
            CNT_7__N_1392, n2963, \CNT[2] , n7564, CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    output \CNT[1] ;
    input \CNT[0] ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2963;
    input \CNT[2] ;
    output n7564;
    output CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2963), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[1] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i7118_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n7564)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i7118_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    
endmodule
//
// Verilog Description of module COUNTER_U61
//

module COUNTER_U61 (\CNT[0] , CNT1, Clk, CNT_7__N_1391, CNT_7__N_1392, 
            n2961) /* synthesis syn_module_defined=1 */ ;
    output \CNT[0] ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT_7__N_1392;
    input n2961;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2961), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U62
//

module COUNTER_U62 (CNT1, Clk, CNT_7__N_1391, CNT1_N_565, \CNT[7] , 
            CNT_7__N_1392, n2975) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1391;
    input CNT1_N_565;
    output \CNT[7] ;
    input CNT_7__N_1392;
    input n2975;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1391), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2975), .SP(CNT_7__N_1392), .CK(Clk), .Q(\CNT[7] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG
//

module SHIFTREG (\QP[0] , Clk, nPCLK, \QP[1] , \QP[2] , \QP[3] , 
            \QP[4] , \QP[5] , \QP[6] , \COL1[7] , Clk_enable_200, 
            n3044, n3046, n3048, n3050, n3052, n3054, n3056, n5061, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL1[7] ;
    input Clk_enable_200;
    input n3044;
    input n3046;
    input n3048;
    input n3050;
    input n3052;
    input n3054;
    input n3056;
    input n5061;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3044), .SP(Clk_enable_200), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3046), .SP(Clk_enable_200), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3048), .SP(Clk_enable_200), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3050), .SP(Clk_enable_200), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3052), .SP(Clk_enable_200), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3054), .SP(Clk_enable_200), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3056), .SP(Clk_enable_200), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_200), .CD(n5061), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U85
//

module SHIFTREG_U85 (\QP[0] , Clk, nPCLK, \QP[1] , \QP[2] , \QP[3] , 
            \QP[4] , \QP[5] , \QP[6] , \COL1[6] , Clk_enable_202, 
            n3072, n3074, n3076, n3078, n3080, n3082, n3084, n5057, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL1[6] ;
    input Clk_enable_202;
    input n3072;
    input n3074;
    input n3076;
    input n3078;
    input n3080;
    input n3082;
    input n3084;
    input n5057;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3072), .SP(Clk_enable_202), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3074), .SP(Clk_enable_202), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3076), .SP(Clk_enable_202), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3078), .SP(Clk_enable_202), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3080), .SP(Clk_enable_202), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3082), .SP(Clk_enable_202), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3084), .SP(Clk_enable_202), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_202), .CD(n5057), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U86
//

module SHIFTREG_U86 (\QP[0] , Clk, nPCLK, \QP[1] , \QP[2] , \QP[3] , 
            \QP[4] , \QP[5] , \QP[6] , \COL1[5] , Clk_enable_204, 
            n3100, n3102, n3104, n3106, n3108, n3110, n3112, n5053, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL1[5] ;
    input Clk_enable_204;
    input n3100;
    input n3102;
    input n3104;
    input n3106;
    input n3108;
    input n3110;
    input n3112;
    input n5053;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3100), .SP(Clk_enable_204), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3102), .SP(Clk_enable_204), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3104), .SP(Clk_enable_204), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3106), .SP(Clk_enable_204), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3108), .SP(Clk_enable_204), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3110), .SP(Clk_enable_204), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3112), .SP(Clk_enable_204), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_204), .CD(n5053), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U87
//

module SHIFTREG_U87 (\QP[0] , Clk, nPCLK, \QP[1] , \QP[2] , \QP[3] , 
            \QP[4] , \QP[5] , \QP[6] , \COL1[4] , Clk_enable_206, 
            n3128, n3130, n3132, n3134, n3136, n3138, n3140, n5049, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL1[4] ;
    input Clk_enable_206;
    input n3128;
    input n3130;
    input n3132;
    input n3134;
    input n3136;
    input n3138;
    input n3140;
    input n5049;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3128), .SP(Clk_enable_206), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3130), .SP(Clk_enable_206), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3132), .SP(Clk_enable_206), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3134), .SP(Clk_enable_206), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3136), .SP(Clk_enable_206), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3138), .SP(Clk_enable_206), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3140), .SP(Clk_enable_206), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_206), .CD(n5049), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U88
//

module SHIFTREG_U88 (\QP[0] , Clk, nPCLK, \QP[1] , \QP[2] , \QP[3] , 
            \QP[4] , \QP[5] , \QP[6] , \COL1[3] , Clk_enable_208, 
            n3156, n3158, n3160, n3162, n3164, n3166, n3168, n5045, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL1[3] ;
    input Clk_enable_208;
    input n3156;
    input n3158;
    input n3160;
    input n3162;
    input n3164;
    input n3166;
    input n3168;
    input n5045;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3156), .SP(Clk_enable_208), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3158), .SP(Clk_enable_208), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3160), .SP(Clk_enable_208), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3162), .SP(Clk_enable_208), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3164), .SP(Clk_enable_208), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3166), .SP(Clk_enable_208), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3168), .SP(Clk_enable_208), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_208), .CD(n5045), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U89
//

module SHIFTREG_U89 (\QP[0] , Clk, nPCLK, \QP[1] , \QP[2] , \QP[3] , 
            \QP[4] , \QP[5] , \QP[6] , \COL1[2] , Clk_enable_210, 
            n3184, n3186, n3188, n3190, n3192, n3194, n3196, n5041, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL1[2] ;
    input Clk_enable_210;
    input n3184;
    input n3186;
    input n3188;
    input n3190;
    input n3192;
    input n3194;
    input n3196;
    input n5041;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3184), .SP(Clk_enable_210), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3186), .SP(Clk_enable_210), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3188), .SP(Clk_enable_210), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3190), .SP(Clk_enable_210), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3192), .SP(Clk_enable_210), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3194), .SP(Clk_enable_210), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3196), .SP(Clk_enable_210), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_210), .CD(n5041), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U90
//

module SHIFTREG_U90 (\QP[0] , Clk, nPCLK, \QP[1] , \QP[2] , \QP[3] , 
            \QP[4] , \QP[5] , \QP[6] , \COL1[1] , Clk_enable_212, 
            n3212, n3214, n3216, n3218, n3220, n3222, n3224, n5037, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL1[1] ;
    input Clk_enable_212;
    input n3212;
    input n3214;
    input n3216;
    input n3218;
    input n3220;
    input n3222;
    input n3224;
    input n5037;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3212), .SP(Clk_enable_212), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3214), .SP(Clk_enable_212), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3216), .SP(Clk_enable_212), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3218), .SP(Clk_enable_212), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3220), .SP(Clk_enable_212), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3222), .SP(Clk_enable_212), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3224), .SP(Clk_enable_212), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_212), .CD(n5037), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U91
//

module SHIFTREG_U91 (\QP[0] , Clk, nPCLK, \QP[1] , \QP[2] , \QP[3] , 
            \QP[4] , \QP[5] , \QP[6] , \COL1[0] , Clk_enable_214, 
            n3240, n3242, n3244, n3246, n3248, n3250, n3252, n5033, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL1[0] ;
    input Clk_enable_214;
    input n3240;
    input n3242;
    input n3244;
    input n3246;
    input n3248;
    input n3250;
    input n3252;
    input n5033;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3240), .SP(Clk_enable_214), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3242), .SP(Clk_enable_214), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3244), .SP(Clk_enable_214), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3246), .SP(Clk_enable_214), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3248), .SP(Clk_enable_214), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3250), .SP(Clk_enable_214), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3252), .SP(Clk_enable_214), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_214), .CD(n5033), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U92
//

module SHIFTREG_U92 (\QP[0] , Clk, nPCLK, \QP[1] , \QP[2] , \QP[3] , 
            \QP[4] , \QP[5] , \QP[6] , \COL0[7] , Clk_enable_201, 
            n3058, n3060, n3062, n3064, n3066, n3068, n3070, n5059, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL0[7] ;
    input Clk_enable_201;
    input n3058;
    input n3060;
    input n3062;
    input n3064;
    input n3066;
    input n3068;
    input n3070;
    input n5059;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3058), .SP(Clk_enable_201), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3060), .SP(Clk_enable_201), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3062), .SP(Clk_enable_201), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3064), .SP(Clk_enable_201), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3066), .SP(Clk_enable_201), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3068), .SP(Clk_enable_201), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3070), .SP(Clk_enable_201), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_201), .CD(n5059), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U93
//

module SHIFTREG_U93 (\QP[0] , Clk, nPCLK, \QP[1] , \QP[2] , \QP[3] , 
            \QP[4] , \QP[5] , \QP[6] , \COL0[6] , Clk_enable_203, 
            n3086, n3088, n3090, n3092, n3094, n3096, n3098, n5055, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL0[6] ;
    input Clk_enable_203;
    input n3086;
    input n3088;
    input n3090;
    input n3092;
    input n3094;
    input n3096;
    input n3098;
    input n5055;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3086), .SP(Clk_enable_203), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3088), .SP(Clk_enable_203), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3090), .SP(Clk_enable_203), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3092), .SP(Clk_enable_203), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3094), .SP(Clk_enable_203), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3096), .SP(Clk_enable_203), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3098), .SP(Clk_enable_203), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_203), .CD(n5055), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U94
//

module SHIFTREG_U94 (\QP[0] , Clk, nPCLK, \QP[1] , \QP[2] , \QP[3] , 
            \QP[4] , \QP[5] , \QP[6] , \COL0[5] , Clk_enable_205, 
            n3114, n3116, n3118, n3120, n3122, n3124, n3126, n5051, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL0[5] ;
    input Clk_enable_205;
    input n3114;
    input n3116;
    input n3118;
    input n3120;
    input n3122;
    input n3124;
    input n3126;
    input n5051;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3114), .SP(Clk_enable_205), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3116), .SP(Clk_enable_205), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3118), .SP(Clk_enable_205), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3120), .SP(Clk_enable_205), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3122), .SP(Clk_enable_205), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3124), .SP(Clk_enable_205), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3126), .SP(Clk_enable_205), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_205), .CD(n5051), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U95
//

module SHIFTREG_U95 (\QP[0] , Clk, nPCLK, \QP[1] , \QP[2] , \QP[3] , 
            \QP[4] , \QP[5] , \QP[6] , \COL0[4] , Clk_enable_207, 
            n3142, n3144, n3146, n3148, n3150, n3152, n3154, n5047, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL0[4] ;
    input Clk_enable_207;
    input n3142;
    input n3144;
    input n3146;
    input n3148;
    input n3150;
    input n3152;
    input n3154;
    input n5047;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3142), .SP(Clk_enable_207), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3144), .SP(Clk_enable_207), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3146), .SP(Clk_enable_207), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3148), .SP(Clk_enable_207), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3150), .SP(Clk_enable_207), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3152), .SP(Clk_enable_207), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3154), .SP(Clk_enable_207), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_207), .CD(n5047), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U96
//

module SHIFTREG_U96 (\QP[0] , Clk, nPCLK, \QP[1] , \QP[2] , \QP[3] , 
            \QP[4] , \QP[5] , \QP[6] , \COL0[3] , Clk_enable_209, 
            n3170, n3172, n3174, n3176, n3178, n3180, n3182, n5043, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL0[3] ;
    input Clk_enable_209;
    input n3170;
    input n3172;
    input n3174;
    input n3176;
    input n3178;
    input n3180;
    input n3182;
    input n5043;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3170), .SP(Clk_enable_209), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3172), .SP(Clk_enable_209), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3174), .SP(Clk_enable_209), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3176), .SP(Clk_enable_209), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3178), .SP(Clk_enable_209), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3180), .SP(Clk_enable_209), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3182), .SP(Clk_enable_209), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_209), .CD(n5043), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U97
//

module SHIFTREG_U97 (\QP[0] , Clk, nPCLK, \QP[1] , \QP[2] , \QP[3] , 
            \QP[4] , \QP[5] , \QP[6] , \COL0[2] , Clk_enable_211, 
            n3198, n3200, n3202, n3204, n3206, n3208, n3210, n5039, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL0[2] ;
    input Clk_enable_211;
    input n3198;
    input n3200;
    input n3202;
    input n3204;
    input n3206;
    input n3208;
    input n3210;
    input n5039;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3198), .SP(Clk_enable_211), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3200), .SP(Clk_enable_211), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3202), .SP(Clk_enable_211), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3204), .SP(Clk_enable_211), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3206), .SP(Clk_enable_211), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3208), .SP(Clk_enable_211), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3210), .SP(Clk_enable_211), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_211), .CD(n5039), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U98
//

module SHIFTREG_U98 (\QP[0] , Clk, nPCLK, \QP[1] , \QP[2] , \QP[3] , 
            \QP[4] , \QP[5] , \QP[6] , \COL0[1] , Clk_enable_213, 
            n3226, n3228, n3230, n3232, n3234, n3236, n3238, n5035, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL0[1] ;
    input Clk_enable_213;
    input n3226;
    input n3228;
    input n3230;
    input n3232;
    input n3234;
    input n3236;
    input n3238;
    input n5035;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3226), .SP(Clk_enable_213), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3228), .SP(Clk_enable_213), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3230), .SP(Clk_enable_213), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3232), .SP(Clk_enable_213), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3234), .SP(Clk_enable_213), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3236), .SP(Clk_enable_213), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3238), .SP(Clk_enable_213), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_213), .CD(n5035), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U99
//

module SHIFTREG_U99 (\QP[0] , Clk, nPCLK, Clk_enable_215, n3254, n3256, 
            n3258, n3260, n3262, n3264, n3266, \QP[1] , \QP[2] , 
            \QP[3] , \QP[4] , \QP[5] , \QP[6] , \COL0[0] , n5031, 
            \SDATA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_215;
    input n3254;
    input n3256;
    input n3258;
    input n3260;
    input n3262;
    input n3264;
    input n3266;
    output \QP[1] ;
    output \QP[2] ;
    output \QP[3] ;
    output \QP[4] ;
    output \QP[5] ;
    output \QP[6] ;
    output \COL0[0] ;
    input n5031;
    input \SDATA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n3254), .SP(Clk_enable_215), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n3256), .SP(Clk_enable_215), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n3258), .SP(Clk_enable_215), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n3260), .SP(Clk_enable_215), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n3262), .SP(Clk_enable_215), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n3264), .SP(Clk_enable_215), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n3266), .SP(Clk_enable_215), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_215), .CD(n5031), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module PALETTE
//

module PALETTE (RGB_c_7, RGB_c_13, RGB_c_14, RGB_c_15, RGB_c_0, RGB_c_1, 
            RGB_c_2, RGB_c_8, RGB_c_16, RGB_c_9, RGB_c_17, RGB_c_18, 
            RGB_c_19, Clk, PCLK_c, nPICTURE, EMPH, GND_net, RGB_c_20, 
            RGB_c_10, RGB_c_21, RGB_c_3, RGB_c_22, RGB_c_23, MODE_N_21, 
            EMP_G, EMP_R, R7, TH_MUX, RPIX, n996, RGB_c_4, PIX, 
            RGB_c_5, RGB_c_6, B_W, DB_PARR, RGB_c_11, \STEP3[4] , 
            \THO_LATCH[4] , \STEP3[0] , \THO_LATCH[0] , \CGA[1] , RGB_c_12, 
            PALSEL, VCC_net, \CGA[3] , \CGA[2] , \CGA[0] , \DBIN[5] , 
            \DBIN[4] , \DBIN[3] , \DBIN[2] , \DBIN[1] , \DBIN[0] ) /* synthesis syn_module_defined=1 */ ;
    output RGB_c_7;
    output RGB_c_13;
    output RGB_c_14;
    output RGB_c_15;
    output RGB_c_0;
    output RGB_c_1;
    output RGB_c_2;
    output RGB_c_8;
    output RGB_c_16;
    output RGB_c_9;
    output RGB_c_17;
    output RGB_c_18;
    output RGB_c_19;
    input Clk;
    input PCLK_c;
    input nPICTURE;
    input [2:0]EMPH;
    input GND_net;
    output RGB_c_20;
    output RGB_c_10;
    output RGB_c_21;
    output RGB_c_3;
    output RGB_c_22;
    output RGB_c_23;
    input MODE_N_21;
    input EMP_G;
    input EMP_R;
    input R7;
    input TH_MUX;
    output RPIX;
    input n996;
    output RGB_c_4;
    output [5:0]PIX;
    output RGB_c_5;
    output RGB_c_6;
    input B_W;
    input DB_PARR;
    output RGB_c_11;
    input \STEP3[4] ;
    input \THO_LATCH[4] ;
    input \STEP3[0] ;
    input \THO_LATCH[0] ;
    input \CGA[1] ;
    output RGB_c_12;
    input [2:0]PALSEL;
    input VCC_net;
    input \CGA[3] ;
    input \CGA[2] ;
    input \CGA[0] ;
    input \DBIN[5] ;
    input \DBIN[4] ;
    input \DBIN[3] ;
    input \DBIN[2] ;
    input \DBIN[1] ;
    input \DBIN[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]n987;
    wire [7:0]bo_7__N_1509;
    
    wire n7373;
    wire [7:0]n997;
    wire [7:0]bo;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1564[18:20])
    
    wire PICTURER2;
    wire [7:0]go;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1564[14:16])
    wire [7:0]gi;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1578[15:17])
    
    wire n7418, n2798;
    wire [7:0]ro;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1564[10:12])
    
    wire n2800, PICTURER, n10162, n568;
    wire [7:0]bi;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1578[19:21])
    
    wire n10184;
    wire [7:0]ri;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1578[11:13])
    wire [7:0]ro_7__N_1452;
    
    wire n10161, n10183, n2794, n7594, n2786, n2796, n10182, n2790, 
        n2792;
    wire [7:0]go_7__N_1460;
    wire [7:0]bo_7__N_1468;
    
    wire n10181, n2784, n2788, n10176, n5006;
    wire [5:0]C;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1569[11:12])
    
    wire n10159, n10175, n2802, n7596, n10160, n10174, C_5__N_1476, 
        CGAH_N_1535;
    wire [4:0]Address;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/palette_ram.v(13[22:29])
    
    wire n10173, n10169, n10168, n10167, n10166;
    
    LUT4 mux_500_i4_3_lut (.A(n987[3]), .B(bo_7__N_1509[3]), .C(n7373), 
         .Z(n997[3])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_500_i4_3_lut.init = 16'hacac;
    LUT4 i6996_2_lut (.A(bo[7]), .B(PICTURER2), .Z(RGB_c_7)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6996_2_lut.init = 16'h2222;
    LUT4 i6988_2_lut (.A(go[5]), .B(PICTURER2), .Z(RGB_c_13)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6988_2_lut.init = 16'h2222;
    LUT4 i6987_2_lut (.A(go[6]), .B(PICTURER2), .Z(RGB_c_14)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6987_2_lut.init = 16'h2222;
    LUT4 i6986_2_lut (.A(go[7]), .B(PICTURER2), .Z(RGB_c_15)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6986_2_lut.init = 16'h2222;
    LUT4 i6949_2_lut (.A(bo[0]), .B(PICTURER2), .Z(RGB_c_0)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6949_2_lut.init = 16'h2222;
    LUT4 mux_500_i3_3_lut (.A(n987[2]), .B(bo_7__N_1509[2]), .C(n7373), 
         .Z(n997[2])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_500_i3_3_lut.init = 16'hacac;
    LUT4 i7004_2_lut (.A(bo[1]), .B(PICTURER2), .Z(RGB_c_1)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i7004_2_lut.init = 16'h2222;
    LUT4 i7003_2_lut (.A(bo[2]), .B(PICTURER2), .Z(RGB_c_2)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i7003_2_lut.init = 16'h2222;
    LUT4 i6995_2_lut (.A(go[0]), .B(PICTURER2), .Z(RGB_c_8)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6995_2_lut.init = 16'h2222;
    LUT4 mux_528_i3_3_lut (.A(gi[4]), .B(gi[5]), .C(n7418), .Z(n2798)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_528_i3_3_lut.init = 16'h5353;
    LUT4 i6985_2_lut (.A(ro[0]), .B(PICTURER2), .Z(RGB_c_16)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6985_2_lut.init = 16'h2222;
    LUT4 i6994_2_lut (.A(go[1]), .B(PICTURER2), .Z(RGB_c_9)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6994_2_lut.init = 16'h2222;
    LUT4 i6984_2_lut (.A(ro[1]), .B(PICTURER2), .Z(RGB_c_17)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6984_2_lut.init = 16'h2222;
    LUT4 i6983_2_lut (.A(ro[2]), .B(PICTURER2), .Z(RGB_c_18)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6983_2_lut.init = 16'h2222;
    LUT4 mux_528_i4_3_lut (.A(gi[5]), .B(gi[6]), .C(n7418), .Z(n2800)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_528_i4_3_lut.init = 16'h5353;
    LUT4 i6982_2_lut (.A(ro[3]), .B(PICTURER2), .Z(RGB_c_19)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6982_2_lut.init = 16'h2222;
    FD1P3AX PICTURER_48 (.D(nPICTURE), .SP(PCLK_c), .CK(Clk), .Q(PICTURER));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PICTURER_48.GSR = "DISABLED";
    CCU2D add_518_9 (.A0(EMPH[2]), .B0(n568), .C0(bo_7__N_1509[7]), .D0(bi[7]), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n10162), 
          .S0(n987[7]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_518_9.INIT0 = 16'h04bf;
    defparam add_518_9.INIT1 = 16'h0000;
    defparam add_518_9.INJECT1_0 = "NO";
    defparam add_518_9.INJECT1_1 = "NO";
    LUT4 i6981_2_lut (.A(ro[4]), .B(PICTURER2), .Z(RGB_c_20)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6981_2_lut.init = 16'h2222;
    CCU2D add_664_9 (.A0(EMPH[2]), .B0(EMPH[1]), .C0(ri[6]), .D0(GND_net), 
          .A1(EMPH[2]), .B1(EMPH[1]), .C1(ri[7]), .D1(GND_net), .CIN(n10184), 
          .S0(ro_7__N_1452[6]), .S1(ro_7__N_1452[7]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_664_9.INIT0 = 16'h1e1e;
    defparam add_664_9.INIT1 = 16'h1e1e;
    defparam add_664_9.INJECT1_0 = "NO";
    defparam add_664_9.INJECT1_1 = "NO";
    LUT4 i6993_2_lut (.A(go[2]), .B(PICTURER2), .Z(RGB_c_10)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6993_2_lut.init = 16'h2222;
    CCU2D add_518_7 (.A0(EMPH[2]), .B0(n568), .C0(bo_7__N_1509[5]), .D0(bi[5]), 
          .A1(EMPH[2]), .B1(n568), .C1(bo_7__N_1509[6]), .D1(bi[6]), 
          .CIN(n10161), .COUT(n10162), .S0(n987[5]), .S1(n987[6]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_518_7.INIT0 = 16'h04bf;
    defparam add_518_7.INIT1 = 16'h04bf;
    defparam add_518_7.INJECT1_0 = "NO";
    defparam add_518_7.INJECT1_1 = "NO";
    CCU2D add_664_7 (.A0(ri[4]), .B0(EMPH[1]), .C0(EMPH[2]), .D0(n2794), 
          .A1(ri[5]), .B1(EMPH[1]), .C1(EMPH[2]), .D1(n7594), .CIN(n10183), 
          .COUT(n10184), .S0(ro_7__N_1452[4]), .S1(ro_7__N_1452[5]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_664_7.INIT0 = 16'h56aa;
    defparam add_664_7.INIT1 = 16'h56aa;
    defparam add_664_7.INJECT1_0 = "NO";
    defparam add_664_7.INJECT1_1 = "NO";
    LUT4 i6980_2_lut (.A(ro[5]), .B(PICTURER2), .Z(RGB_c_21)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6980_2_lut.init = 16'h2222;
    LUT4 mux_528_i1_3_lut (.A(gi[2]), .B(gi[3]), .C(n7418), .Z(n2786)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_528_i1_3_lut.init = 16'h5353;
    LUT4 mux_528_i2_3_lut (.A(gi[3]), .B(gi[4]), .C(n7418), .Z(n2796)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_528_i2_3_lut.init = 16'h5353;
    CCU2D add_664_5 (.A0(ri[2]), .B0(EMPH[1]), .C0(EMPH[2]), .D0(n2790), 
          .A1(ri[3]), .B1(EMPH[1]), .C1(EMPH[2]), .D1(n2792), .CIN(n10182), 
          .COUT(n10183), .S0(ro_7__N_1452[2]), .S1(ro_7__N_1452[3]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_664_5.INIT0 = 16'h56aa;
    defparam add_664_5.INIT1 = 16'h56aa;
    defparam add_664_5.INJECT1_0 = "NO";
    defparam add_664_5.INJECT1_1 = "NO";
    LUT4 i7000_2_lut (.A(bo[3]), .B(PICTURER2), .Z(RGB_c_3)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i7000_2_lut.init = 16'h2222;
    LUT4 mux_529_i5_3_lut (.A(ri[7]), .B(ri[6]), .C(EMPH[1]), .Z(n2794)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_529_i5_3_lut.init = 16'h3535;
    LUT4 i6979_2_lut (.A(ro[6]), .B(PICTURER2), .Z(RGB_c_22)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6979_2_lut.init = 16'h2222;
    LUT4 i10668_2_lut (.A(ri[7]), .B(EMPH[1]), .Z(n7594)) /* synthesis lut_function=(!(A (B))) */ ;
    defparam i10668_2_lut.init = 16'h7777;
    FD1S3AX ro_i0 (.D(ro_7__N_1452[0]), .CK(Clk), .Q(ro[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i0.GSR = "DISABLED";
    FD1S3AX PICTURER2_49 (.D(PICTURER), .CK(Clk), .Q(PICTURER2)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PICTURER2_49.GSR = "DISABLED";
    FD1S3AX go_i0 (.D(go_7__N_1460[0]), .CK(Clk), .Q(go[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i0.GSR = "DISABLED";
    FD1S3AX bo_i0 (.D(bo_7__N_1468[0]), .CK(Clk), .Q(bo[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i0.GSR = "DISABLED";
    LUT4 i6978_2_lut (.A(ro[7]), .B(PICTURER2), .Z(RGB_c_23)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6978_2_lut.init = 16'h2222;
    LUT4 mux_529_i3_3_lut (.A(ri[5]), .B(ri[4]), .C(EMPH[1]), .Z(n2790)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_529_i3_3_lut.init = 16'h3535;
    LUT4 mux_529_i4_3_lut (.A(ri[6]), .B(ri[5]), .C(EMPH[1]), .Z(n2792)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_529_i4_3_lut.init = 16'h3535;
    CCU2D add_664_3 (.A0(ri[0]), .B0(EMPH[1]), .C0(EMPH[2]), .D0(n2784), 
          .A1(ri[1]), .B1(EMPH[1]), .C1(EMPH[2]), .D1(n2788), .CIN(n10181), 
          .COUT(n10182), .S0(ro_7__N_1452[0]), .S1(ro_7__N_1452[1]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_664_3.INIT0 = 16'h56aa;
    defparam add_664_3.INIT1 = 16'h56aa;
    defparam add_664_3.INJECT1_0 = "NO";
    defparam add_664_3.INJECT1_1 = "NO";
    LUT4 mux_500_i2_3_lut (.A(n987[1]), .B(bo_7__N_1509[1]), .C(n7373), 
         .Z(n997[1])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_500_i2_3_lut.init = 16'hacac;
    CCU2D add_664_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(MODE_N_21), .B1(EMP_G), .C1(EMP_R), .D1(EMPH[2]), .COUT(n10181));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_664_1.INIT0 = 16'hF000;
    defparam add_664_1.INIT1 = 16'h0027;
    defparam add_664_1.INJECT1_0 = "NO";
    defparam add_664_1.INJECT1_1 = "NO";
    LUT4 mux_495_i1_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[0]), .D(n997[0]), 
         .Z(bo_7__N_1468[0])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_495_i1_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_495_i8_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[7]), .D(n997[7]), 
         .Z(bo_7__N_1468[7])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_495_i8_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_495_i7_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[6]), .D(n997[6]), 
         .Z(bo_7__N_1468[6])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_495_i7_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_495_i6_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[5]), .D(n997[5]), 
         .Z(bo_7__N_1468[5])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_495_i6_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_495_i5_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[4]), .D(n997[4]), 
         .Z(bo_7__N_1468[4])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_495_i5_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_495_i4_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[3]), .D(n997[3]), 
         .Z(bo_7__N_1468[3])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_495_i4_3_lut_4_lut.init = 16'hfe10;
    FD1S3AX bo_i7 (.D(bo_7__N_1468[7]), .CK(Clk), .Q(bo[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i7.GSR = "DISABLED";
    FD1S3AX bo_i6 (.D(bo_7__N_1468[6]), .CK(Clk), .Q(bo[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i6.GSR = "DISABLED";
    LUT4 mux_495_i3_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[2]), .D(n997[2]), 
         .Z(bo_7__N_1468[2])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_495_i3_3_lut_4_lut.init = 16'hfe10;
    FD1S3AX bo_i5 (.D(bo_7__N_1468[5]), .CK(Clk), .Q(bo[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i5.GSR = "DISABLED";
    FD1S3AX bo_i4 (.D(bo_7__N_1468[4]), .CK(Clk), .Q(bo[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i4.GSR = "DISABLED";
    FD1S3AX bo_i3 (.D(bo_7__N_1468[3]), .CK(Clk), .Q(bo[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i3.GSR = "DISABLED";
    FD1S3AX bo_i2 (.D(bo_7__N_1468[2]), .CK(Clk), .Q(bo[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i2.GSR = "DISABLED";
    LUT4 mux_495_i2_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[1]), .D(n997[1]), 
         .Z(bo_7__N_1468[1])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_495_i2_3_lut_4_lut.init = 16'hfe10;
    FD1S3AX bo_i1 (.D(bo_7__N_1468[1]), .CK(Clk), .Q(bo[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i1.GSR = "DISABLED";
    FD1S3AX go_i7 (.D(go_7__N_1460[7]), .CK(Clk), .Q(go[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i7.GSR = "DISABLED";
    FD1S3AX go_i6 (.D(go_7__N_1460[6]), .CK(Clk), .Q(go[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i6.GSR = "DISABLED";
    FD1S3AX go_i5 (.D(go_7__N_1460[5]), .CK(Clk), .Q(go[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i5.GSR = "DISABLED";
    FD1S3AX go_i4 (.D(go_7__N_1460[4]), .CK(Clk), .Q(go[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i4.GSR = "DISABLED";
    FD1S3AX go_i3 (.D(go_7__N_1460[3]), .CK(Clk), .Q(go[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i3.GSR = "DISABLED";
    FD1S3AX go_i2 (.D(go_7__N_1460[2]), .CK(Clk), .Q(go[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i2.GSR = "DISABLED";
    FD1S3AX go_i1 (.D(go_7__N_1460[1]), .CK(Clk), .Q(go[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i1.GSR = "DISABLED";
    FD1S3AX ro_i7 (.D(ro_7__N_1452[7]), .CK(Clk), .Q(ro[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i7.GSR = "DISABLED";
    FD1S3AX ro_i6 (.D(ro_7__N_1452[6]), .CK(Clk), .Q(ro[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i6.GSR = "DISABLED";
    FD1S3AX ro_i5 (.D(ro_7__N_1452[5]), .CK(Clk), .Q(ro[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i5.GSR = "DISABLED";
    LUT4 R7_I_0_2_lut (.A(R7), .B(TH_MUX), .Z(RPIX)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1573[15:26])
    defparam R7_I_0_2_lut.init = 16'h8888;
    FD1S3AX ro_i4 (.D(ro_7__N_1452[4]), .CK(Clk), .Q(ro[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i4.GSR = "DISABLED";
    FD1S3AX ro_i3 (.D(ro_7__N_1452[3]), .CK(Clk), .Q(ro[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i3.GSR = "DISABLED";
    FD1S3AX ro_i2 (.D(ro_7__N_1452[2]), .CK(Clk), .Q(ro[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i2.GSR = "DISABLED";
    FD1S3AX ro_i1 (.D(ro_7__N_1452[1]), .CK(Clk), .Q(ro[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i1.GSR = "DISABLED";
    LUT4 mux_500_i1_3_lut (.A(n987[0]), .B(bo_7__N_1509[0]), .C(n7373), 
         .Z(n997[0])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_500_i1_3_lut.init = 16'hacac;
    LUT4 i6929_4_lut (.A(n996), .B(EMPH[2]), .C(EMP_R), .D(EMP_G), .Z(n7373)) /* synthesis lut_function=(A+!((C (D)+!C !(D))+!B)) */ ;
    defparam i6929_4_lut.init = 16'haeea;
    LUT4 i6999_2_lut (.A(bo[4]), .B(PICTURER2), .Z(RGB_c_4)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6999_2_lut.init = 16'h2222;
    CCU2D add_667_9 (.A0(EMPH[0]), .B0(EMPH[2]), .C0(gi[6]), .D0(GND_net), 
          .A1(EMPH[0]), .B1(EMPH[2]), .C1(gi[7]), .D1(GND_net), .CIN(n10176), 
          .S0(go_7__N_1460[6]), .S1(go_7__N_1460[7]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_667_9.INIT0 = 16'h1e1e;
    defparam add_667_9.INIT1 = 16'h1e1e;
    defparam add_667_9.INJECT1_0 = "NO";
    defparam add_667_9.INJECT1_1 = "NO";
    LUT4 mux_529_i1_3_lut (.A(ri[3]), .B(ri[2]), .C(EMPH[1]), .Z(n2784)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_529_i1_3_lut.init = 16'h3535;
    LUT4 mux_529_i2_3_lut (.A(ri[4]), .B(ri[3]), .C(EMPH[1]), .Z(n2788)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_529_i2_3_lut.init = 16'h3535;
    FD1P3IX PIX_i0_i1 (.D(C[1]), .SP(PCLK_c), .CD(n5006), .CK(Clk), 
            .Q(PIX[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PIX_i0_i1.GSR = "DISABLED";
    FD1P3IX PIX_i0_i2 (.D(C[2]), .SP(PCLK_c), .CD(n5006), .CK(Clk), 
            .Q(PIX[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PIX_i0_i2.GSR = "DISABLED";
    FD1P3IX PIX_i0_i3 (.D(C[3]), .SP(PCLK_c), .CD(n5006), .CK(Clk), 
            .Q(PIX[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PIX_i0_i3.GSR = "DISABLED";
    FD1P3AX PIX_i0_i5 (.D(C[5]), .SP(PCLK_c), .CK(Clk), .Q(PIX[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PIX_i0_i5.GSR = "DISABLED";
    FD1P3AX PIX_i0_i4 (.D(C[4]), .SP(PCLK_c), .CK(Clk), .Q(PIX[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PIX_i0_i4.GSR = "DISABLED";
    LUT4 i6998_2_lut (.A(bo[5]), .B(PICTURER2), .Z(RGB_c_5)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6998_2_lut.init = 16'h2222;
    CCU2D add_518_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(bi[3]), .B1(bi[0]), .C1(bo_7__N_1509[0]), .D1(n996), .COUT(n10159), 
          .S1(n987[0]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_518_1.INIT0 = 16'h0000;
    defparam add_518_1.INIT1 = 16'ha599;
    defparam add_518_1.INJECT1_0 = "NO";
    defparam add_518_1.INJECT1_1 = "NO";
    CCU2D add_667_7 (.A0(gi[4]), .B0(EMPH[2]), .C0(EMPH[0]), .D0(n2802), 
          .A1(gi[5]), .B1(EMPH[2]), .C1(EMPH[0]), .D1(n7596), .CIN(n10175), 
          .COUT(n10176), .S0(go_7__N_1460[4]), .S1(go_7__N_1460[5]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_667_7.INIT0 = 16'h56aa;
    defparam add_667_7.INIT1 = 16'h56aa;
    defparam add_667_7.INJECT1_0 = "NO";
    defparam add_667_7.INJECT1_1 = "NO";
    LUT4 i6997_2_lut (.A(bo[6]), .B(PICTURER2), .Z(RGB_c_6)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6997_2_lut.init = 16'h2222;
    LUT4 i4537_4_lut (.A(PCLK_c), .B(B_W), .C(nPICTURE), .D(RPIX), .Z(n5006)) /* synthesis lut_function=(A (B+!((D)+!C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam i4537_4_lut.init = 16'h88a8;
    CCU2D add_518_3 (.A0(bi[4]), .B0(bi[1]), .C0(bo_7__N_1509[1]), .D0(n996), 
          .A1(bi[5]), .B1(bi[2]), .C1(bo_7__N_1509[2]), .D1(n996), .CIN(n10159), 
          .COUT(n10160), .S0(n987[1]), .S1(n987[2]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_518_3.INIT0 = 16'ha599;
    defparam add_518_3.INIT1 = 16'ha599;
    defparam add_518_3.INJECT1_0 = "NO";
    defparam add_518_3.INJECT1_1 = "NO";
    CCU2D add_667_5 (.A0(gi[2]), .B0(EMPH[2]), .C0(EMPH[0]), .D0(n2798), 
          .A1(gi[3]), .B1(EMPH[2]), .C1(EMPH[0]), .D1(n2800), .CIN(n10174), 
          .COUT(n10175), .S0(go_7__N_1460[2]), .S1(go_7__N_1460[3]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_667_5.INIT0 = 16'h56aa;
    defparam add_667_5.INIT1 = 16'h56aa;
    defparam add_667_5.INJECT1_0 = "NO";
    defparam add_667_5.INJECT1_1 = "NO";
    LUT4 TH_MUX_I_0_2_lut (.A(TH_MUX), .B(DB_PARR), .Z(C_5__N_1476)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1575[47:63])
    defparam TH_MUX_I_0_2_lut.init = 16'h8888;
    CCU2D add_518_5 (.A0(bi[6]), .B0(bi[3]), .C0(bo_7__N_1509[3]), .D0(n996), 
          .A1(bi[7]), .B1(bi[4]), .C1(bo_7__N_1509[4]), .D1(n996), .CIN(n10160), 
          .COUT(n10161), .S0(n987[3]), .S1(n987[4]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_518_5.INIT0 = 16'ha599;
    defparam add_518_5.INIT1 = 16'ha599;
    defparam add_518_5.INJECT1_0 = "NO";
    defparam add_518_5.INJECT1_1 = "NO";
    LUT4 mux_500_i8_3_lut (.A(n987[7]), .B(bo_7__N_1509[7]), .C(n7373), 
         .Z(n997[7])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_500_i8_3_lut.init = 16'hacac;
    LUT4 i6992_2_lut (.A(go[3]), .B(PICTURER2), .Z(RGB_c_11)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6992_2_lut.init = 16'h2222;
    LUT4 mux_500_i7_3_lut (.A(n987[6]), .B(bo_7__N_1509[6]), .C(n7373), 
         .Z(n997[6])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_500_i7_3_lut.init = 16'hacac;
    LUT4 CGAH_I_0_4_lut (.A(CGAH_N_1535), .B(\STEP3[4] ), .C(\THO_LATCH[4] ), 
         .D(TH_MUX), .Z(Address[4])) /* synthesis lut_function=(A (B (C+!(D))+!B (C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1567[15:43])
    defparam CGAH_I_0_4_lut.init = 16'ha088;
    LUT4 mux_500_i6_3_lut (.A(n987[5]), .B(bo_7__N_1509[5]), .C(n7373), 
         .Z(n997[5])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_500_i6_3_lut.init = 16'hacac;
    LUT4 mux_500_i5_3_lut (.A(n987[4]), .B(bo_7__N_1509[4]), .C(n7373), 
         .Z(n997[4])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_500_i5_3_lut.init = 16'hacac;
    LUT4 mux_528_i5_3_lut (.A(gi[6]), .B(gi[7]), .C(n7418), .Z(n2802)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_528_i5_3_lut.init = 16'h5353;
    LUT4 i10678_2_lut (.A(gi[7]), .B(n7418), .Z(n7596)) /* synthesis lut_function=(!(A (B))) */ ;
    defparam i10678_2_lut.init = 16'h7777;
    CCU2D add_667_3 (.A0(gi[0]), .B0(EMPH[2]), .C0(EMPH[0]), .D0(n2786), 
          .A1(gi[1]), .B1(EMPH[2]), .C1(EMPH[0]), .D1(n2796), .CIN(n10173), 
          .COUT(n10174), .S0(go_7__N_1460[0]), .S1(go_7__N_1460[1]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_667_3.INIT0 = 16'h56aa;
    defparam add_667_3.INIT1 = 16'h56aa;
    defparam add_667_3.INJECT1_0 = "NO";
    defparam add_667_3.INJECT1_1 = "NO";
    CCU2D add_667_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(MODE_N_21), .B1(EMP_G), .C1(EMP_R), .D1(EMPH[2]), .COUT(n10173));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_667_1.INIT0 = 16'hF000;
    defparam add_667_1.INIT1 = 16'h001b;
    defparam add_667_1.INJECT1_0 = "NO";
    defparam add_667_1.INJECT1_1 = "NO";
    FD1P3IX PIX_i0_i0 (.D(C[0]), .SP(PCLK_c), .CD(n5006), .CK(Clk), 
            .Q(PIX[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PIX_i0_i0.GSR = "DISABLED";
    CCU2D sub_34_add_2_9 (.A0(bi[7]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n10169), 
          .S0(bo_7__N_1509[7]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1629[14:26])
    defparam sub_34_add_2_9.INIT0 = 16'h5555;
    defparam sub_34_add_2_9.INIT1 = 16'h0000;
    defparam sub_34_add_2_9.INJECT1_0 = "NO";
    defparam sub_34_add_2_9.INJECT1_1 = "NO";
    LUT4 i204_2_lut (.A(EMP_G), .B(EMP_R), .Z(n568)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam i204_2_lut.init = 16'h8888;
    CCU2D sub_34_add_2_7 (.A0(bi[5]), .B0(bi[7]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[6]), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n10168), 
          .COUT(n10169), .S0(bo_7__N_1509[5]), .S1(bo_7__N_1509[6]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1629[14:26])
    defparam sub_34_add_2_7.INIT0 = 16'h5999;
    defparam sub_34_add_2_7.INIT1 = 16'h5555;
    defparam sub_34_add_2_7.INJECT1_0 = "NO";
    defparam sub_34_add_2_7.INJECT1_1 = "NO";
    CCU2D sub_34_add_2_5 (.A0(bi[3]), .B0(bi[5]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[4]), .B1(bi[6]), .C1(GND_net), .D1(GND_net), .CIN(n10167), 
          .COUT(n10168), .S0(bo_7__N_1509[3]), .S1(bo_7__N_1509[4]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1629[14:26])
    defparam sub_34_add_2_5.INIT0 = 16'h5999;
    defparam sub_34_add_2_5.INIT1 = 16'h5999;
    defparam sub_34_add_2_5.INJECT1_0 = "NO";
    defparam sub_34_add_2_5.INJECT1_1 = "NO";
    CCU2D sub_34_add_2_3 (.A0(bi[1]), .B0(bi[3]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[2]), .B1(bi[4]), .C1(GND_net), .D1(GND_net), .CIN(n10166), 
          .COUT(n10167), .S0(bo_7__N_1509[1]), .S1(bo_7__N_1509[2]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1629[14:26])
    defparam sub_34_add_2_3.INIT0 = 16'h5999;
    defparam sub_34_add_2_3.INIT1 = 16'h5999;
    defparam sub_34_add_2_3.INJECT1_0 = "NO";
    defparam sub_34_add_2_3.INJECT1_1 = "NO";
    LUT4 i7226_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(EMPH[0]), .D(EMPH[2]), 
         .Z(n7418)) /* synthesis lut_function=(A (B (C (D)+!C !(D))+!B (C+!(D)))+!A (C+!(D))) */ ;
    defparam i7226_3_lut_4_lut.init = 16'hf07f;
    LUT4 CGA_0__I_0_2_lut_4_lut (.A(\STEP3[0] ), .B(\THO_LATCH[0] ), .C(TH_MUX), 
         .D(\CGA[1] ), .Z(CGAH_N_1535)) /* synthesis lut_function=(A (B+((D)+!C))+!A (B (C+(D))+!B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1567[15:34])
    defparam CGA_0__I_0_2_lut_4_lut.init = 16'hffca;
    CCU2D sub_34_add_2_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(bi[0]), .B1(bi[2]), .C1(GND_net), .D1(GND_net), .COUT(n10166), 
          .S1(bo_7__N_1509[0]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1629[14:26])
    defparam sub_34_add_2_1.INIT0 = 16'h0000;
    defparam sub_34_add_2_1.INIT1 = 16'h5999;
    defparam sub_34_add_2_1.INJECT1_0 = "NO";
    defparam sub_34_add_2_1.INJECT1_1 = "NO";
    LUT4 i6989_2_lut (.A(go[4]), .B(PICTURER2), .Z(RGB_c_12)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6989_2_lut.init = 16'h2222;
    PALETTE_RGB_TABLE MOD_PALETTE_RGB_TABLE (.PALSEL({PALSEL}), .PIX({PIX}), 
            .Clk(Clk), .VCC_net(VCC_net), .GND_net(GND_net), .ri({ri}), 
            .gi({gi}), .bi({bi})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1576[19:113])
    PALETTE_RAM C_5__I_0 (.Clk(Clk), .VCC_net(VCC_net), .GND_net(GND_net), 
            .C_5__N_1476(C_5__N_1476), .CGAH(Address[4]), .\CGA[3] (\CGA[3] ), 
            .\CGA[2] (\CGA[2] ), .\CGA[1] (\CGA[1] ), .\CGA[0] (\CGA[0] ), 
            .\DBIN[5] (\DBIN[5] ), .\DBIN[4] (\DBIN[4] ), .\DBIN[3] (\DBIN[3] ), 
            .\DBIN[2] (\DBIN[2] ), .\DBIN[1] (\DBIN[1] ), .\DBIN[0] (\DBIN[0] ), 
            .C({C})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1575[13:100])
    
endmodule
//
// Verilog Description of module PALETTE_RGB_TABLE
//

module PALETTE_RGB_TABLE (PALSEL, PIX, Clk, VCC_net, GND_net, ri, 
            gi, bi) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input [2:0]PALSEL;
    input [5:0]PIX;
    input Clk;
    input VCC_net;
    input GND_net;
    output [7:0]ri;
    output [7:0]gi;
    output [7:0]bi;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    DP8KC PALETTE_RGB_TABLE_0_1_0 (.DIA0(GND_net), .DIA1(GND_net), .DIA2(GND_net), 
          .DIA3(GND_net), .DIA4(GND_net), .DIA5(GND_net), .DIA6(GND_net), 
          .DIA7(GND_net), .DIA8(GND_net), .ADA0(GND_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(PIX[0]), .ADA4(PIX[1]), .ADA5(PIX[2]), 
          .ADA6(PIX[3]), .ADA7(PIX[4]), .ADA8(PIX[5]), .ADA9(PALSEL[0]), 
          .ADA10(PALSEL[1]), .ADA11(PALSEL[2]), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(GND_net), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), 
          .ADB4(GND_net), .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), 
          .ADB8(GND_net), .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), 
          .ADB12(VCC_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(Clk), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(ri[2]), .DOA1(ri[3]), .DOA2(ri[4]), 
          .DOA3(ri[5]), .DOA4(ri[6]), .DOA5(ri[7])) /* synthesis MEM_LPC_FILE="PALETTE_RGB_TABLE.lpc", MEM_INIT_FILE="pal_table.mem", syn_instantiated=1, LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=113, LSE_LLINE=1576, LSE_RLINE=1576 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1576[19:113])
    defparam PALETTE_RGB_TABLE_0_1_0.DATA_WIDTH_A = 9;
    defparam PALETTE_RGB_TABLE_0_1_0.DATA_WIDTH_B = 9;
    defparam PALETTE_RGB_TABLE_0_1_0.REGMODE_A = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_1_0.REGMODE_B = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_1_0.CSDECODE_A = "0b000";
    defparam PALETTE_RGB_TABLE_0_1_0.CSDECODE_B = "0b000";
    defparam PALETTE_RGB_TABLE_0_1_0.WRITEMODE_A = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_1_0.WRITEMODE_B = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_1_0.GSR = "ENABLED";
    defparam PALETTE_RGB_TABLE_0_1_0.RESETMODE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_1_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_1_0.INIT_DATA = "STATIC";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_00 = "0x0000000000000000121603C2604E240341100C2B0000000000000000000701C1302C1501A0600019";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_01 = "0x0000005C2F05E3106A3B07C3F07E3E074360623F0000002613024160402E06C3C0763805A230323F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_02 = "0x0040200400000000181B052320642B03E0E0002B0040200400000000040D0301E03C1901E0400019";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_03 = "0x0040205A2B0542D0663907E3F07E3F0743405C3F004020260D018130403007C3F07E3F0662302A3F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_04 = "0x00000000000000000C1503E260522703610006290000000000000000000601E150321801E0700018";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_05 = "0x000000582A0542D062380783D07A390642F0563F000000240D01A1003C2C06A3C0783604C1C0263F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_06 = "0x0000000000000000161B0543406A2A03005000280000000000000000040D02E1E03C170160000016";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_07 = "0x000000562404A2A0623A07E3F07E3F0702F0503F00000020010080E03C3107E3F07E3F05A1700E3F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_08 = "0x0000001200000000122406C3F07E2D048000002D0000000000000000121B0482D05A24036000001B";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_09 = "0x00000048240242405A3F07E3F07E3F07E3605A3F0000002400024000363607E3F07E3F06C240363F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0A = "0x000000000000000010190442A0562703A1000A2D0000000000000000000A0241603218020080001A";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0B = "0x0000005E2D05A2F0683A0783F07E3B0703405E3F0000002813024170443606E3D07A3A0601F0303F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0C = "0x00402008000000701E3106A3F07E3F05A11000320020100000000000001E0482C05A2E0420D00020";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0D = "0x0080406E2C0542B0663F07E3F07E3F0682E0423F0060303200026140523F07E3F07E3F06A1B0003F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0E = "0x00000000000000000E1303E27052240340D002260000000000000000000601E1502C120160100014";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0F = "0x000000502804E2905A3306E3B0763906A300563A0000001E0E01811036280683B07A3805C2102A3A";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    DP8KC PALETTE_RGB_TABLE_0_0_1 (.DIA0(GND_net), .DIA1(GND_net), .DIA2(GND_net), 
          .DIA3(GND_net), .DIA4(GND_net), .DIA5(GND_net), .DIA6(GND_net), 
          .DIA7(GND_net), .DIA8(GND_net), .ADA0(GND_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(PIX[0]), .ADA4(PIX[1]), .ADA5(PIX[2]), 
          .ADA6(PIX[3]), .ADA7(PIX[4]), .ADA8(PIX[5]), .ADA9(PALSEL[0]), 
          .ADA10(PALSEL[1]), .ADA11(PALSEL[2]), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(GND_net), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(PIX[0]), 
          .ADB4(PIX[1]), .ADB5(PIX[2]), .ADB6(PIX[3]), .ADB7(PIX[4]), 
          .ADB8(PIX[5]), .ADB9(PALSEL[0]), .ADB10(PALSEL[1]), .ADB11(PALSEL[2]), 
          .ADB12(VCC_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(Clk), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(bi[0]), .DOA1(bi[1]), .DOA2(bi[2]), 
          .DOA3(bi[3]), .DOA4(bi[4]), .DOA5(bi[5]), .DOA6(bi[6]), .DOA7(bi[7]), 
          .DOA8(gi[0]), .DOB0(gi[1]), .DOB1(gi[2]), .DOB2(gi[3]), .DOB3(gi[4]), 
          .DOB4(gi[5]), .DOB5(gi[6]), .DOB6(gi[7]), .DOB7(ri[0]), .DOB8(ri[1])) /* synthesis MEM_LPC_FILE="PALETTE_RGB_TABLE.lpc", MEM_INIT_FILE="pal_table.mem", syn_instantiated=1, LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=113, LSE_LLINE=1576, LSE_RLINE=1576 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1576[19:113])
    defparam PALETTE_RGB_TABLE_0_0_1.DATA_WIDTH_A = 9;
    defparam PALETTE_RGB_TABLE_0_0_1.DATA_WIDTH_B = 9;
    defparam PALETTE_RGB_TABLE_0_0_1.REGMODE_A = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_0_1.REGMODE_B = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_0_1.CSDECODE_A = "0b000";
    defparam PALETTE_RGB_TABLE_0_0_1.CSDECODE_B = "0b000";
    defparam PALETTE_RGB_TABLE_0_0_1.WRITEMODE_A = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_0_1.WRITEMODE_B = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_0_1.GSR = "ENABLED";
    defparam PALETTE_RGB_TABLE_0_0_1.RESETMODE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_0_1.ASYNC_RESET_RELEASE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_0_1.INIT_DATA = "STATIC";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_00 = "0x000000008A07C0000100200000BDAE3AFE3191AF000000005522F0020100201000305D1048E0FB65";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_01 = "0x00000373F11A6B8148A4362CB1E2FF3FFFF3FFFF00000099CB2FC3F2180A0586A189FF1FFFF3FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_02 = "0x2130921298255002000020015306E53FEFF3EAAE213092135520400200000010008A8F178C033765";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_03 = "0x2130936EF7193A030F84332C03FFFF3FEFF3FFFF2130909DEA0F5160010020D641A9FF1FFFF3FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_04 = "0x000002038F07D00000000000009BAB3B3EB3A8A6000000015C03F00001002010002E601149B11E60";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_05 = "0x00000363E7187A812A95340B91C2FD3FEFF1FFFF00000094C60EC320070C21F5016CFF1FEFF1FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_06 = "0x00000001A90A5062000000000083981C8FE3DDA1000000005D04500200000000002E7230B9B31858";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_07 = "0x00000158FE1B2B03248631DA93A0FB1FCFE3FDFF00000085FE3494A020002113C321F61FDFE3FDFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_08 = "0x00000048920DA000010020000124FF1FFFF3B6B600000001490012420100200000DA6D3B6DB1256D";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_09 = "0x00000125FF3B76D2936D2939216CFF1FEFF3FFFF00000293FF3B70020100000003FEFF3FEFF1FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0A = "0x00000000912880020100200002C9B93BFEF3A6B4000000005903B08200000000003C671189A3116B";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0B = "0x0000037EF139CB4345A015AC63C3FF1FEFF3FFFF000000A5D210C3E01D0A0526B19BFF3FCFF1FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0C = "0x21309222C42CC15200002011A2BDAA398FF3FEC820B05001660440D001000000003C6A14CBF17480";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0D = "0x223113BAFF1DCB7333A215CB7399EA3FFFF3FEFE21B0D0CDFF35D6A200332BF59333CC3FEFF3FEFE";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0E = "0x00000001850570020100201000B3AD3CBF119D99000000014320100000000000004261116950F551";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0F = "0x00000346E237A9A1087F31BAB1A0F31FFFF1FEEA0000027BD70FA280010001050357FF3FEFF3FEEA";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_10 = "0x000000003707A4127BB334A9921B8D31F9714FD7000000001703A2003C98019822010020000012B2";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_11 = "0x000001B9F82F6FC2F4F50DFEA3CCE71D0EC3E5FF0000004CE32D1EB3CADA0984036C37277440A9FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_12 = "0x108841084209A4F291B934C153138701D9F1615710884108220562D04F1C01C80301003008702AB2";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_13 = "0x108843B6772F97C0F2F30D7E43BFDE3C2E82DFFF1088424E6A0ECF81E26109DBC363AE06D452B1FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_14 = "0x00000100330763F2783204A9931A0B01C9634B53000000001803C220439901F86200003010101430";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_15 = "0x000001B1F22E6F52EDF00D6E41BF5F2B9E02D7FF0000024BDE0CAE90C5D7193BD064B23653C09DFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_16 = "0x00000000340783E1722F2451601E8E0289E052D0000000001903C1F138953190420080104090222C";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_17 = "0x000000ACF21EC773E8EF2D1622BD5E1C2E60D9FF000002435F1D16A1CA592933B26732173443A5FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_18 = "0x00000024490B6490933636D80301002002406D5B000000002409236048A4249122010014800024B6";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_19 = "0x000002936D1FF7F2FFFF3FFED3B7C93B7DB2DBFF000001487F1FE7F1DBED3B7C936D8036D491B7FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1A = "0x000000003B080451833524B1600E0C0259B1545A000000001B042240441B01684000000008001BB5";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1B = "0x000003BF761F07A2EDF12DBE53C3E31C9690DFFF00000252E73D86F1D3ED1A044172BB07C4E3B3FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1C = "0x1088411042094C207A3114B1B237193321E05864104820001703C2403F9512780301800018000040";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1D = "0x110881DDF72F9770E16C2CD622BF5F0BBDD0BF7F10C862666C1D4EC2BF512913D26F3B16FC20957F";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1E = "0x00000000310783F075AE23E9000C0200E93246CC00000000140381E0369210C802018000080012A8";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1F = "0x000003A2EA2DD703DC693C45C3B1D72B2DD2C9750000013C5A2CAE82C6D7091B925D2B161BC39775";
    
endmodule
//
// Verilog Description of module PALETTE_RAM
//

module PALETTE_RAM (Clk, VCC_net, GND_net, C_5__N_1476, CGAH, \CGA[3] , 
            \CGA[2] , \CGA[1] , \CGA[0] , \DBIN[5] , \DBIN[4] , \DBIN[3] , 
            \DBIN[2] , \DBIN[1] , \DBIN[0] , C) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input Clk;
    input VCC_net;
    input GND_net;
    input C_5__N_1476;
    input CGAH;
    input \CGA[3] ;
    input \CGA[2] ;
    input \CGA[1] ;
    input \CGA[0] ;
    input \DBIN[5] ;
    input \DBIN[4] ;
    input \DBIN[3] ;
    input \DBIN[2] ;
    input \DBIN[1] ;
    input \DBIN[0] ;
    output [5:0]C;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    DP8KC PALETTE_RAM_0_0_0 (.DIA0(\DBIN[0] ), .DIA1(\DBIN[1] ), .DIA2(\DBIN[2] ), 
          .DIA3(\DBIN[3] ), .DIA4(\DBIN[4] ), .DIA5(\DBIN[5] ), .DIA6(GND_net), 
          .DIA7(GND_net), .DIA8(GND_net), .ADA0(VCC_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(\CGA[0] ), .ADA4(\CGA[1] ), .ADA5(\CGA[2] ), 
          .ADA6(\CGA[3] ), .ADA7(CGAH), .ADA8(GND_net), .ADA9(GND_net), 
          .ADA10(GND_net), .ADA11(GND_net), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(C_5__N_1476), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), 
          .ADB4(GND_net), .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), 
          .ADB8(GND_net), .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), 
          .ADB12(GND_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(GND_net), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(C[0]), .DOA1(C[1]), .DOA2(C[2]), .DOA3(C[3]), 
          .DOA4(C[4]), .DOA5(C[5])) /* synthesis MEM_LPC_FILE="PALETTE_RAM.lpc", MEM_INIT_FILE="INIT_ALL_0s", syn_instantiated=1, LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=100, LSE_LLINE=1575, LSE_RLINE=1575 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1575[13:100])
    defparam PALETTE_RAM_0_0_0.DATA_WIDTH_A = 9;
    defparam PALETTE_RAM_0_0_0.DATA_WIDTH_B = 9;
    defparam PALETTE_RAM_0_0_0.REGMODE_A = "NOREG";
    defparam PALETTE_RAM_0_0_0.REGMODE_B = "NOREG";
    defparam PALETTE_RAM_0_0_0.CSDECODE_A = "0b000";
    defparam PALETTE_RAM_0_0_0.CSDECODE_B = "0b111";
    defparam PALETTE_RAM_0_0_0.WRITEMODE_A = "NORMAL";
    defparam PALETTE_RAM_0_0_0.WRITEMODE_B = "NORMAL";
    defparam PALETTE_RAM_0_0_0.GSR = "ENABLED";
    defparam PALETTE_RAM_0_0_0.RESETMODE = "ASYNC";
    defparam PALETTE_RAM_0_0_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam PALETTE_RAM_0_0_0.INIT_DATA = "STATIC";
    defparam PALETTE_RAM_0_0_0.INITVAL_00 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_01 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_02 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_03 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_04 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_05 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_06 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_07 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_08 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_09 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    
endmodule
//
// Verilog Description of module TIMING_GENERATOR
//

module TIMING_GENERATOR (BLNK, Vo, MODE_c, DENDY_c, Clk, nPCLK, 
            S_EV, PCLK_c, CLIP_OUT, O_HPOS, nEVAL, RC, nRES_c, 
            RESCL, BGCLIP, CLIP_B_N_247, Hnn, \Hn[0] , I_OAM2, PAR_O, 
            N_HB, VSYNC, NFO_OUT, SRLOAD, BLNK_FF, STEP_N_685, E_EV, 
            R2, nVIS, F_NT, MODE_N_21, \Hn[2] , \Hn[1] , SYNC_c, 
            \R2DB[2] , Clk_enable_220, VBL_EN, INT_c, nPICTURE, F_AT, 
            PD_SR) /* synthesis syn_module_defined=1 */ ;
    input BLNK;
    output [7:0]Vo;
    input MODE_c;
    input DENDY_c;
    input Clk;
    input nPCLK;
    output S_EV;
    input PCLK_c;
    output CLIP_OUT;
    output O_HPOS;
    output nEVAL;
    output RC;
    input nRES_c;
    output RESCL;
    input BGCLIP;
    output CLIP_B_N_247;
    output [5:0]Hnn;
    output \Hn[0] ;
    output I_OAM2;
    output PAR_O;
    output N_HB;
    output VSYNC;
    output NFO_OUT;
    output SRLOAD;
    output BLNK_FF;
    output STEP_N_685;
    output E_EV;
    input R2;
    output nVIS;
    output F_NT;
    input MODE_N_21;
    output \Hn[2] ;
    output \Hn[1] ;
    output SYNC_c;
    output \R2DB[2] ;
    input Clk_enable_220;
    input VBL_EN;
    output INT_c;
    output nPICTURE;
    output F_AT;
    output PD_SR;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire VSYNC /* synthesis SET_AS_NETWORK=VSYNC, is_clock=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(125[6:11])
    wire [8:0]H;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(737[11:12])
    
    wire IOAM2_IN_N_355, V_LINE3N_N_535, V_LINE3N_N_533, SEV_IN, H_LINE2_N_446, 
        CLIP1, CLIP1_N_346, CLIP_OUT_N_338, HPOS_IN, nEVAL_N_251, 
        n10653, V_LINE1N_N_516, n4137, n4190, VSYNCo_N_327;
    wire [8:0]V;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(737[14:15])
    
    wire V_LINE0P_N_511, n11513, n11511, n11514, FTB_OUT, FTB_IN_N_373, 
        n4178, V_LINE0N_N_487, n4131, NVIS_IN, NVIS_IN_N_258, n11512, 
        n11637, IOAM2_IN, n11638, PARO_IN, n4143, Clk_enable_6, 
        n11640, n11641, n4175, n4196, n4112, n11450, n4, n11830, 
        Clk_enable_23, n4166, FAT_IN_N_282, IOAM2_IN_N_356, n4121, 
        INT_FF, Clk_enable_9, INT_FF_N_437;
    wire [1:0]ODDEVEN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(706[10:17])
    
    wire V_8__N_515, ODDEVEN_0__N_221;
    wire [2:0]VSET;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(731[10:14])
    
    wire VSET_1__N_226, FTA_IN, FTA_IN_N_379, Clk_enable_232, nRES_N_15, 
        n11631, VSET_0__N_229, n11630, n4199, F_AT_N_286, HSYNCo, 
        FPORCH_FF_N_316, VSYNC_adj_1603, VSYNC_N_408, PICT1, BPORCH_FF, 
        PICT2, PEN_FF, RESCL_IN, HC, HC_N_238, CLIP2, CLIP2_N_343, 
        H_LINE5_N_453, EVAL_IN, H_LINE6_N_460, EEV_IN, H_LINE7_N_468, 
        PARO_IN_N_359, NVIS_IN_N_261, FNT_IN, FNT_IN_N_364, H_8__N_233, 
        FAT_IN, FTA_IN_N_376, FTB_IN, FTB_IN_N_367, NFO1, NFO1_N_382, 
        NFO2, NVIS_IN_N_262, FPORCH_FF, Clk_enable_22, H_LINE0_N_441, 
        Clk_enable_24, BPORCH_FF_N_420, Clk_enable_25, PEN_FF_N_423, 
        Clk_enable_26, V_LINE3P_N_538, VB_FF, Clk_enable_27, VB_FF_N_268, 
        VC_LATCH_N_218, n10686, HIN5, FTA_OUT;
    wire [5:0]Hn;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(675[16:18])
    
    wire PARO_IN_N_361, n11680, N_HB_N_307, H_LINE23_N_478, n11466, 
        Vo_7__N_212, n7476, n7560, n7558, V_LINE2N_N_527, n10722, 
        n11632, CNT1_N_565, CNT1_N_565_adj_1604, C_OUT_N_563, CNT1_N_565_adj_1605, 
        C_OUT_N_563_adj_1606, CNT1_N_565_adj_1607, C_OUT_N_563_adj_1608, 
        CNT1_N_565_adj_1609, C_OUT_N_563_adj_1610, CNT1_N_565_adj_1611, 
        C_OUT_N_563_adj_1612, CNT1_N_565_adj_1613;
    
    LUT4 i10436_2_lut_4_lut (.A(BLNK), .B(H[8]), .C(H[7]), .D(H[6]), 
         .Z(IOAM2_IN_N_355)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(837[23:56])
    defparam i10436_2_lut_4_lut.init = 16'h0001;
    LUT4 i10396_2_lut_3_lut_4_lut (.A(V_LINE3N_N_535), .B(Vo[0]), .C(MODE_c), 
         .D(DENDY_c), .Z(V_LINE3N_N_533)) /* synthesis lut_function=(!(A+!(B (C (D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(768[22:83])
    defparam i10396_2_lut_3_lut_4_lut.init = 16'h4000;
    FD1P3AX SEV_IN_663 (.D(H_LINE2_N_446), .SP(nPCLK), .CK(Clk), .Q(SEV_IN));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam SEV_IN_663.GSR = "DISABLED";
    FD1P3AX S_EV_641 (.D(SEV_IN), .SP(PCLK_c), .CK(Clk), .Q(S_EV));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam S_EV_641.GSR = "DISABLED";
    FD1P3AX CLIP1_664 (.D(CLIP1_N_346), .SP(nPCLK), .CK(Clk), .Q(CLIP1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam CLIP1_664.GSR = "DISABLED";
    FD1P3AX CLIP_OUT_642 (.D(CLIP_OUT_N_338), .SP(PCLK_c), .CK(Clk), .Q(CLIP_OUT));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam CLIP_OUT_642.GSR = "DISABLED";
    FD1P3AX O_HPOS_643 (.D(HPOS_IN), .SP(PCLK_c), .CK(Clk), .Q(O_HPOS));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam O_HPOS_643.GSR = "DISABLED";
    FD1P3AX nEVAL_644 (.D(nEVAL_N_251), .SP(PCLK_c), .CK(Clk), .Q(nEVAL));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam nEVAL_644.GSR = "DISABLED";
    LUT4 i1_3_lut (.A(RC), .B(nRES_c), .C(RESCL), .Z(n10653)) /* synthesis lut_function=(!(A (B (C))+!A (B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam i1_3_lut.init = 16'h3b3b;
    LUT4 i10380_2_lut (.A(CLIP_OUT), .B(BGCLIP), .Z(CLIP_B_N_247)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(735[17:39])
    defparam i10380_2_lut.init = 16'h1111;
    LUT4 i10410_4_lut (.A(V_LINE1N_N_516), .B(n4137), .C(n4190), .D(Vo[3]), 
         .Z(VSYNCo_N_327)) /* synthesis lut_function=(!(A (B+(C+!(D))))) */ ;
    defparam i10410_4_lut.init = 16'h5755;
    LUT4 V_LINE0P_I_160_2_lut_4_lut (.A(Vo[7]), .B(Vo[6]), .C(V[8]), .D(Vo[5]), 
         .Z(V_LINE0P_N_511)) /* synthesis lut_function=(A+(B+((D)+!C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(763[22:51])
    defparam V_LINE0P_I_160_2_lut_4_lut.init = 16'hffef;
    PFUMX i10870 (.BLUT(n11513), .ALUT(n11511), .C0(Vo[2]), .Z(n11514));
    FD1S3AX RC_637 (.D(n10653), .CK(Clk), .Q(RC)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam RC_637.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut (.A(Vo[1]), .B(MODE_c), .C(DENDY_c), .Z(n4137)) /* synthesis lut_function=(A+(B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(763[20:101])
    defparam i1_2_lut_3_lut.init = 16'heaea;
    FD1P3AX FTB_OUT_651 (.D(FTB_IN_N_373), .SP(PCLK_c), .CK(Clk), .Q(FTB_OUT));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam FTB_OUT_651.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_adj_412 (.A(H[1]), .B(H[0]), .C(H[4]), .Z(n4178)) /* synthesis lut_function=(A+(B+!(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(751[20:93])
    defparam i1_2_lut_3_lut_adj_412.init = 16'hefef;
    LUT4 i2_3_lut_4_lut (.A(Vo[2]), .B(MODE_c), .C(DENDY_c), .D(V_LINE0N_N_487), 
         .Z(n4131)) /* synthesis lut_function=((((D)+!C)+!B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(762[20:93])
    defparam i2_3_lut_4_lut.init = 16'hff7f;
    LUT4 NVIS_IN_I_0_1_lut (.A(NVIS_IN), .Z(NVIS_IN_N_258)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(814[23:31])
    defparam NVIS_IN_I_0_1_lut.init = 16'h5555;
    FD1P3AX Hnn_i0_i0 (.D(\Hn[0] ), .SP(PCLK_c), .CK(Clk), .Q(Hnn[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hnn_i0_i0.GSR = "DISABLED";
    LUT4 i2_3_lut (.A(Vo[1]), .B(n4131), .C(Vo[0]), .Z(V_LINE1N_N_516)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(764[20:93])
    defparam i2_3_lut.init = 16'hfefe;
    LUT4 n11512_bdd_2_lut (.A(n11512), .B(V_LINE0P_N_511), .Z(n11513)) /* synthesis lut_function=(!((B)+!A)) */ ;
    defparam n11512_bdd_2_lut.init = 16'h2222;
    LUT4 Vo_7__bdd_4_lut_10930 (.A(DENDY_c), .B(MODE_c), .C(Vo[6]), .D(V[8]), 
         .Z(n11637)) /* synthesis lut_function=(A (B+(C+!(D)))+!A (C+!(D))) */ ;
    defparam Vo_7__bdd_4_lut_10930.init = 16'hf8ff;
    FD1P3AX I_OAM2_646 (.D(IOAM2_IN), .SP(PCLK_c), .CK(Clk), .Q(I_OAM2));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam I_OAM2_646.GSR = "DISABLED";
    LUT4 Vo_7__bdd_4_lut_11010 (.A(Vo[1]), .B(Vo[0]), .C(Vo[3]), .D(n11637), 
         .Z(n11638)) /* synthesis lut_function=(((C+(D))+!B)+!A) */ ;
    defparam Vo_7__bdd_4_lut_11010.init = 16'hfff7;
    FD1P3AX PAR_O_647 (.D(PARO_IN), .SP(PCLK_c), .CK(Clk), .Q(PAR_O));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam PAR_O_647.GSR = "DISABLED";
    LUT4 Vo_7__bdd_3_lut_11012 (.A(Vo[7]), .B(Vo[5]), .C(n11638), .Z(n4143)) /* synthesis lut_function=(A+((C)+!B)) */ ;
    defparam Vo_7__bdd_3_lut_11012.init = 16'hfbfb;
    LUT4 VSYNCo_N_327_bdd_3_lut_10945 (.A(VSYNCo_N_327), .B(N_HB), .C(n11514), 
         .Z(Clk_enable_6)) /* synthesis lut_function=(A (B)+!A (B (C))) */ ;
    defparam VSYNCo_N_327_bdd_3_lut_10945.init = 16'hc8c8;
    LUT4 Vo_1__bdd_3_lut (.A(Vo[1]), .B(Vo[4]), .C(n11640), .Z(n11641)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam Vo_1__bdd_3_lut.init = 16'hfefe;
    LUT4 PCLK_c_bdd_4_lut_11022 (.A(n4175), .B(H[8]), .C(n4196), .D(n4112), 
         .Z(n11450)) /* synthesis lut_function=(!(A+(B (D)+!B (C (D))))) */ ;
    defparam PCLK_c_bdd_4_lut_11022.init = 16'h0155;
    LUT4 PCLK_c_bdd_4_lut (.A(PCLK_c), .B(n4), .C(H[4]), .D(n11830), 
         .Z(Clk_enable_23)) /* synthesis lut_function=(!(A+(B+!(C (D))))) */ ;
    defparam PCLK_c_bdd_4_lut.init = 16'h1000;
    LUT4 i3_4_lut (.A(Vo[2]), .B(V_LINE0P_N_511), .C(Vo[0]), .D(Vo[4]), 
         .Z(n4190)) /* synthesis lut_function=((B+((D)+!C))+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(765[20:101])
    defparam i3_4_lut.init = 16'hffdf;
    LUT4 PCLK_c_bdd_4_lut_11023 (.A(H[2]), .B(H[5]), .C(H[1]), .D(H[0]), 
         .Z(n11830)) /* synthesis lut_function=(!(A (B+!(C (D)))+!A ((C+(D))+!B))) */ ;
    defparam PCLK_c_bdd_4_lut_11023.init = 16'h2004;
    FD1P3AX VSYNC_FF_636 (.D(VSYNCo_N_327), .SP(Clk_enable_6), .CK(Clk), 
            .Q(VSYNC));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam VSYNC_FF_636.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(Vo[3]), .B(Vo[4]), .Z(n4166)) /* synthesis lut_function=(A+!(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(762[22:59])
    defparam i1_2_lut.init = 16'hbbbb;
    LUT4 i10446_2_lut (.A(H[2]), .B(H[1]), .Z(FAT_IN_N_282)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(841[17:34])
    defparam i10446_2_lut.init = 16'h4444;
    LUT4 i10385_4_lut (.A(IOAM2_IN_N_356), .B(H[1]), .C(H[4]), .D(n4121), 
         .Z(H_LINE2_N_446)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(752[19:101])
    defparam i10385_4_lut.init = 16'h0001;
    LUT4 i2_4_lut (.A(Vo[7]), .B(n4166), .C(Vo[6]), .D(Vo[5]), .Z(V_LINE0N_N_487)) /* synthesis lut_function=((B+!(C (D)))+!A) */ ;
    defparam i2_4_lut.init = 16'hdfff;
    LUT4 PD_SR_N_683_I_0_2_lut_3_lut_4_lut (.A(FTB_OUT), .B(NFO_OUT), .C(PCLK_c), 
         .D(Hnn[0]), .Z(SRLOAD)) /* synthesis lut_function=(!(A+(B+(C+!(D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(778[16:37])
    defparam PD_SR_N_683_I_0_2_lut_3_lut_4_lut.init = 16'h0100;
    FD1P3AX INT_FF_638 (.D(INT_FF_N_437), .SP(Clk_enable_9), .CK(Clk), 
            .Q(INT_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam INT_FF_638.GSR = "DISABLED";
    FD1P3AX ODDEVEN_i1 (.D(ODDEVEN_0__N_221), .SP(V_8__N_515), .CK(Clk), 
            .Q(ODDEVEN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam ODDEVEN_i1.GSR = "DISABLED";
    FD1P3AX VSET_i2 (.D(VSET_1__N_226), .SP(nPCLK), .CK(Clk), .Q(VSET[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam VSET_i2.GSR = "DISABLED";
    LUT4 FTA_IN_I_0_1_lut (.A(FTA_IN), .Z(FTA_IN_N_379)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(816[17:24])
    defparam FTA_IN_I_0_1_lut.init = 16'h5555;
    LUT4 Vo_1__bdd_4_lut_11016 (.A(V[8]), .B(Vo[5]), .C(Vo[2]), .D(Vo[3]), 
         .Z(n11640)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam Vo_1__bdd_4_lut_11016.init = 16'hfffe;
    LUT4 i1_2_lut_adj_413 (.A(V[8]), .B(nRES_c), .Z(Clk_enable_232)) /* synthesis lut_function=(A+!(B)) */ ;
    defparam i1_2_lut_adj_413.init = 16'hbbbb;
    LUT4 nRES_I_0_1_lut (.A(nRES_c), .Z(nRES_N_15)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(489[54:59])
    defparam nRES_I_0_1_lut.init = 16'h5555;
    LUT4 i10700_2_lut_then_4_lut (.A(PCLK_c), .B(V_LINE3N_N_535), .C(Vo[0]), 
         .D(MODE_c), .Z(n11631)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;
    defparam i10700_2_lut_then_4_lut.init = 16'h0010;
    FD1P3AX VSET_i1 (.D(VSET_0__N_229), .SP(PCLK_c), .CK(Clk), .Q(VSET[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam VSET_i1.GSR = "DISABLED";
    LUT4 i10700_2_lut_else_4_lut (.A(PCLK_c), .B(Vo[4]), .C(Vo[2]), .D(n4143), 
         .Z(n11630)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;
    defparam i10700_2_lut_else_4_lut.init = 16'h0001;
    LUT4 i2_3_lut_4_lut_adj_414 (.A(H[3]), .B(H[5]), .C(H[6]), .D(H[7]), 
         .Z(n4196)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(832[24:60])
    defparam i2_3_lut_4_lut_adj_414.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_adj_415 (.A(H[3]), .B(H[5]), .C(H[6]), .Z(n4199)) /* synthesis lut_function=(A+(B+!(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(832[24:60])
    defparam i1_2_lut_3_lut_adj_415.init = 16'hefef;
    FD1P3AX NFO_OUT_652 (.D(F_AT_N_286), .SP(PCLK_c), .CK(Clk), .Q(NFO_OUT));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam NFO_OUT_652.GSR = "DISABLED";
    FD1P3AX HSYNC_654 (.D(FPORCH_FF_N_316), .SP(PCLK_c), .CK(Clk), .Q(HSYNCo));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam HSYNC_654.GSR = "DISABLED";
    FD1P3AX VSYNC_655 (.D(VSYNC_N_408), .SP(PCLK_c), .CK(Clk), .Q(VSYNC_adj_1603));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam VSYNC_655.GSR = "DISABLED";
    FD1P3AX PICT1_656 (.D(BPORCH_FF), .SP(PCLK_c), .CK(Clk), .Q(PICT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam PICT1_656.GSR = "DISABLED";
    FD1P3AX PICT2_657 (.D(PEN_FF), .SP(PCLK_c), .CK(Clk), .Q(PICT2));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam PICT2_657.GSR = "DISABLED";
    FD1P3AX RESCL_658 (.D(RESCL_IN), .SP(PCLK_c), .CK(Clk), .Q(RESCL));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam RESCL_658.GSR = "DISABLED";
    FD1P3AX HC_660 (.D(HC_N_238), .SP(nPCLK), .CK(Clk), .Q(HC));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam HC_660.GSR = "DISABLED";
    FD1P3AX CLIP2_665 (.D(CLIP2_N_343), .SP(nPCLK), .CK(Clk), .Q(CLIP2));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam CLIP2_665.GSR = "DISABLED";
    FD1P3AX HPOS_IN_666 (.D(H_LINE5_N_453), .SP(nPCLK), .CK(Clk), .Q(HPOS_IN));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam HPOS_IN_666.GSR = "DISABLED";
    FD1P3AX EVAL_IN_667 (.D(H_LINE6_N_460), .SP(nPCLK), .CK(Clk), .Q(EVAL_IN));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam EVAL_IN_667.GSR = "DISABLED";
    FD1P3AX EEV_IN_668 (.D(H_LINE7_N_468), .SP(nPCLK), .CK(Clk), .Q(EEV_IN));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam EEV_IN_668.GSR = "DISABLED";
    FD1P3AX IOAM2_IN_669 (.D(IOAM2_IN_N_355), .SP(nPCLK), .CK(Clk), .Q(IOAM2_IN));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam IOAM2_IN_669.GSR = "DISABLED";
    FD1P3AX PARO_IN_670 (.D(PARO_IN_N_359), .SP(nPCLK), .CK(Clk), .Q(PARO_IN));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam PARO_IN_670.GSR = "DISABLED";
    FD1P3AX NVIS_IN_671 (.D(NVIS_IN_N_261), .SP(nPCLK), .CK(Clk), .Q(NVIS_IN));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam NVIS_IN_671.GSR = "DISABLED";
    FD1P3AX FNT_IN_672 (.D(FNT_IN_N_364), .SP(nPCLK), .CK(Clk), .Q(FNT_IN));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam FNT_IN_672.GSR = "DISABLED";
    LUT4 H_8__I_31_2_lut (.A(HC), .B(PCLK_c), .Z(H_8__N_233)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(743[82:92])
    defparam H_8__I_31_2_lut.init = 16'h4444;
    FD1P3AX FAT_IN_673 (.D(FAT_IN_N_282), .SP(nPCLK), .CK(Clk), .Q(FAT_IN));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam FAT_IN_673.GSR = "DISABLED";
    FD1P3AX FTA_IN_674 (.D(FTA_IN_N_376), .SP(nPCLK), .CK(Clk), .Q(FTA_IN));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam FTA_IN_674.GSR = "DISABLED";
    FD1P3AX FTB_IN_675 (.D(FTB_IN_N_367), .SP(nPCLK), .CK(Clk), .Q(FTB_IN));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam FTB_IN_675.GSR = "DISABLED";
    FD1P3AX NFO1_676 (.D(NFO1_N_382), .SP(nPCLK), .CK(Clk), .Q(NFO1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam NFO1_676.GSR = "DISABLED";
    FD1P3AX NFO2_677 (.D(NVIS_IN_N_262), .SP(nPCLK), .CK(Clk), .Q(NFO2));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam NFO2_677.GSR = "DISABLED";
    FD1P3AX FPORCH_FF_678 (.D(H_LINE0_N_441), .SP(Clk_enable_22), .CK(Clk), 
            .Q(FPORCH_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam FPORCH_FF_678.GSR = "DISABLED";
    FD1P3AX N_HB_680 (.D(H_LINE0_N_441), .SP(Clk_enable_23), .CK(Clk), 
            .Q(N_HB));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam N_HB_680.GSR = "DISABLED";
    FD1P3AX BPORCH_FF_681 (.D(BPORCH_FF_N_420), .SP(Clk_enable_24), .CK(Clk), 
            .Q(BPORCH_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam BPORCH_FF_681.GSR = "DISABLED";
    FD1P3AX PEN_FF_682 (.D(PEN_FF_N_423), .SP(Clk_enable_25), .CK(Clk), 
            .Q(PEN_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam PEN_FF_682.GSR = "DISABLED";
    FD1P3AX BLNK_FF_683 (.D(V_LINE3P_N_538), .SP(Clk_enable_26), .CK(Clk), 
            .Q(BLNK_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam BLNK_FF_683.GSR = "DISABLED";
    FD1P3AX VB_FF_684 (.D(VB_FF_N_268), .SP(Clk_enable_27), .CK(Clk), 
            .Q(VB_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam VB_FF_684.GSR = "DISABLED";
    LUT4 Hnn0_I_0_2_lut_3_lut (.A(FTB_OUT), .B(NFO_OUT), .C(Hnn[0]), .Z(STEP_N_685)) /* synthesis lut_function=(!(A+(B+!(C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(778[16:37])
    defparam Hnn0_I_0_2_lut_3_lut.init = 16'h1010;
    FD1P3AX RESCL_IN_685 (.D(VC_LATCH_N_218), .SP(nPCLK), .CK(Clk), .Q(RESCL_IN));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam RESCL_IN_685.GSR = "DISABLED";
    FD1P3AX E_EV_645 (.D(EEV_IN), .SP(PCLK_c), .CK(Clk), .Q(E_EV));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam E_EV_645.GSR = "DISABLED";
    LUT4 i3_4_lut_adj_416 (.A(H[1]), .B(H[4]), .C(H[3]), .D(n10686), 
         .Z(HIN5)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(739[15:47])
    defparam i3_4_lut_adj_416.init = 16'h8000;
    LUT4 i1_2_lut_adj_417 (.A(H[2]), .B(H[0]), .Z(n10686)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(739[15:47])
    defparam i1_2_lut_adj_417.init = 16'h8888;
    LUT4 i1_4_lut (.A(VSET[2]), .B(INT_FF_N_437), .C(VSET[0]), .D(PCLK_c), 
         .Z(Clk_enable_9)) /* synthesis lut_function=(!(A (B)+!A !((C (D))+!B))) */ ;
    defparam i1_4_lut.init = 16'h7333;
    LUT4 i10556_2_lut (.A(RESCL), .B(R2), .Z(INT_FF_N_437)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam i10556_2_lut.init = 16'h1111;
    FD1P3AX nVIS_648 (.D(NVIS_IN_N_258), .SP(PCLK_c), .CK(Clk), .Q(nVIS));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam nVIS_648.GSR = "DISABLED";
    LUT4 i10439_2_lut_3_lut_4_lut (.A(BLNK), .B(H[8]), .C(H[7]), .D(H[6]), 
         .Z(PARO_IN_N_359)) /* synthesis lut_function=(!(A+((C+(D))+!B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(753[23:43])
    defparam i10439_2_lut_3_lut_4_lut.init = 16'h0004;
    LUT4 V_8__I_0_1_lut (.A(V[8]), .Z(V_8__N_515)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(763[22:27])
    defparam V_8__I_0_1_lut.init = 16'h5555;
    LUT4 ODDEVEN_0__I_0_1_lut (.A(ODDEVEN[0]), .Z(ODDEVEN_0__N_221)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(828[49:60])
    defparam ODDEVEN_0__I_0_1_lut.init = 16'h5555;
    LUT4 i10430_2_lut (.A(H[4]), .B(n4196), .Z(CLIP1_N_346)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(832[23:60])
    defparam i10430_2_lut.init = 16'h1111;
    LUT4 VSET_1__I_0_1_lut (.A(VSET[1]), .Z(VSET_1__N_226)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(862[22:30])
    defparam VSET_1__I_0_1_lut.init = 16'h5555;
    LUT4 VSET_0__I_0_1_lut (.A(VSET[0]), .Z(VSET_0__N_229)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(803[25:33])
    defparam VSET_0__I_0_1_lut.init = 16'h5555;
    LUT4 i10412_2_lut (.A(CLIP1), .B(CLIP2), .Z(CLIP_OUT_N_338)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(808[23:42])
    defparam i10412_2_lut.init = 16'h4444;
    LUT4 i10462_3_lut_3_lut_4_lut (.A(V_LINE3N_N_535), .B(Vo[0]), .C(MODE_c), 
         .D(DENDY_c), .Z(PEN_FF_N_423)) /* synthesis lut_function=(!(A+!(B (C (D))+!B !(C (D))))) */ ;
    defparam i10462_3_lut_3_lut_4_lut.init = 16'h4111;
    LUT4 i10448_2_lut (.A(H[2]), .B(H[1]), .Z(FTA_IN_N_376)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(842[17:34])
    defparam i10448_2_lut.init = 16'h2222;
    LUT4 i10415_3_lut (.A(EEV_IN), .B(EVAL_IN), .C(HPOS_IN), .Z(nEVAL_N_251)) /* synthesis lut_function=(!(A+(B+(C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(810[23:54])
    defparam i10415_3_lut.init = 16'h0101;
    LUT4 i10467_3_lut_4_lut (.A(Vo[7]), .B(Vo[6]), .C(n11641), .D(Vo[0]), 
         .Z(VB_FF_N_268)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(763[22:43])
    defparam i10467_3_lut_4_lut.init = 16'h0001;
    LUT4 i6909_2_lut (.A(H[2]), .B(H[1]), .Z(FTB_IN_N_367)) /* synthesis lut_function=(A (B)) */ ;
    defparam i6909_2_lut.init = 16'h8888;
    LUT4 FPORCH_FF_I_0_1_lut (.A(FPORCH_FF), .Z(FPORCH_FF_N_316)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(820[23:33])
    defparam FPORCH_FF_I_0_1_lut.init = 16'h5555;
    LUT4 i10418_2_lut (.A(N_HB), .B(VSYNC), .Z(VSYNC_N_408)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(821[23:43])
    defparam i10418_2_lut.init = 16'h1111;
    FD1P3AX F_NT_649 (.D(FNT_IN), .SP(PCLK_c), .CK(Clk), .Q(F_NT));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam F_NT_649.GSR = "DISABLED";
    FD1P3AX FTA_OUT_650 (.D(FTA_IN_N_379), .SP(PCLK_c), .CK(Clk), .Q(FTA_OUT));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam FTA_OUT_650.GSR = "DISABLED";
    LUT4 V_LINE0P_N_511_bdd_4_lut_10948 (.A(Vo[0]), .B(n4166), .C(Vo[1]), 
         .D(MODE_N_21), .Z(n11512)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;
    defparam V_LINE0P_N_511_bdd_4_lut_10948.init = 16'h0001;
    LUT4 FTB_IN_I_0_1_lut (.A(FTB_IN), .Z(FTB_IN_N_373)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(817[23:30])
    defparam FTB_IN_I_0_1_lut.init = 16'h5555;
    FD1P3AX Hnn_i0_i5 (.D(Hn[5]), .SP(PCLK_c), .CK(Clk), .Q(Hnn[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hnn_i0_i5.GSR = "DISABLED";
    FD1P3AX Hnn_i0_i4 (.D(Hn[4]), .SP(PCLK_c), .CK(Clk), .Q(Hnn[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hnn_i0_i4.GSR = "DISABLED";
    FD1P3AX Hnn_i0_i3 (.D(Hn[3]), .SP(PCLK_c), .CK(Clk), .Q(Hnn[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hnn_i0_i3.GSR = "DISABLED";
    FD1P3AX Hnn_i0_i2 (.D(\Hn[2] ), .SP(PCLK_c), .CK(Clk), .Q(Hnn[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hnn_i0_i2.GSR = "DISABLED";
    FD1P3AX Hnn_i0_i1 (.D(\Hn[1] ), .SP(PCLK_c), .CK(Clk), .Q(Hnn[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hnn_i0_i1.GSR = "DISABLED";
    LUT4 i10451_4_lut (.A(PARO_IN_N_361), .B(H[4]), .C(H[5]), .D(H[6]), 
         .Z(NFO1_N_382)) /* synthesis lut_function=(!(A+(B+(C+!(D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(844[23:61])
    defparam i10451_4_lut.init = 16'h0100;
    LUT4 PCLK_c_bdd_3_lut_4_lut (.A(H[0]), .B(H[1]), .C(n11450), .D(PCLK_c), 
         .Z(Clk_enable_24)) /* synthesis lut_function=(!(A+(((D)+!C)+!B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(756[20:93])
    defparam PCLK_c_bdd_3_lut_4_lut.init = 16'h0040;
    LUT4 n4112_bdd_4_lut (.A(H[2]), .B(H[0]), .C(H[1]), .D(H[4]), .Z(n11680)) /* synthesis lut_function=(A (B (C (D)))+!A !(B+(C+(D)))) */ ;
    defparam n4112_bdd_4_lut.init = 16'h8001;
    LUT4 i2_2_lut (.A(H[5]), .B(n4), .Z(n4112)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(750[20:93])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 Vo_2__bdd_4_lut_10942 (.A(Vo[0]), .B(V_LINE0N_N_487), .C(Vo[1]), 
         .D(MODE_N_21), .Z(n11511)) /* synthesis lut_function=(!((B+!(C (D)))+!A)) */ ;
    defparam Vo_2__bdd_4_lut_10942.init = 16'h2000;
    LUT4 i3_4_lut_adj_418 (.A(N_HB_N_307), .B(H[2]), .C(n4178), .D(n4199), 
         .Z(H_LINE23_N_478)) /* synthesis lut_function=(A+((C+(D))+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(761[20:93])
    defparam i3_4_lut_adj_418.init = 16'hfffb;
    LUT4 H_LINE23_N_478_bdd_2_lut (.A(H_LINE23_N_478), .B(n11466), .Z(HC_N_238)) /* synthesis lut_function=(A (B)) */ ;
    defparam H_LINE23_N_478_bdd_2_lut.init = 16'h8888;
    FD1P3AX Hn_i0_i0 (.D(H[0]), .SP(nPCLK), .CK(Clk), .Q(\Hn[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hn_i0_i0.GSR = "DISABLED";
    LUT4 i1_2_lut_adj_419 (.A(H[2]), .B(H[4]), .Z(n4175)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(751[22:75])
    defparam i1_2_lut_adj_419.init = 16'heeee;
    LUT4 N_HB_I_60_2_lut (.A(H[8]), .B(H[7]), .Z(N_HB_N_307)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(761[22:35])
    defparam N_HB_I_60_2_lut.init = 16'hdddd;
    LUT4 H_LINE23_N_478_bdd_4_lut (.A(H_LINE5_N_453), .B(ODDEVEN[0]), .C(RESCL), 
         .D(MODE_N_21), .Z(n11466)) /* synthesis lut_function=((B+!(C (D)))+!A) */ ;
    defparam H_LINE23_N_478_bdd_4_lut.init = 16'hdfff;
    LUT4 i2_3_lut_adj_420 (.A(PCLK_c), .B(RESCL_IN), .C(HC), .Z(Vo_7__N_212)) /* synthesis lut_function=(!(((C)+!B)+!A)) */ ;
    defparam i2_3_lut_adj_420.init = 16'h0808;
    LUT4 i2_3_lut_adj_421 (.A(H[2]), .B(n4199), .C(H[0]), .Z(n4121)) /* synthesis lut_function=(A+(B+!(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(752[20:101])
    defparam i2_3_lut_adj_421.init = 16'hefef;
    LUT4 i7032_2_lut (.A(H[4]), .B(H[1]), .Z(n7476)) /* synthesis lut_function=(A (B)) */ ;
    defparam i7032_2_lut.init = 16'h8888;
    LUT4 BLNK_I_0_713_2_lut (.A(BLNK), .B(H[8]), .Z(PARO_IN_N_361)) /* synthesis lut_function=(A+!(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(753[23:35])
    defparam BLNK_I_0_713_2_lut.init = 16'hbbbb;
    LUT4 i10406_2_lut (.A(NFO1), .B(NFO2), .Z(F_AT_N_286)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(776[28:44])
    defparam i10406_2_lut.init = 16'h1111;
    LUT4 i10432_2_lut (.A(H[8]), .B(VB_FF), .Z(CLIP2_N_343)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(833[23:41])
    defparam i10432_2_lut.init = 16'h4444;
    LUT4 HSYNCo_I_0_702_2_lut (.A(HSYNCo), .B(VSYNC_adj_1603), .Z(SYNC_c)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(786[15:28])
    defparam HSYNCo_I_0_702_2_lut.init = 16'heeee;
    LUT4 i10390_2_lut (.A(IOAM2_IN_N_355), .B(n7560), .Z(H_LINE6_N_460)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(754[19:101])
    defparam i10390_2_lut.init = 16'h8888;
    LUT4 i2_3_lut_adj_422 (.A(H[3]), .B(n7558), .C(H[5]), .Z(n7560)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i2_3_lut_adj_422.init = 16'h8080;
    LUT4 i10456_2_lut (.A(BLNK), .B(H[8]), .Z(NVIS_IN_N_262)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(845[23:40])
    defparam i10456_2_lut.init = 16'h1111;
    LUT4 i10392_4_lut (.A(BLNK), .B(H[6]), .C(H[7]), .D(n7560), .Z(H_LINE7_N_468)) /* synthesis lut_function=(!(A+!(B (C (D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(755[19:93])
    defparam i10392_4_lut.init = 16'h4000;
    LUT4 i10444_3_lut (.A(H[1]), .B(H[2]), .C(BLNK), .Z(FNT_IN_N_364)) /* synthesis lut_function=(!(A+(B+(C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(840[23:48])
    defparam i10444_3_lut.init = 16'h0101;
    FD1P3AX R2DB7_639 (.D(INT_FF), .SP(Clk_enable_220), .CK(Clk), .Q(\R2DB[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam R2DB7_639.GSR = "DISABLED";
    LUT4 VBL_EN_I_0_2_lut (.A(VBL_EN), .B(INT_FF), .Z(INT_c)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(790[14:29])
    defparam VBL_EN_I_0_2_lut.init = 16'h8888;
    FD1P3AX Hn_i0_i1 (.D(H[1]), .SP(nPCLK), .CK(Clk), .Q(\Hn[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hn_i0_i1.GSR = "DISABLED";
    FD1P3AX Hn_i0_i2 (.D(H[2]), .SP(nPCLK), .CK(Clk), .Q(\Hn[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hn_i0_i2.GSR = "DISABLED";
    FD1P3AX Hn_i0_i3 (.D(H[3]), .SP(nPCLK), .CK(Clk), .Q(Hn[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hn_i0_i3.GSR = "DISABLED";
    FD1P3AX Hn_i0_i4 (.D(H[4]), .SP(nPCLK), .CK(Clk), .Q(Hn[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hn_i0_i4.GSR = "DISABLED";
    FD1P3AX Hn_i0_i5 (.D(H[5]), .SP(nPCLK), .CK(Clk), .Q(Hn[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hn_i0_i5.GSR = "DISABLED";
    LUT4 i10522_4_lut (.A(PEN_FF_N_423), .B(PCLK_c), .C(V_LINE2N_N_527), 
         .D(n10722), .Z(Clk_enable_25)) /* synthesis lut_function=(!(A (B)+!A (B+(C (D))))) */ ;
    defparam i10522_4_lut.init = 16'h2333;
    LUT4 i10459_2_lut_3_lut_4_lut (.A(n4112), .B(n4175), .C(H[1]), .D(H[0]), 
         .Z(BPORCH_FF_N_420)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(751[22:75])
    defparam i10459_2_lut_3_lut_4_lut.init = 16'h0010;
    PFUMX i10925 (.BLUT(n11630), .ALUT(n11631), .C0(DENDY_c), .Z(n11632));
    LUT4 i10516_3_lut_4_lut (.A(V_LINE3N_N_535), .B(Vo[0]), .C(PCLK_c), 
         .D(VB_FF_N_268), .Z(Clk_enable_27)) /* synthesis lut_function=(!(A (C+!(D))+!A (B (C+!(D))+!B (C)))) */ ;
    defparam i10516_3_lut_4_lut.init = 16'h0f01;
    LUT4 i2_3_lut_4_lut_adj_423 (.A(Vo[1]), .B(Vo[3]), .C(n4190), .D(MODE_N_21), 
         .Z(V_LINE2N_N_527)) /* synthesis lut_function=(A+(B+(C+!(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(766[20:101])
    defparam i2_3_lut_4_lut_adj_423.init = 16'hfeff;
    LUT4 n4112_bdd_3_lut_4_lut (.A(H[5]), .B(n4), .C(PCLK_c), .D(n11680), 
         .Z(Clk_enable_22)) /* synthesis lut_function=(!(A+(B+(C+!(D))))) */ ;
    defparam n4112_bdd_3_lut_4_lut.init = 16'h0100;
    LUT4 PICT1_I_0_729_2_lut (.A(PICT1), .B(PICT2), .Z(nPICTURE)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(787[19:32])
    defparam PICT1_I_0_729_2_lut.init = 16'heeee;
    FD1P3IX ODDEVEN_i0 (.D(ODDEVEN[1]), .SP(Clk_enable_232), .CD(nRES_N_15), 
            .CK(Clk), .Q(ODDEVEN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam ODDEVEN_i0.GSR = "DISABLED";
    FD1P3JX VSET_i0 (.D(V_LINE3N_N_533), .SP(nPCLK), .PD(n11632), .CK(Clk), 
            .Q(VSET[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam VSET_i0.GSR = "DISABLED";
    LUT4 i10274_2_lut_3_lut (.A(VB_FF_N_268), .B(MODE_c), .C(DENDY_c), 
         .Z(n10722)) /* synthesis lut_function=((B (C))+!A) */ ;
    defparam i10274_2_lut_3_lut.init = 16'hd5d5;
    LUT4 i10402_2_lut (.A(V_LINE3N_N_535), .B(Vo[0]), .Z(V_LINE3P_N_538)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(771[19:85])
    defparam i10402_2_lut.init = 16'h1111;
    LUT4 i6897_2_lut_3_lut (.A(FAT_IN), .B(NFO1), .C(NFO2), .Z(F_AT)) /* synthesis lut_function=(A (B+(C))) */ ;
    defparam i6897_2_lut_3_lut.init = 16'ha8a8;
    LUT4 i2_3_lut_adj_424 (.A(Vo[1]), .B(Vo[2]), .C(V_LINE0N_N_487), .Z(V_LINE3N_N_535)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(768[22:75])
    defparam i2_3_lut_adj_424.init = 16'hfefe;
    LUT4 i1_3_lut_4_lut (.A(PCLK_c), .B(Hnn[0]), .C(NFO_OUT), .D(FTA_OUT), 
         .Z(PD_SR)) /* synthesis lut_function=(!(A+((C+(D))+!B))) */ ;
    defparam i1_3_lut_4_lut.init = 16'h0004;
    LUT4 i1_3_lut_4_lut_adj_425 (.A(H[3]), .B(H[8]), .C(H[7]), .D(H[6]), 
         .Z(n4)) /* synthesis lut_function=(A+((C+(D))+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(750[20:93])
    defparam i1_3_lut_4_lut_adj_425.init = 16'hfffb;
    LUT4 i10382_2_lut_4_lut (.A(H[5]), .B(n4), .C(n7476), .D(n10686), 
         .Z(H_LINE0_N_441)) /* synthesis lut_function=(!(A+(B+!(C (D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(750[19:93])
    defparam i10382_2_lut_4_lut.init = 16'h1000;
    LUT4 i10519_3_lut (.A(VC_LATCH_N_218), .B(PCLK_c), .C(V_LINE3P_N_538), 
         .Z(Clk_enable_26)) /* synthesis lut_function=(!(A (B)+!A (B+!(C)))) */ ;
    defparam i10519_3_lut.init = 16'h3232;
    LUT4 i10441_2_lut_3_lut (.A(BLNK), .B(H[8]), .C(VB_FF), .Z(NVIS_IN_N_261)) /* synthesis lut_function=(!(A+(B+!(C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(839[23:49])
    defparam i10441_2_lut_3_lut.init = 16'h1010;
    LUT4 i10388_3_lut_4_lut (.A(PARO_IN_N_361), .B(H[7]), .C(n7476), .D(n4121), 
         .Z(H_LINE5_N_453)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(753[23:43])
    defparam i10388_3_lut_4_lut.init = 16'h0010;
    LUT4 NVIS_IN_N_262_I_0_720_2_lut_3_lut (.A(BLNK), .B(H[8]), .C(H[7]), 
         .Z(IOAM2_IN_N_356)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(752[23:43])
    defparam NVIS_IN_N_262_I_0_720_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_4_lut (.A(H[4]), .B(H[1]), .C(H[2]), .D(H[0]), .Z(n7558)) /* synthesis lut_function=(A (B (C (D)))) */ ;
    defparam i1_2_lut_4_lut.init = 16'h8000;
    LUT4 i10426_4_lut (.A(V_LINE2N_N_527), .B(Vo[4]), .C(n4143), .D(Vo[2]), 
         .Z(VC_LATCH_N_218)) /* synthesis lut_function=(!(A ((C+!(D))+!B))) */ ;
    defparam i10426_4_lut.init = 16'h5d55;
    COUNTER_U111 Vo_7__I_0_736 (.Clk(Clk), .nPCLK(nPCLK), .CNT1_N_565(CNT1_N_565), 
            .\Vo[7] (Vo[7]), .PCLK_c(PCLK_c), .Vo_7__N_212(Vo_7__N_212)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U112 VCNT_8 (.Clk(Clk), .nPCLK(nPCLK), .CNT1_N_565(CNT1_N_565_adj_1604), 
            .\V[8] (V[8]), .PCLK_c(PCLK_c), .Vo_7__N_212(Vo_7__N_212)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U113 VCNT_6 (.Clk(Clk), .nPCLK(nPCLK), .\Vo[6] (Vo[6]), .C_OUT_N_563(C_OUT_N_563), 
            .PCLK_c(PCLK_c), .Vo_7__N_212(Vo_7__N_212), .\Vo[7] (Vo[7]), 
            .\V[8] (V[8]), .CNT1_N_565(CNT1_N_565_adj_1604), .CNT1_N_565_adj_6(CNT1_N_565)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U114 VCNT_5 (.Clk(Clk), .nPCLK(nPCLK), .CNT1_N_565(CNT1_N_565_adj_1605), 
            .\Vo[5] (Vo[5]), .PCLK_c(PCLK_c), .Vo_7__N_212(Vo_7__N_212)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U115 VCNT_4 (.Clk(Clk), .nPCLK(nPCLK), .\Vo[4] (Vo[4]), .C_OUT_N_563(C_OUT_N_563_adj_1606), 
            .\Vo[5] (Vo[5]), .C_OUT_N_563_adj_5(C_OUT_N_563), .PCLK_c(PCLK_c), 
            .Vo_7__N_212(Vo_7__N_212), .CNT1_N_565(CNT1_N_565_adj_1605)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U116 VCNT_3 (.Clk(Clk), .nPCLK(nPCLK), .CNT1_N_565(CNT1_N_565_adj_1607), 
            .\Vo[3] (Vo[3]), .PCLK_c(PCLK_c), .Vo_7__N_212(Vo_7__N_212)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U117 VCNT_2 (.\Vo[2] (Vo[2]), .C_OUT_N_563(C_OUT_N_563_adj_1608), 
            .Clk(Clk), .nPCLK(nPCLK), .\Vo[3] (Vo[3]), .C_OUT_N_563_adj_4(C_OUT_N_563_adj_1606), 
            .CNT1_N_565(CNT1_N_565_adj_1607), .PCLK_c(PCLK_c), .Vo_7__N_212(Vo_7__N_212)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U118 VCNT_1 (.Clk(Clk), .nPCLK(nPCLK), .CNT1_N_565(CNT1_N_565_adj_1609), 
            .\Vo[1] (Vo[1]), .PCLK_c(PCLK_c), .Vo_7__N_212(Vo_7__N_212)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U119 VCNT_0 (.\Vo[0] (Vo[0]), .H_LINE23_N_478(H_LINE23_N_478), 
            .Clk(Clk), .nPCLK(nPCLK), .\Vo[1] (Vo[1]), .C_OUT_N_563(C_OUT_N_563_adj_1608), 
            .CNT1_N_565(CNT1_N_565_adj_1609), .PCLK_c(PCLK_c), .Vo_7__N_212(Vo_7__N_212)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U120 H_8__I_0_700 (.Clk(Clk), .nPCLK(nPCLK), .\H[8] (H[8]), 
            .\H[7] (H[7]), .C_OUT_N_563(C_OUT_N_563_adj_1610), .PCLK_c(PCLK_c), 
            .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U121 HCNT_7 (.\H[7] (H[7]), .\H[5] (H[5]), .HIN5(HIN5), .\H[6] (H[6]), 
            .Clk(Clk), .nPCLK(nPCLK), .PCLK_c(PCLK_c), .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U122 HCNT_6 (.Clk(Clk), .nPCLK(nPCLK), .CNT1_N_565(CNT1_N_565_adj_1611), 
            .\H[6] (H[6]), .PCLK_c(PCLK_c), .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U123 HCNT_5 (.\H[5] (H[5]), .HIN5(HIN5), .\H[6] (H[6]), .CNT1_N_565(CNT1_N_565_adj_1611), 
            .C_OUT_N_563(C_OUT_N_563_adj_1610), .Clk(Clk), .nPCLK(nPCLK), 
            .PCLK_c(PCLK_c), .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U124 HCNT_4 (.\H[4] (H[4]), .\H[3] (H[3]), .C_OUT_N_563(C_OUT_N_563_adj_1612), 
            .Clk(Clk), .nPCLK(nPCLK), .PCLK_c(PCLK_c), .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U125 HCNT_3 (.Clk(Clk), .nPCLK(nPCLK), .\H[3] (H[3]), .\H[1] (H[1]), 
            .\H[0] (H[0]), .\H[2] (H[2]), .PCLK_c(PCLK_c), .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U126 HCNT_2 (.Clk(Clk), .nPCLK(nPCLK), .CNT1_N_565(CNT1_N_565_adj_1613), 
            .\H[2] (H[2]), .PCLK_c(PCLK_c), .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U127 HCNT_1 (.\H[1] (H[1]), .\H[0] (H[0]), .\H[2] (H[2]), 
            .C_OUT_N_563(C_OUT_N_563_adj_1612), .CNT1_N_565(CNT1_N_565_adj_1613), 
            .Clk(Clk), .nPCLK(nPCLK), .PCLK_c(PCLK_c), .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U128 HCNT_0 (.\H[0] (H[0]), .Clk(Clk), .nPCLK(nPCLK), .PCLK_c(PCLK_c), 
            .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    
endmodule
//
// Verilog Description of module COUNTER_U111
//

module COUNTER_U111 (Clk, nPCLK, CNT1_N_565, \Vo[7] , PCLK_c, Vo_7__N_212) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    input CNT1_N_565;
    output \Vo[7] ;
    input PCLK_c;
    input Vo_7__N_212;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[7] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U112
//

module COUNTER_U112 (Clk, nPCLK, CNT1_N_565, \V[8] , PCLK_c, Vo_7__N_212) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    input CNT1_N_565;
    output \V[8] ;
    input PCLK_c;
    input Vo_7__N_212;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\V[8] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U113
//

module COUNTER_U113 (Clk, nPCLK, \Vo[6] , C_OUT_N_563, PCLK_c, Vo_7__N_212, 
            \Vo[7] , \V[8] , CNT1_N_565, CNT1_N_565_adj_6) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    output \Vo[6] ;
    input C_OUT_N_563;
    input PCLK_c;
    input Vo_7__N_212;
    input \Vo[7] ;
    input \V[8] ;
    output CNT1_N_565;
    output CNT1_N_565_adj_6;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut (.A(\Vo[6] ), .B(C_OUT_N_563), .Z(CNT1_N_565_c)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[6] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 CNT_I_0_3_lut_4_lut (.A(\Vo[6] ), .B(C_OUT_N_563), .C(\Vo[7] ), 
         .D(\V[8] ), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_3_lut_4_lut.init = 16'h7f80;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\Vo[6] ), .B(C_OUT_N_563), .C(\Vo[7] ), 
         .Z(CNT1_N_565_adj_6)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    
endmodule
//
// Verilog Description of module COUNTER_U114
//

module COUNTER_U114 (Clk, nPCLK, CNT1_N_565, \Vo[5] , PCLK_c, Vo_7__N_212) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    input CNT1_N_565;
    output \Vo[5] ;
    input PCLK_c;
    input Vo_7__N_212;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[5] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U115
//

module COUNTER_U115 (Clk, nPCLK, \Vo[4] , C_OUT_N_563, \Vo[5] , C_OUT_N_563_adj_5, 
            PCLK_c, Vo_7__N_212, CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    output \Vo[4] ;
    input C_OUT_N_563;
    input \Vo[5] ;
    output C_OUT_N_563_adj_5;
    input PCLK_c;
    input Vo_7__N_212;
    output CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_19_2_lut_3_lut (.A(\Vo[4] ), .B(C_OUT_N_563), .C(\Vo[5] ), 
         .Z(C_OUT_N_563_adj_5)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_3_lut.init = 16'h8080;
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[4] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 CNT_I_0_2_lut_3_lut (.A(\Vo[4] ), .B(C_OUT_N_563), .C(\Vo[5] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    LUT4 CNT_I_0_2_lut (.A(\Vo[4] ), .B(C_OUT_N_563), .Z(CNT1_N_565_c)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    
endmodule
//
// Verilog Description of module COUNTER_U116
//

module COUNTER_U116 (Clk, nPCLK, CNT1_N_565, \Vo[3] , PCLK_c, Vo_7__N_212) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    input CNT1_N_565;
    output \Vo[3] ;
    input PCLK_c;
    input Vo_7__N_212;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[3] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U117
//

module COUNTER_U117 (\Vo[2] , C_OUT_N_563, Clk, nPCLK, \Vo[3] , C_OUT_N_563_adj_4, 
            CNT1_N_565, PCLK_c, Vo_7__N_212) /* synthesis syn_module_defined=1 */ ;
    output \Vo[2] ;
    input C_OUT_N_563;
    input Clk;
    input nPCLK;
    input \Vo[3] ;
    output C_OUT_N_563_adj_4;
    output CNT1_N_565;
    input PCLK_c;
    input Vo_7__N_212;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c, CNT1;
    
    LUT4 CNT_I_0_2_lut (.A(\Vo[2] ), .B(C_OUT_N_563), .Z(CNT1_N_565_c)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_19_2_lut_3_lut (.A(\Vo[2] ), .B(C_OUT_N_563), .C(\Vo[3] ), 
         .Z(C_OUT_N_563_adj_4)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_3_lut.init = 16'h8080;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\Vo[2] ), .B(C_OUT_N_563), .C(\Vo[3] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U118
//

module COUNTER_U118 (Clk, nPCLK, CNT1_N_565, \Vo[1] , PCLK_c, Vo_7__N_212) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    input CNT1_N_565;
    output \Vo[1] ;
    input PCLK_c;
    input Vo_7__N_212;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[1] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U119
//

module COUNTER_U119 (\Vo[0] , H_LINE23_N_478, Clk, nPCLK, \Vo[1] , 
            C_OUT_N_563, CNT1_N_565, PCLK_c, Vo_7__N_212) /* synthesis syn_module_defined=1 */ ;
    output \Vo[0] ;
    input H_LINE23_N_478;
    input Clk;
    input nPCLK;
    input \Vo[1] ;
    output C_OUT_N_563;
    output CNT1_N_565;
    input PCLK_c;
    input Vo_7__N_212;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c, CNT1;
    
    LUT4 i1_2_lut (.A(\Vo[0] ), .B(H_LINE23_N_478), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_19_2_lut_3_lut (.A(\Vo[0] ), .B(H_LINE23_N_478), .C(\Vo[1] ), 
         .Z(C_OUT_N_563)) /* synthesis lut_function=(!((B+!(C))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_3_lut.init = 16'h2020;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\Vo[0] ), .B(H_LINE23_N_478), .C(\Vo[1] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(A (B (C)+!B !(C))+!A (C)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'hd2d2;
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U120
//

module COUNTER_U120 (Clk, nPCLK, \H[8] , \H[7] , C_OUT_N_563, PCLK_c, 
            H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    output \H[8] ;
    input \H[7] ;
    input C_OUT_N_563;
    input PCLK_c;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, CNT1_N_565;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_3_lut (.A(\H[8] ), .B(\H[7] ), .C(C_OUT_N_563), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C))+!A !(B (C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_3_lut.init = 16'h6a6a;
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[8] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U121
//

module COUNTER_U121 (\H[7] , \H[5] , HIN5, \H[6] , Clk, nPCLK, PCLK_c, 
            H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    output \H[7] ;
    input \H[5] ;
    input HIN5;
    input \H[6] ;
    input Clk;
    input nPCLK;
    input PCLK_c;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565, CNT1;
    
    LUT4 CNT_I_0_2_lut_4_lut (.A(\H[7] ), .B(\H[5] ), .C(HIN5), .D(\H[6] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C (D)))+!A !(B (C (D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut_4_lut.init = 16'h6aaa;
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[7] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U122
//

module COUNTER_U122 (Clk, nPCLK, CNT1_N_565, \H[6] , PCLK_c, H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    input CNT1_N_565;
    output \H[6] ;
    input PCLK_c;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[6] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U123
//

module COUNTER_U123 (\H[5] , HIN5, \H[6] , CNT1_N_565, C_OUT_N_563, 
            Clk, nPCLK, PCLK_c, H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    output \H[5] ;
    input HIN5;
    input \H[6] ;
    output CNT1_N_565;
    output C_OUT_N_563;
    input Clk;
    input nPCLK;
    input PCLK_c;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_adj_1595, CNT1;
    
    LUT4 CNT_I_0_2_lut_3_lut (.A(\H[5] ), .B(HIN5), .C(\H[6] ), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    LUT4 CNT_I_0_19_2_lut_3_lut (.A(\H[5] ), .B(HIN5), .C(\H[6] ), .Z(C_OUT_N_563)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_3_lut.init = 16'h8080;
    LUT4 CNT_I_0_2_lut (.A(\H[5] ), .B(HIN5), .Z(CNT1_N_565_adj_1595)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1595), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[5] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U124
//

module COUNTER_U124 (\H[4] , \H[3] , C_OUT_N_563, Clk, nPCLK, PCLK_c, 
            H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    output \H[4] ;
    input \H[3] ;
    input C_OUT_N_563;
    input Clk;
    input nPCLK;
    input PCLK_c;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565, CNT1;
    
    LUT4 CNT_I_0_3_lut (.A(\H[4] ), .B(\H[3] ), .C(C_OUT_N_563), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C))+!A !(B (C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_3_lut.init = 16'h6a6a;
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[4] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U125
//

module COUNTER_U125 (Clk, nPCLK, \H[3] , \H[1] , \H[0] , \H[2] , 
            PCLK_c, H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    output \H[3] ;
    input \H[1] ;
    input \H[0] ;
    input \H[2] ;
    input PCLK_c;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, CNT1_N_565;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut_4_lut (.A(\H[3] ), .B(\H[1] ), .C(\H[0] ), .D(\H[2] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C (D)))+!A !(B (C (D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut_4_lut.init = 16'h6aaa;
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[3] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U126
//

module COUNTER_U126 (Clk, nPCLK, CNT1_N_565, \H[2] , PCLK_c, H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    input CNT1_N_565;
    output \H[2] ;
    input PCLK_c;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U127
//

module COUNTER_U127 (\H[1] , \H[0] , \H[2] , C_OUT_N_563, CNT1_N_565, 
            Clk, nPCLK, PCLK_c, H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    output \H[1] ;
    input \H[0] ;
    input \H[2] ;
    output C_OUT_N_563;
    output CNT1_N_565;
    input Clk;
    input nPCLK;
    input PCLK_c;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_adj_1594, CNT1;
    
    LUT4 CNT_I_0_19_2_lut_3_lut (.A(\H[1] ), .B(\H[0] ), .C(\H[2] ), .Z(C_OUT_N_563)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_3_lut.init = 16'h8080;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\H[1] ), .B(\H[0] ), .C(\H[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    LUT4 CNT_I_0_2_lut (.A(\H[1] ), .B(\H[0] ), .Z(CNT1_N_565_adj_1594)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1594), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[1] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U128
//

module COUNTER_U128 (\H[0] , Clk, nPCLK, PCLK_c, H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    output \H[0] ;
    input Clk;
    input nPCLK;
    input PCLK_c;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire H_0__N_404, CNT1;
    
    LUT4 H_0__I_0_1_lut (.A(\H[0] ), .Z(H_0__N_404)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(753[94:99])
    defparam H_0__I_0_1_lut.init = 16'h5555;
    FD1P3AX CNT1_15 (.D(H_0__N_404), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(PCLK_c), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module OBJ_EVAL
//

module OBJ_EVAL (SPR0_EV, PAR_O, PCLK_c, S_EV, Clk, nPCLK, PD_SR_N_683, 
            TAL_LATCH_N_890, Vo, OB_R, GND_net, nVIS, I_OAM2, SPR_OV, 
            \Hnn[0] , OMSTEP_1__N_1053, OV, OMFG_N_973, OMFG, O8_16, 
            PD_FIFO) /* synthesis syn_module_defined=1 */ ;
    output SPR0_EV;
    input PAR_O;
    input PCLK_c;
    input S_EV;
    input Clk;
    input nPCLK;
    input PD_SR_N_683;
    input TAL_LATCH_N_890;
    input [7:0]Vo;
    input [7:0]OB_R;
    input GND_net;
    input nVIS;
    input I_OAM2;
    input SPR_OV;
    input \Hnn[0] ;
    output OMSTEP_1__N_1053;
    output [3:0]OV;
    output OMFG_N_973;
    output OMFG;
    input O8_16;
    output PD_FIFO;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire SPR0_EV1, n2262, SPR0_EV1_N_984;
    wire [1:0]PDFIFO;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1190[10:16])
    
    wire OVZ;
    wire [5:0]CLATCH;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1188[10:16])
    
    wire DO_COPY_N_998, PD_FIFO_N_979, PDFIFO_0__N_978, n10157;
    wire [7:0]OVS;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1193[11:14])
    
    wire n10158, n10155, n10156, OMFG_N_974, n11, n10;
    
    LUT4 i1825_4_lut_4_lut (.A(SPR0_EV), .B(SPR0_EV1), .C(PAR_O), .D(PCLK_c), 
         .Z(n2262)) /* synthesis lut_function=(A (((D)+!C)+!B)+!A !(B+((D)+!C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam i1825_4_lut_4_lut.init = 16'haa3a;
    LUT4 S_EV_I_0_2_lut_2_lut (.A(S_EV), .B(PCLK_c), .Z(SPR0_EV1_N_984)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1209[14:27])
    defparam S_EV_I_0_2_lut_2_lut.init = 16'h2222;
    FD1P3AX PDFIFO_i0_i0 (.D(OVZ), .SP(nPCLK), .CK(Clk), .Q(PDFIFO[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam PDFIFO_i0_i0.GSR = "DISABLED";
    FD1P3AX CLATCH_i0 (.D(DO_COPY_N_998), .SP(PD_SR_N_683), .CK(Clk), 
            .Q(CLATCH[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam CLATCH_i0.GSR = "DISABLED";
    FD1P3AX SPR0_EV1_57 (.D(DO_COPY_N_998), .SP(SPR0_EV1_N_984), .CK(Clk), 
            .Q(SPR0_EV1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam SPR0_EV1_57.GSR = "DISABLED";
    FD1S3AX SPR0_EV_58 (.D(n2262), .CK(Clk), .Q(SPR0_EV));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam SPR0_EV_58.GSR = "DISABLED";
    LUT4 i10492_2_lut (.A(PCLK_c), .B(PDFIFO[1]), .Z(PD_FIFO_N_979)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1208[15:36])
    defparam i10492_2_lut.init = 16'h2222;
    LUT4 PDFIFO_0__I_0_1_lut (.A(PDFIFO[0]), .Z(PDFIFO_0__N_978)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1208[49:59])
    defparam PDFIFO_0__I_0_1_lut.init = 16'h5555;
    FD1P3AX CLATCH_i5 (.D(CLATCH[4]), .SP(PCLK_c), .CK(Clk), .Q(CLATCH[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam CLATCH_i5.GSR = "DISABLED";
    FD1P3AX CLATCH_i4 (.D(CLATCH[3]), .SP(PD_SR_N_683), .CK(Clk), .Q(CLATCH[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam CLATCH_i4.GSR = "DISABLED";
    FD1P3AX CLATCH_i3 (.D(CLATCH[2]), .SP(PCLK_c), .CK(Clk), .Q(CLATCH[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam CLATCH_i3.GSR = "DISABLED";
    FD1P3AX CLATCH_i2 (.D(CLATCH[1]), .SP(PD_SR_N_683), .CK(Clk), .Q(CLATCH[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam CLATCH_i2.GSR = "DISABLED";
    FD1P3AX CLATCH_i1 (.D(CLATCH[0]), .SP(PCLK_c), .CK(Clk), .Q(CLATCH[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam CLATCH_i1.GSR = "DISABLED";
    FD1P3AX PDFIFO_i0_i1 (.D(TAL_LATCH_N_890), .SP(nPCLK), .CK(Clk), .Q(PDFIFO[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam PDFIFO_i0_i1.GSR = "DISABLED";
    CCU2D V_7__I_0_add_2_7 (.A0(Vo[5]), .B0(OB_R[5]), .C0(GND_net), .D0(GND_net), 
          .A1(Vo[6]), .B1(OB_R[6]), .C1(GND_net), .D1(GND_net), .CIN(n10157), 
          .COUT(n10158), .S0(OVS[5]), .S1(OVS[6]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1194[19:40])
    defparam V_7__I_0_add_2_7.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_7.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_7.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_7.INJECT1_1 = "NO";
    LUT4 i10498_3_lut_4_lut (.A(nVIS), .B(I_OAM2), .C(SPR_OV), .D(OVZ), 
         .Z(DO_COPY_N_998)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1198[21:34])
    defparam i10498_3_lut_4_lut.init = 16'h0001;
    LUT4 i10510_2_lut_3_lut (.A(nVIS), .B(I_OAM2), .C(\Hnn[0] ), .Z(OMSTEP_1__N_1053)) /* synthesis lut_function=(A+(B+!(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1198[21:34])
    defparam i10510_2_lut_3_lut.init = 16'hefef;
    CCU2D V_7__I_0_add_2_3 (.A0(Vo[1]), .B0(OB_R[1]), .C0(GND_net), .D0(GND_net), 
          .A1(Vo[2]), .B1(OB_R[2]), .C1(GND_net), .D1(GND_net), .CIN(n10155), 
          .COUT(n10156), .S0(OV[1]), .S1(OV[2]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1194[19:40])
    defparam V_7__I_0_add_2_3.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_3.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_3.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_3.INJECT1_1 = "NO";
    CCU2D V_7__I_0_add_2_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(Vo[0]), .B1(OB_R[0]), .C1(GND_net), .D1(GND_net), 
          .COUT(n10155), .S1(OV[0]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1194[19:40])
    defparam V_7__I_0_add_2_1.INIT0 = 16'h0000;
    defparam V_7__I_0_add_2_1.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_1.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_1.INJECT1_1 = "NO";
    LUT4 OMFG_I_0_1_lut (.A(OMFG_N_973), .Z(OMFG)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1199[15:63])
    defparam OMFG_I_0_1_lut.init = 16'h5555;
    LUT4 i2_3_lut (.A(CLATCH[1]), .B(CLATCH[3]), .C(CLATCH[5]), .Z(OMFG_N_974)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1199[18:51])
    defparam i2_3_lut.init = 16'hfefe;
    LUT4 i6_4_lut (.A(n11), .B(OVS[6]), .C(n10), .D(OVS[7]), .Z(OVZ)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1196[14:139])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i4_4_lut (.A(OVS[4]), .B(OMFG_N_974), .C(OB_R[7]), .D(Vo[7]), 
         .Z(n11)) /* synthesis lut_function=(A+(B+!((D)+!C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1196[14:139])
    defparam i4_4_lut.init = 16'heefe;
    LUT4 i3_3_lut (.A(OVS[5]), .B(O8_16), .C(OV[3]), .Z(n10)) /* synthesis lut_function=(A+!(B+!(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1196[14:139])
    defparam i3_3_lut.init = 16'hbaba;
    CCU2D V_7__I_0_add_2_9 (.A0(Vo[7]), .B0(OB_R[7]), .C0(GND_net), .D0(GND_net), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n10158), 
          .S0(OVS[7]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1194[19:40])
    defparam V_7__I_0_add_2_9.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_9.INIT1 = 16'h0000;
    defparam V_7__I_0_add_2_9.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_9.INJECT1_1 = "NO";
    CCU2D V_7__I_0_add_2_5 (.A0(Vo[3]), .B0(OB_R[3]), .C0(GND_net), .D0(GND_net), 
          .A1(Vo[4]), .B1(OB_R[4]), .C1(GND_net), .D1(GND_net), .CIN(n10156), 
          .COUT(n10157), .S0(OV[3]), .S1(OVS[4]));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1194[19:40])
    defparam V_7__I_0_add_2_5.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_5.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_5.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_5.INJECT1_1 = "NO";
    FD1P3AX PD_FIFO_56 (.D(PDFIFO_0__N_978), .SP(PD_FIFO_N_979), .CK(Clk), 
            .Q(PD_FIFO));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam PD_FIFO_56.GSR = "DISABLED";
    LUT4 OMFG_I_277_2_lut_4_lut (.A(CLATCH[1]), .B(CLATCH[3]), .C(CLATCH[5]), 
         .D(DO_COPY_N_998), .Z(OMFG_N_973)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1199[16:63])
    defparam OMFG_I_277_2_lut_4_lut.init = 16'hfffe;
    
endmodule
//
// Verilog Description of module READBUSMUX
//

module READBUSMUX (R2, R7, R4, Clk, OB_R, PCLK_c, OB, DBIN, 
            D, RnWR, nDBER, R_EN, RPIX, R2DB, XRB_N_606, PIX, 
            Clk_enable_234, RC, PD_out_1, PD_out_2, PD_out_3, PD_out_4, 
            PD_out_5, PD_out_6, PD_out_7, PD_out_0) /* synthesis syn_module_defined=1 */ ;
    input R2;
    input R7;
    input R4;
    input Clk;
    output [7:0]OB_R;
    input PCLK_c;
    input [7:0]OB;
    input [7:0]DBIN;
    output [7:0]D;
    input RnWR;
    input nDBER;
    output R_EN;
    input RPIX;
    input [2:0]R2DB;
    input XRB_N_606;
    input [5:0]PIX;
    input Clk_enable_234;
    input RC;
    input PD_out_1;
    input PD_out_2;
    input PD_out_3;
    input PD_out_4;
    input PD_out_5;
    input PD_out_6;
    input PD_out_7;
    input PD_out_0;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire D_7__N_171;
    wire [7:0]Do;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(643[10:12])
    
    wire n6, n5, n6_adj_1580, n5_adj_1581, n6_adj_1582, n5_adj_1583, 
        n6_adj_1584, n5_adj_1585, n6_adj_1586, n5_adj_1587, n6_adj_1588, 
        n5_adj_1589, n6_adj_1590, n5_adj_1591, n6_adj_1592, n5_adj_1593;
    wire [7:0]PD_R;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(641[10:14])
    
    LUT4 i3_4_lut_4_lut (.A(R2), .B(R7), .C(R4), .Z(D_7__N_171)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(646[18:42])
    defparam i3_4_lut_4_lut.init = 16'hfefe;
    FD1S3JX Do_i7 (.D(n5), .CK(Clk), .PD(n6), .Q(Do[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i7.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i0 (.D(OB[0]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i0.GSR = "DISABLED";
    FD1S3JX Do_i0 (.D(n5_adj_1581), .CK(Clk), .PD(n6_adj_1580), .Q(Do[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i0.GSR = "DISABLED";
    FD1S3JX Do_i6 (.D(n5_adj_1583), .CK(Clk), .PD(n6_adj_1582), .Q(Do[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i6.GSR = "DISABLED";
    FD1S3JX Do_i5 (.D(n5_adj_1585), .CK(Clk), .PD(n6_adj_1584), .Q(Do[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i5.GSR = "DISABLED";
    FD1S3JX Do_i4 (.D(n5_adj_1587), .CK(Clk), .PD(n6_adj_1586), .Q(Do[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i4.GSR = "DISABLED";
    FD1S3JX Do_i3 (.D(n5_adj_1589), .CK(Clk), .PD(n6_adj_1588), .Q(Do[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i3.GSR = "DISABLED";
    FD1S3JX Do_i2 (.D(n5_adj_1591), .CK(Clk), .PD(n6_adj_1590), .Q(Do[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i2.GSR = "DISABLED";
    FD1S3JX Do_i1 (.D(n5_adj_1593), .CK(Clk), .PD(n6_adj_1592), .Q(Do[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i1.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i7 (.D(OB[7]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i7.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i6 (.D(OB[6]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i6.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i5 (.D(OB[5]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i5.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i4 (.D(OB[4]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i4.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i3 (.D(OB[3]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i3.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i2 (.D(OB[2]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i2.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i1 (.D(OB[1]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i1.GSR = "DISABLED";
    LUT4 DBIN_7__I_0_i1_3_lut (.A(DBIN[0]), .B(Do[0]), .C(D_7__N_171), 
         .Z(D[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i1_3_lut.init = 16'hcaca;
    LUT4 i10420_2_lut (.A(RnWR), .B(nDBER), .Z(R_EN)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    defparam i10420_2_lut.init = 16'hdddd;
    LUT4 DBIN_7__I_0_i2_3_lut (.A(DBIN[1]), .B(Do[1]), .C(D_7__N_171), 
         .Z(D[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i2_3_lut.init = 16'hcaca;
    LUT4 i2_4_lut (.A(R2), .B(RPIX), .C(R2DB[2]), .D(DBIN[7]), .Z(n6)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i2_4_lut.init = 16'heca0;
    LUT4 i1_4_lut (.A(R4), .B(XRB_N_606), .C(OB_R[7]), .D(PD_R[7]), 
         .Z(n5)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i1_4_lut.init = 16'hb3a0;
    LUT4 i2_4_lut_adj_398 (.A(R2), .B(RPIX), .C(DBIN[0]), .D(PIX[0]), 
         .Z(n6_adj_1580)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i2_4_lut_adj_398.init = 16'heca0;
    LUT4 i1_4_lut_adj_399 (.A(R4), .B(XRB_N_606), .C(OB_R[0]), .D(PD_R[0]), 
         .Z(n5_adj_1581)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i1_4_lut_adj_399.init = 16'hb3a0;
    LUT4 DBIN_7__I_0_i3_3_lut (.A(DBIN[2]), .B(Do[2]), .C(D_7__N_171), 
         .Z(D[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i3_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i4_3_lut (.A(DBIN[3]), .B(Do[3]), .C(D_7__N_171), 
         .Z(D[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i4_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i5_3_lut (.A(DBIN[4]), .B(Do[4]), .C(D_7__N_171), 
         .Z(D[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i5_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i6_3_lut (.A(DBIN[5]), .B(Do[5]), .C(D_7__N_171), 
         .Z(D[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i6_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i7_3_lut (.A(DBIN[6]), .B(Do[6]), .C(D_7__N_171), 
         .Z(D[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i7_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i8_3_lut (.A(DBIN[7]), .B(Do[7]), .C(D_7__N_171), 
         .Z(D[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i8_3_lut.init = 16'hcaca;
    LUT4 i2_4_lut_adj_400 (.A(R2), .B(RPIX), .C(R2DB[1]), .D(DBIN[6]), 
         .Z(n6_adj_1582)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i2_4_lut_adj_400.init = 16'heca0;
    LUT4 i1_4_lut_adj_401 (.A(R4), .B(XRB_N_606), .C(OB_R[6]), .D(PD_R[6]), 
         .Z(n5_adj_1583)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i1_4_lut_adj_401.init = 16'hb3a0;
    IFS1P3IX PD_R__i1 (.D(PD_out_1), .SP(Clk_enable_234), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i1.GSR = "DISABLED";
    LUT4 i2_4_lut_adj_402 (.A(R2), .B(RPIX), .C(R2DB[0]), .D(PIX[5]), 
         .Z(n6_adj_1584)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i2_4_lut_adj_402.init = 16'heca0;
    LUT4 i1_4_lut_adj_403 (.A(R4), .B(XRB_N_606), .C(OB_R[5]), .D(PD_R[5]), 
         .Z(n5_adj_1585)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i1_4_lut_adj_403.init = 16'hb3a0;
    LUT4 i2_4_lut_adj_404 (.A(R2), .B(RPIX), .C(DBIN[4]), .D(PIX[4]), 
         .Z(n6_adj_1586)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i2_4_lut_adj_404.init = 16'heca0;
    LUT4 i1_4_lut_adj_405 (.A(R4), .B(XRB_N_606), .C(OB_R[4]), .D(PD_R[4]), 
         .Z(n5_adj_1587)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i1_4_lut_adj_405.init = 16'hb3a0;
    LUT4 i2_4_lut_adj_406 (.A(R2), .B(RPIX), .C(DBIN[3]), .D(PIX[3]), 
         .Z(n6_adj_1588)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i2_4_lut_adj_406.init = 16'heca0;
    LUT4 i1_4_lut_adj_407 (.A(R4), .B(XRB_N_606), .C(OB_R[3]), .D(PD_R[3]), 
         .Z(n5_adj_1589)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i1_4_lut_adj_407.init = 16'hb3a0;
    LUT4 i2_4_lut_adj_408 (.A(R2), .B(RPIX), .C(DBIN[2]), .D(PIX[2]), 
         .Z(n6_adj_1590)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i2_4_lut_adj_408.init = 16'heca0;
    LUT4 i1_4_lut_adj_409 (.A(R4), .B(XRB_N_606), .C(OB_R[2]), .D(PD_R[2]), 
         .Z(n5_adj_1591)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i1_4_lut_adj_409.init = 16'hb3a0;
    LUT4 i2_4_lut_adj_410 (.A(R2), .B(RPIX), .C(DBIN[1]), .D(PIX[1]), 
         .Z(n6_adj_1592)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i2_4_lut_adj_410.init = 16'heca0;
    LUT4 i1_4_lut_adj_411 (.A(R4), .B(XRB_N_606), .C(OB_R[1]), .D(PD_R[1]), 
         .Z(n5_adj_1593)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i1_4_lut_adj_411.init = 16'hb3a0;
    IFS1P3IX PD_R__i2 (.D(PD_out_2), .SP(Clk_enable_234), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i2.GSR = "DISABLED";
    IFS1P3IX PD_R__i3 (.D(PD_out_3), .SP(Clk_enable_234), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i3.GSR = "DISABLED";
    IFS1P3IX PD_R__i4 (.D(PD_out_4), .SP(Clk_enable_234), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i4.GSR = "DISABLED";
    IFS1P3IX PD_R__i5 (.D(PD_out_5), .SP(Clk_enable_234), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i5.GSR = "DISABLED";
    IFS1P3IX PD_R__i6 (.D(PD_out_6), .SP(Clk_enable_234), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i6.GSR = "DISABLED";
    IFS1P3IX PD_R__i7 (.D(PD_out_7), .SP(Clk_enable_234), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i7.GSR = "DISABLED";
    IFS1P3IX PD_R__i0 (.D(PD_out_0), .SP(Clk_enable_234), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module PLL
//

module PLL (MCLK_c, Clk, GND_net) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input MCLK_c;
    output Clk;
    input GND_net;
    
    wire MCLK_c /* synthesis is_clock=1, SET_AS_NETWORK=MCLK_c */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(36[7:11])
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    EHXPLLJ PLLInst_0 (.CLKI(MCLK_c), .CLKFB(Clk), .PHASESEL0(GND_net), 
            .PHASESEL1(GND_net), .PHASEDIR(GND_net), .PHASESTEP(GND_net), 
            .LOADREG(GND_net), .STDBY(GND_net), .PLLWAKESYNC(GND_net), 
            .RST(GND_net), .RESETC(GND_net), .RESETD(GND_net), .RESETM(GND_net), 
            .ENCLKOP(GND_net), .ENCLKOS(GND_net), .ENCLKOS2(GND_net), 
            .ENCLKOS3(GND_net), .PLLCLK(GND_net), .PLLRST(GND_net), .PLLSTB(GND_net), 
            .PLLWE(GND_net), .PLLDATI0(GND_net), .PLLDATI1(GND_net), .PLLDATI2(GND_net), 
            .PLLDATI3(GND_net), .PLLDATI4(GND_net), .PLLDATI5(GND_net), 
            .PLLDATI6(GND_net), .PLLDATI7(GND_net), .PLLADDR0(GND_net), 
            .PLLADDR1(GND_net), .PLLADDR2(GND_net), .PLLADDR3(GND_net), 
            .PLLADDR4(GND_net), .CLKOP(Clk)) /* synthesis FREQUENCY_PIN_CLKOP="42.954540", FREQUENCY_PIN_CLKI="21.477270", ICP_CURRENT="7", LPF_RESISTOR="8", syn_instantiated=1, LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=152, LSE_RLINE=155 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(152[5] 155[2])
    defparam PLLInst_0.CLKI_DIV = 1;
    defparam PLLInst_0.CLKFB_DIV = 2;
    defparam PLLInst_0.CLKOP_DIV = 11;
    defparam PLLInst_0.CLKOS_DIV = 1;
    defparam PLLInst_0.CLKOS2_DIV = 1;
    defparam PLLInst_0.CLKOS3_DIV = 1;
    defparam PLLInst_0.CLKOP_ENABLE = "ENABLED";
    defparam PLLInst_0.CLKOS_ENABLE = "DISABLED";
    defparam PLLInst_0.CLKOS2_ENABLE = "DISABLED";
    defparam PLLInst_0.CLKOS3_ENABLE = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_A0 = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_B0 = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_C0 = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_D0 = "DISABLED";
    defparam PLLInst_0.CLKOP_CPHASE = 10;
    defparam PLLInst_0.CLKOS_CPHASE = 0;
    defparam PLLInst_0.CLKOS2_CPHASE = 0;
    defparam PLLInst_0.CLKOS3_CPHASE = 0;
    defparam PLLInst_0.CLKOP_FPHASE = 0;
    defparam PLLInst_0.CLKOS_FPHASE = 0;
    defparam PLLInst_0.CLKOS2_FPHASE = 0;
    defparam PLLInst_0.CLKOS3_FPHASE = 0;
    defparam PLLInst_0.FEEDBK_PATH = "CLKOP";
    defparam PLLInst_0.FRACN_ENABLE = "DISABLED";
    defparam PLLInst_0.FRACN_DIV = 0;
    defparam PLLInst_0.CLKOP_TRIM_POL = "RISING";
    defparam PLLInst_0.CLKOP_TRIM_DELAY = 0;
    defparam PLLInst_0.CLKOS_TRIM_POL = "FALLING";
    defparam PLLInst_0.CLKOS_TRIM_DELAY = 0;
    defparam PLLInst_0.PLL_USE_WB = "DISABLED";
    defparam PLLInst_0.PREDIVIDER_MUXA1 = 0;
    defparam PLLInst_0.PREDIVIDER_MUXB1 = 0;
    defparam PLLInst_0.PREDIVIDER_MUXC1 = 0;
    defparam PLLInst_0.PREDIVIDER_MUXD1 = 0;
    defparam PLLInst_0.OUTDIVIDER_MUXA2 = "DIVA";
    defparam PLLInst_0.OUTDIVIDER_MUXB2 = "DIVB";
    defparam PLLInst_0.OUTDIVIDER_MUXC2 = "DIVC";
    defparam PLLInst_0.OUTDIVIDER_MUXD2 = "DIVD";
    defparam PLLInst_0.PLL_LOCK_MODE = 0;
    defparam PLLInst_0.STDBY_ENABLE = "DISABLED";
    defparam PLLInst_0.DPHASE_SOURCE = "DISABLED";
    defparam PLLInst_0.PLLRST_ENA = "DISABLED";
    defparam PLLInst_0.MRST_ENA = "DISABLED";
    defparam PLLInst_0.DCRST_ENA = "DISABLED";
    defparam PLLInst_0.DDRST_ENA = "DISABLED";
    defparam PLLInst_0.INTFB_WAKE = "DISABLED";
    
endmodule
//
// Verilog Description of module OAM
//

module OAM (W4, Clk, nPCLK, nEVAL, \Hn[0] , PCLK_c, BLNK, PAR_O, 
            \Hn[2] , \Hnn[0] , OMFG, OMFG_N_973, OB, I_OAM2, OMSTEP_1__N_1053, 
            nVIS, SPR_OV, SPR0_EV, SPR0HIT_LATCH, n10678, \R2DB[0] , 
            RESCL, ALE_N_601, VCC_net, GND_net, DBIN, W3) /* synthesis syn_module_defined=1 */ ;
    input W4;
    input Clk;
    input nPCLK;
    input nEVAL;
    input \Hn[0] ;
    input PCLK_c;
    input BLNK;
    input PAR_O;
    input \Hn[2] ;
    input \Hnn[0] ;
    input OMFG;
    input OMFG_N_973;
    output [7:0]OB;
    input I_OAM2;
    input OMSTEP_1__N_1053;
    input nVIS;
    output SPR_OV;
    input SPR0_EV;
    input SPR0HIT_LATCH;
    output n10678;
    output \R2DB[0] ;
    input RESCL;
    input ALE_N_601;
    input VCC_net;
    input GND_net;
    input [7:0]DBIN;
    input W3;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire W4FF, W4Q_2__N_1019, ORES_LATCH, OMV_LATCH, n10732, n2849, 
        n16, OAM2STEP_N_1107, n10676, Clk_enable_45, TMV_LATCH;
    wire [2:0]OSTEP;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1247[10:15])
    wire [4:0]W4Q;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1244[10:13])
    
    wire OAMQ_7__N_1041, OAMCTR2, OSTEP_2__N_1059, OAM2STEP_N_1104;
    wire [4:0]OAM2ADR;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1266[11:18])
    
    wire n7339, OAM2STEP_N_1114, OFETCH_N_1090, n8, WE, M4_N_1103;
    wire [7:0]OAM1ADR;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1267[11:18])
    
    wire n11578, OVF_LATCH, OAMCTR2_N_1061;
    wire [7:0]CNT1_7__N_1142;
    
    wire n4, OMFG_LATCH, ORES_N_1115, ORES;
    wire [7:0]OB2;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1251[10:13])
    
    wire OB2_7__N_1043, W4Q_3__N_1011, W4Q_2__N_1014;
    wire [1:0]OMSTEP;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1245[10:16])
    
    wire OAM1ADR_0__N_1040;
    wire [7:0]OAMQ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1275[11:15])
    wire [7:0]OAM2Q;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1275[17:22])
    
    wire OAP_N_1091;
    wire [7:0]n115;
    
    wire OBDZ_2__N_1038, n7379, n5010, n4104, n11579, n10497, n10495, 
        Clk_enable_46, C_OUT_N_563, CNT1_N_565, CNT1_N_565_adj_1579;
    
    LUT4 i10508_2_lut (.A(W4), .B(W4FF), .Z(W4Q_2__N_1019)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1289[66:79])
    defparam i10508_2_lut.init = 16'h4444;
    FD1P3AX ORES_LATCH_123 (.D(nEVAL), .SP(nPCLK), .CK(Clk), .Q(ORES_LATCH));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam ORES_LATCH_123.GSR = "DISABLED";
    LUT4 i1_4_lut (.A(\Hn[0] ), .B(OMV_LATCH), .C(n10732), .D(n2849), 
         .Z(n16)) /* synthesis lut_function=(!(A ((D)+!B)+!A (B (C (D))+!B (C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam i1_4_lut.init = 16'h05cd;
    LUT4 i1_4_lut_adj_395 (.A(PCLK_c), .B(OAM2STEP_N_1107), .C(ORES_LATCH), 
         .D(n10676), .Z(Clk_enable_45)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))) */ ;
    defparam i1_4_lut_adj_395.init = 16'h8a0a;
    LUT4 i1_2_lut (.A(TMV_LATCH), .B(OSTEP[0]), .Z(n10676)) /* synthesis lut_function=(!((B)+!A)) */ ;
    defparam i1_2_lut.init = 16'h2222;
    LUT4 i2_3_lut (.A(W4Q[2]), .B(BLNK), .C(W4Q[4]), .Z(OAMQ_7__N_1041)) /* synthesis lut_function=(!(((C)+!B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1276[41:52])
    defparam i2_3_lut.init = 16'h0808;
    LUT4 i10512_2_lut (.A(nEVAL), .B(OAMCTR2), .Z(OSTEP_2__N_1059)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1294[41:60])
    defparam i10512_2_lut.init = 16'hdddd;
    LUT4 i10506_3_lut (.A(OAM2STEP_N_1107), .B(OSTEP[0]), .C(nPCLK), .Z(OAM2STEP_N_1104)) /* synthesis lut_function=(!((B+(C))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1263[19:98])
    defparam i10506_3_lut.init = 16'h0202;
    LUT4 i10374_2_lut (.A(OAM2ADR[4]), .B(PCLK_c), .Z(n7339)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i10374_2_lut.init = 16'h1111;
    LUT4 OAM2STEP_I_308_4_lut (.A(PAR_O), .B(\Hn[0] ), .C(\Hn[2] ), .D(OAM2STEP_N_1114), 
         .Z(OAM2STEP_N_1107)) /* synthesis lut_function=(!(A (B (C)+!B !((D)+!C))+!A (B+!(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1263[42:97])
    defparam OAM2STEP_I_308_4_lut.init = 16'h3b0a;
    LUT4 OSTEP_1__I_0_2_lut (.A(OSTEP[1]), .B(OSTEP[2]), .Z(OAM2STEP_N_1114)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1263[72:95])
    defparam OSTEP_1__I_0_2_lut.init = 16'heeee;
    LUT4 i10501_4_lut (.A(BLNK), .B(OFETCH_N_1090), .C(n8), .D(\Hnn[0] ), 
         .Z(WE)) /* synthesis lut_function=(A (B)+!A (B+!(C+!(D)))) */ ;
    defparam i10501_4_lut.init = 16'hcdcc;
    LUT4 OAM1ADR_7__bdd_4_lut_10902 (.A(M4_N_1103), .B(OAM1ADR[0]), .C(OAM1ADR[3]), 
         .D(OAM1ADR[1]), .Z(n11578)) /* synthesis lut_function=(A (B (C (D)))+!A !(B+((D)+!C))) */ ;
    defparam OAM1ADR_7__bdd_4_lut_10902.init = 16'h8010;
    FD1P3AX OVF_LATCH_124 (.D(OAMCTR2_N_1061), .SP(nPCLK), .CK(Clk), .Q(OVF_LATCH));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OVF_LATCH_124.GSR = "DISABLED";
    LUT4 mux_14_i3_3_lut_4_lut (.A(OAM1ADR[0]), .B(OAM1ADR[1]), .C(M4_N_1103), 
         .D(OAM1ADR[2]), .Z(CNT1_7__N_1142[2])) /* synthesis lut_function=(!(A (B (D)+!B !(C (D)+!C !(D)))+!A !(C (D)+!C !(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1298[74:87])
    defparam mux_14_i3_3_lut_4_lut.init = 16'h708f;
    LUT4 i1_3_lut_4_lut (.A(OAM1ADR[0]), .B(OAM1ADR[1]), .C(OAM1ADR[2]), 
         .D(M4_N_1103), .Z(n4)) /* synthesis lut_function=(A (B (C)+!B !((D)+!C))+!A !((D)+!C)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1298[74:87])
    defparam i1_3_lut_4_lut.init = 16'h80f0;
    FD1P3AX OMFG_LATCH_125 (.D(OMFG), .SP(nPCLK), .CK(Clk), .Q(OMFG_LATCH));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OMFG_LATCH_125.GSR = "DISABLED";
    LUT4 nPCLK_I_0_2_lut_2_lut (.A(PCLK_c), .B(ORES_LATCH), .Z(ORES_N_1115)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1262[17:39])
    defparam nPCLK_I_0_2_lut_2_lut.init = 16'hdddd;
    LUT4 ORES_I_0_1_lut_2_lut (.A(PCLK_c), .B(ORES_LATCH), .Z(ORES)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1262[16:39])
    defparam ORES_I_0_1_lut_2_lut.init = 16'h2222;
    FD1P3AX OSTEP_i0_i2 (.D(OMFG_N_973), .SP(nPCLK), .CK(Clk), .Q(OSTEP[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OSTEP_i0_i2.GSR = "DISABLED";
    FD1P3AX OB2_i0_i0 (.D(OB[0]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i0.GSR = "DISABLED";
    FD1P3AX OSTEP_i0_i1 (.D(I_OAM2), .SP(nPCLK), .CK(Clk), .Q(OSTEP[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OSTEP_i0_i1.GSR = "DISABLED";
    FD1P3AX W4Q_i4 (.D(W4Q_3__N_1011), .SP(PCLK_c), .CK(Clk), .Q(W4Q[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam W4Q_i4.GSR = "DISABLED";
    FD1P3AX W4Q_i3 (.D(W4Q_2__N_1014), .SP(nPCLK), .CK(Clk), .Q(W4Q[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam W4Q_i3.GSR = "DISABLED";
    LUT4 OAMSTEP_I_304_2_lut (.A(OMSTEP[1]), .B(OMSTEP[0]), .Z(n2849)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1260[19:67])
    defparam OAMSTEP_I_304_2_lut.init = 16'h2222;
    LUT4 OAM1ADR_0__I_0_1_lut (.A(OAM1ADR[0]), .Z(OAM1ADR_0__N_1040)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1265[52:63])
    defparam OAM1ADR_0__I_0_1_lut.init = 16'h5555;
    FD1P3AX OMSTEP_i0_i0 (.D(OFETCH_N_1090), .SP(nPCLK), .CK(Clk), .Q(OMSTEP[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OMSTEP_i0_i0.GSR = "DISABLED";
    FD1P3AX W4Q_i0 (.D(W4Q_2__N_1019), .SP(PCLK_c), .CK(Clk), .Q(W4Q[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam W4Q_i0.GSR = "DISABLED";
    FD1P3AX OSTEP_i0_i0 (.D(OSTEP_2__N_1059), .SP(nPCLK), .CK(Clk), .Q(OSTEP[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OSTEP_i0_i0.GSR = "DISABLED";
    FD1P3AX W4Q_i2 (.D(W4Q[1]), .SP(PCLK_c), .CK(Clk), .Q(W4Q[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam W4Q_i2.GSR = "DISABLED";
    FD1P3AX W4Q_i1 (.D(W4Q[0]), .SP(nPCLK), .CK(Clk), .Q(W4Q[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam W4Q_i1.GSR = "DISABLED";
    FD1P3AX OMSTEP_i0_i1 (.D(OMSTEP_1__N_1053), .SP(nPCLK), .CK(Clk), 
            .Q(OMSTEP[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OMSTEP_i0_i1.GSR = "DISABLED";
    LUT4 mux_71_i2_3_lut (.A(OAMQ[1]), .B(OAM2Q[1]), .C(OAP_N_1091), .Z(n115[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i2_3_lut.init = 16'hcaca;
    LUT4 OAP_I_299_3_lut (.A(\Hnn[0] ), .B(BLNK), .C(nVIS), .Z(OAP_N_1091)) /* synthesis lut_function=(!(A (B)+!A (B+!(C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1257[15:41])
    defparam OAP_I_299_3_lut.init = 16'h3232;
    LUT4 mux_71_i3_4_lut (.A(OAMQ[2]), .B(OAM2Q[2]), .C(OAP_N_1091), .D(OBDZ_2__N_1038), 
         .Z(n115[2])) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i3_4_lut.init = 16'hc0ca;
    LUT4 mux_71_i4_4_lut (.A(OAMQ[3]), .B(OAM2Q[3]), .C(OAP_N_1091), .D(OBDZ_2__N_1038), 
         .Z(n115[3])) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i4_4_lut.init = 16'hc0ca;
    LUT4 mux_71_i5_4_lut (.A(OAMQ[4]), .B(OAM2Q[4]), .C(OAP_N_1091), .D(OBDZ_2__N_1038), 
         .Z(n115[4])) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i5_4_lut.init = 16'hc0ca;
    LUT4 mux_71_i6_3_lut (.A(OAMQ[5]), .B(OAM2Q[5]), .C(OAP_N_1091), .Z(n115[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i6_3_lut.init = 16'hcaca;
    LUT4 mux_71_i7_3_lut (.A(OAMQ[6]), .B(OAM2Q[6]), .C(OAP_N_1091), .Z(n115[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i7_3_lut.init = 16'hcaca;
    LUT4 mux_71_i8_3_lut (.A(OAMQ[7]), .B(OAM2Q[7]), .C(OAP_N_1091), .Z(n115[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i8_3_lut.init = 16'hcaca;
    LUT4 mux_71_i1_3_lut (.A(OAMQ[0]), .B(OAM2Q[0]), .C(OAP_N_1091), .Z(n115[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i1_3_lut.init = 16'hcaca;
    LUT4 i10489_2_lut (.A(PCLK_c), .B(OAM1ADR[2]), .Z(n7379)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i10489_2_lut.init = 16'h1111;
    LUT4 OAM1ADR_1__I_0_137_2_lut_2_lut (.A(OAM1ADR[1]), .B(OAM1ADR[0]), 
         .Z(OBDZ_2__N_1038)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1265[37:65])
    defparam OAM1ADR_1__I_0_137_2_lut_2_lut.init = 16'h2222;
    LUT4 i4548_2_lut_2_lut (.A(PCLK_c), .B(I_OAM2), .Z(n5010)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam i4548_2_lut_2_lut.init = 16'h4444;
    LUT4 OAM1ADR_7__bdd_4_lut (.A(OAM1ADR[7]), .B(OAM1ADR[6]), .C(n4104), 
         .D(n11578), .Z(n11579)) /* synthesis lut_function=(A (B (C (D)))) */ ;
    defparam OAM1ADR_7__bdd_4_lut.init = 16'h8000;
    FD1P3AX OB2_i0_i7 (.D(OB[7]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i7.GSR = "DISABLED";
    FD1P3AX OB2_i0_i6 (.D(OB[6]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i6.GSR = "DISABLED";
    FD1P3AX OB2_i0_i5 (.D(OB[5]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i5.GSR = "DISABLED";
    FD1P3AX OB2_i0_i4 (.D(OB[4]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i4.GSR = "DISABLED";
    FD1P3AX OB2_i0_i3 (.D(OB[3]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i3.GSR = "DISABLED";
    FD1P3AX OB2_i0_i2 (.D(OB[2]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i2.GSR = "DISABLED";
    FD1P3AX OB2_i0_i1 (.D(OB[1]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i1.GSR = "DISABLED";
    LUT4 i3_3_lut_4_lut (.A(PCLK_c), .B(nVIS), .C(OAMCTR2), .D(SPR_OV), 
         .Z(n8)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1254[17:66])
    defparam i3_3_lut_4_lut.init = 16'hfffe;
    LUT4 i2_3_lut_4_lut (.A(PCLK_c), .B(nVIS), .C(SPR0_EV), .D(SPR0HIT_LATCH), 
         .Z(n10678)) /* synthesis lut_function=(!(A+(B+(C+!(D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1254[17:66])
    defparam i2_3_lut_4_lut.init = 16'h0100;
    FD1S3AX R2DB5_115 (.D(n10497), .CK(Clk), .Q(\R2DB[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam R2DB5_115.GSR = "DISABLED";
    FD1S3AX SPR_OV_116 (.D(n10495), .CK(Clk), .Q(SPR_OV));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam SPR_OV_116.GSR = "DISABLED";
    FD1P3AX OAMCTR2_117 (.D(ORES_N_1115), .SP(Clk_enable_45), .CK(Clk), 
            .Q(OAMCTR2));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OAMCTR2_117.GSR = "DISABLED";
    FD1P3AX W4FF_114 (.D(W4Q[3]), .SP(Clk_enable_46), .CK(Clk), .Q(W4FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam W4FF_114.GSR = "DISABLED";
    LUT4 OAMCTR2_I_0_1_lut (.A(OAMCTR2), .Z(OAMCTR2_N_1061)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1294[51:59])
    defparam OAMCTR2_I_0_1_lut.init = 16'h5555;
    LUT4 OMFG_N_1057_I_0_2_lut (.A(OMFG_N_973), .B(BLNK), .Z(M4_N_1103)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1261[14:30])
    defparam OMFG_N_1057_I_0_2_lut.init = 16'heeee;
    FD1P3IX TMV_LATCH_127 (.D(C_OUT_N_563), .SP(nPCLK), .CD(n7339), .CK(Clk), 
            .Q(TMV_LATCH));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam TMV_LATCH_127.GSR = "DISABLED";
    LUT4 i1_4_lut_adj_396 (.A(RESCL), .B(\R2DB[0] ), .C(ALE_N_601), .D(n10732), 
         .Z(n10497)) /* synthesis lut_function=(!(A+!(B+!(C+(D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam i1_4_lut_adj_396.init = 16'h4445;
    LUT4 i10283_2_lut (.A(OMFG_LATCH), .B(OVF_LATCH), .Z(n10732)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i10283_2_lut.init = 16'heeee;
    FD1P3JX OB_i0_i1 (.D(n115[1]), .SP(nPCLK), .PD(n5010), .CK(Clk), 
            .Q(OB[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i1.GSR = "DISABLED";
    FD1P3JX OB_i0_i2 (.D(n115[2]), .SP(nPCLK), .PD(n5010), .CK(Clk), 
            .Q(OB[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i2.GSR = "DISABLED";
    LUT4 i1_4_lut_adj_397 (.A(I_OAM2), .B(SPR_OV), .C(PCLK_c), .D(n16), 
         .Z(n10495)) /* synthesis lut_function=(!(A+!(B+(C (D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam i1_4_lut_adj_397.init = 16'h5444;
    LUT4 i10548_2_lut (.A(BLNK), .B(PCLK_c), .Z(OB2_7__N_1043)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1288[15:31])
    defparam i10548_2_lut.init = 16'h4444;
    FD1P3JX OB_i0_i3 (.D(n115[3]), .SP(nPCLK), .PD(n5010), .CK(Clk), 
            .Q(OB[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i3.GSR = "DISABLED";
    FD1P3JX OB_i0_i4 (.D(n115[4]), .SP(nPCLK), .PD(n5010), .CK(Clk), 
            .Q(OB[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i4.GSR = "DISABLED";
    FD1P3JX OB_i0_i5 (.D(n115[5]), .SP(nPCLK), .PD(n5010), .CK(Clk), 
            .Q(OB[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i5.GSR = "DISABLED";
    FD1P3JX OB_i0_i6 (.D(n115[6]), .SP(nPCLK), .PD(n5010), .CK(Clk), 
            .Q(OB[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i6.GSR = "DISABLED";
    FD1P3JX OB_i0_i7 (.D(n115[7]), .SP(nPCLK), .PD(n5010), .CK(Clk), 
            .Q(OB[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i7.GSR = "DISABLED";
    FD1P3JX OB_i0_i0 (.D(n115[0]), .SP(nPCLK), .PD(n5010), .CK(Clk), 
            .Q(OB[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i0.GSR = "DISABLED";
    FD1P3IX OMV_LATCH_126 (.D(n11579), .SP(nPCLK), .CD(n7379), .CK(Clk), 
            .Q(OMV_LATCH));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OMV_LATCH_126.GSR = "DISABLED";
    LUT4 W4Q_3__I_0_1_lut (.A(W4Q[3]), .Z(W4Q_3__N_1011)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1289[49:56])
    defparam W4Q_3__I_0_1_lut.init = 16'h5555;
    LUT4 W4Q_2__I_0_1_lut (.A(W4Q[2]), .Z(W4Q_2__N_1014)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1256[20:27])
    defparam W4Q_2__I_0_1_lut.init = 16'h5555;
    LUT4 i1_2_lut_2_lut (.A(W4), .B(W4Q[3]), .Z(Clk_enable_46)) /* synthesis lut_function=(A+!(B)) */ ;
    defparam i1_2_lut_2_lut.init = 16'hbbbb;
    LUT4 i10504_2_lut (.A(W4Q[2]), .B(W4Q[4]), .Z(OFETCH_N_1090)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1256[17:38])
    defparam i10504_2_lut.init = 16'h2222;
    OAM_RAM OAMQ_7__I_0 (.Clk(Clk), .VCC_net(VCC_net), .GND_net(GND_net), 
            .OAMQ_7__N_1041(OAMQ_7__N_1041), .OAM1ADR({OAM1ADR}), .DBIN({DBIN}), 
            .OAMQ({OAMQ})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1276[10:89])
    OAM_COUNTER OAMCNT (.OAM1ADR({OAM1ADR}), .n4(n4), .DBIN({DBIN}), .W3(W3), 
            .PCLK_c(PCLK_c), .OMSTEP({OMSTEP}), .n4104(n4104), .PAR_O(PAR_O), 
            .OMFG_N_973(OMFG_N_973), .BLNK(BLNK), .Clk(Clk), .\CNT1_7__N_1142[2] (CNT1_7__N_1142[2]), 
            .OAM1ADR_0__N_1040(OAM1ADR_0__N_1040)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1270[13:77])
    COUNTER_U100 OAM2CNT_4 (.\OAM2ADR[4] (OAM2ADR[4]), .C_OUT_N_563(C_OUT_N_563), 
            .Clk(Clk), .nPCLK(nPCLK), .OAM2STEP_N_1104(OAM2STEP_N_1104), 
            .ORES(ORES)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1273[9:121])
    COUNTER_U101 OAM2CNT_3 (.\OAM2ADR[3] (OAM2ADR[3]), .Clk(Clk), .OAM2STEP_N_1104(OAM2STEP_N_1104), 
            .ORES(ORES), .nPCLK(nPCLK), .CNT1_N_565(CNT1_N_565)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1273[9:121])
    COUNTER_U102 OAM2CNT_2 (.Clk(Clk), .nPCLK(nPCLK), .CNT1_N_565(CNT1_N_565_adj_1579), 
            .\OAM2ADR[2] (OAM2ADR[2]), .OAM2STEP_N_1104(OAM2STEP_N_1104), 
            .ORES(ORES)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1273[9:121])
    COUNTER_U103 OAM2CNT_1 (.\OAM2ADR[1] (OAM2ADR[1]), .Clk(Clk), .OAM2STEP_N_1104(OAM2STEP_N_1104), 
            .ORES(ORES), .\OAM2ADR[0] (OAM2ADR[0]), .\OAM2ADR[3] (OAM2ADR[3]), 
            .\OAM2ADR[2] (OAM2ADR[2]), .CNT1_N_565(CNT1_N_565), .CNT1_N_565_adj_3(CNT1_N_565_adj_1579), 
            .C_OUT_N_563(C_OUT_N_563), .nPCLK(nPCLK)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1273[9:121])
    COUNTER_U104 OAM2CNT_0 (.Clk(Clk), .nPCLK(nPCLK), .\OAM2ADR[0] (OAM2ADR[0]), 
            .OAM2STEP_N_1104(OAM2STEP_N_1104), .ORES(ORES)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1273[9:121])
    OAM2_RAM MOD_OAM2_RAM (.Clk(Clk), .VCC_net(VCC_net), .GND_net(GND_net), 
            .WE(WE), .OAM2ADR({OAM2ADR}), .OB2({OB2}), .OAM2Q({OAM2Q})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1277[10:90])
    
endmodule
//
// Verilog Description of module OAM_RAM
//

module OAM_RAM (Clk, VCC_net, GND_net, OAMQ_7__N_1041, OAM1ADR, DBIN, 
            OAMQ) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input Clk;
    input VCC_net;
    input GND_net;
    input OAMQ_7__N_1041;
    input [7:0]OAM1ADR;
    input [7:0]DBIN;
    output [7:0]OAMQ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    DP8KC OAM_RAM_0_0_0 (.DIA0(DBIN[0]), .DIA1(DBIN[1]), .DIA2(DBIN[2]), 
          .DIA3(DBIN[3]), .DIA4(DBIN[4]), .DIA5(DBIN[5]), .DIA6(DBIN[6]), 
          .DIA7(DBIN[7]), .DIA8(GND_net), .ADA0(VCC_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(OAM1ADR[0]), .ADA4(OAM1ADR[1]), .ADA5(OAM1ADR[2]), 
          .ADA6(OAM1ADR[3]), .ADA7(OAM1ADR[4]), .ADA8(OAM1ADR[5]), .ADA9(OAM1ADR[6]), 
          .ADA10(OAM1ADR[7]), .ADA11(GND_net), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(OAMQ_7__N_1041), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), 
          .ADB4(GND_net), .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), 
          .ADB8(GND_net), .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), 
          .ADB12(GND_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(GND_net), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(OAMQ[0]), .DOA1(OAMQ[1]), .DOA2(OAMQ[2]), 
          .DOA3(OAMQ[3]), .DOA4(OAMQ[4]), .DOA5(OAMQ[5]), .DOA6(OAMQ[6]), 
          .DOA7(OAMQ[7])) /* synthesis MEM_LPC_FILE="OAM_RAM.lpc", MEM_INIT_FILE="INIT_ALL_0s", syn_instantiated=1, LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=89, LSE_LLINE=1276, LSE_RLINE=1276 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1276[10:89])
    defparam OAM_RAM_0_0_0.DATA_WIDTH_A = 9;
    defparam OAM_RAM_0_0_0.DATA_WIDTH_B = 9;
    defparam OAM_RAM_0_0_0.REGMODE_A = "OUTREG";
    defparam OAM_RAM_0_0_0.REGMODE_B = "NOREG";
    defparam OAM_RAM_0_0_0.CSDECODE_A = "0b000";
    defparam OAM_RAM_0_0_0.CSDECODE_B = "0b111";
    defparam OAM_RAM_0_0_0.WRITEMODE_A = "NORMAL";
    defparam OAM_RAM_0_0_0.WRITEMODE_B = "NORMAL";
    defparam OAM_RAM_0_0_0.GSR = "ENABLED";
    defparam OAM_RAM_0_0_0.RESETMODE = "SYNC";
    defparam OAM_RAM_0_0_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam OAM_RAM_0_0_0.INIT_DATA = "STATIC";
    defparam OAM_RAM_0_0_0.INITVAL_00 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_01 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_02 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_03 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_04 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_05 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_06 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_07 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_08 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_09 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    
endmodule
//
// Verilog Description of module OAM_COUNTER
//

module OAM_COUNTER (OAM1ADR, n4, DBIN, W3, PCLK_c, OMSTEP, n4104, 
            PAR_O, OMFG_N_973, BLNK, Clk, \CNT1_7__N_1142[2] , OAM1ADR_0__N_1040) /* synthesis syn_module_defined=1 */ ;
    output [7:0]OAM1ADR;
    input n4;
    input [7:0]DBIN;
    input W3;
    input PCLK_c;
    input [1:0]OMSTEP;
    output n4104;
    input PAR_O;
    input OMFG_N_973;
    input BLNK;
    input Clk;
    input \CNT1_7__N_1142[2] ;
    input OAM1ADR_0__N_1040;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire n4060;
    wire [7:0]CNT1;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1681[10:14])
    wire [7:0]n27;
    wire [7:0]CNT1_7__N_1142;
    
    wire CNT_7__N_1141, Clk_enable_195;
    wire [7:0]n56;
    
    wire n7333;
    
    LUT4 i1_2_lut_3_lut_4_lut (.A(OAM1ADR[3]), .B(n4), .C(OAM1ADR[4]), 
         .D(OAM1ADR[5]), .Z(n4060)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1690[48:112])
    defparam i1_2_lut_3_lut_4_lut.init = 16'h8000;
    LUT4 mux_8_i1_3_lut (.A(CNT1[0]), .B(DBIN[0]), .C(W3), .Z(n27[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1689[64:92])
    defparam mux_8_i1_3_lut.init = 16'hcaca;
    LUT4 i2587_2_lut_3_lut (.A(OAM1ADR[3]), .B(n4), .C(OAM1ADR[4]), .Z(CNT1_7__N_1142[4])) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1690[48:112])
    defparam i2587_2_lut_3_lut.init = 16'h7878;
    LUT4 i2588_3_lut_4_lut (.A(OAM1ADR[3]), .B(n4), .C(OAM1ADR[4]), .D(OAM1ADR[5]), 
         .Z(CNT1_7__N_1142[5])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1690[48:112])
    defparam i2588_3_lut_4_lut.init = 16'h7f80;
    LUT4 i10592_3_lut_4_lut (.A(W3), .B(PCLK_c), .C(OMSTEP[1]), .D(OMSTEP[0]), 
         .Z(CNT_7__N_1141)) /* synthesis lut_function=(!(A+(B ((D)+!C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1689[13:24])
    defparam i10592_3_lut_4_lut.init = 16'h1151;
    LUT4 i1_2_lut (.A(OAM1ADR[4]), .B(OAM1ADR[5]), .Z(n4104)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1690[48:112])
    defparam i1_2_lut.init = 16'h8888;
    LUT4 i2590_3_lut (.A(OAM1ADR[7]), .B(OAM1ADR[6]), .C(n4060), .Z(CNT1_7__N_1142[7])) /* synthesis lut_function=(!(A (B (C))+!A !(B (C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1690[48:112])
    defparam i2590_3_lut.init = 16'h6a6a;
    LUT4 i1_2_lut_adj_394 (.A(CNT_7__N_1141), .B(PAR_O), .Z(Clk_enable_195)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1689[13:32])
    defparam i1_2_lut_adj_394.init = 16'hdddd;
    LUT4 mux_8_i8_3_lut (.A(CNT1[7]), .B(DBIN[7]), .C(W3), .Z(n27[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1689[64:92])
    defparam mux_8_i8_3_lut.init = 16'hcaca;
    LUT4 mux_8_i7_3_lut (.A(CNT1[6]), .B(DBIN[6]), .C(W3), .Z(n27[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1689[64:92])
    defparam mux_8_i7_3_lut.init = 16'hcaca;
    LUT4 mux_8_i6_3_lut (.A(CNT1[5]), .B(DBIN[5]), .C(W3), .Z(n27[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1689[64:92])
    defparam mux_8_i6_3_lut.init = 16'hcaca;
    LUT4 xor_13_i2_2_lut (.A(OAM1ADR[1]), .B(OAM1ADR[0]), .Z(n56[1])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1690[78:112])
    defparam xor_13_i2_2_lut.init = 16'h6666;
    LUT4 mux_8_i5_3_lut (.A(CNT1[4]), .B(DBIN[4]), .C(W3), .Z(n27[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1689[64:92])
    defparam mux_8_i5_3_lut.init = 16'hcaca;
    LUT4 i10356_2_lut_3_lut (.A(CNT_7__N_1141), .B(OMFG_N_973), .C(BLNK), 
         .Z(n7333)) /* synthesis lut_function=(!((B+(C))+!A)) */ ;
    defparam i10356_2_lut_3_lut.init = 16'h0202;
    LUT4 mux_8_i4_3_lut (.A(CNT1[3]), .B(DBIN[3]), .C(W3), .Z(n27[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1689[64:92])
    defparam mux_8_i4_3_lut.init = 16'hcaca;
    LUT4 mux_8_i3_3_lut (.A(CNT1[2]), .B(DBIN[2]), .C(W3), .Z(n27[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1689[64:92])
    defparam mux_8_i3_3_lut.init = 16'hcaca;
    LUT4 mux_8_i2_3_lut (.A(CNT1[1]), .B(DBIN[1]), .C(W3), .Z(n27[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1689[64:92])
    defparam mux_8_i2_3_lut.init = 16'hcaca;
    FD1P3IX CNT__i7 (.D(n27[7]), .SP(Clk_enable_195), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i7.GSR = "DISABLED";
    FD1P3IX CNT__i6 (.D(n27[6]), .SP(Clk_enable_195), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i6.GSR = "DISABLED";
    FD1P3IX CNT__i5 (.D(n27[5]), .SP(Clk_enable_195), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i5.GSR = "DISABLED";
    FD1P3IX CNT__i4 (.D(n27[4]), .SP(Clk_enable_195), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i4.GSR = "DISABLED";
    FD1P3IX CNT__i3 (.D(n27[3]), .SP(Clk_enable_195), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i3.GSR = "DISABLED";
    FD1P3IX CNT__i2 (.D(n27[2]), .SP(Clk_enable_195), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i2.GSR = "DISABLED";
    FD1P3IX CNT__i1 (.D(n27[1]), .SP(Clk_enable_195), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i1.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i2 (.D(\CNT1_7__N_1142[2] ), .SP(CNT_7__N_1141), .CK(Clk), 
            .Q(CNT1[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i2.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i3 (.D(CNT1_7__N_1142[3]), .SP(CNT_7__N_1141), .CK(Clk), 
            .Q(CNT1[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i3.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i4 (.D(CNT1_7__N_1142[4]), .SP(CNT_7__N_1141), .CK(Clk), 
            .Q(CNT1[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i4.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i5 (.D(CNT1_7__N_1142[5]), .SP(CNT_7__N_1141), .CK(Clk), 
            .Q(CNT1[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i5.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i6 (.D(CNT1_7__N_1142[6]), .SP(CNT_7__N_1141), .CK(Clk), 
            .Q(CNT1[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i6.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i7 (.D(CNT1_7__N_1142[7]), .SP(CNT_7__N_1141), .CK(Clk), 
            .Q(CNT1[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i7.GSR = "DISABLED";
    FD1P3IX CNT__i0 (.D(n27[0]), .SP(Clk_enable_195), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i0.GSR = "DISABLED";
    FD1P3IX CNT1_i0_i0 (.D(OAM1ADR_0__N_1040), .SP(CNT_7__N_1141), .CD(n7333), 
            .CK(Clk), .Q(CNT1[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i0.GSR = "DISABLED";
    LUT4 i2586_2_lut (.A(OAM1ADR[3]), .B(n4), .Z(CNT1_7__N_1142[3])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1690[48:112])
    defparam i2586_2_lut.init = 16'h6666;
    LUT4 i2589_2_lut_4_lut (.A(OAM1ADR[6]), .B(OAM1ADR[3]), .C(n4), .D(n4104), 
         .Z(CNT1_7__N_1142[6])) /* synthesis lut_function=(!(A (B (C (D)))+!A !(B (C (D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1690[48:112])
    defparam i2589_2_lut_4_lut.init = 16'h6aaa;
    FD1P3IX CNT1_i0_i1 (.D(n56[1]), .SP(CNT_7__N_1141), .CD(n7333), .CK(Clk), 
            .Q(CNT1[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i1.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U100
//

module COUNTER_U100 (\OAM2ADR[4] , C_OUT_N_563, Clk, nPCLK, OAM2STEP_N_1104, 
            ORES) /* synthesis syn_module_defined=1 */ ;
    output \OAM2ADR[4] ;
    input C_OUT_N_563;
    input Clk;
    input nPCLK;
    input OAM2STEP_N_1104;
    input ORES;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565, CNT1;
    
    LUT4 CNT_I_0_2_lut (.A(\OAM2ADR[4] ), .B(C_OUT_N_563), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(CNT1), .SP(OAM2STEP_N_1104), .CK(Clk), .CD(ORES), 
            .Q(\OAM2ADR[4] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U101
//

module COUNTER_U101 (\OAM2ADR[3] , Clk, OAM2STEP_N_1104, ORES, nPCLK, 
            CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    output \OAM2ADR[3] ;
    input Clk;
    input OAM2STEP_N_1104;
    input ORES;
    input nPCLK;
    input CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3DX CNT_14 (.D(CNT1), .SP(OAM2STEP_N_1104), .CK(Clk), .CD(ORES), 
            .Q(\OAM2ADR[3] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U102
//

module COUNTER_U102 (Clk, nPCLK, CNT1_N_565, \OAM2ADR[2] , OAM2STEP_N_1104, 
            ORES) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    input CNT1_N_565;
    output \OAM2ADR[2] ;
    input OAM2STEP_N_1104;
    input ORES;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(CNT1), .SP(OAM2STEP_N_1104), .CK(Clk), .CD(ORES), 
            .Q(\OAM2ADR[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U103
//

module COUNTER_U103 (\OAM2ADR[1] , Clk, OAM2STEP_N_1104, ORES, \OAM2ADR[0] , 
            \OAM2ADR[3] , \OAM2ADR[2] , CNT1_N_565, CNT1_N_565_adj_3, 
            C_OUT_N_563, nPCLK) /* synthesis syn_module_defined=1 */ ;
    output \OAM2ADR[1] ;
    input Clk;
    input OAM2STEP_N_1104;
    input ORES;
    input \OAM2ADR[0] ;
    input \OAM2ADR[3] ;
    input \OAM2ADR[2] ;
    output CNT1_N_565;
    output CNT1_N_565_adj_3;
    output C_OUT_N_563;
    input nPCLK;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, CNT1_N_565_adj_1578;
    
    FD1P3DX CNT_14 (.D(CNT1), .SP(OAM2STEP_N_1104), .CK(Clk), .CD(ORES), 
            .Q(\OAM2ADR[1] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), 
         .C(\OAM2ADR[3] ), .D(\OAM2ADR[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h78f0;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), .C(\OAM2ADR[2] ), 
         .Z(CNT1_N_565_adj_3)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    LUT4 CNT_I_0_19_2_lut_3_lut_4_lut (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), 
         .C(\OAM2ADR[3] ), .D(\OAM2ADR[2] ), .Z(C_OUT_N_563)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_3_lut_4_lut.init = 16'h8000;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1578), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), .Z(CNT1_N_565_adj_1578)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    
endmodule
//
// Verilog Description of module COUNTER_U104
//

module COUNTER_U104 (Clk, nPCLK, \OAM2ADR[0] , OAM2STEP_N_1104, ORES) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    output \OAM2ADR[0] ;
    input OAM2STEP_N_1104;
    input ORES;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, CNT1_N_565;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(CNT1), .SP(OAM2STEP_N_1104), .CK(Clk), .CD(ORES), 
            .Q(\OAM2ADR[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i46_1_lut (.A(\OAM2ADR[0] ), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam i46_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module OAM2_RAM
//

module OAM2_RAM (Clk, VCC_net, GND_net, WE, OAM2ADR, OB2, OAM2Q) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input Clk;
    input VCC_net;
    input GND_net;
    input WE;
    input [4:0]OAM2ADR;
    input [7:0]OB2;
    output [7:0]OAM2Q;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    DP8KC OAM2_RAM_0_0_0 (.DIA0(OB2[0]), .DIA1(OB2[1]), .DIA2(OB2[2]), 
          .DIA3(OB2[3]), .DIA4(OB2[4]), .DIA5(OB2[5]), .DIA6(OB2[6]), 
          .DIA7(OB2[7]), .DIA8(GND_net), .ADA0(VCC_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(OAM2ADR[0]), .ADA4(OAM2ADR[1]), .ADA5(OAM2ADR[2]), 
          .ADA6(OAM2ADR[3]), .ADA7(OAM2ADR[4]), .ADA8(GND_net), .ADA9(GND_net), 
          .ADA10(GND_net), .ADA11(GND_net), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(WE), .CSA0(GND_net), .CSA1(GND_net), 
          .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), .DIB1(GND_net), 
          .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), .DIB5(GND_net), 
          .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), .ADB0(GND_net), 
          .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), .ADB4(GND_net), 
          .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), .ADB8(GND_net), 
          .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), .ADB12(GND_net), 
          .CEB(VCC_net), .OCEB(VCC_net), .CLKB(GND_net), .WEB(GND_net), 
          .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), .RSTB(GND_net), 
          .DOA0(OAM2Q[0]), .DOA1(OAM2Q[1]), .DOA2(OAM2Q[2]), .DOA3(OAM2Q[3]), 
          .DOA4(OAM2Q[4]), .DOA5(OAM2Q[5]), .DOA6(OAM2Q[6]), .DOA7(OAM2Q[7])) /* synthesis MEM_LPC_FILE="OAM2_RAM.lpc", MEM_INIT_FILE="INIT_ALL_0s", syn_instantiated=1, LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=90, LSE_LLINE=1277, LSE_RLINE=1277 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1277[10:90])
    defparam OAM2_RAM_0_0_0.DATA_WIDTH_A = 9;
    defparam OAM2_RAM_0_0_0.DATA_WIDTH_B = 9;
    defparam OAM2_RAM_0_0_0.REGMODE_A = "OUTREG";
    defparam OAM2_RAM_0_0_0.REGMODE_B = "NOREG";
    defparam OAM2_RAM_0_0_0.CSDECODE_A = "0b000";
    defparam OAM2_RAM_0_0_0.CSDECODE_B = "0b111";
    defparam OAM2_RAM_0_0_0.WRITEMODE_A = "NORMAL";
    defparam OAM2_RAM_0_0_0.WRITEMODE_B = "NORMAL";
    defparam OAM2_RAM_0_0_0.GSR = "ENABLED";
    defparam OAM2_RAM_0_0_0.RESETMODE = "SYNC";
    defparam OAM2_RAM_0_0_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam OAM2_RAM_0_0_0.INIT_DATA = "STATIC";
    defparam OAM2_RAM_0_0_0.INITVAL_00 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_01 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_02 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_03 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_04 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_05 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_06 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_07 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_08 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_09 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    
endmodule
//
// Verilog Description of module CLK_DIV
//

module CLK_DIV (MCLK_c, SUBCLK_c, Clk2_N_24, MODE_c, DENDY_c, PCLK_c, 
            nPCLK, nRES_c, MODE_N_21) /* synthesis syn_module_defined=1 */ ;
    input MCLK_c;
    output SUBCLK_c;
    input Clk2_N_24;
    input MODE_c;
    input DENDY_c;
    output PCLK_c;
    output nPCLK;
    input nRES_c;
    input MODE_N_21;
    
    wire MCLK_c /* synthesis is_clock=1, SET_AS_NETWORK=MCLK_c */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(36[7:11])
    wire Clk2_N_24 /* synthesis is_inv_clock=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(478[5:10])
    wire [2:0]DIV;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(479[10:13])
    
    wire DIV_2__N_12;
    wire [1:0]SUB;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(480[10:13])
    
    wire DIV2n, DIV_2__N_10, SUB_1__N_17;
    
    FD1S3AX DIV_i0 (.D(DIV_2__N_12), .CK(MCLK_c), .Q(DIV[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=157, LSE_RLINE=164 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(485[8] 490[28])
    defparam DIV_i0.GSR = "DISABLED";
    FD1S3AX SUBCLK_29 (.D(SUB[1]), .CK(MCLK_c), .Q(SUBCLK_c)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=157, LSE_RLINE=164 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(485[8] 490[28])
    defparam SUBCLK_29.GSR = "DISABLED";
    FD1S3AX DIV2n_30 (.D(DIV_2__N_10), .CK(Clk2_N_24), .Q(DIV2n)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=157, LSE_RLINE=164 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(491[8] 493[28])
    defparam DIV2n_30.GSR = "DISABLED";
    LUT4 DIV_1__I_0_2_lut_3_lut (.A(DIV[1]), .B(MODE_c), .C(DENDY_c), 
         .Z(DIV_2__N_10)) /* synthesis lut_function=(!((B (C))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(492[19:32])
    defparam DIV_1__I_0_2_lut_3_lut.init = 16'h2a2a;
    FD1S3AX DIV_i2 (.D(DIV_2__N_10), .CK(MCLK_c), .Q(DIV[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=157, LSE_RLINE=164 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(485[8] 490[28])
    defparam DIV_i2.GSR = "DISABLED";
    FD1S3AX DIV_i1 (.D(DIV[0]), .CK(MCLK_c), .Q(DIV[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=157, LSE_RLINE=164 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(485[8] 490[28])
    defparam DIV_i1.GSR = "DISABLED";
    LUT4 PCLK_I_0_1_lut (.A(PCLK_c), .Z(nPCLK)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(483[16:52])
    defparam PCLK_I_0_1_lut.init = 16'h5555;
    FD1S3AX SUB_i1 (.D(SUB[0]), .CK(MCLK_c), .Q(SUB[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=157, LSE_RLINE=164 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(485[8] 490[28])
    defparam SUB_i1.GSR = "DISABLED";
    FD1S3AX SUB_i0 (.D(SUB_1__N_17), .CK(MCLK_c), .Q(SUB[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=157, LSE_RLINE=164 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(485[8] 490[28])
    defparam SUB_i0.GSR = "DISABLED";
    LUT4 i10362_2_lut (.A(SUBCLK_c), .B(nRES_c), .Z(SUB_1__N_17)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(489[42:61])
    defparam i10362_2_lut.init = 16'h4444;
    LUT4 i1_4_lut (.A(DIV[2]), .B(MODE_N_21), .C(DIV2n), .D(DIV[1]), 
         .Z(PCLK_c)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam i1_4_lut.init = 16'hfefa;
    LUT4 i10360_3_lut (.A(DIV[1]), .B(DIV[2]), .C(nRES_c), .Z(DIV_2__N_12)) /* synthesis lut_function=(!(A+(B+!(C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(487[46:74])
    defparam i10360_3_lut.init = 16'h1010;
    
endmodule
//
// Verilog Description of module REGISTER_SELECT
//

module REGISTER_SELECT (DBIN, Clk, DB_out_0, GND_net, RnWR, VCC_net, 
            RnW_c, nDBER, DB_nOE_c_c, DB_out_7, DB_out_6, DB_out_5, 
            A_c_1, A_c_0, DB_out_4, R2, Clk_enable_220, DB_out_3, 
            W6_2, W5_1, RC, Clk_enable_44, W6_1, W5_2, DB_out_2, 
            DB_out_1, W0, W1, W3, R4, W4, R7, W7, DB_DIR_c, 
            A_c_2) /* synthesis syn_module_defined=1 */ ;
    output [7:0]DBIN;
    input Clk;
    input DB_out_0;
    input GND_net;
    output RnWR;
    input VCC_net;
    input RnW_c;
    output nDBER;
    input DB_nOE_c_c;
    input DB_out_7;
    input DB_out_6;
    input DB_out_5;
    input A_c_1;
    input A_c_0;
    input DB_out_4;
    output R2;
    output Clk_enable_220;
    input DB_out_3;
    output W6_2;
    output W5_1;
    input RC;
    output Clk_enable_44;
    output W6_1;
    output W5_2;
    input DB_out_2;
    input DB_out_1;
    output W0;
    output W1;
    output W3;
    output R4;
    output W4;
    output R7;
    output W7;
    output DB_DIR_c;
    input A_c_2;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire DBIN_7__N_33;
    wire [2:0]ADR;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(523[10:13])
    
    wire n7498, W6_1_N_81, W7_N_87, R7_N_90, n4088, W5_1_N_69, R2_N_56, 
        W3_N_60, W1_N_53, DWR2_N_77, Clk_enable_221, Clk_enable_222, 
        DWR2, DWR2_N_74, W0_N_41, W4_N_63, R4_N_67, DWR1;
    
    IFS1P3DX DBIN_i0_i0 (.D(DB_out_0), .SP(DBIN_7__N_33), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i0.GSR = "DISABLED";
    IFS1P3DX RnWR_132 (.D(RnW_c), .SP(VCC_net), .SCLK(Clk), .CD(GND_net), 
            .Q(RnWR)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam RnWR_132.GSR = "DISABLED";
    IFS1P3DX nDBER_133 (.D(DB_nOE_c_c), .SP(VCC_net), .SCLK(Clk), .CD(GND_net), 
            .Q(nDBER)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam nDBER_133.GSR = "DISABLED";
    IFS1P3DX DBIN_i0_i7 (.D(DB_out_7), .SP(DBIN_7__N_33), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i7.GSR = "DISABLED";
    IFS1P3DX DBIN_i0_i6 (.D(DB_out_6), .SP(DBIN_7__N_33), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i6.GSR = "DISABLED";
    LUT4 i2_3_lut_4_lut (.A(ADR[2]), .B(ADR[1]), .C(n7498), .D(nDBER), 
         .Z(W6_1_N_81)) /* synthesis lut_function=(!(((C+(D))+!B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(542[18:34])
    defparam i2_3_lut_4_lut.init = 16'h0008;
    LUT4 W7_I_22_2_lut_3_lut_4_lut (.A(ADR[2]), .B(ADR[1]), .C(RnWR), 
         .D(ADR[0]), .Z(W7_N_87)) /* synthesis lut_function=(!(((C+!(D))+!B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(542[18:34])
    defparam W7_I_22_2_lut_3_lut_4_lut.init = 16'h0800;
    LUT4 W7_N_88_I_0_2_lut_3_lut_4_lut (.A(ADR[2]), .B(ADR[1]), .C(RnWR), 
         .D(ADR[0]), .Z(R7_N_90)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(542[18:34])
    defparam W7_N_88_I_0_2_lut_3_lut_4_lut.init = 16'h8000;
    LUT4 i2_3_lut_4_lut_adj_388 (.A(ADR[2]), .B(ADR[1]), .C(n4088), .D(nDBER), 
         .Z(W5_1_N_69)) /* synthesis lut_function=(!((B+((D)+!C))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(539[18:34])
    defparam i2_3_lut_4_lut_adj_388.init = 16'h0020;
    IFS1P3DX DBIN_i0_i5 (.D(DB_out_5), .SP(DBIN_7__N_33), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i5.GSR = "DISABLED";
    LUT4 i2_3_lut_4_lut_adj_389 (.A(ADR[2]), .B(ADR[1]), .C(ADR[0]), .D(RnWR), 
         .Z(R2_N_56)) /* synthesis lut_function=(!(A+((C+!(D))+!B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(536[17:34])
    defparam i2_3_lut_4_lut_adj_389.init = 16'h0400;
    IFS1P3DX ADR_i1 (.D(A_c_1), .SP(VCC_net), .SCLK(Clk), .CD(GND_net), 
            .Q(ADR[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam ADR_i1.GSR = "DISABLED";
    IFS1P3DX ADR_i0 (.D(A_c_0), .SP(VCC_net), .SCLK(Clk), .CD(GND_net), 
            .Q(ADR[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam ADR_i0.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(ADR[2]), .B(ADR[1]), .C(RnWR), .D(ADR[0]), 
         .Z(W3_N_60)) /* synthesis lut_function=(!(A+((C+!(D))+!B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(536[17:34])
    defparam i1_2_lut_3_lut_4_lut.init = 16'h0400;
    LUT4 i1_2_lut_3_lut_4_lut_adj_390 (.A(ADR[2]), .B(ADR[1]), .C(RnWR), 
         .D(ADR[0]), .Z(W1_N_53)) /* synthesis lut_function=(!(A+(B+(C+!(D))))) */ ;
    defparam i1_2_lut_3_lut_4_lut_adj_390.init = 16'h0100;
    IFS1P3DX DBIN_i0_i4 (.D(DB_out_4), .SP(DBIN_7__N_33), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i4.GSR = "DISABLED";
    LUT4 i4552_1_lut (.A(R2), .Z(Clk_enable_220)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam i4552_1_lut.init = 16'h5555;
    LUT4 i1_2_lut (.A(DWR2_N_77), .B(R2), .Z(Clk_enable_221)) /* synthesis lut_function=((B)+!A) */ ;
    defparam i1_2_lut.init = 16'hdddd;
    LUT4 i1_2_lut_adj_391 (.A(DWR2_N_77), .B(R2), .Z(Clk_enable_222)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i1_2_lut_adj_391.init = 16'heeee;
    LUT4 DWR2_I_0_1_lut (.A(DWR2), .Z(DWR2_N_74)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(541[64:69])
    defparam DWR2_I_0_1_lut.init = 16'h5555;
    IFS1P3DX DBIN_i0_i3 (.D(DB_out_3), .SP(DBIN_7__N_33), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i3.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut (.A(W6_2), .B(W5_1), .C(RC), .Z(Clk_enable_44)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(548[15:40])
    defparam i1_2_lut_3_lut.init = 16'hfefe;
    LUT4 i10664_2_lut_3_lut_4_lut (.A(ADR[2]), .B(ADR[1]), .C(RnWR), .D(ADR[0]), 
         .Z(W0_N_41)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;
    defparam i10664_2_lut_3_lut_4_lut.init = 16'h0001;
    LUT4 i2_3_lut_4_lut_adj_392 (.A(W6_2), .B(W5_1), .C(W6_1), .D(W5_2), 
         .Z(DWR2_N_77)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(548[15:40])
    defparam i2_3_lut_4_lut_adj_392.init = 16'hfffe;
    IFS1P3DX DBIN_i0_i2 (.D(DB_out_2), .SP(DBIN_7__N_33), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i2.GSR = "DISABLED";
    IFS1P3DX DBIN_i0_i1 (.D(DB_out_1), .SP(DBIN_7__N_33), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i1.GSR = "DISABLED";
    LUT4 W4_I_13_2_lut_4_lut (.A(ADR[2]), .B(ADR[1]), .C(ADR[0]), .D(RnWR), 
         .Z(W4_N_63)) /* synthesis lut_function=(!((B+(C+(D)))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(539[18:52])
    defparam W4_I_13_2_lut_4_lut.init = 16'h0002;
    FD1S3IX W0_134 (.D(W0_N_41), .CK(Clk), .CD(nDBER), .Q(W0));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W0_134.GSR = "DISABLED";
    FD1S3IX W1_135 (.D(W1_N_53), .CK(Clk), .CD(nDBER), .Q(W1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W1_135.GSR = "DISABLED";
    FD1S3IX R2_136 (.D(R2_N_56), .CK(Clk), .CD(nDBER), .Q(R2));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam R2_136.GSR = "DISABLED";
    FD1S3IX W3_137 (.D(W3_N_60), .CK(Clk), .CD(nDBER), .Q(W3));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W3_137.GSR = "DISABLED";
    FD1S3IX R4_138 (.D(R4_N_67), .CK(Clk), .CD(nDBER), .Q(R4));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam R4_138.GSR = "DISABLED";
    FD1S3IX W4_139 (.D(W4_N_63), .CK(Clk), .CD(nDBER), .Q(W4));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W4_139.GSR = "DISABLED";
    FD1S3IX W5_1_140 (.D(W5_1_N_69), .CK(Clk), .CD(DWR2_N_74), .Q(W5_1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W5_1_140.GSR = "DISABLED";
    FD1S3IX W5_2_141 (.D(W5_1_N_69), .CK(Clk), .CD(DWR2), .Q(W5_2));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W5_2_141.GSR = "DISABLED";
    LUT4 W4_N_64_I_0_2_lut_4_lut (.A(ADR[2]), .B(ADR[1]), .C(ADR[0]), 
         .D(RnWR), .Z(R4_N_67)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(538[18:52])
    defparam W4_N_64_I_0_2_lut_4_lut.init = 16'h0200;
    FD1S3IX W6_1_142 (.D(W6_1_N_81), .CK(Clk), .CD(DWR2_N_74), .Q(W6_1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W6_1_142.GSR = "DISABLED";
    FD1S3IX W6_2_143 (.D(W6_1_N_81), .CK(Clk), .CD(DWR2), .Q(W6_2));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W6_2_143.GSR = "DISABLED";
    FD1S3IX R7_144 (.D(R7_N_90), .CK(Clk), .CD(nDBER), .Q(R7));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam R7_144.GSR = "DISABLED";
    FD1S3IX W7_145 (.D(W7_N_87), .CK(Clk), .CD(nDBER), .Q(W7));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W7_145.GSR = "DISABLED";
    LUT4 i10368_2_lut (.A(DB_nOE_c_c), .B(RnW_c), .Z(DBIN_7__N_33)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i10368_2_lut.init = 16'h1111;
    LUT4 RnW_I_0_1_lut (.A(RnW_c), .Z(DB_DIR_c)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(146[18:22])
    defparam RnW_I_0_1_lut.init = 16'h5555;
    FD1P3JX DWR2_147 (.D(DWR1), .SP(Clk_enable_221), .PD(R2), .CK(Clk), 
            .Q(DWR2));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DWR2_147.GSR = "DISABLED";
    FD1P3JX DWR1_146 (.D(DWR2_N_74), .SP(Clk_enable_222), .PD(R2), .CK(Clk), 
            .Q(DWR1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DWR1_146.GSR = "DISABLED";
    LUT4 i7054_2_lut (.A(RnWR), .B(ADR[0]), .Z(n7498)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i7054_2_lut.init = 16'heeee;
    IFS1P3DX ADR_i2 (.D(A_c_2), .SP(VCC_net), .SCLK(Clk), .CD(GND_net), 
            .Q(ADR[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam ADR_i2.GSR = "DISABLED";
    LUT4 i1_2_lut_adj_393 (.A(RnWR), .B(ADR[0]), .Z(n4088)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(535[17:52])
    defparam i1_2_lut_adj_393.init = 16'h4444;
    
endmodule
//
// Verilog Description of module TSALL
// module not written out since it is a black-box. 
//

//
// Verilog Description of module REG2000_2001
//

module REG2000_2001 (EMP_R, EMP_G, MODE_c, DENDY_c, EMPH, n996, 
            Clk, nPCLK, nVIS, CLIP_B_N_247, CLIPOR, W1, nCLPB_N_130, 
            CLIP_OUT, O8_16, BGCLIP, DBIN, I1_32, VBL_EN, W0, 
            OBSEL, B_W, BGSEL, BLNK_FF, BLNK, N_HB, SC_CNT, RC) /* synthesis syn_module_defined=1 */ ;
    output EMP_R;
    output EMP_G;
    input MODE_c;
    input DENDY_c;
    output [2:0]EMPH;
    output n996;
    input Clk;
    input nPCLK;
    input nVIS;
    input CLIP_B_N_247;
    output CLIPOR;
    input W1;
    output nCLPB_N_130;
    input CLIP_OUT;
    output O8_16;
    output BGCLIP;
    input [7:0]DBIN;
    output I1_32;
    output VBL_EN;
    input W0;
    output OBSEL;
    output B_W;
    output BGSEL;
    input BLNK_FF;
    output BLNK;
    input N_HB;
    output SC_CNT;
    input RC;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire OBCLIP, W1_N_127;
    wire [7:0]W1R;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(586[10:13])
    
    wire BGE, OBE, nVISR, CLIPBR, CLIPOR_N_138, W0_N_121;
    wire [4:0]W0R;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(585[10:13])
    
    wire n5094, n5088;
    
    LUT4 EMP_R_I_0_70_3_lut_4_lut (.A(EMP_R), .B(EMP_G), .C(MODE_c), .D(DENDY_c), 
         .Z(EMPH[0])) /* synthesis lut_function=(A (B+(C (D)))+!A !((C (D))+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(598[15:37])
    defparam EMP_R_I_0_70_3_lut_4_lut.init = 16'haccc;
    LUT4 i507_2_lut_3_lut (.A(EMPH[2]), .B(EMP_G), .C(EMP_R), .Z(n996)) /* synthesis lut_function=(!(A+!(B (C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam i507_2_lut_3_lut.init = 16'h4040;
    FD1P3AX OBCLIP_58 (.D(W1R[2]), .SP(W1_N_127), .CK(Clk), .Q(OBCLIP));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam OBCLIP_58.GSR = "DISABLED";
    FD1P3AX BGE_59 (.D(W1R[3]), .SP(W1_N_127), .CK(Clk), .Q(BGE));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam BGE_59.GSR = "DISABLED";
    FD1P3AX OBE_60 (.D(W1R[4]), .SP(W1_N_127), .CK(Clk), .Q(OBE));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam OBE_60.GSR = "DISABLED";
    FD1P3AX EMP_R_61 (.D(W1R[5]), .SP(W1_N_127), .CK(Clk), .Q(EMP_R));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam EMP_R_61.GSR = "DISABLED";
    FD1P3AX EMP_G_62 (.D(W1R[6]), .SP(W1_N_127), .CK(Clk), .Q(EMP_G));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam EMP_G_62.GSR = "DISABLED";
    FD1P3AX nVISR_63 (.D(nVIS), .SP(nPCLK), .CK(Clk), .Q(nVISR));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam nVISR_63.GSR = "DISABLED";
    FD1P3AX CLIPBR_64 (.D(CLIP_B_N_247), .SP(nPCLK), .CK(Clk), .Q(CLIPBR));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam CLIPBR_64.GSR = "DISABLED";
    FD1P3AX CLIPOR_65 (.D(CLIPOR_N_138), .SP(nPCLK), .CK(Clk), .Q(CLIPOR));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam CLIPOR_65.GSR = "DISABLED";
    LUT4 W1_I_0_1_lut (.A(W1), .Z(W1_N_127)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(608[14:17])
    defparam W1_I_0_1_lut.init = 16'h5555;
    LUT4 i10371_3_lut (.A(nVISR), .B(BGE), .C(CLIPBR), .Z(nCLPB_N_130)) /* synthesis lut_function=(!(A+((C)+!B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(595[16:42])
    defparam i10371_3_lut.init = 16'h0404;
    LUT4 i10376_4_lut (.A(OBE), .B(nVISR), .C(CLIP_OUT), .D(OBCLIP), 
         .Z(CLIPOR_N_138)) /* synthesis lut_function=(!((B+!(C+(D)))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(612[20:46])
    defparam i10376_4_lut.init = 16'h2220;
    FD1P3AX O8_16_56 (.D(W0R[3]), .SP(W0_N_121), .CK(Clk), .Q(O8_16));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam O8_16_56.GSR = "DISABLED";
    FD1P3AX BGCLIP_57 (.D(W1R[1]), .SP(W1_N_127), .CK(Clk), .Q(BGCLIP));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam BGCLIP_57.GSR = "DISABLED";
    FD1P3IX W1R__i7 (.D(DBIN[7]), .SP(W1), .CD(n5094), .CK(Clk), .Q(EMPH[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i7.GSR = "DISABLED";
    FD1P3IX W1R__i6 (.D(DBIN[6]), .SP(W1), .CD(n5094), .CK(Clk), .Q(W1R[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i6.GSR = "DISABLED";
    FD1P3IX W1R__i5 (.D(DBIN[5]), .SP(W1), .CD(n5094), .CK(Clk), .Q(W1R[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i5.GSR = "DISABLED";
    FD1P3IX W1R__i4 (.D(DBIN[4]), .SP(W1), .CD(n5094), .CK(Clk), .Q(W1R[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i4.GSR = "DISABLED";
    FD1P3IX W1R__i3 (.D(DBIN[3]), .SP(W1), .CD(n5094), .CK(Clk), .Q(W1R[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i3.GSR = "DISABLED";
    FD1P3IX W1R__i2 (.D(DBIN[2]), .SP(W1), .CD(n5094), .CK(Clk), .Q(W1R[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i2.GSR = "DISABLED";
    FD1P3IX W1R__i1 (.D(DBIN[1]), .SP(W1), .CD(n5094), .CK(Clk), .Q(W1R[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i1.GSR = "DISABLED";
    FD1P3AX I1_32_53 (.D(W0R[0]), .SP(W0_N_121), .CK(Clk), .Q(I1_32));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam I1_32_53.GSR = "DISABLED";
    FD1P3IX W0R__i4 (.D(DBIN[7]), .SP(W0), .CD(n5088), .CK(Clk), .Q(VBL_EN)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W0R__i4.GSR = "DISABLED";
    FD1P3IX W0R__i3 (.D(DBIN[5]), .SP(W0), .CD(n5088), .CK(Clk), .Q(W0R[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W0R__i3.GSR = "DISABLED";
    FD1P3IX W0R__i2 (.D(DBIN[4]), .SP(W0), .CD(n5088), .CK(Clk), .Q(W0R[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W0R__i2.GSR = "DISABLED";
    FD1P3IX W0R__i1 (.D(DBIN[3]), .SP(W0), .CD(n5088), .CK(Clk), .Q(W0R[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W0R__i1.GSR = "DISABLED";
    FD1P3AX OBSEL_54 (.D(W0R[1]), .SP(W0_N_121), .CK(Clk), .Q(OBSEL));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam OBSEL_54.GSR = "DISABLED";
    FD1P3IX W1R__i0 (.D(DBIN[0]), .SP(W1), .CD(n5094), .CK(Clk), .Q(B_W)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i0.GSR = "DISABLED";
    FD1P3AX BGSEL_55 (.D(W0R[2]), .SP(W0_N_121), .CK(Clk), .Q(BGSEL));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam BGSEL_55.GSR = "DISABLED";
    LUT4 BLACK_I_0_2_lut_3_lut (.A(BGE), .B(OBE), .C(BLNK_FF), .Z(BLNK)) /* synthesis lut_function=(A (C)+!A ((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(592[17:30])
    defparam BLACK_I_0_2_lut_3_lut.init = 16'hf1f1;
    FD1P3IX W0R__i0 (.D(DBIN[2]), .SP(W0), .CD(n5088), .CK(Clk), .Q(W0R[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W0R__i0.GSR = "DISABLED";
    LUT4 i6899_2_lut_3_lut (.A(BGE), .B(OBE), .C(N_HB), .Z(SC_CNT)) /* synthesis lut_function=(A (C)+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(592[17:30])
    defparam i6899_2_lut_3_lut.init = 16'he0e0;
    LUT4 W0_I_0_1_lut (.A(W0), .Z(W0_N_121)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(607[14:17])
    defparam W0_I_0_1_lut.init = 16'h5555;
    LUT4 i1524_2_lut (.A(W0), .B(RC), .Z(n5088)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam i1524_2_lut.init = 16'h8888;
    LUT4 i1500_2_lut (.A(W1), .B(RC), .Z(n5094)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam i1500_2_lut.init = 16'h8888;
    LUT4 EMP_G_I_0_71_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(MODE_c), .D(DENDY_c), 
         .Z(EMPH[1])) /* synthesis lut_function=(A (B+(C (D)))+!A !((C (D))+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(599[15:37])
    defparam EMP_G_I_0_71_3_lut_4_lut.init = 16'haccc;
    
endmodule
//
// Verilog Description of module PAR_GEN
//

module PAR_GEN (\PAD[0] , Clk, PCLK_c, GND_net, W6_2, BLNK, DBIN, 
            BGSEL, PAR_O, W5_2, RC, W6_1, W5_1, THO, OBSEL, 
            O8_16, TVO1, \PAD[1] , nPCLK, OV, F_AT, OB, E_EV, 
            PD_out_0, W0, TAL_LATCH_N_890, VINV_LATCH_N_896, SC_CNT, 
            F_NT, \Hnn[0] , STEP_N_685, TSTEP, \Hn[2] , Clk_enable_44, 
            PD_out_7, PD_out_6, PD_out_5, PD_out_4, PD_out_3, PD_out_2, 
            PD_out_1, \Hn[1] , RESCL, PA12_c_12, PA11_c_11, PA10_c_10, 
            PA9_c_9, PA8_c_8, SH2, \PAD[7] , \PAD[6] , \PAD[5] , 
            \PAD[4] , \PAD[3] , \PAD[2] , DB_PAR_N_593, PA13_c_13, 
            I1_32, \W7Q[3] , \W7Q[1] ) /* synthesis syn_module_defined=1 */ ;
    output \PAD[0] ;
    input Clk;
    input PCLK_c;
    input GND_net;
    input W6_2;
    input BLNK;
    input [7:0]DBIN;
    input BGSEL;
    input PAR_O;
    input W5_2;
    input RC;
    input W6_1;
    input W5_1;
    output [4:0]THO;
    input OBSEL;
    input O8_16;
    output TVO1;
    output \PAD[1] ;
    input nPCLK;
    input [3:0]OV;
    input F_AT;
    input [7:0]OB;
    input E_EV;
    input PD_out_0;
    input W0;
    output TAL_LATCH_N_890;
    output VINV_LATCH_N_896;
    input SC_CNT;
    input F_NT;
    input \Hnn[0] ;
    input STEP_N_685;
    input TSTEP;
    input \Hn[2] ;
    input Clk_enable_44;
    input PD_out_7;
    input PD_out_6;
    input PD_out_5;
    input PD_out_4;
    input PD_out_3;
    input PD_out_2;
    input PD_out_1;
    input \Hn[1] ;
    input RESCL;
    output PA12_c_12;
    output PA11_c_11;
    output PA10_c_10;
    output PA9_c_9;
    output PA8_c_8;
    input SH2;
    output \PAD[7] ;
    output \PAD[6] ;
    output \PAD[5] ;
    output \PAD[4] ;
    output \PAD[3] ;
    output \PAD[2] ;
    input DB_PAR_N_593;
    output PA13_c_13;
    input I1_32;
    input \W7Q[3] ;
    input \W7Q[1] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [13:0]PAMUX;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1110[12:17])
    wire [1:0]W62;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1071[10:13])
    
    wire Clk_enable_42;
    wire [2:0]FVO;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1096[11:14])
    
    wire NBFVO1, n11340;
    wire [11:0]TP;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1061[11:13])
    
    wire n2748;
    wire [4:0]TVO;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1094[11:14])
    
    wire n6, TVZR, TVZR_N_884, TP_11__N_870, TP_11__N_869, n11370, 
        Clk_enable_229, TV_4__N_819, TV_4__N_812, Clk_enable_233, TV_4__N_807, 
        TH_4__N_773, TV_4__N_800, n2750, TH_4__N_780;
    wire [7:0]OBOUT;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1060[10:15])
    wire [7:0]PDOUT;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1059[10:15])
    wire [6:0]TP_11__N_871;
    
    wire n11376, n11382;
    wire [3:0]OVR;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1056[10:13])
    
    wire PARR, n11346, TH_4__N_785, OVOUT_3__N_868;
    wire [7:0]PDIN;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1058[10:14])
    
    wire TV_IN, n4074, TV_IN_N_915;
    wire [1:0]EEVR;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1066[10:14])
    wire [2:0]TP_11__N_880;
    wire [1:0]Z_TV;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1068[10:14])
    
    wire Z_TV_1__N_886, Clk_enable_217, NTH_N_899, NTV_N_906, TAL_LATCH, 
        TVZ, VINV_LATCH, SCCNTR, TV_4__N_824, FV_2__N_832, FV_2__N_829, 
        FV_2__N_837, n4999, n11352, n4057, TP_11__N_879, TP_11__N_878, 
        TH_4__N_790;
    wire [3:0]OVOUT;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1057[10:15])
    
    wire THSTEP_N_925, NTHDO;
    wire [4:0]TH;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1062[10:12])
    
    wire THLOAD_N_916, NTVDO, ZTV_N_928, n5071, n11358, W62_FF, 
        W62_FF_N_912, TVLOAD_N_921, TH_4__N_795, n10692, TVZB, n6_adj_1561, 
        THZ_N_934, NTH_IN, Clk_enable_67;
    wire [2:0]FV;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1065[10:12])
    
    wire CNT1, n2886, CNT1_adj_1562, n2882;
    wire [4:0]TV;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1063[10:12])
    
    wire CNT1_adj_1563, n2921, CNT1_adj_1564, n2914, CNT1_adj_1565, 
        n2912, CNT1_adj_1566, n2908, CNT1_adj_1567, n2906, NTV, 
        CNT1_adj_1568, n2894, CNT1_adj_1569, n2890, n4, NTH, n11334, 
        n5, CNT1_N_565, CNT1_N_565_adj_1570, C_OUT_N_563, CNT1_N_565_adj_1571, 
        CNT1_N_565_adj_1572, Clk_enable_68, CNT1_N_565_adj_1573, C_OUT_N_563_adj_1574, 
        CNT1_N_565_adj_1575, C_OUT_N_563_adj_1576;
    
    OFS1P3DX PAD_i0_i0 (.D(PAMUX[0]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i0.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut (.A(W6_2), .B(PCLK_c), .C(W62[1]), .Z(Clk_enable_42)) /* synthesis lut_function=(A+!(B+!(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'hbaba;
    LUT4 BLNK_N_932_I_0_2_lut (.A(BLNK), .B(FVO[1]), .Z(NBFVO1)) /* synthesis lut_function=((B)+!A) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1107[17:31])
    defparam BLNK_N_932_I_0_2_lut.init = 16'hdddd;
    LUT4 n11340_bdd_4_lut (.A(n11340), .B(TP[5]), .C(DBIN[6]), .D(n2748), 
         .Z(PAMUX[6])) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11340_bdd_4_lut.init = 16'haad8;
    LUT4 i1_2_lut (.A(TVO[0]), .B(TVO[3]), .Z(n6)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1091[15:74])
    defparam i1_2_lut.init = 16'h8888;
    LUT4 TVZR_I_0_1_lut (.A(TVZR), .Z(TVZR_N_884)) /* synthesis lut_function=(!(A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1155[21:26])
    defparam TVZR_I_0_1_lut.init = 16'h5555;
    LUT4 BGSEL_I_0_3_lut (.A(BGSEL), .B(TP_11__N_870), .C(PAR_O), .Z(TP_11__N_869)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1154[20:74])
    defparam BGSEL_I_0_3_lut.init = 16'hcaca;
    LUT4 n11370_bdd_4_lut (.A(n11370), .B(TP[2]), .C(DBIN[2]), .D(n2748), 
         .Z(PAMUX[2])) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11370_bdd_4_lut.init = 16'haad8;
    LUT4 i2_3_lut (.A(W5_2), .B(W6_2), .C(RC), .Z(Clk_enable_229)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1123[11:22])
    defparam i2_3_lut.init = 16'hfefe;
    LUT4 TV_4__I_236_4_lut (.A(W6_2), .B(W5_2), .C(DBIN[6]), .D(DBIN[4]), 
         .Z(TV_4__N_819)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1122[50:85])
    defparam TV_4__I_236_4_lut.init = 16'heca0;
    LUT4 TV_4__I_233_4_lut (.A(W6_2), .B(W5_2), .C(DBIN[7]), .D(DBIN[5]), 
         .Z(TV_4__N_812)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1123[50:85])
    defparam TV_4__I_233_4_lut.init = 16'heca0;
    LUT4 i1_3_lut (.A(W6_1), .B(RC), .C(W5_2), .Z(Clk_enable_233)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1125[11:27])
    defparam i1_3_lut.init = 16'hfefe;
    LUT4 TV_4__I_231_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[0]), .D(DBIN[6]), 
         .Z(TV_4__N_807)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1124[50:85])
    defparam TV_4__I_231_4_lut.init = 16'heca0;
    LUT4 TH_4__I_217_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[4]), .D(DBIN[7]), 
         .Z(TH_4__N_773)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1120[50:85])
    defparam TH_4__I_217_4_lut.init = 16'heca0;
    LUT4 TV_4__I_228_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[1]), .D(DBIN[7]), 
         .Z(TV_4__N_800)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1125[50:85])
    defparam TV_4__I_228_4_lut.init = 16'heca0;
    LUT4 n2750_bdd_4_lut_10801 (.A(n2750), .B(THO[4]), .C(THO[2]), .D(n2748), 
         .Z(n11370)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2750_bdd_4_lut_10801.init = 16'he4aa;
    LUT4 TH_4__I_220_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[3]), .D(DBIN[6]), 
         .Z(TH_4__N_780)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1119[50:85])
    defparam TH_4__I_220_4_lut.init = 16'heca0;
    LUT4 OBSEL_I_0_3_lut (.A(OBSEL), .B(OBOUT[0]), .C(O8_16), .Z(TP_11__N_870)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1154[30:63])
    defparam OBSEL_I_0_3_lut.init = 16'hcaca;
    LUT4 mux_199_i7_3_lut (.A(PDOUT[7]), .B(OBOUT[7]), .C(PAR_O), .Z(TP_11__N_871[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1153[20:53])
    defparam mux_199_i7_3_lut.init = 16'hcaca;
    LUT4 n11376_bdd_4_lut (.A(n11376), .B(TP[1]), .C(DBIN[1]), .D(n2748), 
         .Z(PAMUX[1])) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11376_bdd_4_lut.init = 16'haad8;
    LUT4 n2750_bdd_4_lut_10806 (.A(n2750), .B(THO[3]), .C(THO[1]), .D(n2748), 
         .Z(n11376)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2750_bdd_4_lut_10806.init = 16'he4aa;
    LUT4 n11382_bdd_4_lut (.A(n11382), .B(TP[0]), .C(DBIN[0]), .D(n2748), 
         .Z(PAMUX[0])) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11382_bdd_4_lut.init = 16'haad8;
    LUT4 n2750_bdd_4_lut (.A(n2750), .B(THO[2]), .C(THO[0]), .D(n2748), 
         .Z(n11382)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2750_bdd_4_lut.init = 16'he4aa;
    LUT4 n2750_bdd_4_lut_10776 (.A(n2750), .B(TVO1), .C(n2748), .Z(n11340)) /* synthesis lut_function=(A (B+!(C))+!A (C)) */ ;
    defparam n2750_bdd_4_lut_10776.init = 16'hdada;
    OFS1P3DX PAD_i0_i1 (.D(PAMUX[1]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i1.GSR = "DISABLED";
    LUT4 mux_199_i6_3_lut (.A(PDOUT[6]), .B(OBOUT[6]), .C(PAR_O), .Z(TP_11__N_871[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1153[20:53])
    defparam mux_199_i6_3_lut.init = 16'hcaca;
    FD1P3AX OVR_i0_i0 (.D(OV[0]), .SP(nPCLK), .CK(Clk), .Q(OVR[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVR_i0_i0.GSR = "DISABLED";
    LUT4 NBFVO1_I_0_i2_4_lut (.A(TVO[4]), .B(TP[8]), .C(PARR), .D(F_AT), 
         .Z(PAMUX[9])) /* synthesis lut_function=(A (B+!(C))+!A (B (C+(D))+!B !(C+!(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1112[22:98])
    defparam NBFVO1_I_0_i2_4_lut.init = 16'hcfca;
    LUT4 n11346_bdd_4_lut (.A(n11346), .B(TP[4]), .C(DBIN[5]), .D(n2748), 
         .Z(PAMUX[5])) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11346_bdd_4_lut.init = 16'haad8;
    LUT4 mux_199_i5_3_lut (.A(PDOUT[5]), .B(OBOUT[5]), .C(PAR_O), .Z(TP_11__N_871[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1153[20:53])
    defparam mux_199_i5_3_lut.init = 16'hcaca;
    LUT4 n2750_bdd_4_lut_10781 (.A(n2750), .B(TVO[4]), .C(TVO[0]), .D(n2748), 
         .Z(n11346)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2750_bdd_4_lut_10781.init = 16'he4aa;
    LUT4 TH_4__I_222_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[2]), .D(DBIN[5]), 
         .Z(TH_4__N_785)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1118[50:85])
    defparam TH_4__I_222_4_lut.init = 16'heca0;
    FD1P3AX OBOUT_i0_i0 (.D(OB[0]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i0.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i0 (.D(PDIN[0]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i0.GSR = "DISABLED";
    FD1S3JX TV_IN_241 (.D(TV_IN_N_915), .CK(Clk), .PD(n4074), .Q(TV_IN)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TV_IN_241.GSR = "DISABLED";
    FD1P3AX EEVR_i0 (.D(E_EV), .SP(nPCLK), .CK(Clk), .Q(EEVR[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam EEVR_i0.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i0 (.D(PD_out_0), .SP(nPCLK), .CK(Clk), .Q(PDIN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i0.GSR = "DISABLED";
    FD1P3AX TP_i0_i0 (.D(TP_11__N_880[0]), .SP(nPCLK), .CK(Clk), .Q(TP[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i0.GSR = "DISABLED";
    FD1P3AX Z_TV_i0_i0 (.D(Z_TV_1__N_886), .SP(nPCLK), .CK(Clk), .Q(Z_TV[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam Z_TV_i0_i0.GSR = "DISABLED";
    LUT4 i2_3_lut_adj_380 (.A(W6_1), .B(W0), .C(RC), .Z(Clk_enable_217)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1126[11:27])
    defparam i2_3_lut_adj_380.init = 16'hfefe;
    LUT4 NTH_I_250_4_lut (.A(W6_1), .B(W0), .C(DBIN[2]), .D(DBIN[0]), 
         .Z(NTH_N_899)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1126[50:85])
    defparam NTH_I_250_4_lut.init = 16'heca0;
    LUT4 mux_199_i4_3_lut (.A(PDOUT[4]), .B(OBOUT[4]), .C(PAR_O), .Z(TP_11__N_871[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1153[20:53])
    defparam mux_199_i4_3_lut.init = 16'hcaca;
    LUT4 NTV_I_253_4_lut (.A(W6_1), .B(W0), .C(DBIN[3]), .D(DBIN[1]), 
         .Z(NTV_N_906)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1127[50:85])
    defparam NTV_I_253_4_lut.init = 16'heca0;
    FD1P3AX TAL_LATCH_251 (.D(TAL_LATCH_N_890), .SP(nPCLK), .CK(Clk), 
            .Q(TAL_LATCH));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TAL_LATCH_251.GSR = "DISABLED";
    FD1P3AX TVZR_246 (.D(TVZ), .SP(PCLK_c), .CK(Clk), .Q(TVZR));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TVZR_246.GSR = "DISABLED";
    LUT4 NBFVO1_I_0_i1_4_lut (.A(TVO[3]), .B(TP[7]), .C(PARR), .D(F_AT), 
         .Z(PAMUX[8])) /* synthesis lut_function=(A (B+!(C))+!A (B (C+(D))+!B !(C+!(D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1112[22:98])
    defparam NBFVO1_I_0_i1_4_lut.init = 16'hcfca;
    FD1P3AX VINV_LATCH_240 (.D(OB[7]), .SP(VINV_LATCH_N_896), .CK(Clk), 
            .Q(VINV_LATCH));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam VINV_LATCH_240.GSR = "DISABLED";
    FD1P3AX SCCNTR_248 (.D(SC_CNT), .SP(PCLK_c), .CK(Clk), .Q(SCCNTR));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam SCCNTR_248.GSR = "DISABLED";
    LUT4 TV_4__I_238_4_lut (.A(W6_2), .B(W5_2), .C(DBIN[5]), .D(DBIN[3]), 
         .Z(TV_4__N_824)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1121[50:85])
    defparam TV_4__I_238_4_lut.init = 16'heca0;
    LUT4 FV_2__I_241_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[5]), .D(DBIN[1]), 
         .Z(FV_2__N_832)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1129[50:85])
    defparam FV_2__I_241_4_lut.init = 16'heca0;
    LUT4 W5_2_I_0_277_2_lut (.A(W5_2), .B(DBIN[2]), .Z(FV_2__N_829)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1130[69:85])
    defparam W5_2_I_0_277_2_lut.init = 16'h8888;
    LUT4 mux_199_i3_3_lut (.A(PDOUT[3]), .B(OBOUT[3]), .C(PAR_O), .Z(TP_11__N_871[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1153[20:53])
    defparam mux_199_i3_3_lut.init = 16'hcaca;
    LUT4 mux_199_i2_3_lut (.A(PDOUT[2]), .B(OBOUT[2]), .C(PAR_O), .Z(TP_11__N_871[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1153[20:53])
    defparam mux_199_i2_3_lut.init = 16'hcaca;
    LUT4 FV_2__I_243_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[4]), .D(DBIN[0]), 
         .Z(FV_2__N_837)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1128[50:85])
    defparam FV_2__I_243_4_lut.init = 16'heca0;
    LUT4 i4530_2_lut_2_lut (.A(PCLK_c), .B(W6_2), .Z(n4999)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam i4530_2_lut_2_lut.init = 16'h4444;
    LUT4 n11352_bdd_4_lut (.A(n11352), .B(TP[3]), .C(DBIN[4]), .D(n2748), 
         .Z(PAMUX[4])) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11352_bdd_4_lut.init = 16'haad8;
    LUT4 mux_199_i1_3_lut (.A(PDOUT[1]), .B(OBOUT[1]), .C(PAR_O), .Z(TP_11__N_871[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1153[20:53])
    defparam mux_199_i1_3_lut.init = 16'hcaca;
    LUT4 i10495_2_lut (.A(F_NT), .B(\Hnn[0] ), .Z(TAL_LATCH_N_890)) /* synthesis lut_function=(!(A (B))) */ ;
    defparam i10495_2_lut.init = 16'h7777;
    LUT4 n2750_bdd_4_lut_10786 (.A(n2750), .B(TVO[3]), .C(THO[4]), .D(n2748), 
         .Z(n11352)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2750_bdd_4_lut_10786.init = 16'he4aa;
    LUT4 i2_3_lut_adj_381 (.A(TVO1), .B(n4057), .C(BLNK), .Z(TVZ)) /* synthesis lut_function=(!(A+((C)+!B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam i2_3_lut_adj_381.init = 16'h0404;
    LUT4 PDOUT_0__I_0_3_lut (.A(PDOUT[0]), .B(TP_11__N_879), .C(PAR_O), 
         .Z(TP_11__N_878)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1152[20:77])
    defparam PDOUT_0__I_0_3_lut.init = 16'hcaca;
    LUT4 TH_4__I_224_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[1]), .D(DBIN[4]), 
         .Z(TH_4__N_790)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1117[50:85])
    defparam TH_4__I_224_4_lut.init = 16'heca0;
    LUT4 OBOUT_0__I_0_4_lut (.A(OBOUT[0]), .B(VINV_LATCH), .C(O8_16), 
         .D(OVOUT[3]), .Z(TP_11__N_879)) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1152[30:66])
    defparam OBOUT_0__I_0_4_lut.init = 16'h3aca;
    LUT4 THSTEP_I_262_2_lut (.A(STEP_N_685), .B(TSTEP), .Z(THSTEP_N_925)) /* synthesis lut_function=(A+(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1080[21:48])
    defparam THSTEP_I_262_2_lut.init = 16'heeee;
    LUT4 NBFVO1_I_0_i3_3_lut_4_lut (.A(NTHDO), .B(TP[9]), .C(\Hn[2] ), 
         .D(BLNK), .Z(PAMUX[10])) /* synthesis lut_function=(A (B+((D)+!C))+!A !(((D)+!C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1112[22:98])
    defparam NBFVO1_I_0_i3_3_lut_4_lut.init = 16'haaca;
    FD1P3IX TH__i4 (.D(TH_4__N_773), .SP(Clk_enable_44), .CD(RC), .CK(Clk), 
            .Q(TH[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TH__i4.GSR = "DISABLED";
    FD1P3IX TH__i3 (.D(TH_4__N_780), .SP(Clk_enable_44), .CD(RC), .CK(Clk), 
            .Q(TH[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TH__i3.GSR = "DISABLED";
    FD1P3IX TH__i2 (.D(TH_4__N_785), .SP(Clk_enable_44), .CD(RC), .CK(Clk), 
            .Q(TH[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TH__i2.GSR = "DISABLED";
    FD1P3IX TH__i1 (.D(TH_4__N_790), .SP(Clk_enable_44), .CD(RC), .CK(Clk), 
            .Q(TH[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TH__i1.GSR = "DISABLED";
    LUT4 THLOAD_I_255_3_lut (.A(EEVR[1]), .B(PCLK_c), .C(W62[1]), .Z(THLOAD_N_916)) /* synthesis lut_function=(A (B)+!A (B+!(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1078[18:51])
    defparam THLOAD_I_255_3_lut.init = 16'hcdcd;
    FD1P3AX Z_TV_i0_i1 (.D(TVZR_N_884), .SP(nPCLK), .CK(Clk), .Q(Z_TV[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam Z_TV_i0_i1.GSR = "DISABLED";
    FD1P3AX TP_i0_i11 (.D(TP_11__N_869), .SP(nPCLK), .CK(Clk), .Q(TP[11])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i11.GSR = "DISABLED";
    FD1P3AX TP_i0_i10 (.D(TP_11__N_871[6]), .SP(nPCLK), .CK(Clk), .Q(TP[10])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i10.GSR = "DISABLED";
    FD1P3AX TP_i0_i9 (.D(TP_11__N_871[5]), .SP(nPCLK), .CK(Clk), .Q(TP[9])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i9.GSR = "DISABLED";
    FD1P3AX TP_i0_i8 (.D(TP_11__N_871[4]), .SP(nPCLK), .CK(Clk), .Q(TP[8])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i8.GSR = "DISABLED";
    FD1P3AX TP_i0_i7 (.D(TP_11__N_871[3]), .SP(nPCLK), .CK(Clk), .Q(TP[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i7.GSR = "DISABLED";
    FD1P3AX TP_i0_i6 (.D(TP_11__N_871[2]), .SP(nPCLK), .CK(Clk), .Q(TP[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i6.GSR = "DISABLED";
    FD1P3AX TP_i0_i5 (.D(TP_11__N_871[1]), .SP(nPCLK), .CK(Clk), .Q(TP[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i5.GSR = "DISABLED";
    LUT4 NBFVO1_I_0_i4_3_lut_4_lut (.A(NTVDO), .B(TP[10]), .C(\Hn[2] ), 
         .D(BLNK), .Z(PAMUX[11])) /* synthesis lut_function=(A (B+((D)+!C))+!A !(((D)+!C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1112[22:98])
    defparam NBFVO1_I_0_i4_3_lut_4_lut.init = 16'haaca;
    FD1P3AX TP_i0_i4 (.D(TP_11__N_871[0]), .SP(nPCLK), .CK(Clk), .Q(TP[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i4.GSR = "DISABLED";
    FD1P3AX TP_i0_i3 (.D(TP_11__N_878), .SP(nPCLK), .CK(Clk), .Q(TP[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i3.GSR = "DISABLED";
    LUT4 NBFVO1_I_0_i5_4_lut_4_lut (.A(BLNK), .B(TP[11]), .C(\Hn[2] ), 
         .D(FVO[0]), .Z(PAMUX[12])) /* synthesis lut_function=(A (D)+!A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1112[22:98])
    defparam NBFVO1_I_0_i5_4_lut_4_lut.init = 16'hea40;
    FD1P3AX TP_i0_i2 (.D(TP_11__N_880[2]), .SP(nPCLK), .CK(Clk), .Q(TP[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i2.GSR = "DISABLED";
    FD1P3AX TP_i0_i1 (.D(TP_11__N_880[1]), .SP(nPCLK), .CK(Clk), .Q(TP[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i1.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i7 (.D(PD_out_7), .SP(nPCLK), .CK(Clk), .Q(PDIN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i7.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i6 (.D(PD_out_6), .SP(nPCLK), .CK(Clk), .Q(PDIN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i6.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i5 (.D(PD_out_5), .SP(nPCLK), .CK(Clk), .Q(PDIN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i5.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i4 (.D(PD_out_4), .SP(nPCLK), .CK(Clk), .Q(PDIN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i4.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i3 (.D(PD_out_3), .SP(nPCLK), .CK(Clk), .Q(PDIN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i3.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i2 (.D(PD_out_2), .SP(nPCLK), .CK(Clk), .Q(PDIN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i2.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i1 (.D(PD_out_1), .SP(nPCLK), .CK(Clk), .Q(PDIN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i1.GSR = "DISABLED";
    FD1P3AX W62_i1 (.D(W62[0]), .SP(PCLK_c), .CK(Clk), .Q(W62[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam W62_i1.GSR = "DISABLED";
    FD1P3AX EEVR_i1 (.D(EEVR[0]), .SP(PCLK_c), .CK(Clk), .Q(EEVR[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam EEVR_i1.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i7 (.D(PDIN[7]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i7.GSR = "DISABLED";
    LUT4 mux_196_i3_4_lut (.A(FVO[2]), .B(VINV_LATCH), .C(PAR_O), .D(OVOUT[2]), 
         .Z(TP_11__N_880[2])) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1151[20:53])
    defparam mux_196_i3_4_lut.init = 16'h3aca;
    LUT4 i10486_2_lut (.A(Z_TV[0]), .B(Z_TV[1]), .Z(ZTV_N_928)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1082[14:36])
    defparam i10486_2_lut.init = 16'h1111;
    FD1P3AX PDOUT_i0_i6 (.D(PDIN[6]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i6.GSR = "DISABLED";
    LUT4 i4602_2_lut_3_lut (.A(PCLK_c), .B(\Hn[2] ), .C(BLNK), .Z(n5071)) /* synthesis lut_function=(!(((C)+!B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam i4602_2_lut_3_lut.init = 16'h0808;
    FD1P3AX PDOUT_i0_i5 (.D(PDIN[5]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i5.GSR = "DISABLED";
    LUT4 n11358_bdd_4_lut (.A(n11358), .B(\Hn[1] ), .C(DBIN[3]), .D(n2748), 
         .Z(PAMUX[3])) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11358_bdd_4_lut.init = 16'haad8;
    FD1P3AX PDOUT_i0_i4 (.D(PDIN[4]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i4.GSR = "DISABLED";
    LUT4 n2750_bdd_4_lut_10796 (.A(n2750), .B(TVO[2]), .C(THO[3]), .D(n2748), 
         .Z(n11358)) /* synthesis lut_function=(A (C+!(D))+!A (B (D))) */ ;
    defparam n2750_bdd_4_lut_10796.init = 16'he4aa;
    FD1P3AX PDOUT_i0_i3 (.D(PDIN[3]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i3.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i2 (.D(PDIN[2]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i2.GSR = "DISABLED";
    FD1P3AX W62_FF_245 (.D(W62_FF_N_912), .SP(Clk_enable_42), .CK(Clk), 
            .Q(W62_FF));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam W62_FF_245.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i1 (.D(PDIN[1]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i1.GSR = "DISABLED";
    LUT4 TVLOAD_I_259_3_lut (.A(SCCNTR), .B(W62[1]), .C(RESCL), .Z(TVLOAD_N_921)) /* synthesis lut_function=(A (B+(C))+!A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1079[21:50])
    defparam TVLOAD_I_259_3_lut.init = 16'hecec;
    LUT4 mux_196_i2_4_lut (.A(FVO[1]), .B(VINV_LATCH), .C(PAR_O), .D(OVOUT[1]), 
         .Z(TP_11__N_880[1])) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1151[20:53])
    defparam mux_196_i2_4_lut.init = 16'h3aca;
    FD1P3IX TH__i0 (.D(TH_4__N_795), .SP(Clk_enable_44), .CD(RC), .CK(Clk), 
            .Q(TH[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TH__i0.GSR = "DISABLED";
    LUT4 i1_2_lut_adj_382 (.A(NTHDO), .B(NTVDO), .Z(n10692)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1087[17:40])
    defparam i1_2_lut_adj_382.init = 16'h8888;
    FD1P3AX OBOUT_i0_i7 (.D(OB[7]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i7.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i6 (.D(OB[6]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i6.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i5 (.D(OB[5]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i5.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i4 (.D(OB[4]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i4.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i3 (.D(OB[3]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i3.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i2 (.D(OB[2]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i2.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i1 (.D(OB[1]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i1.GSR = "DISABLED";
    LUT4 i2_3_lut_adj_383 (.A(n4057), .B(TVO1), .C(BLNK), .Z(TVZB)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1092[15:74])
    defparam i2_3_lut_adj_383.init = 16'h8080;
    LUT4 i4_4_lut (.A(THO[2]), .B(THO[0]), .C(THO[4]), .D(n6_adj_1561), 
         .Z(THZ_N_934)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1089[15:58])
    defparam i4_4_lut.init = 16'h8000;
    LUT4 THZ_I_0_2_lut_3_lut (.A(THZ_N_934), .B(BLNK), .C(TVZB), .Z(NTH_IN)) /* synthesis lut_function=(A ((C)+!B)+!A (C)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1089[15:66])
    defparam THZ_I_0_2_lut_3_lut.init = 16'hf2f2;
    FD1P3AX OVR_i0_i3 (.D(OV[3]), .SP(nPCLK), .CK(Clk), .Q(OVR[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVR_i0_i3.GSR = "DISABLED";
    FD1P3AX OVR_i0_i2 (.D(OV[2]), .SP(nPCLK), .CK(Clk), .Q(OVR[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVR_i0_i2.GSR = "DISABLED";
    FD1P3AX OVR_i0_i1 (.D(OV[1]), .SP(nPCLK), .CK(Clk), .Q(OVR[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVR_i0_i1.GSR = "DISABLED";
    LUT4 i1_2_lut_adj_384 (.A(THO[1]), .B(THO[3]), .Z(n6_adj_1561)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1089[15:58])
    defparam i1_2_lut_adj_384.init = 16'h8888;
    FD1P3AX PAD_i0_i12 (.D(PAMUX[12]), .SP(PCLK_c), .CK(Clk), .Q(PA12_c_12)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i12.GSR = "DISABLED";
    FD1P3AX PAD_i0_i11 (.D(PAMUX[11]), .SP(PCLK_c), .CK(Clk), .Q(PA11_c_11)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i11.GSR = "DISABLED";
    FD1P3AX PAD_i0_i10 (.D(PAMUX[10]), .SP(PCLK_c), .CK(Clk), .Q(PA10_c_10)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i10.GSR = "DISABLED";
    FD1P3AX PAD_i0_i9 (.D(PAMUX[9]), .SP(PCLK_c), .CK(Clk), .Q(PA9_c_9)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i9.GSR = "DISABLED";
    FD1P3AX PAD_i0_i8 (.D(PAMUX[8]), .SP(PCLK_c), .CK(Clk), .Q(PA8_c_8)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i8.GSR = "DISABLED";
    LUT4 PCLK_I_0_2_lut (.A(PCLK_c), .B(SH2), .Z(VINV_LATCH_N_896)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1131[12:22])
    defparam PCLK_I_0_2_lut.init = 16'h8888;
    OFS1P3DX PAD_i0_i7 (.D(PAMUX[7]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i7.GSR = "DISABLED";
    OFS1P3DX PAD_i0_i6 (.D(PAMUX[6]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i6.GSR = "DISABLED";
    OFS1P3DX PAD_i0_i5 (.D(PAMUX[5]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i5.GSR = "DISABLED";
    OFS1P3DX PAD_i0_i4 (.D(PAMUX[4]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i4.GSR = "DISABLED";
    OFS1P3DX PAD_i0_i3 (.D(PAMUX[3]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i3.GSR = "DISABLED";
    OFS1P3DX PAD_i0_i2 (.D(PAMUX[2]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i2.GSR = "DISABLED";
    LUT4 i10536_3_lut_4_lut (.A(E_EV), .B(TSTEP), .C(TVLOAD_N_921), .D(PCLK_c), 
         .Z(Clk_enable_67)) /* synthesis lut_function=(!(A (D)+!A (B (D)+!B ((D)+!C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1081[21:39])
    defparam i10536_3_lut_4_lut.init = 16'h00fe;
    LUT4 Z_TV_1__I_246_2_lut_3_lut (.A(E_EV), .B(TSTEP), .C(PCLK_c), .Z(Z_TV_1__N_886)) /* synthesis lut_function=(A (C)+!A ((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1081[21:39])
    defparam Z_TV_1__I_246_2_lut_3_lut.init = 16'hf1f1;
    FD1P3AX OVOUT_i0_i0 (.D(OVR[0]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OVOUT[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVOUT_i0_i0.GSR = "DISABLED";
    LUT4 i4_4_lut_adj_385 (.A(TV_IN), .B(TVO[2]), .C(TVO[4]), .D(n6), 
         .Z(n4057)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1091[15:74])
    defparam i4_4_lut_adj_385.init = 16'h8000;
    LUT4 i2440_3_lut_4_lut (.A(TVLOAD_N_921), .B(PCLK_c), .C(FV[1]), .D(CNT1), 
         .Z(n2886)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i2440_3_lut_4_lut.init = 16'hfd20;
    LUT4 i2436_3_lut_4_lut (.A(TVLOAD_N_921), .B(PCLK_c), .C(FV[0]), .D(CNT1_adj_1562), 
         .Z(n2882)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i2436_3_lut_4_lut.init = 16'hfd20;
    LUT4 i2474_3_lut_4_lut (.A(TVLOAD_N_921), .B(PCLK_c), .C(TV[4]), .D(CNT1_adj_1563), 
         .Z(n2921)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i2474_3_lut_4_lut.init = 16'hfd20;
    LUT4 i2467_3_lut_4_lut (.A(TVLOAD_N_921), .B(PCLK_c), .C(TV[3]), .D(CNT1_adj_1564), 
         .Z(n2914)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i2467_3_lut_4_lut.init = 16'hfd20;
    LUT4 i2465_3_lut_4_lut (.A(TVLOAD_N_921), .B(PCLK_c), .C(TV[2]), .D(CNT1_adj_1565), 
         .Z(n2912)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i2465_3_lut_4_lut.init = 16'hfd20;
    LUT4 i2461_3_lut_4_lut (.A(TVLOAD_N_921), .B(PCLK_c), .C(TV[1]), .D(CNT1_adj_1566), 
         .Z(n2908)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i2461_3_lut_4_lut.init = 16'hfd20;
    LUT4 i2459_3_lut_4_lut (.A(TVLOAD_N_921), .B(PCLK_c), .C(TV[0]), .D(CNT1_adj_1567), 
         .Z(n2906)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i2459_3_lut_4_lut.init = 16'hfd20;
    LUT4 i2448_3_lut_4_lut (.A(TVLOAD_N_921), .B(PCLK_c), .C(NTV), .D(CNT1_adj_1568), 
         .Z(n2894)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i2448_3_lut_4_lut.init = 16'hfd20;
    LUT4 i2444_3_lut_4_lut (.A(TVLOAD_N_921), .B(PCLK_c), .C(FV[2]), .D(CNT1_adj_1569), 
         .Z(n2890)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i2444_3_lut_4_lut.init = 16'hfd20;
    LUT4 i2301_3_lut (.A(DB_PAR_N_593), .B(PARR), .C(F_AT), .Z(n2750)) /* synthesis lut_function=(!(A+!(B+!(C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(885[8:14])
    defparam i2301_3_lut.init = 16'h4545;
    LUT4 i10645_2_lut (.A(PCLK_c), .B(W62[1]), .Z(W62_FF_N_912)) /* synthesis lut_function=(A+!(B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam i10645_2_lut.init = 16'hbbbb;
    LUT4 Hn2_I_0_2_lut (.A(\Hn[2] ), .B(BLNK), .Z(PARR)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1109[16:27])
    defparam Hn2_I_0_2_lut.init = 16'h2222;
    LUT4 TH_4__I_226_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[0]), .D(DBIN[3]), 
         .Z(TH_4__N_795)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1116[50:85])
    defparam TH_4__I_226_4_lut.init = 16'heca0;
    FD1P3IX PAD_i0_i13 (.D(NBFVO1), .SP(PCLK_c), .CD(n5071), .CK(Clk), 
            .Q(PA13_c_13)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i13.GSR = "DISABLED";
    FD1P3IX TV_i1 (.D(TV_4__N_819), .SP(Clk_enable_229), .CD(RC), .CK(Clk), 
            .Q(TV[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TV_i1.GSR = "DISABLED";
    FD1P3IX TV_i2 (.D(TV_4__N_812), .SP(Clk_enable_229), .CD(RC), .CK(Clk), 
            .Q(TV[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TV_i2.GSR = "DISABLED";
    FD1P3IX TV_i3 (.D(TV_4__N_807), .SP(Clk_enable_233), .CD(RC), .CK(Clk), 
            .Q(TV[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TV_i3.GSR = "DISABLED";
    FD1P3IX TV_i4 (.D(TV_4__N_800), .SP(Clk_enable_233), .CD(RC), .CK(Clk), 
            .Q(TV[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TV_i4.GSR = "DISABLED";
    LUT4 i1_2_lut_adj_386 (.A(TVZB), .B(BLNK), .Z(n4)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1086[25:40])
    defparam i1_2_lut_adj_386.init = 16'h8888;
    FD1P3IX NTH_237 (.D(NTH_N_899), .SP(Clk_enable_217), .CD(RC), .CK(Clk), 
            .Q(NTH));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam NTH_237.GSR = "DISABLED";
    FD1P3IX NTV_238 (.D(NTV_N_906), .SP(Clk_enable_217), .CD(RC), .CK(Clk), 
            .Q(NTV));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam NTV_238.GSR = "DISABLED";
    FD1P3AX OVOUT_i0_i1 (.D(OVR[1]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OVOUT[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVOUT_i0_i1.GSR = "DISABLED";
    FD1P3AX OVOUT_i0_i2 (.D(OVR[2]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OVOUT[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVOUT_i0_i2.GSR = "DISABLED";
    FD1P3AX OVOUT_i0_i3 (.D(OVR[3]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OVOUT[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVOUT_i0_i3.GSR = "DISABLED";
    LUT4 n11334_bdd_4_lut (.A(n11334), .B(TP[6]), .C(DBIN[7]), .D(n2748), 
         .Z(PAMUX[7])) /* synthesis lut_function=(A (B+(D))+!A !((D)+!C)) */ ;
    defparam n11334_bdd_4_lut.init = 16'haad8;
    LUT4 n2750_bdd_4_lut_10771_4_lut (.A(n2750), .B(TVO[2]), .C(DB_PAR_N_593), 
         .D(PARR), .Z(n11334)) /* synthesis lut_function=(A (B+(C+(D)))+!A !(C+(D))) */ ;
    defparam n2750_bdd_4_lut_10771_4_lut.init = 16'haaad;
    FD1P3IX W62_i0 (.D(W62_FF), .SP(nPCLK), .CD(n4999), .CK(Clk), .Q(W62[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam W62_i0.GSR = "DISABLED";
    FD1P3IX TV_i0 (.D(TV_4__N_824), .SP(Clk_enable_229), .CD(RC), .CK(Clk), 
            .Q(TV[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TV_i0.GSR = "DISABLED";
    FD1P3IX FV__i1 (.D(FV_2__N_832), .SP(Clk_enable_233), .CD(RC), .CK(Clk), 
            .Q(FV[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam FV__i1.GSR = "DISABLED";
    FD1P3IX FV__i2 (.D(FV_2__N_829), .SP(Clk_enable_233), .CD(RC), .CK(Clk), 
            .Q(FV[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam FV__i2.GSR = "DISABLED";
    FD1P3IX FV__i0 (.D(FV_2__N_837), .SP(Clk_enable_233), .CD(RC), .CK(Clk), 
            .Q(FV[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam FV__i0.GSR = "DISABLED";
    LUT4 i1_4_lut (.A(THZ_N_934), .B(n5), .C(BLNK), .D(FVO[1]), .Z(n4074)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1132[16:45])
    defparam i1_4_lut.init = 16'haca0;
    LUT4 i1_2_lut_adj_387 (.A(FVO[2]), .B(FVO[0]), .Z(n5)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1093[15:47])
    defparam i1_2_lut_adj_387.init = 16'h8888;
    LUT4 i10550_2_lut (.A(PCLK_c), .B(TAL_LATCH), .Z(OVOUT_3__N_868)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1133[12:33])
    defparam i10550_2_lut.init = 16'h2222;
    LUT4 I1_32_I_0_2_lut (.A(I1_32), .B(BLNK), .Z(TV_IN_N_915)) /* synthesis lut_function=(A (B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1084[17:33])
    defparam I1_32_I_0_2_lut.init = 16'h8888;
    LUT4 i2299_2_lut_4_lut (.A(\W7Q[3] ), .B(\W7Q[1] ), .C(\Hn[2] ), .D(BLNK), 
         .Z(n2748)) /* synthesis lut_function=(A ((D)+!C)+!A (B ((D)+!C))) */ ;
    defparam i2299_2_lut_4_lut.init = 16'hee0e;
    LUT4 mux_196_i1_4_lut (.A(FVO[0]), .B(VINV_LATCH), .C(PAR_O), .D(OVOUT[0]), 
         .Z(TP_11__N_880[0])) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1151[20:53])
    defparam mux_196_i1_4_lut.init = 16'h3aca;
    COUNTER_U63 TVCNT_4 (.CNT1(CNT1_adj_1563), .Clk(Clk), .PCLK_c(PCLK_c), 
            .CNT1_N_565(CNT1_N_565), .\TVO[4] (TVO[4]), .Clk_enable_67(Clk_enable_67), 
            .ZTV_N_928(ZTV_N_928), .n2921(n2921)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1100[9:115])
    COUNTER_U64 TVCNT_3 (.CNT1(CNT1_adj_1564), .Clk(Clk), .PCLK_c(PCLK_c), 
            .CNT1_N_565(CNT1_N_565_adj_1570), .\TVO[3] (TVO[3]), .Clk_enable_67(Clk_enable_67), 
            .ZTV_N_928(ZTV_N_928), .n2914(n2914)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1100[9:115])
    COUNTER_U65 TVCNT_2 (.\TVO[2] (TVO[2]), .C_OUT_N_563(C_OUT_N_563), .\TVO[3] (TVO[3]), 
            .\TVO[4] (TVO[4]), .CNT1_N_565(CNT1_N_565), .CNT1_N_565_adj_2(CNT1_N_565_adj_1570), 
            .CNT1(CNT1_adj_1565), .Clk(Clk), .PCLK_c(PCLK_c), .Clk_enable_67(Clk_enable_67), 
            .ZTV_N_928(ZTV_N_928), .n2912(n2912)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1100[9:115])
    COUNTER_U66 TVCNT_1 (.CNT1(CNT1_adj_1566), .Clk(Clk), .PCLK_c(PCLK_c), 
            .CNT1_N_565(CNT1_N_565_adj_1571), .TVO1(TVO1), .Clk_enable_67(Clk_enable_67), 
            .ZTV_N_928(ZTV_N_928), .n2908(n2908)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1100[9:115])
    COUNTER_U67 TVCNT_0 (.\TVO[0] (TVO[0]), .TV_IN(TV_IN), .TVO1(TVO1), 
            .C_OUT_N_563(C_OUT_N_563), .CNT1_N_565(CNT1_N_565_adj_1571), 
            .CNT1(CNT1_adj_1567), .Clk(Clk), .PCLK_c(PCLK_c), .Clk_enable_67(Clk_enable_67), 
            .ZTV_N_928(ZTV_N_928), .n2906(n2906)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1100[9:115])
    COUNTER_U68 THCNT_4 (.Clk(Clk), .PCLK_c(PCLK_c), .CNT1_N_565(CNT1_N_565_adj_1572), 
            .\THO[4] (THO[4]), .Clk_enable_68(Clk_enable_68), .\TH[4] (TH[4]), 
            .THLOAD_N_916(THLOAD_N_916)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1099[9:115])
    COUNTER_U69 THCNT_3 (.\TH[3] (TH[3]), .THLOAD_N_916(THLOAD_N_916), .Clk(Clk), 
            .PCLK_c(PCLK_c), .CNT1_N_565(CNT1_N_565_adj_1573), .\THO[3] (THO[3]), 
            .Clk_enable_68(Clk_enable_68)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1099[9:115])
    COUNTER_U70 THCNT_2 (.\THO[2] (THO[2]), .C_OUT_N_563(C_OUT_N_563_adj_1574), 
            .Clk(Clk), .PCLK_c(PCLK_c), .Clk_enable_68(Clk_enable_68), 
            .\TH[2] (TH[2]), .THLOAD_N_916(THLOAD_N_916), .\THO[3] (THO[3]), 
            .\THO[4] (THO[4]), .CNT1_N_565(CNT1_N_565_adj_1572), .CNT1_N_565_adj_1(CNT1_N_565_adj_1573)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1099[9:115])
    COUNTER_U71 THCNT_1 (.PCLK_c(PCLK_c), .\W62[1] (W62[1]), .\EEVR[1] (EEVR[1]), 
            .THSTEP_N_925(THSTEP_N_925), .Clk_enable_68(Clk_enable_68), 
            .\TH[1] (TH[1]), .THLOAD_N_916(THLOAD_N_916), .\THO[1] (THO[1]), 
            .Clk(Clk), .CNT1_N_565(CNT1_N_565_adj_1575)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1099[9:115])
    COUNTER_U72 THCNT_0 (.\THO[0] (THO[0]), .I1_32(I1_32), .BLNK(BLNK), 
            .Clk(Clk), .PCLK_c(PCLK_c), .\THO[1] (THO[1]), .CNT1_N_565(CNT1_N_565_adj_1575), 
            .C_OUT_N_563(C_OUT_N_563_adj_1574), .Clk_enable_68(Clk_enable_68), 
            .\TH[0] (TH[0]), .THLOAD_N_916(THLOAD_N_916)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1099[9:115])
    COUNTER_U73 NTVCNT (.CNT1(CNT1_adj_1568), .Clk(Clk), .PCLK_c(PCLK_c), 
            .NTVDO(NTVDO), .Clk_enable_67(Clk_enable_67), .n2894(n2894), 
            .TVZ(TVZ), .NTHDO(NTHDO), .n4(n4)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1102[9:107])
    COUNTER_U74 NTHCNT (.NTHDO(NTHDO), .THZ_N_934(THZ_N_934), .BLNK(BLNK), 
            .TVZB(TVZB), .Clk(Clk), .PCLK_c(PCLK_c), .Clk_enable_68(Clk_enable_68), 
            .NTH(NTH), .THLOAD_N_916(THLOAD_N_916)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1101[9:107])
    COUNTER_U75 FVCNT_2 (.CNT1(CNT1_adj_1569), .Clk(Clk), .PCLK_c(PCLK_c), 
            .\FVO[2] (FVO[2]), .Clk_enable_67(Clk_enable_67), .n2890(n2890), 
            .\FVO[1] (FVO[1]), .C_OUT_N_563(C_OUT_N_563_adj_1576)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1103[9:115])
    COUNTER_U76 FVCNT_1 (.\FVO[1] (FVO[1]), .Clk(Clk), .Clk_enable_67(Clk_enable_67), 
            .n2886(n2886), .C_OUT_N_563(C_OUT_N_563_adj_1576), .CNT1(CNT1), 
            .PCLK_c(PCLK_c)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1103[9:115])
    COUNTER_U77 FVCNT_0 (.CNT1(CNT1_adj_1562), .Clk(Clk), .PCLK_c(PCLK_c), 
            .\FVO[0] (FVO[0]), .BLNK(BLNK), .NTH_IN(NTH_IN), .n10692(n10692), 
            .C_OUT_N_563(C_OUT_N_563_adj_1576), .Clk_enable_67(Clk_enable_67), 
            .n2882(n2882), .TVZB(TVZB)) /* synthesis syn_module_defined=1 */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1103[9:115])
    
endmodule
//
// Verilog Description of module COUNTER_U63
//

module COUNTER_U63 (CNT1, Clk, PCLK_c, CNT1_N_565, \TVO[4] , Clk_enable_67, 
            ZTV_N_928, n2921) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input PCLK_c;
    input CNT1_N_565;
    output \TVO[4] ;
    input Clk_enable_67;
    input ZTV_N_928;
    input n2921;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(n2921), .SP(Clk_enable_67), .CK(Clk), .CD(ZTV_N_928), 
            .Q(\TVO[4] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U64
//

module COUNTER_U64 (CNT1, Clk, PCLK_c, CNT1_N_565, \TVO[3] , Clk_enable_67, 
            ZTV_N_928, n2914) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input PCLK_c;
    input CNT1_N_565;
    output \TVO[3] ;
    input Clk_enable_67;
    input ZTV_N_928;
    input n2914;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(n2914), .SP(Clk_enable_67), .CK(Clk), .CD(ZTV_N_928), 
            .Q(\TVO[3] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U65
//

module COUNTER_U65 (\TVO[2] , C_OUT_N_563, \TVO[3] , \TVO[4] , CNT1_N_565, 
            CNT1_N_565_adj_2, CNT1, Clk, PCLK_c, Clk_enable_67, ZTV_N_928, 
            n2912) /* synthesis syn_module_defined=1 */ ;
    output \TVO[2] ;
    input C_OUT_N_563;
    input \TVO[3] ;
    input \TVO[4] ;
    output CNT1_N_565;
    output CNT1_N_565_adj_2;
    output CNT1;
    input Clk;
    input PCLK_c;
    input Clk_enable_67;
    input ZTV_N_928;
    input n2912;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_adj_1560;
    
    LUT4 CNT_I_0_3_lut_4_lut (.A(\TVO[2] ), .B(C_OUT_N_563), .C(\TVO[3] ), 
         .D(\TVO[4] ), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_3_lut_4_lut.init = 16'h7f80;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\TVO[2] ), .B(C_OUT_N_563), .C(\TVO[3] ), 
         .Z(CNT1_N_565_adj_2)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    LUT4 CNT_I_0_2_lut (.A(\TVO[2] ), .B(C_OUT_N_563), .Z(CNT1_N_565_adj_1560)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1560), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(n2912), .SP(Clk_enable_67), .CK(Clk), .CD(ZTV_N_928), 
            .Q(\TVO[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U66
//

module COUNTER_U66 (CNT1, Clk, PCLK_c, CNT1_N_565, TVO1, Clk_enable_67, 
            ZTV_N_928, n2908) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input PCLK_c;
    input CNT1_N_565;
    output TVO1;
    input Clk_enable_67;
    input ZTV_N_928;
    input n2908;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(n2908), .SP(Clk_enable_67), .CK(Clk), .CD(ZTV_N_928), 
            .Q(TVO1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U67
//

module COUNTER_U67 (\TVO[0] , TV_IN, TVO1, C_OUT_N_563, CNT1_N_565, 
            CNT1, Clk, PCLK_c, Clk_enable_67, ZTV_N_928, n2906) /* synthesis syn_module_defined=1 */ ;
    output \TVO[0] ;
    input TV_IN;
    input TVO1;
    output C_OUT_N_563;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input PCLK_c;
    input Clk_enable_67;
    input ZTV_N_928;
    input n2906;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_adj_1558;
    
    LUT4 CNT_I_0_19_2_lut_3_lut (.A(\TVO[0] ), .B(TV_IN), .C(TVO1), .Z(C_OUT_N_563)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_3_lut.init = 16'h8080;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\TVO[0] ), .B(TV_IN), .C(TVO1), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1558), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(n2906), .SP(Clk_enable_67), .CK(Clk), .CD(ZTV_N_928), 
            .Q(\TVO[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut (.A(\TVO[0] ), .B(TV_IN), .Z(CNT1_N_565_adj_1558)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    
endmodule
//
// Verilog Description of module COUNTER_U68
//

module COUNTER_U68 (Clk, PCLK_c, CNT1_N_565, \THO[4] , Clk_enable_68, 
            \TH[4] , THLOAD_N_916) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input PCLK_c;
    input CNT1_N_565;
    output \THO[4] ;
    input Clk_enable_68;
    input \TH[4] ;
    input THLOAD_N_916;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, n2896;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2896), .SP(Clk_enable_68), .CK(Clk), .Q(\THO[4] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i2450_3_lut (.A(CNT1), .B(\TH[4] ), .C(THLOAD_N_916), .Z(n2896)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i2450_3_lut.init = 16'hacac;
    
endmodule
//
// Verilog Description of module COUNTER_U69
//

module COUNTER_U69 (\TH[3] , THLOAD_N_916, Clk, PCLK_c, CNT1_N_565, 
            \THO[3] , Clk_enable_68) /* synthesis syn_module_defined=1 */ ;
    input \TH[3] ;
    input THLOAD_N_916;
    input Clk;
    input PCLK_c;
    input CNT1_N_565;
    output \THO[3] ;
    input Clk_enable_68;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, n2892;
    
    LUT4 i2446_3_lut (.A(CNT1), .B(\TH[3] ), .C(THLOAD_N_916), .Z(n2892)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i2446_3_lut.init = 16'hacac;
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2892), .SP(Clk_enable_68), .CK(Clk), .Q(\THO[3] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U70
//

module COUNTER_U70 (\THO[2] , C_OUT_N_563, Clk, PCLK_c, Clk_enable_68, 
            \TH[2] , THLOAD_N_916, \THO[3] , \THO[4] , CNT1_N_565, 
            CNT1_N_565_adj_1) /* synthesis syn_module_defined=1 */ ;
    output \THO[2] ;
    input C_OUT_N_563;
    input Clk;
    input PCLK_c;
    input Clk_enable_68;
    input \TH[2] ;
    input THLOAD_N_916;
    input \THO[3] ;
    input \THO[4] ;
    output CNT1_N_565;
    output CNT1_N_565_adj_1;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c, CNT1, n2888;
    
    LUT4 CNT_I_0_2_lut (.A(\THO[2] ), .B(C_OUT_N_563), .Z(CNT1_N_565_c)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2888), .SP(Clk_enable_68), .CK(Clk), .Q(\THO[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i2442_3_lut (.A(CNT1), .B(\TH[2] ), .C(THLOAD_N_916), .Z(n2888)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i2442_3_lut.init = 16'hacac;
    LUT4 CNT_I_0_3_lut_4_lut (.A(\THO[2] ), .B(C_OUT_N_563), .C(\THO[3] ), 
         .D(\THO[4] ), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_3_lut_4_lut.init = 16'h7f80;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\THO[2] ), .B(C_OUT_N_563), .C(\THO[3] ), 
         .Z(CNT1_N_565_adj_1)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    
endmodule
//
// Verilog Description of module COUNTER_U71
//

module COUNTER_U71 (PCLK_c, \W62[1] , \EEVR[1] , THSTEP_N_925, Clk_enable_68, 
            \TH[1] , THLOAD_N_916, \THO[1] , Clk, CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    input PCLK_c;
    input \W62[1] ;
    input \EEVR[1] ;
    input THSTEP_N_925;
    output Clk_enable_68;
    input \TH[1] ;
    input THLOAD_N_916;
    output \THO[1] ;
    input Clk;
    input CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, n2979;
    
    LUT4 i10648_4_lut (.A(PCLK_c), .B(\W62[1] ), .C(\EEVR[1] ), .D(THSTEP_N_925), 
         .Z(Clk_enable_68)) /* synthesis lut_function=(!(A+!(B+(C+(D))))) */ ;
    defparam i10648_4_lut.init = 16'h5554;
    LUT4 i2532_3_lut (.A(CNT1), .B(\TH[1] ), .C(THLOAD_N_916), .Z(n2979)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i2532_3_lut.init = 16'hacac;
    FD1P3AX CNT_14 (.D(n2979), .SP(Clk_enable_68), .CK(Clk), .Q(\THO[1] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U72
//

module COUNTER_U72 (\THO[0] , I1_32, BLNK, Clk, PCLK_c, \THO[1] , 
            CNT1_N_565, C_OUT_N_563, Clk_enable_68, \TH[0] , THLOAD_N_916) /* synthesis syn_module_defined=1 */ ;
    output \THO[0] ;
    input I1_32;
    input BLNK;
    input Clk;
    input PCLK_c;
    input \THO[1] ;
    output CNT1_N_565;
    output C_OUT_N_563;
    input Clk_enable_68;
    input \TH[0] ;
    input THLOAD_N_916;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c, CNT1, n2977;
    
    LUT4 i1_2_lut_3_lut (.A(\THO[0] ), .B(I1_32), .C(BLNK), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B (C))+!A !(B (C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'h9595;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\THO[0] ), .B(I1_32), .C(BLNK), 
         .D(\THO[1] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (B (C (D)+!C !(D))+!B !(D))+!A (D)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'hd52a;
    LUT4 CNT_I_0_19_2_lut_3_lut_4_lut (.A(\THO[0] ), .B(I1_32), .C(BLNK), 
         .D(\THO[1] ), .Z(C_OUT_N_563)) /* synthesis lut_function=(!((B (C+!(D))+!B !(D))+!A)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_3_lut_4_lut.init = 16'h2a00;
    FD1P3AX CNT_14 (.D(n2977), .SP(Clk_enable_68), .CK(Clk), .Q(\THO[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i2530_3_lut (.A(CNT1), .B(\TH[0] ), .C(THLOAD_N_916), .Z(n2977)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i2530_3_lut.init = 16'hacac;
    
endmodule
//
// Verilog Description of module COUNTER_U73
//

module COUNTER_U73 (CNT1, Clk, PCLK_c, NTVDO, Clk_enable_67, n2894, 
            TVZ, NTHDO, n4) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input PCLK_c;
    output NTVDO;
    input Clk_enable_67;
    input n2894;
    input TVZ;
    input NTHDO;
    input n4;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2894), .SP(Clk_enable_67), .CK(Clk), .Q(NTVDO));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_4_lut (.A(NTVDO), .B(TVZ), .C(NTHDO), .D(n4), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B+(C (D)))+!A !(B+(C (D))))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_4_lut.init = 16'h5666;
    
endmodule
//
// Verilog Description of module COUNTER_U74
//

module COUNTER_U74 (NTHDO, THZ_N_934, BLNK, TVZB, Clk, PCLK_c, Clk_enable_68, 
            NTH, THLOAD_N_916) /* synthesis syn_module_defined=1 */ ;
    output NTHDO;
    input THZ_N_934;
    input BLNK;
    input TVZB;
    input Clk;
    input PCLK_c;
    input Clk_enable_68;
    input NTH;
    input THLOAD_N_916;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565, CNT1, n2900;
    
    LUT4 CNT_I_0_2_lut_4_lut (.A(NTHDO), .B(THZ_N_934), .C(BLNK), .D(TVZB), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B ((D)+!C)+!B (D))+!A !(B ((D)+!C)+!B (D)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut_4_lut.init = 16'h55a6;
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2900), .SP(Clk_enable_68), .CK(Clk), .Q(NTHDO));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i2453_3_lut (.A(CNT1), .B(NTH), .C(THLOAD_N_916), .Z(n2900)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i2453_3_lut.init = 16'hacac;
    
endmodule
//
// Verilog Description of module COUNTER_U75
//

module COUNTER_U75 (CNT1, Clk, PCLK_c, \FVO[2] , Clk_enable_67, n2890, 
            \FVO[1] , C_OUT_N_563) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input PCLK_c;
    output \FVO[2] ;
    input Clk_enable_67;
    input n2890;
    input \FVO[1] ;
    input C_OUT_N_563;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3AX CNT_14 (.D(n2890), .SP(Clk_enable_67), .CK(Clk), .Q(\FVO[2] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_3_lut (.A(\FVO[2] ), .B(\FVO[1] ), .C(C_OUT_N_563), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C))+!A !(B (C)))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_3_lut.init = 16'h6a6a;
    
endmodule
//
// Verilog Description of module COUNTER_U76
//

module COUNTER_U76 (\FVO[1] , Clk, Clk_enable_67, n2886, C_OUT_N_563, 
            CNT1, PCLK_c) /* synthesis syn_module_defined=1 */ ;
    output \FVO[1] ;
    input Clk;
    input Clk_enable_67;
    input n2886;
    input C_OUT_N_563;
    output CNT1;
    input PCLK_c;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565;
    
    FD1P3AX CNT_14 (.D(n2886), .SP(Clk_enable_67), .CK(Clk), .Q(\FVO[1] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut (.A(\FVO[1] ), .B(C_OUT_N_563), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U77
//

module COUNTER_U77 (CNT1, Clk, PCLK_c, \FVO[0] , BLNK, NTH_IN, n10692, 
            C_OUT_N_563, Clk_enable_67, n2882, TVZB) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input PCLK_c;
    output \FVO[0] ;
    input BLNK;
    input NTH_IN;
    input n10692;
    output C_OUT_N_563;
    input Clk_enable_67;
    input n2882;
    input TVZB;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1_4_lut (.A(\FVO[0] ), .B(BLNK), .C(NTH_IN), .D(n10692), .Z(C_OUT_N_563)) /* synthesis lut_function=(A ((C (D))+!B)) */ ;   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam i1_4_lut.init = 16'ha222;
    FD1P3AX CNT_14 (.D(n2882), .SP(Clk_enable_67), .CK(Clk), .Q(\FVO[0] ));   // d:/radiosoft/video game/dendy/src/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 FVO_0__bdd_4_lut (.A(\FVO[0] ), .B(BLNK), .C(TVZB), .D(n10692), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(!(A ((C (D))+!B)+!A !((C (D))+!B))) */ ;
    defparam FVO_0__bdd_4_lut.init = 16'h5999;
    
endmodule
