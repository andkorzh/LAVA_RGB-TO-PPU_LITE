// Verilog netlist produced by program LSE :  version Diamond Version 3.5.0.102
// Netlist written on Sat Sep 19 15:17:45 2026
//
// Verilog Description of module RP2C02_LITE_LAVA
//

module RP2C02_LITE_LAVA (MCLK, MODE, DENDY, nRES, P_BUTTON, RnW, 
            nDBE, A, PD, DB, RGB, PA8, PA9, PA10, PA11, PA12, 
            PA13, INT, ALE, nWR, nRD, SYNC, PCLK, SUBCLK, DB_nOE, 
            DB_DIR, PD_DIR, PD_nOE) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(35[8:24])
    input MCLK;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(36[7:11])
    input MODE;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(38[7:11])
    input DENDY;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(39[7:12])
    input nRES;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(40[7:11])
    input P_BUTTON;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(41[7:15])
    input RnW;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(42[7:10])
    input nDBE;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(43[7:11])
    input [2:0]A;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(44[12:13])
    inout [7:0]PD;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(45[12:14])
    inout [7:0]DB;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(47[13:15])
    output [23:0]RGB;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    output PA8;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(49[8:11])
    output PA9;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(50[8:11])
    output PA10;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(51[8:12])
    output PA11;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(52[8:12])
    output PA12;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(53[8:12])
    output PA13;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(54[8:12])
    output INT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(55[8:11])
    output ALE;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(56[8:11])
    output nWR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(57[8:11])
    output nRD;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(58[8:11])
    output SYNC;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(59[8:12])
    output PCLK;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(60[8:12])
    output SUBCLK;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(61[8:14])
    output DB_nOE;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(62[8:14])
    output DB_DIR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(63[8:14])
    output PD_DIR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(64[8:14])
    output PD_nOE;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(65[8:14])
    
    wire MCLK_c /* synthesis is_clock=1, SET_AS_NETWORK=MCLK_c */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(36[7:11])
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire Clk2_N_24 /* synthesis is_inv_clock=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(478[5:10])
    
    wire GND_net, VCC_net, MODE_c, DENDY_c, nRES_c, P_BUTTON_c, 
        RnW_c, DB_nOE_c_c, A_c_2, A_c_1, A_c_0, RGB_c_23, RGB_c_22, 
        RGB_c_21, RGB_c_20, RGB_c_19, RGB_c_18, RGB_c_17, RGB_c_16, 
        RGB_c_15, RGB_c_14, RGB_c_13, RGB_c_12, RGB_c_11, RGB_c_10, 
        RGB_c_9, RGB_c_8, RGB_c_7, RGB_c_6, RGB_c_5, RGB_c_4, RGB_c_3, 
        RGB_c_2, RGB_c_1, RGB_c_0, PA8_c_8, PA9_c_9, PA10_c_10, 
        PA11_c_11, PA12_c_12, PA13_c_13, INT_c, ALE_c, nWR_c, nRD_c, 
        SYNC_c, SUBCLK_c, DB_DIR_c;
    wire [5:0]Hn;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(71[11:13])
    wire [5:0]Hnn;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(72[11:14])
    wire [7:0]DBIN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(73[11:15])
    wire [2:0]EMPH;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(74[11:15])
    wire [7:0]OB;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(75[11:13])
    wire [3:0]OV;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(76[11:13])
    wire [7:0]Vo;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(77[11:13])
    wire [2:0]R2DB;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(79[11:15])
    wire [4:0]THO;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(80[11:14])
    wire [13:0]PAD;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(80[27:30])
    wire [4:0]ZCOL;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(82[11:15])
    wire [4:0]CGA;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(83[11:14])
    wire [2:0]PALSEL;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(84[11:17])
    
    wire W0, W1, R2, W3, W4, R4, W5_1, W5_2, W6_1, W6_2, 
        W7, R7, R_EN, I1_32, OBSEL, BGSEL, O8_16, VBL_EN, B_W, 
        BGCLIP, S_EV, O_HPOS, nEVAL, E_EV, I_OAM2, PAR_O, nVIS, 
        F_NT, VSYNC, SC_CNT, nPICTURE, RC, RESCL, TH_MUX, TVO1, 
        OMFG, PD_FIFO, SPR0_EV, SPR_OV, SH2, P_BUTTON_N_7;
    wire [2:0]DIV;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(479[10:13])
    
    wire nRES_N_15, SUB_1__N_16, DIV_2__N_10, RnWR, nDBER, n8813, 
        Clk_enable_86, CLIPOR, EMP_R, EMP_G, nCLPB_N_130, n38, n12, 
        n8599;
    wire [7:0]PD_R;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(641[10:14])
    wire [7:0]OB_R;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(642[10:14])
    wire [7:0]D;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(645[11:12])
    
    wire n25, n76, n84, n86, n87, n88, n89, n90, n91;
    wire [7:0]Do_7__N_163;
    
    wire HC;
    wire [1:0]ODDEVEN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(706[10:17])
    
    wire CLIP_OUT, FTA_OUT, NFO_OUT, N_HB, RESCL_IN, BLNK_FF;
    wire [2:0]VSET;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(731[10:14])
    wire [8:0]H;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(737[11:12])
    
    wire CLIP_B_N_247, H_8__N_233, Vo_7__N_212, H_LINE5_N_453, H_LINE23_N_478, 
        HC_N_237, XRB_N_606;
    wire [3:0]BGC2;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(952[10:14])
    
    wire CLPB_LATCH, F_AT_LATCH, THO1R;
    wire [7:0]PDAT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(957[10:14])
    
    wire PD_SR, PD_SEL;
    wire [1:0]ATSEL;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(969[11:16])
    
    wire n9866, n9864, n9863, n9984;
    wire [11:0]TP;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1061[11:13])
    
    wire NTV_IN, n9983, TVZ, TVZB;
    wire [4:0]TVO;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1094[11:14])
    
    wire NTVDO;
    wire [2:0]FVO;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1096[11:14])
    
    wire NBFVO1;
    wire [13:0]PAMUX;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1110[12:17])
    
    wire n9981, THSTEP_N_923;
    wire [7:0]PAMUX_7__N_859;
    wire [7:0]PAMUX_7__N_851;
    
    wire n8831, TH_4__N_776, n9826, n5079, TAL_LATCH_N_890, n9980, 
        SPR0_EV1, OVZ, Clk_enable_467, n9975, DB_out_0, SPR0_EV1_N_984;
    wire [4:0]W4Q;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1244[10:13])
    
    wire ORES_LATCH;
    wire [2:0]OSTEP;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1247[10:15])
    
    wire OVF_LATCH, OMFG_LATCH, OMV_LATCH, OAMCTR2, ORES, Clk_enable_543;
    wire [7:0]OAM1ADR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1267[11:18])
    
    wire OAP_N_1091, Clk_enable_518, OAM2STEP_N_1107, OAM2STEP_N_1104, 
        OAMQ_7__N_1041, OB2_7__N_1043, DB_out_1, DB_out_2, DB_out_3, 
        OMSTEP_1__N_1053, DB_out_4, DB_out_5, DB_out_6, DB_out_7, 
        Clk_enable_47, SPR0HIT_LATCH;
    wire [7:0]SEL_LATCH;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1328[10:19])
    
    wire n6362, Clk_enable_247, Clk_enable_173, Clk_enable_571, n8933, 
        SH2_N_1372, SH3_N_1381, SH5_N_1385, SH7_N_1390, PD_out_0, 
        PD_out_1, PD_out_2, PD_out_3, PD_out_4, PD_out_5, PD_out_6, 
        PD_out_7, ATR_IN0_2__N_1360, ATR_IN1_2__N_1362, ATR_IN2_2__N_1363, 
        ATR_IN3_2__N_1364, ATR_IN4_2__N_1365, ATR_IN5_2__N_1366, n12_adj_2159, 
        ATR_IN6_2__N_1367, ATR_IN7_2__N_1368, n4;
    wire [4:0]THO_LATCH;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1512[17:26])
    wire [4:0]STEP3;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1512[28:33])
    
    wire n9944, R2DB6_N_1437, n9942, n9941, Clk_enable_393, n9938, 
        DB_PARR;
    wire [7:0]ri;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1578[11:13])
    
    wire CGAH_N_1535, Clk_enable_528, Clk_enable_560, Clk_enable_563;
    wire [5:0]V_DIV;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1703[10:15])
    
    wire Clk_enable_511, n10442, Clk_enable_78, Clk_enable_162, n5081, 
        n6, n9830, n9828, Clk_enable_84, n9928, n9925, Clk_enable_153, 
        CNT1_N_565, n9923, n6646;
    wire [7:0]CNT1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1681[10:14])
    
    wire CNT_7__N_1140, n3533, n10432, Clk_enable_535, n989, n9911, 
        n9910, n8992, n9907, n4016, n6437, Clk_enable_68, n3985, 
        n9901, n9899, n9118, n9897, n9117, n9115, n9114, Clk_enable_542, 
        n9892, n9754, Clk_enable_150, n9752, n3689, n4_adj_2160, 
        n5118, n2282, n5110, n8475, n9889, Clk_enable_561, Clk_enable_113, 
        n8, n9838, n5086, Clk_enable_160, Clk_enable_157, Clk_enable_562, 
        Clk_enable_267, n9868;
    
    VHI i2 (.Z(VCC_net));
    INV i9310 (.A(MCLK_c), .Z(Clk2_N_24));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(36[7:11])
    PIX_MUX MOD_PIX_MUX (.Clk(Clk), .Clk_enable_571(Clk_enable_571), .R2DB6_N_1437(R2DB6_N_1437), 
            .Clk_enable_563(Clk_enable_563), .ZCOL({ZCOL}), .THO({THO}), 
            .Clk_enable_173(Clk_enable_173), .TH_MUX(TH_MUX), .\CGA[3] (CGA[3]), 
            .\CGA[2] (CGA[2]), .\CGA[1] (CGA[1]), .\STEP3[4] (STEP3[4]), 
            .Clk_enable_560(Clk_enable_560), .\THO_LATCH[4] (THO_LATCH[4]), 
            .BGC2({BGC2}), .CLPB_LATCH(CLPB_LATCH), .\R2DB[1] (R2DB[1]), 
            .n4016(n4016), .n9910(n9910), .CGAH_N_1535(CGAH_N_1535), .n10442(n10442)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(420[9] 434[2])
    OB DB_nOE_pad (.I(DB_nOE_c_c), .O(DB_nOE));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(62[8:14])
    OB SUBCLK_pad (.I(SUBCLK_c), .O(SUBCLK));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(61[8:14])
    OB PCLK_pad (.I(n10442), .O(PCLK));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(60[8:12])
    OB SYNC_pad (.I(SYNC_c), .O(SYNC));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(59[8:12])
    OB nRD_pad (.I(nRD_c), .O(nRD));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(58[8:11])
    OB nWR_pad (.I(nWR_c), .O(nWR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(57[8:11])
    OB ALE_pad (.I(ALE_c), .O(ALE));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(56[8:11])
    OB INT_pad (.I(INT_c), .O(INT));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(55[8:11])
    OB PA13_pad (.I(PA13_c_13), .O(PA13));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(54[8:12])
    OB PA12_pad (.I(PA12_c_12), .O(PA12));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(53[8:12])
    OB PA11_pad (.I(PA11_c_11), .O(PA11));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(52[8:12])
    OB PA10_pad (.I(PA10_c_10), .O(PA10));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(51[8:12])
    OB PA9_pad (.I(PA9_c_9), .O(PA9));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(50[8:11])
    OB PA8_pad (.I(PA8_c_8), .O(PA8));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(49[8:11])
    OB RGB_pad_0 (.I(RGB_c_0), .O(RGB[0]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_1 (.I(RGB_c_1), .O(RGB[1]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_2 (.I(RGB_c_2), .O(RGB[2]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_3 (.I(RGB_c_3), .O(RGB[3]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_4 (.I(RGB_c_4), .O(RGB[4]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_5 (.I(RGB_c_5), .O(RGB[5]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_6 (.I(RGB_c_6), .O(RGB[6]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_7 (.I(RGB_c_7), .O(RGB[7]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_8 (.I(RGB_c_8), .O(RGB[8]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_9 (.I(RGB_c_9), .O(RGB[9]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_10 (.I(RGB_c_10), .O(RGB[10]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_11 (.I(RGB_c_11), .O(RGB[11]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_12 (.I(RGB_c_12), .O(RGB[12]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_13 (.I(RGB_c_13), .O(RGB[13]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_14 (.I(RGB_c_14), .O(RGB[14]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_15 (.I(RGB_c_15), .O(RGB[15]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_16 (.I(RGB_c_16), .O(RGB[16]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_17 (.I(RGB_c_17), .O(RGB[17]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_18 (.I(RGB_c_18), .O(RGB[18]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_19 (.I(RGB_c_19), .O(RGB[19]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_20 (.I(RGB_c_20), .O(RGB[20]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_21 (.I(RGB_c_21), .O(RGB[21]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_22 (.I(RGB_c_22), .O(RGB[22]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    OB RGB_pad_23 (.I(RGB_c_23), .O(RGB[23]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(48[14:17])
    BB DB_pad_0 (.I(D[0]), .T(R_EN), .B(DB[0]), .O(DB_out_0));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB DB_pad_1 (.I(D[1]), .T(R_EN), .B(DB[1]), .O(DB_out_1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB DB_pad_2 (.I(D[2]), .T(R_EN), .B(DB[2]), .O(DB_out_2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB DB_pad_3 (.I(D[3]), .T(R_EN), .B(DB[3]), .O(DB_out_3));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB DB_pad_4 (.I(D[4]), .T(R_EN), .B(DB[4]), .O(DB_out_4));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB DB_pad_5 (.I(D[5]), .T(R_EN), .B(DB[5]), .O(DB_out_5));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB DB_pad_6 (.I(D[6]), .T(R_EN), .B(DB[6]), .O(DB_out_6));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB DB_pad_7 (.I(D[7]), .T(R_EN), .B(DB[7]), .O(DB_out_7));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    BB PD_pad_0 (.I(PAD[0]), .T(n9901), .B(PD[0]), .O(PD_out_0));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    BB PD_pad_1 (.I(PAD[1]), .T(n9901), .B(PD[1]), .O(PD_out_1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    BB PD_pad_2 (.I(PAD[2]), .T(n9901), .B(PD[2]), .O(PD_out_2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    BB PD_pad_3 (.I(PAD[3]), .T(n9901), .B(PD[3]), .O(PD_out_3));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    BB PD_pad_4 (.I(PAD[4]), .T(n9901), .B(PD[4]), .O(PD_out_4));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    BB PD_pad_5 (.I(PAD[5]), .T(n9901), .B(PD[5]), .O(PD_out_5));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    BB PD_pad_6 (.I(PAD[6]), .T(n9901), .B(PD[6]), .O(PD_out_6));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    PALETTE MOD_PALETTE (.Clk(Clk), .Clk_enable_563(Clk_enable_563), .nPICTURE(nPICTURE), 
            .\EMPH[2] (EMPH[2]), .n9928(n9928), .GND_net(GND_net), .\ri[7] (ri[7]), 
            .n6646(n6646), .n9980(n9980), .EMP_G(EMP_G), .EMP_R(EMP_R), 
            .Clk_enable_78(Clk_enable_78), .TH_MUX(TH_MUX), .DB_PARR(DB_PARR), 
            .CGAH_N_1535(CGAH_N_1535), .\STEP3[4] (STEP3[4]), .\THO_LATCH[4] (THO_LATCH[4]), 
            .Clk_enable_150(Clk_enable_150), .Clk_enable_153(Clk_enable_153), 
            .Clk_enable_157(Clk_enable_157), .Clk_enable_160(Clk_enable_160), 
            .Clk_enable_162(Clk_enable_162), .n989(n989), .B_W(B_W), .n9899(n9899), 
            .\EMPH[0] (EMPH[0]), .RGB_c_0(RGB_c_0), .RGB_c_1(RGB_c_1), 
            .RGB_c_2(RGB_c_2), .RGB_c_3(RGB_c_3), .RGB_c_4(RGB_c_4), .RGB_c_5(RGB_c_5), 
            .RGB_c_6(RGB_c_6), .RGB_c_7(RGB_c_7), .RGB_c_8(RGB_c_8), .R7(R7), 
            .n91(n91), .\DBIN[7] (DBIN[7]), .n84(n84), .n86(n86), .n87(n87), 
            .n88(n88), .n89(n89), .n90(n90), .RGB_c_9(RGB_c_9), .RGB_c_10(RGB_c_10), 
            .RGB_c_11(RGB_c_11), .RGB_c_12(RGB_c_12), .RGB_c_13(RGB_c_13), 
            .RGB_c_14(RGB_c_14), .RGB_c_15(RGB_c_15), .RGB_c_16(RGB_c_16), 
            .RGB_c_17(RGB_c_17), .RGB_c_18(RGB_c_18), .RGB_c_19(RGB_c_19), 
            .RGB_c_20(RGB_c_20), .RGB_c_21(RGB_c_21), .RGB_c_22(RGB_c_22), 
            .RGB_c_23(RGB_c_23), .PALSEL({PALSEL}), .VCC_net(VCC_net), 
            .\CGA[3] (CGA[3]), .\CGA[2] (CGA[2]), .\CGA[1] (CGA[1]), .n9910(n9910), 
            .\DBIN[5] (DBIN[5]), .\DBIN[4] (DBIN[4]), .\DBIN[3] (DBIN[3]), 
            .\DBIN[2] (DBIN[2]), .\DBIN[1] (DBIN[1]), .\DBIN[0] (DBIN[0])) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(437[9] 453[2])
    PUR PUR_INST (.PUR(VCC_net));
    defparam PUR_INST.RST_PULSE = 1;
    BB PD_pad_7 (.I(PAD[7]), .T(n9901), .B(PD[7]), .O(PD_out_7));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(149[31:33])
    LUT4 i1_2_lut_rep_227 (.A(VSYNC), .B(n8831), .Z(Clk_enable_528)) /* synthesis lut_function=(!(A+!(B))) */ ;
    defparam i1_2_lut_rep_227.init = 16'h4444;
    OBJ_FIFO MOD_OBJ_FIFO (.SEL_LATCH({SEL_LATCH}), .n10442(n10442), .CLIPOR(CLIPOR), 
            .OB({OB}), .PD_FIFO(PD_FIFO), .Clk(Clk), .ATR_IN0_2__N_1360(ATR_IN0_2__N_1360), 
            .Clk_enable_571(Clk_enable_571), .Clk_enable_68(Clk_enable_68), 
            .ATR_IN1_2__N_1362(ATR_IN1_2__N_1362), .ATR_IN2_2__N_1363(ATR_IN2_2__N_1363), 
            .ATR_IN3_2__N_1364(ATR_IN3_2__N_1364), .ATR_IN4_2__N_1365(ATR_IN4_2__N_1365), 
            .ATR_IN5_2__N_1366(ATR_IN5_2__N_1366), .ATR_IN6_2__N_1367(ATR_IN6_2__N_1367), 
            .ATR_IN7_2__N_1368(ATR_IN7_2__N_1368), .Clk_enable_173(Clk_enable_173), 
            .O_HPOS(O_HPOS), .SH3_N_1381(SH3_N_1381), .SH5_N_1385(SH5_N_1385), 
            .Clk_enable_560(Clk_enable_560), .SH7_N_1390(SH7_N_1390), .SPR0HIT_LATCH(SPR0HIT_LATCH), 
            .SH2(SH2), .Clk_enable_247(Clk_enable_247), .SH2_N_1372(SH2_N_1372), 
            .PD_out_7(PD_out_7), .PD_out_0(PD_out_0), .PD_out_6(PD_out_6), 
            .PD_out_1(PD_out_1), .PD_out_5(PD_out_5), .PD_out_2(PD_out_2), 
            .PD_out_4(PD_out_4), .PD_out_3(PD_out_3), .Clk_enable_543(Clk_enable_543), 
            .\Hnn[5] (Hnn[5]), .\Hnn[4] (Hnn[4]), .\Hnn[3] (Hnn[3]), .ZCOL({ZCOL}), 
            .Clk_enable_535(Clk_enable_535), .n5118(n5118), .n10432(n10432), 
            .nVIS(nVIS), .Clk_enable_467(Clk_enable_467)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(402[10] 417[2])
    LUT4 P_BUTTON_I_0_1_lut (.A(P_BUTTON_c), .Z(P_BUTTON_N_7)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(457[1:10])
    defparam P_BUTTON_I_0_1_lut.init = 16'h5555;
    GSR GSR_INST (.GSR(nRES_c));
    LUT4 i5856_2_lut_rep_375 (.A(MODE_c), .B(DENDY_c), .Z(n9980)) /* synthesis lut_function=(A (B)) */ ;
    defparam i5856_2_lut_rep_375.init = 16'h8888;
    LUT4 DIV_1__I_0_2_lut_3_lut (.A(MODE_c), .B(DENDY_c), .C(DIV[1]), 
         .Z(DIV_2__N_10)) /* synthesis lut_function=(!(A (B+!(C))+!A !(C))) */ ;
    defparam DIV_1__I_0_2_lut_3_lut.init = 16'h7070;
    LUT4 EMP_G_I_0_71_3_lut_rep_323_4_lut (.A(MODE_c), .B(DENDY_c), .C(EMP_R), 
         .D(EMP_G), .Z(n9928)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (C)) */ ;
    defparam EMP_G_I_0_71_3_lut_rep_323_4_lut.init = 16'hf870;
    LUT4 EMP_R_I_0_70_3_lut_4_lut (.A(MODE_c), .B(DENDY_c), .C(EMP_G), 
         .D(EMP_R), .Z(EMPH[0])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (C)) */ ;
    defparam EMP_R_I_0_70_3_lut_4_lut.init = 16'hf870;
    LUT4 i2_2_lut_3_lut (.A(MODE_c), .B(DENDY_c), .C(ODDEVEN[0]), .Z(n6)) /* synthesis lut_function=(((C)+!B)+!A) */ ;
    defparam i2_2_lut_3_lut.init = 16'hf7f7;
    LUT4 i5867_2_lut_3_lut_4_lut (.A(MODE_c), .B(DENDY_c), .C(Vo[2]), 
         .D(Vo[0]), .Z(n6362)) /* synthesis lut_function=(A (B (C (D)))) */ ;
    defparam i5867_2_lut_3_lut_4_lut.init = 16'h8000;
    LUT4 m1_lut (.Z(n10432)) /* synthesis lut_function=1, syn_instantiated=1 */ ;
    defparam m1_lut.init = 16'hffff;
    LUT4 i2300_2_lut_3_lut (.A(VSYNC), .B(n8831), .C(V_DIV[0]), .Z(n12_adj_2159)) /* synthesis lut_function=(A (C)+!A !(B (C)+!B !(C))) */ ;
    defparam i2300_2_lut_3_lut.init = 16'hb4b4;
    IB A_pad_0 (.I(A[0]), .O(A_c_0));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(44[12:13])
    IB A_pad_1 (.I(A[1]), .O(A_c_1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(44[12:13])
    IB A_pad_2 (.I(A[2]), .O(A_c_2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(44[12:13])
    IB DB_nOE_c_pad (.I(nDBE), .O(DB_nOE_c_c));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(43[7:11])
    IB RnW_pad (.I(RnW), .O(RnW_c));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(42[7:10])
    IB P_BUTTON_pad (.I(P_BUTTON), .O(P_BUTTON_c));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(41[7:15])
    IB nRES_pad (.I(nRES), .O(nRES_c));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(40[7:11])
    IB DENDY_pad (.I(DENDY), .O(DENDY_c));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(39[7:12])
    IB MODE_pad (.I(MODE), .O(MODE_c));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(38[7:11])
    IB MCLK_pad (.I(MCLK), .O(MCLK_c));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(36[7:11])
    OB PD_nOE_pad (.I(GND_net), .O(PD_nOE));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(65[8:14])
    OB PD_DIR_pad (.I(n9901), .O(PD_DIR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(64[8:14])
    OB DB_DIR_pad (.I(DB_DIR_c), .O(DB_DIR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(63[8:14])
    TIMING_GENERATOR Hn_2__I_0 (.nVIS(nVIS), .Clk(Clk), .Clk_enable_511(Clk_enable_511), 
            .Clk_enable_563(Clk_enable_563), .\Hn[1] (Hn[1]), .F_NT(F_NT), 
            .\Hnn[0] (Hnn[0]), .\Hn[0] (Hn[0]), .Clk_enable_571(Clk_enable_571), 
            .S_EV(S_EV), .Vo({Vo}), .n9980(n9980), .VSYNC(VSYNC), .RC(RC), 
            .n25(n25), .VSET({VSET[2], Open_0, VSET[0]}), .ODDEVEN({Open_1, 
            ODDEVEN[0]}), .nRES_N_15(nRES_N_15), .CLIP_OUT(CLIP_OUT), 
            .THO({THO}), .\PAMUX_7__N_859[1] (PAMUX_7__N_859[1]), .\PAMUX_7__N_859[2] (PAMUX_7__N_859[2]), 
            .\TVO[2] (TVO[2]), .\PAMUX_7__N_859[3] (PAMUX_7__N_859[3]), 
            .\TVO[3] (TVO[3]), .\PAMUX_7__N_859[4] (PAMUX_7__N_859[4]), 
            .\TVO[0] (TVO[0]), .\TVO[4] (TVO[4]), .\PAMUX_7__N_859[5] (PAMUX_7__N_859[5]), 
            .\PAMUX_7__N_859[0] (PAMUX_7__N_859[0]), .\H[8] (H[8]), .n9942(n9942), 
            .O_HPOS(O_HPOS), .E_EV(E_EV), .I_OAM2(I_OAM2), .n9984(n9984), 
            .BLNK_FF(BLNK_FF), .TVO1(TVO1), .n8813(n8813), .TVZ(TVZ), 
            .n9981(n9981), .\Hn[2] (Hn[2]), .n8992(n8992), .n3533(n3533), 
            .n9830(n9830), .n9826(n9826), .NTV_IN(NTV_IN), .NTVDO(NTVDO), 
            .n9863(n9863), .\W4Q[4] (W4Q[4]), .\W4Q[2] (W4Q[2]), .OAMQ_7__N_1041(OAMQ_7__N_1041), 
            .TVZB(TVZB), .OVZ(OVZ), .SPR_OV(SPR_OV), .n9828(n9828), 
            .n10442(n10442), .n5110(n5110), .OAP_N_1091(OAP_N_1091), .Clk_enable_47(Clk_enable_47), 
            .n9901(n9901), .nRD_c(nRD_c), .I1_32(I1_32), .n9868(n9868), 
            .CNT1_N_565(CNT1_N_565), .NFO_OUT(NFO_OUT), .n9944(n9944), 
            .n9938(n9938), .Clk_enable_267(Clk_enable_267), .n9838(n9838), 
            .FTA_OUT(FTA_OUT), .Clk_enable_560(Clk_enable_560), .OMFG(OMFG), 
            .RESCL(RESCL), .RESCL_IN(RESCL_IN), .Clk_enable_113(Clk_enable_113), 
            .n38(n38), .HC(HC), .Clk_enable_173(Clk_enable_173), .HC_N_237(HC_N_237), 
            .H_LINE5_N_453(H_LINE5_N_453), .n9897(n9897), .BGCLIP(BGCLIP), 
            .CLIP_B_N_247(CLIP_B_N_247), .n8933(n8933), .R2DB({R2DB}), 
            .n4(n4), .n3985(n3985), .n8599(n8599), .OMV_LATCH(OMV_LATCH), 
            .n9983(n9983), .nEVAL(nEVAL), .n9923(n9923), .nPICTURE(nPICTURE), 
            .PAR_O(PAR_O), .SH2_N_1372(SH2_N_1372), .SH3_N_1381(SH3_N_1381), 
            .SH7_N_1390(SH7_N_1390), .SH5_N_1385(SH5_N_1385), .OMSTEP_1__N_1053(OMSTEP_1__N_1053), 
            .n9889(n9889), .n4_adj_22(n4_adj_2160), .n4016(n4016), .n9925(n9925), 
            .Clk_enable_543(Clk_enable_543), .Clk_enable_393(Clk_enable_393), 
            .\Hnn[5] (Hnn[5]), .\Hnn[4] (Hnn[4]), .\Hnn[3] (Hnn[3]), .N_HB(N_HB), 
            .SYNC_c(SYNC_c), .H_LINE23_N_478(H_LINE23_N_478), .n8831(n8831), 
            .VBL_EN(VBL_EN), .INT_c(INT_c), .n6362(n6362), .MODE_c(MODE_c), 
            .Clk_enable_535(Clk_enable_535), .n3689(n3689), .n8475(n8475), 
            .DENDY_c(DENDY_c), .Clk_enable_561(Clk_enable_561), .Clk_enable_247(Clk_enable_247), 
            .Vo_7__N_212(Vo_7__N_212), .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(235[18] 276[2])
    LUT4 i8592_3_lut (.A(PDAT[1]), .B(PDAT[3]), .C(THO1R), .Z(n9114)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;
    defparam i8592_3_lut.init = 16'hcaca;
    LUT4 i8593_3_lut (.A(PDAT[5]), .B(PDAT[7]), .C(THO1R), .Z(n9115)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;
    defparam i8593_3_lut.init = 16'hcaca;
    LUT4 i8595_3_lut (.A(PDAT[0]), .B(PDAT[2]), .C(THO1R), .Z(n9117)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;
    defparam i8595_3_lut.init = 16'hcaca;
    LUT4 i8596_3_lut (.A(PDAT[4]), .B(PDAT[6]), .C(THO1R), .Z(n9118)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;
    defparam i8596_3_lut.init = 16'hcaca;
    OBJ_EVAL MOD_OBJ_EVAL (.Clk(Clk), .Clk_enable_571(Clk_enable_571), .OVZ(OVZ), 
            .Clk_enable_84(Clk_enable_84), .n9830(n9830), .SPR0_EV1(SPR0_EV1), 
            .SPR0_EV1_N_984(SPR0_EV1_N_984), .Clk_enable_563(Clk_enable_563), 
            .Vo({Vo}), .OB_R({OB_R}), .GND_net(GND_net), .Clk_enable_173(Clk_enable_173), 
            .TAL_LATCH_N_890(TAL_LATCH_N_890), .OV({OV}), .SPR0_EV(SPR0_EV), 
            .n2282(n2282), .n3533(n3533), .Clk_enable_562(Clk_enable_562), 
            .n9942(n9942), .n6437(n6437), .O8_16(O8_16), .n10442(n10442), 
            .PD_FIFO(PD_FIFO)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(358[10] 376[2])
    LOCAL_BUS_CONTROL MOD_LOCAL_BUS_CONTROL (.DB_PARR(DB_PARR), .Clk(Clk), 
            .Clk_enable_563(Clk_enable_563), .n9981(n9981), .R7(R7), .W7(W7), 
            .Clk_enable_47(Clk_enable_47), .n10442(n10442), .E_EV(E_EV), 
            .n9866(n9866), .n10432(n10432), .n9754(n9754), .n9752(n9752), 
            .n8933(n8933), .ALE_c(ALE_c), .Clk_enable_560(Clk_enable_560), 
            .n9942(n9942), .OMFG_LATCH(OMFG_LATCH), .OVF_LATCH(OVF_LATCH), 
            .n4(n4), .n9941(n9941), .RC(RC), .Clk_enable_86(Clk_enable_86), 
            .n9907(n9907), .PAMUX_7__N_851({PAMUX_7__N_851}), .DBIN({DBIN}), 
            .\PAMUX[7] (PAMUX[7]), .Clk_enable_393(Clk_enable_393), .\Hn[1] (Hn[1]), 
            .\TP[3] (TP[3]), .Clk_enable_543(Clk_enable_543), .\TP[1] (TP[1]), 
            .TH_MUX(TH_MUX), .nWR_c(nWR_c), .\TP[2] (TP[2]), .\PAMUX[6] (PAMUX[6]), 
            .\TP[4] (TP[4]), .\TP[0] (TP[0]), .PA11_c_11(PA11_c_11), .PA12_c_12(PA12_c_12), 
            .PA8_c_8(PA8_c_8), .PA13_c_13(PA13_c_13), .PA9_c_9(PA9_c_9), 
            .PA10_c_10(PA10_c_10), .n9975(n9975), .Clk_enable_542(Clk_enable_542), 
            .XRB_N_606(XRB_N_606)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(279[19] 297[2])
    REGISTER_SELECT MOD_REGISTER_SELECT (.Clk(Clk), .A_c_0(A_c_0), .RnWR(RnWR), 
            .RnW_c(RnW_c), .nDBER(nDBER), .DB_nOE_c_c(DB_nOE_c_c), .W5_1(W5_1), 
            .W5_2(W5_2), .W6_1(W6_1), .W6_2(W6_2), .A_c_2(A_c_2), .A_c_1(A_c_1), 
            .R2(R2), .DBIN({DBIN}), .DB_out_0(DB_out_0), .W0(W0), .W1(W1), 
            .nRES_c(nRES_c), .SUBCLK_c(SUBCLK_c), .SUB_1__N_16(SUB_1__N_16), 
            .W3(W3), .R4(R4), .W4(W4), .R7(R7), .W7(W7), .Clk_enable_518(Clk_enable_518), 
            .RC(RC), .TH_4__N_776(TH_4__N_776), .DB_out_1(DB_out_1), .DB_out_2(DB_out_2), 
            .DB_out_3(DB_out_3), .DB_out_4(DB_out_4), .DB_out_5(DB_out_5), 
            .DB_out_6(DB_out_6), .DB_out_7(DB_out_7), .\VSET[2] (VSET[2]), 
            .n38(n38), .\VSET[0] (VSET[0]), .n10442(n10442), .Clk_enable_113(Clk_enable_113), 
            .RESCL(RESCL), .H_LINE23_N_478(H_LINE23_N_478), .n6(n6), .H_LINE5_N_453(H_LINE5_N_453), 
            .HC_N_237(HC_N_237), .DB_DIR_c(DB_DIR_c), .n76(n76), .XRB_N_606(XRB_N_606), 
            .\PD_R[6] (PD_R[6]), .\Do_7__N_163[6] (Do_7__N_163[6]), .\R2DB[1] (R2DB[1]), 
            .n9899(n9899), .Clk_enable_561(Clk_enable_561), .n25(n25), 
            .nRES_N_15(nRES_N_15)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(167[17] 187[2])
    CLK_DIV MOD_CLK_DIV (.MCLK_c(MCLK_c), .SUB_1__N_16(SUB_1__N_16), .SUBCLK_c(SUBCLK_c), 
            .Clk2_N_24(Clk2_N_24), .DIV_2__N_10(DIV_2__N_10), .n9980(n9980), 
            .\DIV[1] (DIV[1]), .Clk_enable_153(Clk_enable_153), .Clk_enable_393(Clk_enable_393), 
            .Clk_enable_535(Clk_enable_535), .Clk_enable_157(Clk_enable_157), 
            .Clk_enable_160(Clk_enable_160), .Clk_enable_162(Clk_enable_162), 
            .Clk_enable_78(Clk_enable_78), .n10442(n10442), .Clk_enable_511(Clk_enable_511), 
            .Clk_enable_563(Clk_enable_563), .Clk_enable_560(Clk_enable_560), 
            .HC(HC), .H_8__N_233(H_8__N_233), .Clk_enable_150(Clk_enable_150), 
            .SPR0_EV(SPR0_EV), .SPR0HIT_LATCH(SPR0HIT_LATCH), .R2DB6_N_1437(R2DB6_N_1437), 
            .n4(n4_adj_2160), .Clk_enable_571(Clk_enable_571), .Clk_enable_173(Clk_enable_173), 
            .Clk_enable_247(Clk_enable_247), .nRES_c(nRES_c), .Clk_enable_543(Clk_enable_543), 
            .RESCL_IN(RESCL_IN), .Vo_7__N_212(Vo_7__N_212), .nVIS(nVIS), 
            .n9889(n9889), .OAMCTR2(OAMCTR2), .SPR_OV(SPR_OV), .n8(n8), 
            .Clk_enable_467(Clk_enable_467), .\Hn[0] (Hn[0]), .n8933(n8933), 
            .\OAM1ADR[7] (OAM1ADR[7]), .\CNT1[7] (CNT1[7]), .n9983(n9983), 
            .n5081(n5081), .\OSTEP[0] (OSTEP[0]), .OAM2STEP_N_1107(OAM2STEP_N_1107), 
            .OAM2STEP_N_1104(OAM2STEP_N_1104), .NFO_OUT(NFO_OUT), .FTA_OUT(FTA_OUT), 
            .\Hnn[0] (Hnn[0]), .PD_SR(PD_SR), .ORES_LATCH(ORES_LATCH), 
            .ORES(ORES), .n9864(n9864), .\OAM1ADR[0] (OAM1ADR[0]), .\CNT1[0] (CNT1[0]), 
            .n5079(n5079), .F_AT_LATCH(F_AT_LATCH), .PD_SEL(PD_SEL), .W3(W3), 
            .PAR_O(PAR_O), .CNT_7__N_1140(CNT_7__N_1140), .SPR0_EV1(SPR0_EV1), 
            .n2282(n2282), .S_EV(S_EV), .SPR0_EV1_N_984(SPR0_EV1_N_984), 
            .\Hnn[5] (Hnn[5]), .n5118(n5118), .Clk_enable_84(Clk_enable_84), 
            .I_OAM2(I_OAM2), .n5086(n5086)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(157[9] 164[2])
    PALETTE_SWITCH PALSEL_2__I_0 (.PALSEL({PALSEL}), .\V_DIV[0] (V_DIV[0]), 
            .P_BUTTON_N_7(P_BUTTON_N_7), .P_BUTTON_c(P_BUTTON_c), .Clk(Clk), 
            .n12(n12_adj_2159), .Clk_enable_528(Clk_enable_528)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(455[16] 459[2])
    PLL MOD_PLL (.MCLK_c(MCLK_c), .Clk(Clk), .GND_net(GND_net)) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(152[5] 155[2])
    PFUMX i8594 (.BLUT(n9114), .ALUT(n9115), .C0(TVO1), .Z(ATSEL[1]));
    PFUMX i8597 (.BLUT(n9117), .ALUT(n9118), .C0(TVO1), .Z(ATSEL[0]));
    LUT4 i6_4_lut (.A(n9923), .B(n12), .C(n3689), .D(Vo[1]), .Z(n8475)) /* synthesis lut_function=(A+(B+(C+!(D)))) */ ;
    defparam i6_4_lut.init = 16'hfeff;
    LUT4 i5_4_lut (.A(Vo[4]), .B(Vo[2]), .C(DENDY_c), .D(Vo[0]), .Z(n12)) /* synthesis lut_function=(A+(B+(C+!(D)))) */ ;
    defparam i5_4_lut.init = 16'hfeff;
    REG2000_2001 MOD_REG2000_2001 (.Clk(Clk), .W0(W0), .DBIN({DBIN}), 
            .EMP_G(EMP_G), .EMP_R(EMP_R), .n9980(n9980), .\ri[7] (ri[7]), 
            .n6646(n6646), .Clk_enable_571(Clk_enable_571), .CLIP_B_N_247(CLIP_B_N_247), 
            .O8_16(O8_16), .I1_32(I1_32), .BGCLIP(BGCLIP), .OBSEL(OBSEL), 
            .Clk_enable_173(Clk_enable_173), .nVIS(nVIS), .BGSEL(BGSEL), 
            .CLIP_OUT(CLIP_OUT), .\EMPH[2] (EMPH[2]), .n989(n989), .RC(RC), 
            .CLIPOR(CLIPOR), .Clk_enable_543(Clk_enable_543), .nCLPB_N_130(nCLPB_N_130), 
            .n9984(n9984), .BLNK_FF(BLNK_FF), .n9942(n9942), .N_HB(N_HB), 
            .SC_CNT(SC_CNT), .n9752(n9752), .n9754(n9754), .\H[8] (H[8]), 
            .n9897(n9897), .\Hn[2] (Hn[2]), .n9892(n9892), .\FVO[1] (FVO[1]), 
            .NBFVO1(NBFVO1), .n10442(n10442), .OB2_7__N_1043(OB2_7__N_1043), 
            .n9911(n9911), .W1(W1), .B_W(B_W), .VBL_EN(VBL_EN)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(190[14] 213[2])
    BG_COLOR MOD_BG_COLOR (.THO1R(THO1R), .Clk(Clk), .Clk_enable_393(Clk_enable_393), 
            .\THO[1] (THO[1]), .Clk_enable_563(Clk_enable_563), .Clk_enable_267(Clk_enable_267), 
            .ATSEL({ATSEL}), .Clk_enable_571(Clk_enable_571), .PD_SR(PD_SR), 
            .PD_out_0(PD_out_0), .\Hnn[0] (Hnn[0]), .n9944(n9944), .n9941(n9941), 
            .n10442(n10442), .THSTEP_N_923(THSTEP_N_923), .Clk_enable_84(Clk_enable_84), 
            .n9938(n9938), .PD_out_7(PD_out_7), .PD_out_6(PD_out_6), .PD_out_5(PD_out_5), 
            .PD_out_4(PD_out_4), .PD_out_3(PD_out_3), .CLPB_LATCH(CLPB_LATCH), 
            .Clk_enable_560(Clk_enable_560), .nCLPB_N_130(nCLPB_N_130), 
            .PD_out_2(PD_out_2), .PD_out_1(PD_out_1), .Clk_enable_543(Clk_enable_543), 
            .Clk_enable_511(Clk_enable_511), .F_AT_LATCH(F_AT_LATCH), .n9925(n9925), 
            .BGC2({BGC2}), .PDAT({PDAT}), .PD_SEL(PD_SEL), .RC(RC), 
            .\DBIN[0] (DBIN[0]), .W5_1(W5_1), .\DBIN[1] (DBIN[1]), .\DBIN[2] (DBIN[2]), 
            .NFO_OUT(NFO_OUT), .n9838(n9838)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(300[10] 317[2])
    READBUSMUX MOD_READBUSMUX (.Clk(Clk), .Clk_enable_86(Clk_enable_86), 
            .RC(RC), .PD_out_0(PD_out_0), .OB_R({OB_R}), .Clk_enable_563(Clk_enable_563), 
            .OB({OB}), .DBIN({DBIN}), .D({D}), .R2(R2), .R7(R7), .R4(R4), 
            .Clk_enable_47(Clk_enable_47), .PD_out_5(PD_out_5), .PD_out_4(PD_out_4), 
            .PD_out_3(PD_out_3), .PD_out_2(PD_out_2), .PD_out_1(PD_out_1), 
            .PD_out_7(PD_out_7), .\PD_R[6] (PD_R[6]), .PD_out_6(PD_out_6), 
            .\Do_7__N_163[6] (Do_7__N_163[6]), .Clk_enable_393(Clk_enable_393), 
            .Clk_enable_511(Clk_enable_511), .Clk_enable_560(Clk_enable_560), 
            .XRB_N_606(XRB_N_606), .n91(n91), .n84(n84), .\R2DB[2] (R2DB[2]), 
            .n76(n76), .n86(n86), .\R2DB[0] (R2DB[0]), .n87(n87), .n88(n88), 
            .n89(n89), .n90(n90), .RnWR(RnWR), .nDBER(nDBER), .R_EN(R_EN)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(216[12] 232[2])
    PAR_GEN MOD_PAR_GEN (.n10442(n10442), .SH2(SH2), .SEL_LATCH({SEL_LATCH}), 
            .ATR_IN0_2__N_1360(ATR_IN0_2__N_1360), .ATR_IN2_2__N_1363(ATR_IN2_2__N_1363), 
            .ATR_IN3_2__N_1364(ATR_IN3_2__N_1364), .\PAD[0] (PAD[0]), .Clk(Clk), 
            .Clk_enable_563(Clk_enable_563), .ATR_IN4_2__N_1365(ATR_IN4_2__N_1365), 
            .Clk_enable_571(Clk_enable_571), .OV({OV}), .RC(RC), .OB({OB}), 
            .E_EV(E_EV), .PD_out_0(PD_out_0), .TP({Open_2, Open_3, Open_4, 
            Open_5, Open_6, Open_7, Open_8, Open_9, Open_10, Open_11, 
            Open_12, TP[0]}), .n9866(n9866), .I1_32(I1_32), .n9942(n9942), 
            .TAL_LATCH_N_890(TAL_LATCH_N_890), .TVZ(TVZ), .Clk_enable_68(Clk_enable_68), 
            .W6_2(W6_2), .W5_1(W5_1), .DBIN({DBIN}), .Clk_enable_173(Clk_enable_173), 
            .\TP[4] (TP[4]), .\TP[3] (TP[3]), .\TP[2] (TP[2]), .\TP[1] (TP[1]), 
            .PD_out_7(PD_out_7), .PD_out_6(PD_out_6), .PD_out_5(PD_out_5), 
            .PD_out_4(PD_out_4), .PD_out_3(PD_out_3), .PD_out_2(PD_out_2), 
            .PD_out_1(PD_out_1), .Clk_enable_560(Clk_enable_560), .W5_2(W5_2), 
            .Clk_enable_247(Clk_enable_247), .PA12_c_12(PA12_c_12), .PA11_c_11(PA11_c_11), 
            .PA10_c_10(PA10_c_10), .PA9_c_9(PA9_c_9), .PA8_c_8(PA8_c_8), 
            .PAR_O(PAR_O), .\PAD[7] (PAD[7]), .\PAMUX[7] (PAMUX[7]), .\PAD[6] (PAD[6]), 
            .\PAMUX[6] (PAMUX[6]), .W6_1(W6_1), .W0(W0), .\PAD[5] (PAD[5]), 
            .SC_CNT(SC_CNT), .\PAD[4] (PAD[4]), .\PAD[3] (PAD[3]), .\PAD[2] (PAD[2]), 
            .\PAD[1] (PAD[1]), .F_NT(F_NT), .\Hnn[0] (Hnn[0]), .\TVO[2] (TVO[2]), 
            .\TVO[4] (TVO[4]), .n8813(n8813), .\TVO[0] (TVO[0]), .\TVO[3] (TVO[3]), 
            .NTVDO(NTVDO), .NTV_IN(NTV_IN), .RESCL(RESCL), .n9975(n9975), 
            .n9907(n9907), .\FVO[1] (FVO[1]), .TH_4__N_776(TH_4__N_776), 
            .TVO1(TVO1), .BGSEL(BGSEL), .OBSEL(OBSEL), .O8_16(O8_16), 
            .ATR_IN5_2__N_1366(ATR_IN5_2__N_1366), .ATR_IN6_2__N_1367(ATR_IN6_2__N_1367), 
            .ATR_IN7_2__N_1368(ATR_IN7_2__N_1368), .n9892(n9892), .n9925(n9925), 
            .\Hn[2] (Hn[2]), .Clk_enable_518(Clk_enable_518), .THO({THO}), 
            .ATR_IN1_2__N_1362(ATR_IN1_2__N_1362), .\PAMUX_7__N_859[1] (PAMUX_7__N_859[1]), 
            .PAMUX_7__N_851({PAMUX_7__N_851}), .n8992(n8992), .\PAMUX_7__N_859[2] (PAMUX_7__N_859[2]), 
            .\PAMUX_7__N_859[3] (PAMUX_7__N_859[3]), .\PAMUX_7__N_859[4] (PAMUX_7__N_859[4]), 
            .\PAMUX_7__N_859[5] (PAMUX_7__N_859[5]), .\PAMUX_7__N_859[0] (PAMUX_7__N_859[0]), 
            .PA13_c_13(PA13_c_13), .n5110(n5110), .NBFVO1(NBFVO1), .Clk_enable_393(Clk_enable_393), 
            .Clk_enable_542(Clk_enable_542), .THSTEP_N_923(THSTEP_N_923), 
            .Clk_enable_511(Clk_enable_511), .n9868(n9868), .CNT1_N_565(CNT1_N_565), 
            .n9911(n9911), .TVZB(TVZB), .n9863(n9863)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(320[9] 355[2])
    OAM MOD_OAM (.ORES_LATCH(ORES_LATCH), .Clk(Clk), .Clk_enable_571(Clk_enable_571), 
        .nEVAL(nEVAL), .OVF_LATCH(OVF_LATCH), .OMFG_LATCH(OMFG_LATCH), 
        .OMFG(OMFG), .n9828(n9828), .I_OAM2(I_OAM2), .W4Q({W4Q[4], Open_13, 
        Open_14, Open_15, Open_16}), .Clk_enable_563(Clk_enable_563), 
        .\W4Q[2] (W4Q[2]), .OMSTEP_1__N_1053(OMSTEP_1__N_1053), .OMV_LATCH(OMV_LATCH), 
        .OB2_7__N_1043(OB2_7__N_1043), .OB({OB}), .\OAM1ADR[7] (OAM1ADR[7]), 
        .\OSTEP[0] (OSTEP[0]), .OAMCTR2(OAMCTR2), .\OAM1ADR[0] (OAM1ADR[0]), 
        .n9826(n9826), .W4(W4), .PAR_O(PAR_O), .\Hn[0] (Hn[0]), .\Hn[2] (Hn[2]), 
        .OAM2STEP_N_1107(OAM2STEP_N_1107), .n10442(n10442), .n9942(n9942), 
        .\R2DB[0] (R2DB[0]), .n3985(n3985), .SPR_OV(SPR_OV), .n8599(n8599), 
        .n9864(n9864), .n9983(n9983), .W3(W3), .Clk_enable_562(Clk_enable_562), 
        .OAP_N_1091(OAP_N_1091), .n8(n8), .\Hnn[0] (Hnn[0]), .n5086(n5086), 
        .VCC_net(VCC_net), .GND_net(GND_net), .OAMQ_7__N_1041(OAMQ_7__N_1041), 
        .DBIN({DBIN}), .n5081(n5081), .n5079(n5079), .\CNT1[7] (CNT1[7]), 
        .CNT_7__N_1140(CNT_7__N_1140), .n6437(n6437), .\CNT1[0] (CNT1[0]), 
        .Clk_enable_543(Clk_enable_543), .OAM2STEP_N_1104(OAM2STEP_N_1104), 
        .ORES(ORES), .Clk_enable_173(Clk_enable_173)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(379[5] 399[2])
    VLO i1 (.Z(GND_net));
    TSALL TSALL_INST (.TSALL(GND_net));
    
endmodule
//
// Verilog Description of module PIX_MUX
//

module PIX_MUX (Clk, Clk_enable_571, R2DB6_N_1437, Clk_enable_563, ZCOL, 
            THO, Clk_enable_173, TH_MUX, \CGA[3] , \CGA[2] , \CGA[1] , 
            \STEP3[4] , Clk_enable_560, \THO_LATCH[4] , BGC2, CLPB_LATCH, 
            \R2DB[1] , n4016, n9910, CGAH_N_1535, n10442) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_571;
    output R2DB6_N_1437;
    input Clk_enable_563;
    input [4:0]ZCOL;
    input [4:0]THO;
    input Clk_enable_173;
    input TH_MUX;
    output \CGA[3] ;
    output \CGA[2] ;
    output \CGA[1] ;
    output \STEP3[4] ;
    input Clk_enable_560;
    output \THO_LATCH[4] ;
    input [3:0]BGC2;
    input CLPB_LATCH;
    output \R2DB[1] ;
    input n4016;
    output n9910;
    output CGAH_N_1535;
    input n10442;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire BGC_LATCH, ZCOL_LATCH, n9945, OCOLN, OCOL_N_1442;
    wire [4:0]ZCOLN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1512[10:15])
    wire [4:0]THO_LATCH;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1512[17:26])
    wire [3:0]STEP2;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1513[10:15])
    wire [3:0]STEP2_3__N_1426;
    wire [4:0]STEP3;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1512[28:33])
    
    wire n5102;
    
    FD1P3AX BGC_LATCH_46 (.D(R2DB6_N_1437), .SP(Clk_enable_571), .CK(Clk), 
            .Q(BGC_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam BGC_LATCH_46.GSR = "DISABLED";
    FD1P3AX ZCOL_LATCH_47 (.D(n9945), .SP(Clk_enable_571), .CK(Clk), .Q(ZCOL_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam ZCOL_LATCH_47.GSR = "DISABLED";
    FD1P3AX OCOLN_48 (.D(OCOL_N_1442), .SP(Clk_enable_571), .CK(Clk), 
            .Q(OCOLN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam OCOLN_48.GSR = "DISABLED";
    FD1P3AX ZCOLN_i0_i0 (.D(ZCOL[0]), .SP(Clk_enable_563), .CK(Clk), .Q(ZCOLN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam ZCOLN_i0_i0.GSR = "DISABLED";
    FD1P3AX THO_LATCH_i0_i0 (.D(THO[0]), .SP(Clk_enable_563), .CK(Clk), 
            .Q(THO_LATCH[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam THO_LATCH_i0_i0.GSR = "DISABLED";
    FD1P3AX STEP2_i0_i0 (.D(STEP2_3__N_1426[0]), .SP(Clk_enable_173), .CK(Clk), 
            .Q(STEP2[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP2_i0_i0.GSR = "DISABLED";
    LUT4 STEP3_4__I_0_49_i4_3_lut (.A(STEP3[3]), .B(THO_LATCH[3]), .C(TH_MUX), 
         .Z(\CGA[3] )) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1519[19:55])
    defparam STEP3_4__I_0_49_i4_3_lut.init = 16'hcaca;
    LUT4 STEP3_4__I_0_49_i3_3_lut (.A(STEP3[2]), .B(THO_LATCH[2]), .C(TH_MUX), 
         .Z(\CGA[2] )) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1519[19:55])
    defparam STEP3_4__I_0_49_i3_3_lut.init = 16'hcaca;
    LUT4 STEP3_4__I_0_49_i2_3_lut (.A(STEP3[1]), .B(THO_LATCH[1]), .C(TH_MUX), 
         .Z(\CGA[1] )) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1519[19:55])
    defparam STEP3_4__I_0_49_i2_3_lut.init = 16'hcaca;
    LUT4 ZCOLN_1__I_0_2_lut_rep_340 (.A(ZCOLN[1]), .B(ZCOLN[0]), .Z(n9945)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1516[19:42])
    defparam ZCOLN_1__I_0_2_lut_rep_340.init = 16'heeee;
    LUT4 i8830_3_lut_4_lut (.A(ZCOLN[1]), .B(ZCOLN[0]), .C(R2DB6_N_1437), 
         .D(ZCOLN[4]), .Z(OCOL_N_1442)) /* synthesis lut_function=(!(A (C (D))+!A ((C (D))+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1516[19:42])
    defparam i8830_3_lut_4_lut.init = 16'h0eee;
    FD1P3AX STEP2_i0_i3 (.D(STEP2_3__N_1426[3]), .SP(Clk_enable_173), .CK(Clk), 
            .Q(STEP2[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP2_i0_i3.GSR = "DISABLED";
    FD1P3AX STEP2_i0_i2 (.D(STEP2_3__N_1426[2]), .SP(Clk_enable_173), .CK(Clk), 
            .Q(STEP2[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP2_i0_i2.GSR = "DISABLED";
    FD1P3AX STEP2_i0_i1 (.D(STEP2_3__N_1426[1]), .SP(Clk_enable_173), .CK(Clk), 
            .Q(STEP2[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP2_i0_i1.GSR = "DISABLED";
    FD1P3AX STEP3_i0_i4 (.D(OCOLN), .SP(Clk_enable_560), .CK(Clk), .Q(\STEP3[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP3_i0_i4.GSR = "DISABLED";
    FD1P3AX THO_LATCH_i0_i4 (.D(THO[4]), .SP(Clk_enable_560), .CK(Clk), 
            .Q(\THO_LATCH[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam THO_LATCH_i0_i4.GSR = "DISABLED";
    FD1P3AX THO_LATCH_i0_i3 (.D(THO[3]), .SP(Clk_enable_560), .CK(Clk), 
            .Q(THO_LATCH[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam THO_LATCH_i0_i3.GSR = "DISABLED";
    FD1P3AX THO_LATCH_i0_i2 (.D(THO[2]), .SP(Clk_enable_560), .CK(Clk), 
            .Q(THO_LATCH[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam THO_LATCH_i0_i2.GSR = "DISABLED";
    FD1P3AX THO_LATCH_i0_i1 (.D(THO[1]), .SP(Clk_enable_560), .CK(Clk), 
            .Q(THO_LATCH[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam THO_LATCH_i0_i1.GSR = "DISABLED";
    FD1P3AX ZCOLN_i0_i4 (.D(ZCOL[4]), .SP(Clk_enable_560), .CK(Clk), .Q(ZCOLN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam ZCOLN_i0_i4.GSR = "DISABLED";
    FD1P3AX ZCOLN_i0_i3 (.D(ZCOL[3]), .SP(Clk_enable_560), .CK(Clk), .Q(ZCOLN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam ZCOLN_i0_i3.GSR = "DISABLED";
    FD1P3AX ZCOLN_i0_i2 (.D(ZCOL[2]), .SP(Clk_enable_560), .CK(Clk), .Q(ZCOLN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam ZCOLN_i0_i2.GSR = "DISABLED";
    FD1P3AX ZCOLN_i0_i1 (.D(ZCOL[1]), .SP(Clk_enable_560), .CK(Clk), .Q(ZCOLN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam ZCOLN_i0_i1.GSR = "DISABLED";
    LUT4 mux_25_i1_4_lut (.A(ZCOLN[0]), .B(BGC2[0]), .C(OCOL_N_1442), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1426[0])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1530[25:53])
    defparam mux_25_i1_4_lut.init = 16'haca0;
    FD1S3AX R2DB6_41 (.D(n4016), .CK(Clk), .Q(\R2DB[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam R2DB6_41.GSR = "DISABLED";
    LUT4 mux_25_i4_4_lut (.A(ZCOLN[3]), .B(BGC2[3]), .C(OCOL_N_1442), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1426[3])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1530[25:53])
    defparam mux_25_i4_4_lut.init = 16'haca0;
    LUT4 mux_25_i3_4_lut (.A(ZCOLN[2]), .B(BGC2[2]), .C(OCOL_N_1442), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1426[2])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1530[25:53])
    defparam mux_25_i3_4_lut.init = 16'haca0;
    LUT4 i2387_3_lut (.A(CLPB_LATCH), .B(BGC2[0]), .C(BGC2[1]), .Z(R2DB6_N_1437)) /* synthesis lut_function=(A (B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1523[54:73])
    defparam i2387_3_lut.init = 16'ha8a8;
    LUT4 mux_25_i2_4_lut (.A(ZCOLN[1]), .B(BGC2[1]), .C(OCOL_N_1442), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1426[1])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1530[25:53])
    defparam mux_25_i2_4_lut.init = 16'haca0;
    LUT4 STEP3_4__I_0_49_i1_3_lut_rep_305 (.A(STEP3[0]), .B(THO_LATCH[0]), 
         .C(TH_MUX), .Z(n9910)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1519[19:55])
    defparam STEP3_4__I_0_49_i1_3_lut_rep_305.init = 16'hcaca;
    LUT4 CGA_0__I_0_2_lut_4_lut (.A(STEP3[0]), .B(THO_LATCH[0]), .C(TH_MUX), 
         .D(\CGA[1] ), .Z(CGAH_N_1535)) /* synthesis lut_function=(A (B+((D)+!C))+!A (B (C+(D))+!B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1519[19:55])
    defparam CGA_0__I_0_2_lut_4_lut.init = 16'hffca;
    LUT4 i4594_3_lut (.A(n10442), .B(BGC_LATCH), .C(ZCOL_LATCH), .Z(n5102)) /* synthesis lut_function=(!((B+(C))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam i4594_3_lut.init = 16'h0202;
    FD1P3IX STEP3_i0_i1 (.D(STEP2[1]), .SP(Clk_enable_560), .CD(n5102), 
            .CK(Clk), .Q(STEP3[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP3_i0_i1.GSR = "DISABLED";
    FD1P3IX STEP3_i0_i2 (.D(STEP2[2]), .SP(Clk_enable_560), .CD(n5102), 
            .CK(Clk), .Q(STEP3[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP3_i0_i2.GSR = "DISABLED";
    FD1P3IX STEP3_i0_i3 (.D(STEP2[3]), .SP(Clk_enable_560), .CD(n5102), 
            .CK(Clk), .Q(STEP3[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP3_i0_i3.GSR = "DISABLED";
    FD1P3IX STEP3_i0_i0 (.D(STEP2[0]), .SP(Clk_enable_563), .CD(n5102), 
            .CK(Clk), .Q(STEP3[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=420, LSE_RLINE=434 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1521[8] 1535[27])
    defparam STEP3_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module PALETTE
//

module PALETTE (Clk, Clk_enable_563, nPICTURE, \EMPH[2] , n9928, GND_net, 
            \ri[7] , n6646, n9980, EMP_G, EMP_R, Clk_enable_78, 
            TH_MUX, DB_PARR, CGAH_N_1535, \STEP3[4] , \THO_LATCH[4] , 
            Clk_enable_150, Clk_enable_153, Clk_enable_157, Clk_enable_160, 
            Clk_enable_162, n989, B_W, n9899, \EMPH[0] , RGB_c_0, 
            RGB_c_1, RGB_c_2, RGB_c_3, RGB_c_4, RGB_c_5, RGB_c_6, 
            RGB_c_7, RGB_c_8, R7, n91, \DBIN[7] , n84, n86, n87, 
            n88, n89, n90, RGB_c_9, RGB_c_10, RGB_c_11, RGB_c_12, 
            RGB_c_13, RGB_c_14, RGB_c_15, RGB_c_16, RGB_c_17, RGB_c_18, 
            RGB_c_19, RGB_c_20, RGB_c_21, RGB_c_22, RGB_c_23, PALSEL, 
            VCC_net, \CGA[3] , \CGA[2] , \CGA[1] , n9910, \DBIN[5] , 
            \DBIN[4] , \DBIN[3] , \DBIN[2] , \DBIN[1] , \DBIN[0] ) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_563;
    input nPICTURE;
    input \EMPH[2] ;
    input n9928;
    input GND_net;
    output \ri[7] ;
    input n6646;
    input n9980;
    input EMP_G;
    input EMP_R;
    input Clk_enable_78;
    input TH_MUX;
    input DB_PARR;
    input CGAH_N_1535;
    input \STEP3[4] ;
    input \THO_LATCH[4] ;
    input Clk_enable_150;
    input Clk_enable_153;
    input Clk_enable_157;
    input Clk_enable_160;
    input Clk_enable_162;
    input n989;
    input B_W;
    output n9899;
    input \EMPH[0] ;
    output RGB_c_0;
    output RGB_c_1;
    output RGB_c_2;
    output RGB_c_3;
    output RGB_c_4;
    output RGB_c_5;
    output RGB_c_6;
    output RGB_c_7;
    output RGB_c_8;
    input R7;
    output n91;
    input \DBIN[7] ;
    output n84;
    output n86;
    output n87;
    output n88;
    output n89;
    output n90;
    output RGB_c_9;
    output RGB_c_10;
    output RGB_c_11;
    output RGB_c_12;
    output RGB_c_13;
    output RGB_c_14;
    output RGB_c_15;
    output RGB_c_16;
    output RGB_c_17;
    output RGB_c_18;
    output RGB_c_19;
    output RGB_c_20;
    output RGB_c_21;
    output RGB_c_22;
    output RGB_c_23;
    input [2:0]PALSEL;
    input VCC_net;
    input \CGA[3] ;
    input \CGA[2] ;
    input \CGA[1] ;
    input n9910;
    input \DBIN[5] ;
    input \DBIN[4] ;
    input \DBIN[3] ;
    input \DBIN[2] ;
    input \DBIN[1] ;
    input \DBIN[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire PICTURER, n8232;
    wire [7:0]ri;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1578[11:13])
    wire [7:0]ro_7__N_1452;
    
    wire n8231, n2792, n8221, n8213;
    wire [7:0]bi;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1578[19:21])
    wire [7:0]bo_7__N_1509;
    
    wire n8207, n1311, n1310, n8208;
    wire [5:0]PIX;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(78[11:14])
    wire [3:0]CN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1568[11:13])
    
    wire C_5__N_1476;
    wire [4:0]Address;   // d:/ppu_reverse/fpga/lava_ppu_lite/palette_ram.v(13[22:29])
    wire [7:0]ro;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1564[10:12])
    
    wire PICTURER2;
    wire [7:0]go;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1564[14:16])
    wire [7:0]go_7__N_1460;
    wire [7:0]bo;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1564[18:20])
    wire [7:0]bo_7__N_1468;
    
    wire n8212, n8211;
    wire [5:0]C;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1569[11:12])
    
    wire n1314, n8206, n1299, n3236, n1301, n3234, n8210, n1313, 
        n1312, n1300, n3235, n8209, n1307, n1309, n1308, n9979, 
        n9890;
    wire [7:0]n1000;
    
    wire n8995, n1303, n3232, n8230, n2788, n2790, n1302, n3233, 
        n8229, n2776, n2786, n1305, n3230, n1304, n3231, n1306, 
        n3006;
    wire [7:0]gi;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1578[15:17])
    
    wire n2784, n8224, n8237, n6644, n8236, n2780, n2782, n2774, 
        n2778, n8235, n8223, n8234, n8222;
    
    FD1P3AX PICTURER_48 (.D(nPICTURE), .SP(Clk_enable_563), .CK(Clk), 
            .Q(PICTURER));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PICTURER_48.GSR = "DISABLED";
    CCU2D add_666_9 (.A0(\EMPH[2] ), .B0(n9928), .C0(ri[6]), .D0(GND_net), 
          .A1(\EMPH[2] ), .B1(n9928), .C1(\ri[7] ), .D1(GND_net), .CIN(n8232), 
          .S0(ro_7__N_1452[6]), .S1(ro_7__N_1452[7]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_666_9.INIT0 = 16'h1e1e;
    defparam add_666_9.INIT1 = 16'h1e1e;
    defparam add_666_9.INJECT1_0 = "NO";
    defparam add_666_9.INJECT1_1 = "NO";
    CCU2D add_666_7 (.A0(ri[4]), .B0(n9928), .C0(\EMPH[2] ), .D0(n2792), 
          .A1(ri[5]), .B1(n9928), .C1(\EMPH[2] ), .D1(n6646), .CIN(n8231), 
          .COUT(n8232), .S0(ro_7__N_1452[4]), .S1(ro_7__N_1452[5]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_666_7.INIT0 = 16'h56aa;
    defparam add_666_7.INIT1 = 16'h56aa;
    defparam add_666_7.INJECT1_0 = "NO";
    defparam add_666_7.INJECT1_1 = "NO";
    LUT4 mux_530_i5_3_lut (.A(\ri[7] ), .B(ri[6]), .C(n9928), .Z(n2792)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_530_i5_3_lut.init = 16'h3535;
    CCU2D add_669_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(n9980), .B1(EMP_G), .C1(EMP_R), .D1(\EMPH[2] ), .COUT(n8221));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_669_1.INIT0 = 16'hF000;
    defparam add_669_1.INIT1 = 16'h001b;
    defparam add_669_1.INJECT1_0 = "NO";
    defparam add_669_1.INJECT1_1 = "NO";
    CCU2D sub_34_add_2_9 (.A0(bi[7]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n8213), 
          .S0(bo_7__N_1509[7]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1629[14:26])
    defparam sub_34_add_2_9.INIT0 = 16'h5555;
    defparam sub_34_add_2_9.INIT1 = 16'h0000;
    defparam sub_34_add_2_9.INJECT1_0 = "NO";
    defparam sub_34_add_2_9.INJECT1_1 = "NO";
    CCU2D add_520_rep_2_5 (.A0(bo_7__N_1509[3]), .B0(bi[6]), .C0(GND_net), 
          .D0(GND_net), .A1(bo_7__N_1509[4]), .B1(bi[7]), .C1(GND_net), 
          .D1(GND_net), .CIN(n8207), .COUT(n8208), .S0(n1311), .S1(n1310));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_520_rep_2_5.INIT0 = 16'h5999;
    defparam add_520_rep_2_5.INIT1 = 16'h5999;
    defparam add_520_rep_2_5.INJECT1_0 = "NO";
    defparam add_520_rep_2_5.INJECT1_1 = "NO";
    FD1P3AX PIX_i0_i0 (.D(CN[0]), .SP(Clk_enable_78), .CK(Clk), .Q(PIX[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PIX_i0_i0.GSR = "DISABLED";
    LUT4 TH_MUX_I_0_2_lut (.A(TH_MUX), .B(DB_PARR), .Z(C_5__N_1476)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1575[47:63])
    defparam TH_MUX_I_0_2_lut.init = 16'h8888;
    LUT4 CGAH_I_0_4_lut (.A(CGAH_N_1535), .B(\STEP3[4] ), .C(\THO_LATCH[4] ), 
         .D(TH_MUX), .Z(Address[4])) /* synthesis lut_function=(A (B (C+!(D))+!B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1567[15:43])
    defparam CGAH_I_0_4_lut.init = 16'ha088;
    FD1S3AX ro_i0 (.D(ro_7__N_1452[0]), .CK(Clk), .Q(ro[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i0.GSR = "DISABLED";
    FD1S3AX PICTURER2_49 (.D(PICTURER), .CK(Clk), .Q(PICTURER2)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PICTURER2_49.GSR = "DISABLED";
    FD1S3AX go_i0 (.D(go_7__N_1460[0]), .CK(Clk), .Q(go[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i0.GSR = "DISABLED";
    FD1S3AX bo_i0 (.D(bo_7__N_1468[0]), .CK(Clk), .Q(bo[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i0.GSR = "DISABLED";
    CCU2D sub_34_add_2_7 (.A0(bi[5]), .B0(bi[7]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[6]), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n8212), 
          .COUT(n8213), .S0(bo_7__N_1509[5]), .S1(bo_7__N_1509[6]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1629[14:26])
    defparam sub_34_add_2_7.INIT0 = 16'h5999;
    defparam sub_34_add_2_7.INIT1 = 16'h5555;
    defparam sub_34_add_2_7.INJECT1_0 = "NO";
    defparam sub_34_add_2_7.INJECT1_1 = "NO";
    CCU2D sub_34_add_2_5 (.A0(bi[3]), .B0(bi[5]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[4]), .B1(bi[6]), .C1(GND_net), .D1(GND_net), .CIN(n8211), 
          .COUT(n8212), .S0(bo_7__N_1509[3]), .S1(bo_7__N_1509[4]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1629[14:26])
    defparam sub_34_add_2_5.INIT0 = 16'h5999;
    defparam sub_34_add_2_5.INIT1 = 16'h5999;
    defparam sub_34_add_2_5.INJECT1_0 = "NO";
    defparam sub_34_add_2_5.INJECT1_1 = "NO";
    FD1P3AX PIX_i0_i5 (.D(C[5]), .SP(Clk_enable_150), .CK(Clk), .Q(PIX[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PIX_i0_i5.GSR = "DISABLED";
    FD1P3AX PIX_i0_i4 (.D(C[4]), .SP(Clk_enable_153), .CK(Clk), .Q(PIX[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PIX_i0_i4.GSR = "DISABLED";
    FD1P3AX PIX_i0_i3 (.D(CN[3]), .SP(Clk_enable_157), .CK(Clk), .Q(PIX[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PIX_i0_i3.GSR = "DISABLED";
    FD1P3AX PIX_i0_i2 (.D(CN[2]), .SP(Clk_enable_160), .CK(Clk), .Q(PIX[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PIX_i0_i2.GSR = "DISABLED";
    FD1P3AX PIX_i0_i1 (.D(CN[1]), .SP(Clk_enable_162), .CK(Clk), .Q(PIX[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam PIX_i0_i1.GSR = "DISABLED";
    CCU2D add_520_rep_2_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(bo_7__N_1509[0]), .B1(bi[3]), .C1(GND_net), .D1(GND_net), 
          .COUT(n8206), .S1(n1314));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_520_rep_2_1.INIT0 = 16'h0000;
    defparam add_520_rep_2_1.INIT1 = 16'h5999;
    defparam add_520_rep_2_1.INJECT1_0 = "NO";
    defparam add_520_rep_2_1.INJECT1_1 = "NO";
    LUT4 i2743_3_lut (.A(n1299), .B(bo_7__N_1509[7]), .C(n989), .Z(n3236)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam i2743_3_lut.init = 16'hacac;
    LUT4 i2741_3_lut (.A(n1301), .B(bo_7__N_1509[5]), .C(n989), .Z(n3234)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam i2741_3_lut.init = 16'hacac;
    CCU2D sub_34_add_2_3 (.A0(bi[1]), .B0(bi[3]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[2]), .B1(bi[4]), .C1(GND_net), .D1(GND_net), .CIN(n8210), 
          .COUT(n8211), .S0(bo_7__N_1509[1]), .S1(bo_7__N_1509[2]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1629[14:26])
    defparam sub_34_add_2_3.INIT0 = 16'h5999;
    defparam sub_34_add_2_3.INIT1 = 16'h5999;
    defparam sub_34_add_2_3.INJECT1_0 = "NO";
    defparam sub_34_add_2_3.INJECT1_1 = "NO";
    CCU2D add_520_rep_2_3 (.A0(bo_7__N_1509[1]), .B0(bi[4]), .C0(GND_net), 
          .D0(GND_net), .A1(bo_7__N_1509[2]), .B1(bi[5]), .C1(GND_net), 
          .D1(GND_net), .CIN(n8206), .COUT(n8207), .S0(n1313), .S1(n1312));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_520_rep_2_3.INIT0 = 16'h5999;
    defparam add_520_rep_2_3.INIT1 = 16'h5999;
    defparam add_520_rep_2_3.INJECT1_0 = "NO";
    defparam add_520_rep_2_3.INJECT1_1 = "NO";
    LUT4 i2742_3_lut (.A(n1300), .B(bo_7__N_1509[6]), .C(n989), .Z(n3235)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam i2742_3_lut.init = 16'hacac;
    CCU2D add_520_rep_2_9 (.A0(bo_7__N_1509[7]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n8209), .S0(n1307));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_520_rep_2_9.INIT0 = 16'h5555;
    defparam add_520_rep_2_9.INIT1 = 16'h0000;
    defparam add_520_rep_2_9.INJECT1_0 = "NO";
    defparam add_520_rep_2_9.INJECT1_1 = "NO";
    CCU2D add_520_rep_2_7 (.A0(bo_7__N_1509[5]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(bo_7__N_1509[6]), .B1(GND_net), .C1(GND_net), 
          .D1(GND_net), .CIN(n8208), .COUT(n8209), .S0(n1309), .S1(n1308));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_520_rep_2_7.INIT0 = 16'h5555;
    defparam add_520_rep_2_7.INIT1 = 16'h5555;
    defparam add_520_rep_2_7.INJECT1_0 = "NO";
    defparam add_520_rep_2_7.INJECT1_1 = "NO";
    LUT4 C_3__I_0_i1_2_lut_4_lut (.A(B_W), .B(nPICTURE), .C(n9899), .D(C[0]), 
         .Z(CN[0])) /* synthesis lut_function=(!(A+!(B (C (D))+!B (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1572[16:45])
    defparam C_3__I_0_i1_2_lut_4_lut.init = 16'h5100;
    LUT4 C_3__I_0_i4_2_lut_4_lut (.A(B_W), .B(nPICTURE), .C(n9899), .D(C[3]), 
         .Z(CN[3])) /* synthesis lut_function=(!(A+!(B (C (D))+!B (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1572[16:45])
    defparam C_3__I_0_i4_2_lut_4_lut.init = 16'h5100;
    LUT4 C_3__I_0_i3_2_lut_4_lut (.A(B_W), .B(nPICTURE), .C(n9899), .D(C[2]), 
         .Z(CN[2])) /* synthesis lut_function=(!(A+!(B (C (D))+!B (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1572[16:45])
    defparam C_3__I_0_i3_2_lut_4_lut.init = 16'h5100;
    LUT4 C_3__I_0_i2_2_lut_4_lut (.A(B_W), .B(nPICTURE), .C(n9899), .D(C[1]), 
         .Z(CN[1])) /* synthesis lut_function=(!(A+!(B (C (D))+!B (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1572[16:45])
    defparam C_3__I_0_i2_2_lut_4_lut.init = 16'h5100;
    CCU2D sub_34_add_2_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(bi[0]), .B1(bi[2]), .C1(GND_net), .D1(GND_net), .COUT(n8210), 
          .S1(bo_7__N_1509[0]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1629[14:26])
    defparam sub_34_add_2_1.INIT0 = 16'h0000;
    defparam sub_34_add_2_1.INIT1 = 16'h5999;
    defparam sub_34_add_2_1.INJECT1_0 = "NO";
    defparam sub_34_add_2_1.INJECT1_1 = "NO";
    LUT4 i1_2_lut_rep_374 (.A(EMP_G), .B(EMP_R), .Z(n9979)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam i1_2_lut_rep_374.init = 16'h8888;
    LUT4 i6255_3_lut_rep_285_4_lut (.A(EMP_G), .B(EMP_R), .C(\EMPH[2] ), 
         .D(\EMPH[0] ), .Z(n9890)) /* synthesis lut_function=(A (B (C (D)+!C !(D))+!B ((D)+!C))+!A ((D)+!C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam i6255_3_lut_rep_285_4_lut.init = 16'hf70f;
    LUT4 mux_502_i7_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[6]), .D(n1308), 
         .Z(n1000[6])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_502_i7_3_lut_4_lut.init = 16'hfe10;
    LUT4 i8927_3_lut_4_lut_3_lut (.A(EMP_G), .B(EMP_R), .C(\EMPH[2] ), 
         .Z(n8995)) /* synthesis lut_function=(!(A ((C)+!B)+!A (B))) */ ;
    defparam i8927_3_lut_4_lut_3_lut.init = 16'h1919;
    LUT4 mux_502_i8_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[7]), .D(n1307), 
         .Z(n1000[7])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_502_i8_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_502_i6_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[5]), .D(n1309), 
         .Z(n1000[5])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_502_i6_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_502_i4_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[3]), .D(n1311), 
         .Z(n1000[3])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_502_i4_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_502_i5_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[4]), .D(n1310), 
         .Z(n1000[4])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_502_i5_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_502_i2_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[1]), .D(n1313), 
         .Z(n1000[1])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_502_i2_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_502_i3_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[2]), .D(n1312), 
         .Z(n1000[2])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_502_i3_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_502_i1_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[0]), .D(n1314), 
         .Z(n1000[0])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_502_i1_3_lut_4_lut.init = 16'hfe10;
    LUT4 i2739_3_lut (.A(n1303), .B(bo_7__N_1509[3]), .C(n989), .Z(n3232)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam i2739_3_lut.init = 16'hacac;
    CCU2D add_666_5 (.A0(ri[2]), .B0(n9928), .C0(\EMPH[2] ), .D0(n2788), 
          .A1(ri[3]), .B1(n9928), .C1(\EMPH[2] ), .D1(n2790), .CIN(n8230), 
          .COUT(n8231), .S0(ro_7__N_1452[2]), .S1(ro_7__N_1452[3]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_666_5.INIT0 = 16'h56aa;
    defparam add_666_5.INIT1 = 16'h56aa;
    defparam add_666_5.INJECT1_0 = "NO";
    defparam add_666_5.INJECT1_1 = "NO";
    LUT4 i2740_3_lut (.A(n1302), .B(bo_7__N_1509[4]), .C(n989), .Z(n3233)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam i2740_3_lut.init = 16'hacac;
    CCU2D add_666_3 (.A0(ri[0]), .B0(n9928), .C0(\EMPH[2] ), .D0(n2776), 
          .A1(ri[1]), .B1(n9928), .C1(\EMPH[2] ), .D1(n2786), .CIN(n8229), 
          .COUT(n8230), .S0(ro_7__N_1452[0]), .S1(ro_7__N_1452[1]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_666_3.INIT0 = 16'h56aa;
    defparam add_666_3.INIT1 = 16'h56aa;
    defparam add_666_3.INJECT1_0 = "NO";
    defparam add_666_3.INJECT1_1 = "NO";
    FD1S3AX ro_i1 (.D(ro_7__N_1452[1]), .CK(Clk), .Q(ro[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i1.GSR = "DISABLED";
    FD1S3AX ro_i2 (.D(ro_7__N_1452[2]), .CK(Clk), .Q(ro[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i2.GSR = "DISABLED";
    FD1S3AX ro_i3 (.D(ro_7__N_1452[3]), .CK(Clk), .Q(ro[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i3.GSR = "DISABLED";
    FD1S3AX ro_i4 (.D(ro_7__N_1452[4]), .CK(Clk), .Q(ro[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i4.GSR = "DISABLED";
    FD1S3AX ro_i5 (.D(ro_7__N_1452[5]), .CK(Clk), .Q(ro[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i5.GSR = "DISABLED";
    FD1S3AX ro_i6 (.D(ro_7__N_1452[6]), .CK(Clk), .Q(ro[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i6.GSR = "DISABLED";
    FD1S3AX ro_i7 (.D(ro_7__N_1452[7]), .CK(Clk), .Q(ro[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam ro_i7.GSR = "DISABLED";
    FD1S3AX go_i1 (.D(go_7__N_1460[1]), .CK(Clk), .Q(go[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i1.GSR = "DISABLED";
    FD1S3AX go_i2 (.D(go_7__N_1460[2]), .CK(Clk), .Q(go[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i2.GSR = "DISABLED";
    FD1S3AX go_i3 (.D(go_7__N_1460[3]), .CK(Clk), .Q(go[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i3.GSR = "DISABLED";
    FD1S3AX go_i4 (.D(go_7__N_1460[4]), .CK(Clk), .Q(go[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i4.GSR = "DISABLED";
    FD1S3AX go_i5 (.D(go_7__N_1460[5]), .CK(Clk), .Q(go[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i5.GSR = "DISABLED";
    FD1S3AX go_i6 (.D(go_7__N_1460[6]), .CK(Clk), .Q(go[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i6.GSR = "DISABLED";
    FD1S3AX go_i7 (.D(go_7__N_1460[7]), .CK(Clk), .Q(go[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam go_i7.GSR = "DISABLED";
    FD1S3AX bo_i1 (.D(bo_7__N_1468[1]), .CK(Clk), .Q(bo[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i1.GSR = "DISABLED";
    FD1S3AX bo_i2 (.D(bo_7__N_1468[2]), .CK(Clk), .Q(bo[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i2.GSR = "DISABLED";
    FD1S3AX bo_i3 (.D(bo_7__N_1468[3]), .CK(Clk), .Q(bo[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i3.GSR = "DISABLED";
    FD1S3AX bo_i4 (.D(bo_7__N_1468[4]), .CK(Clk), .Q(bo[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i4.GSR = "DISABLED";
    FD1S3AX bo_i5 (.D(bo_7__N_1468[5]), .CK(Clk), .Q(bo[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i5.GSR = "DISABLED";
    FD1S3AX bo_i6 (.D(bo_7__N_1468[6]), .CK(Clk), .Q(bo[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i6.GSR = "DISABLED";
    FD1S3AX bo_i7 (.D(bo_7__N_1468[7]), .CK(Clk), .Q(bo[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=437, LSE_RLINE=453 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam bo_i7.GSR = "DISABLED";
    LUT4 i2737_3_lut (.A(n1305), .B(bo_7__N_1509[1]), .C(n989), .Z(n3230)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam i2737_3_lut.init = 16'hacac;
    LUT4 i2738_3_lut (.A(n1304), .B(bo_7__N_1509[2]), .C(n989), .Z(n3231)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam i2738_3_lut.init = 16'hacac;
    LUT4 i2518_3_lut (.A(n1306), .B(bo_7__N_1509[0]), .C(n989), .Z(n3006)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam i2518_3_lut.init = 16'hacac;
    LUT4 mux_530_i3_3_lut (.A(ri[5]), .B(ri[4]), .C(n9928), .Z(n2788)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_530_i3_3_lut.init = 16'h3535;
    LUT4 mux_530_i4_3_lut (.A(ri[6]), .B(ri[5]), .C(n9928), .Z(n2790)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_530_i4_3_lut.init = 16'h3535;
    CCU2D add_666_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(n9980), .B1(EMP_G), .C1(EMP_R), .D1(\EMPH[2] ), .COUT(n8229));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_666_1.INIT0 = 16'hF000;
    defparam add_666_1.INIT1 = 16'h0027;
    defparam add_666_1.INJECT1_0 = "NO";
    defparam add_666_1.INJECT1_1 = "NO";
    LUT4 mux_531_i5_3_lut (.A(gi[6]), .B(gi[7]), .C(n9890), .Z(n2784)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_531_i5_3_lut.init = 16'h5353;
    LUT4 i5941_2_lut (.A(bo[0]), .B(PICTURER2), .Z(RGB_c_0)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5941_2_lut.init = 16'h2222;
    CCU2D add_669_9 (.A0(\EMPH[0] ), .B0(\EMPH[2] ), .C0(gi[6]), .D0(GND_net), 
          .A1(\EMPH[0] ), .B1(\EMPH[2] ), .C1(gi[7]), .D1(GND_net), 
          .CIN(n8224), .S0(go_7__N_1460[6]), .S1(go_7__N_1460[7]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_669_9.INIT0 = 16'h1e1e;
    defparam add_669_9.INIT1 = 16'h1e1e;
    defparam add_669_9.INJECT1_0 = "NO";
    defparam add_669_9.INJECT1_1 = "NO";
    LUT4 mux_530_i1_3_lut (.A(ri[3]), .B(ri[2]), .C(n9928), .Z(n2776)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_530_i1_3_lut.init = 16'h3535;
    LUT4 mux_530_i2_3_lut (.A(ri[4]), .B(ri[3]), .C(n9928), .Z(n2786)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_530_i2_3_lut.init = 16'h3535;
    CCU2D add_520_rep_1_9 (.A0(bi[7]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n8237), 
          .S0(n1299));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_520_rep_1_9.INIT0 = 16'h5555;
    defparam add_520_rep_1_9.INIT1 = 16'h0000;
    defparam add_520_rep_1_9.INJECT1_0 = "NO";
    defparam add_520_rep_1_9.INJECT1_1 = "NO";
    LUT4 i8944_2_lut_4_lut (.A(n9979), .B(\EMPH[0] ), .C(\EMPH[2] ), .D(gi[7]), 
         .Z(n6644)) /* synthesis lut_function=(!(A (B (C (D))+!B !(C+!(D)))+!A (B (D)+!B !(C+!(D))))) */ ;
    defparam i8944_2_lut_4_lut.init = 16'h38ff;
    LUT4 i5961_2_lut (.A(bo[1]), .B(PICTURER2), .Z(RGB_c_1)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5961_2_lut.init = 16'h2222;
    LUT4 i5960_2_lut (.A(bo[2]), .B(PICTURER2), .Z(RGB_c_2)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5960_2_lut.init = 16'h2222;
    CCU2D add_520_rep_1_7 (.A0(bi[5]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(bi[6]), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n8236), 
          .COUT(n8237), .S0(n1301), .S1(n1300));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_520_rep_1_7.INIT0 = 16'h5555;
    defparam add_520_rep_1_7.INIT1 = 16'h5555;
    defparam add_520_rep_1_7.INJECT1_0 = "NO";
    defparam add_520_rep_1_7.INJECT1_1 = "NO";
    LUT4 i5959_2_lut (.A(bo[3]), .B(PICTURER2), .Z(RGB_c_3)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5959_2_lut.init = 16'h2222;
    LUT4 i5958_2_lut (.A(bo[4]), .B(PICTURER2), .Z(RGB_c_4)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5958_2_lut.init = 16'h2222;
    LUT4 i5957_2_lut (.A(bo[5]), .B(PICTURER2), .Z(RGB_c_5)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5957_2_lut.init = 16'h2222;
    LUT4 i5956_2_lut (.A(bo[6]), .B(PICTURER2), .Z(RGB_c_6)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5956_2_lut.init = 16'h2222;
    LUT4 i5953_2_lut (.A(bo[7]), .B(PICTURER2), .Z(RGB_c_7)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5953_2_lut.init = 16'h2222;
    LUT4 i5952_2_lut (.A(go[0]), .B(PICTURER2), .Z(RGB_c_8)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5952_2_lut.init = 16'h2222;
    LUT4 R7_I_0_2_lut_rep_294 (.A(R7), .B(TH_MUX), .Z(n9899)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1573[15:26])
    defparam R7_I_0_2_lut_rep_294.init = 16'h8888;
    LUT4 and_36_i1_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[0]), .Z(n91)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1573[15:26])
    defparam and_36_i1_2_lut_3_lut.init = 16'h8080;
    LUT4 and_36_i8_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(\DBIN[7] ), .Z(n84)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1573[15:26])
    defparam and_36_i8_2_lut_3_lut.init = 16'h8080;
    LUT4 and_36_i6_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[5]), .Z(n86)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1573[15:26])
    defparam and_36_i6_2_lut_3_lut.init = 16'h8080;
    LUT4 and_36_i5_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[4]), .Z(n87)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1573[15:26])
    defparam and_36_i5_2_lut_3_lut.init = 16'h8080;
    LUT4 and_36_i4_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[3]), .Z(n88)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1573[15:26])
    defparam and_36_i4_2_lut_3_lut.init = 16'h8080;
    LUT4 mux_531_i3_3_lut (.A(gi[4]), .B(gi[5]), .C(n9890), .Z(n2780)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_531_i3_3_lut.init = 16'h5353;
    LUT4 and_36_i3_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[2]), .Z(n89)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1573[15:26])
    defparam and_36_i3_2_lut_3_lut.init = 16'h8080;
    LUT4 and_36_i2_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[1]), .Z(n90)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1573[15:26])
    defparam and_36_i2_2_lut_3_lut.init = 16'h8080;
    LUT4 i5951_2_lut (.A(go[1]), .B(PICTURER2), .Z(RGB_c_9)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5951_2_lut.init = 16'h2222;
    LUT4 i5950_2_lut (.A(go[2]), .B(PICTURER2), .Z(RGB_c_10)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5950_2_lut.init = 16'h2222;
    LUT4 i5949_2_lut (.A(go[3]), .B(PICTURER2), .Z(RGB_c_11)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5949_2_lut.init = 16'h2222;
    LUT4 i5948_2_lut (.A(go[4]), .B(PICTURER2), .Z(RGB_c_12)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5948_2_lut.init = 16'h2222;
    LUT4 i5940_2_lut (.A(go[5]), .B(PICTURER2), .Z(RGB_c_13)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5940_2_lut.init = 16'h2222;
    LUT4 i5925_2_lut (.A(go[6]), .B(PICTURER2), .Z(RGB_c_14)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5925_2_lut.init = 16'h2222;
    LUT4 i5883_2_lut (.A(go[7]), .B(PICTURER2), .Z(RGB_c_15)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5883_2_lut.init = 16'h2222;
    LUT4 i5864_2_lut (.A(ro[0]), .B(PICTURER2), .Z(RGB_c_16)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5864_2_lut.init = 16'h2222;
    LUT4 i5863_2_lut (.A(ro[1]), .B(PICTURER2), .Z(RGB_c_17)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5863_2_lut.init = 16'h2222;
    LUT4 i5860_2_lut (.A(ro[2]), .B(PICTURER2), .Z(RGB_c_18)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5860_2_lut.init = 16'h2222;
    LUT4 i5859_2_lut (.A(ro[3]), .B(PICTURER2), .Z(RGB_c_19)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5859_2_lut.init = 16'h2222;
    LUT4 i5986_2_lut (.A(ro[4]), .B(PICTURER2), .Z(RGB_c_20)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i5986_2_lut.init = 16'h2222;
    LUT4 i6020_2_lut (.A(ro[5]), .B(PICTURER2), .Z(RGB_c_21)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6020_2_lut.init = 16'h2222;
    PFUMX mux_497_i8 (.BLUT(n3236), .ALUT(n1000[7]), .C0(n8995), .Z(bo_7__N_1468[7]));
    LUT4 i6021_2_lut (.A(ro[6]), .B(PICTURER2), .Z(RGB_c_22)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6021_2_lut.init = 16'h2222;
    LUT4 i6022_2_lut (.A(ro[7]), .B(PICTURER2), .Z(RGB_c_23)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1580[20:74])
    defparam i6022_2_lut.init = 16'h2222;
    PFUMX mux_497_i6 (.BLUT(n3234), .ALUT(n1000[5]), .C0(n8995), .Z(bo_7__N_1468[5]));
    PFUMX mux_497_i7 (.BLUT(n3235), .ALUT(n1000[6]), .C0(n8995), .Z(bo_7__N_1468[6]));
    LUT4 mux_531_i4_3_lut (.A(gi[5]), .B(gi[6]), .C(n9890), .Z(n2782)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_531_i4_3_lut.init = 16'h5353;
    LUT4 mux_531_i1_3_lut (.A(gi[2]), .B(gi[3]), .C(n9890), .Z(n2774)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_531_i1_3_lut.init = 16'h5353;
    PFUMX mux_497_i4 (.BLUT(n3232), .ALUT(n1000[3]), .C0(n8995), .Z(bo_7__N_1468[3]));
    PFUMX mux_497_i5 (.BLUT(n3233), .ALUT(n1000[4]), .C0(n8995), .Z(bo_7__N_1468[4]));
    LUT4 mux_531_i2_3_lut (.A(gi[3]), .B(gi[4]), .C(n9890), .Z(n2778)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam mux_531_i2_3_lut.init = 16'h5353;
    PFUMX mux_497_i2 (.BLUT(n3230), .ALUT(n1000[1]), .C0(n8995), .Z(bo_7__N_1468[1]));
    PFUMX mux_497_i3 (.BLUT(n3231), .ALUT(n1000[2]), .C0(n8995), .Z(bo_7__N_1468[2]));
    PFUMX mux_497_i1 (.BLUT(n3006), .ALUT(n1000[0]), .C0(n8995), .Z(bo_7__N_1468[0]));
    CCU2D add_520_rep_1_5 (.A0(bi[3]), .B0(bi[6]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[4]), .B1(bi[7]), .C1(GND_net), .D1(GND_net), .CIN(n8235), 
          .COUT(n8236), .S0(n1303), .S1(n1302));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_520_rep_1_5.INIT0 = 16'h5999;
    defparam add_520_rep_1_5.INIT1 = 16'h5999;
    defparam add_520_rep_1_5.INJECT1_0 = "NO";
    defparam add_520_rep_1_5.INJECT1_1 = "NO";
    CCU2D add_669_7 (.A0(gi[4]), .B0(\EMPH[2] ), .C0(\EMPH[0] ), .D0(n2784), 
          .A1(gi[5]), .B1(\EMPH[2] ), .C1(\EMPH[0] ), .D1(n6644), .CIN(n8223), 
          .COUT(n8224), .S0(go_7__N_1460[4]), .S1(go_7__N_1460[5]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_669_7.INIT0 = 16'h56aa;
    defparam add_669_7.INIT1 = 16'h56aa;
    defparam add_669_7.INJECT1_0 = "NO";
    defparam add_669_7.INJECT1_1 = "NO";
    CCU2D add_520_rep_1_3 (.A0(bi[1]), .B0(bi[4]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[2]), .B1(bi[5]), .C1(GND_net), .D1(GND_net), .CIN(n8234), 
          .COUT(n8235), .S0(n1305), .S1(n1304));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_520_rep_1_3.INIT0 = 16'h5999;
    defparam add_520_rep_1_3.INIT1 = 16'h5999;
    defparam add_520_rep_1_3.INJECT1_0 = "NO";
    defparam add_520_rep_1_3.INJECT1_1 = "NO";
    CCU2D add_669_5 (.A0(gi[2]), .B0(\EMPH[2] ), .C0(\EMPH[0] ), .D0(n2780), 
          .A1(gi[3]), .B1(\EMPH[2] ), .C1(\EMPH[0] ), .D1(n2782), .CIN(n8222), 
          .COUT(n8223), .S0(go_7__N_1460[2]), .S1(go_7__N_1460[3]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_669_5.INIT0 = 16'h56aa;
    defparam add_669_5.INIT1 = 16'h56aa;
    defparam add_669_5.INJECT1_0 = "NO";
    defparam add_669_5.INJECT1_1 = "NO";
    CCU2D add_520_rep_1_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(bi[0]), .B1(bi[3]), .C1(GND_net), .D1(GND_net), .COUT(n8234), 
          .S1(n1306));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_520_rep_1_1.INIT0 = 16'h0000;
    defparam add_520_rep_1_1.INIT1 = 16'h5999;
    defparam add_520_rep_1_1.INJECT1_0 = "NO";
    defparam add_520_rep_1_1.INJECT1_1 = "NO";
    CCU2D add_669_3 (.A0(gi[0]), .B0(\EMPH[2] ), .C0(\EMPH[0] ), .D0(n2774), 
          .A1(gi[1]), .B1(\EMPH[2] ), .C1(\EMPH[0] ), .D1(n2778), .CIN(n8221), 
          .COUT(n8222), .S0(go_7__N_1460[0]), .S1(go_7__N_1460[1]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1590[7] 1631[14])
    defparam add_669_3.INIT0 = 16'h56aa;
    defparam add_669_3.INIT1 = 16'h56aa;
    defparam add_669_3.INJECT1_0 = "NO";
    defparam add_669_3.INJECT1_1 = "NO";
    PALETTE_RGB_TABLE MOD_PALETTE_RGB_TABLE (.PALSEL({PALSEL}), .PIX({PIX}), 
            .Clk(Clk), .VCC_net(VCC_net), .GND_net(GND_net), .ri({\ri[7] , 
            ri[6:0]}), .gi({gi}), .bi({bi})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1576[19:113])
    PALETTE_RAM C_5__I_0 (.Clk(Clk), .VCC_net(VCC_net), .GND_net(GND_net), 
            .C_5__N_1476(C_5__N_1476), .CGAH(Address[4]), .\CGA[3] (\CGA[3] ), 
            .\CGA[2] (\CGA[2] ), .\CGA[1] (\CGA[1] ), .n9910(n9910), .\DBIN[5] (\DBIN[5] ), 
            .\DBIN[4] (\DBIN[4] ), .\DBIN[3] (\DBIN[3] ), .\DBIN[2] (\DBIN[2] ), 
            .\DBIN[1] (\DBIN[1] ), .\DBIN[0] (\DBIN[0] ), .C({C})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1575[13:100])
    
endmodule
//
// Verilog Description of module PALETTE_RGB_TABLE
//

module PALETTE_RGB_TABLE (PALSEL, PIX, Clk, VCC_net, GND_net, ri, 
            gi, bi) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input [2:0]PALSEL;
    input [5:0]PIX;
    input Clk;
    input VCC_net;
    input GND_net;
    output [7:0]ri;
    output [7:0]gi;
    output [7:0]bi;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    DP8KC PALETTE_RGB_TABLE_0_1_0 (.DIA0(GND_net), .DIA1(GND_net), .DIA2(GND_net), 
          .DIA3(GND_net), .DIA4(GND_net), .DIA5(GND_net), .DIA6(GND_net), 
          .DIA7(GND_net), .DIA8(GND_net), .ADA0(GND_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(PIX[0]), .ADA4(PIX[1]), .ADA5(PIX[2]), 
          .ADA6(PIX[3]), .ADA7(PIX[4]), .ADA8(PIX[5]), .ADA9(PALSEL[0]), 
          .ADA10(PALSEL[1]), .ADA11(PALSEL[2]), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(GND_net), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), 
          .ADB4(GND_net), .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), 
          .ADB8(GND_net), .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), 
          .ADB12(VCC_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(Clk), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(ri[2]), .DOA1(ri[3]), .DOA2(ri[4]), 
          .DOA3(ri[5]), .DOA4(ri[6]), .DOA5(ri[7])) /* synthesis MEM_LPC_FILE="PALETTE_RGB_TABLE.lpc", MEM_INIT_FILE="pal_table.mem", syn_instantiated=1, LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=113, LSE_LLINE=1576, LSE_RLINE=1576 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1576[19:113])
    defparam PALETTE_RGB_TABLE_0_1_0.DATA_WIDTH_A = 9;
    defparam PALETTE_RGB_TABLE_0_1_0.DATA_WIDTH_B = 9;
    defparam PALETTE_RGB_TABLE_0_1_0.REGMODE_A = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_1_0.REGMODE_B = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_1_0.CSDECODE_A = "0b000";
    defparam PALETTE_RGB_TABLE_0_1_0.CSDECODE_B = "0b000";
    defparam PALETTE_RGB_TABLE_0_1_0.WRITEMODE_A = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_1_0.WRITEMODE_B = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_1_0.GSR = "ENABLED";
    defparam PALETTE_RGB_TABLE_0_1_0.RESETMODE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_1_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_1_0.INIT_DATA = "STATIC";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_00 = "0x0000000000000000121603C2604E240341100C2B0000000000000000000701C1302C1501A0600019";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_01 = "0x0000005C2F05E3106A3B07C3F07E3E074360623F0000002613024160402E06C3C0763805A230323F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_02 = "0x0040200400000000181B052320642B03E0E0002B0040200400000000040D0301E03C1901E0400019";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_03 = "0x0040205A2B0542D0663907E3F07E3F0743405C3F004020260D018130403007C3F07E3F0662302A3F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_04 = "0x00000000000000000C1503E260522703610006290000000000000000000601E150321801E0700018";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_05 = "0x000000582A0542D062380783D07A390642F0563F000000240D01A1003C2C06A3C0783604C1C0263F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_06 = "0x0000000000000000161B0543406A2A03005000280000000000000000040D02E1E03C170160000016";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_07 = "0x000000562404A2A0623A07E3F07E3F0702F0503F00000020010080E03C3107E3F07E3F05A1700E3F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_08 = "0x0000001200000000122406C3F07E2D048000002D0000000000000000121B0482D05A24036000001B";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_09 = "0x00000048240242405A3F07E3F07E3F07E3605A3F0000002400024000363607E3F07E3F06C240363F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0A = "0x000000000000000010190442A0562703A1000A2D0000000000000000000A0241603218020080001A";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0B = "0x0000005E2D05A2F0683A0783F07E3B0703405E3F0000002813024170443606E3D07A3A0601F0303F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0C = "0x00402008000000701E3106A3F07E3F05A11000320020100000000000001E0482C05A2E0420D00020";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0D = "0x0080406E2C0542B0663F07E3F07E3F0682E0423F0060303200026140523F07E3F07E3F06A1B0003F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0E = "0x00000000000000000E1303E27052240340D002260000000000000000000601E1502C120160100014";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0F = "0x000000502804E2905A3306E3B0763906A300563A0000001E0E01811036280683B07A3805C2102A3A";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    DP8KC PALETTE_RGB_TABLE_0_0_1 (.DIA0(GND_net), .DIA1(GND_net), .DIA2(GND_net), 
          .DIA3(GND_net), .DIA4(GND_net), .DIA5(GND_net), .DIA6(GND_net), 
          .DIA7(GND_net), .DIA8(GND_net), .ADA0(GND_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(PIX[0]), .ADA4(PIX[1]), .ADA5(PIX[2]), 
          .ADA6(PIX[3]), .ADA7(PIX[4]), .ADA8(PIX[5]), .ADA9(PALSEL[0]), 
          .ADA10(PALSEL[1]), .ADA11(PALSEL[2]), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(GND_net), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(PIX[0]), 
          .ADB4(PIX[1]), .ADB5(PIX[2]), .ADB6(PIX[3]), .ADB7(PIX[4]), 
          .ADB8(PIX[5]), .ADB9(PALSEL[0]), .ADB10(PALSEL[1]), .ADB11(PALSEL[2]), 
          .ADB12(VCC_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(Clk), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(bi[0]), .DOA1(bi[1]), .DOA2(bi[2]), 
          .DOA3(bi[3]), .DOA4(bi[4]), .DOA5(bi[5]), .DOA6(bi[6]), .DOA7(bi[7]), 
          .DOA8(gi[0]), .DOB0(gi[1]), .DOB1(gi[2]), .DOB2(gi[3]), .DOB3(gi[4]), 
          .DOB4(gi[5]), .DOB5(gi[6]), .DOB6(gi[7]), .DOB7(ri[0]), .DOB8(ri[1])) /* synthesis MEM_LPC_FILE="PALETTE_RGB_TABLE.lpc", MEM_INIT_FILE="pal_table.mem", syn_instantiated=1, LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=113, LSE_LLINE=1576, LSE_RLINE=1576 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1576[19:113])
    defparam PALETTE_RGB_TABLE_0_0_1.DATA_WIDTH_A = 9;
    defparam PALETTE_RGB_TABLE_0_0_1.DATA_WIDTH_B = 9;
    defparam PALETTE_RGB_TABLE_0_0_1.REGMODE_A = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_0_1.REGMODE_B = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_0_1.CSDECODE_A = "0b000";
    defparam PALETTE_RGB_TABLE_0_0_1.CSDECODE_B = "0b000";
    defparam PALETTE_RGB_TABLE_0_0_1.WRITEMODE_A = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_0_1.WRITEMODE_B = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_0_1.GSR = "ENABLED";
    defparam PALETTE_RGB_TABLE_0_0_1.RESETMODE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_0_1.ASYNC_RESET_RELEASE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_0_1.INIT_DATA = "STATIC";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_00 = "0x000000008A07C0000100200000BDAE3AFE3191AF000000005522F0020100201000305D1048E0FB65";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_01 = "0x00000373F11A6B8148A4362CB1E2FF3FFFF3FFFF00000099CB2FC3F2180A0586A189FF1FFFF3FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_02 = "0x2130921298255002000020015306E53FEFF3EAAE213092135520400200000010008A8F178C033765";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_03 = "0x2130936EF7193A030F84332C03FFFF3FEFF3FFFF2130909DEA0F5160010020D641A9FF1FFFF3FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_04 = "0x000002038F07D00000000000009BAB3B3EB3A8A6000000015C03F00001002010002E601149B11E60";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_05 = "0x00000363E7187A812A95340B91C2FD3FEFF1FFFF00000094C60EC320070C21F5016CFF1FEFF1FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_06 = "0x00000001A90A5062000000000083981C8FE3DDA1000000005D04500200000000002E7230B9B31858";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_07 = "0x00000158FE1B2B03248631DA93A0FB1FCFE3FDFF00000085FE3494A020002113C321F61FDFE3FDFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_08 = "0x00000048920DA000010020000124FF1FFFF3B6B600000001490012420100200000DA6D3B6DB1256D";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_09 = "0x00000125FF3B76D2936D2939216CFF1FEFF3FFFF00000293FF3B70020100000003FEFF3FEFF1FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0A = "0x00000000912880020100200002C9B93BFEF3A6B4000000005903B08200000000003C671189A3116B";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0B = "0x0000037EF139CB4345A015AC63C3FF1FEFF3FFFF000000A5D210C3E01D0A0526B19BFF3FCFF1FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0C = "0x21309222C42CC15200002011A2BDAA398FF3FEC820B05001660440D001000000003C6A14CBF17480";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0D = "0x223113BAFF1DCB7333A215CB7399EA3FFFF3FEFE21B0D0CDFF35D6A200332BF59333CC3FEFF3FEFE";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0E = "0x00000001850570020100201000B3AD3CBF119D99000000014320100000000000004261116950F551";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0F = "0x00000346E237A9A1087F31BAB1A0F31FFFF1FEEA0000027BD70FA280010001050357FF3FEFF3FEEA";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_10 = "0x000000003707A4127BB334A9921B8D31F9714FD7000000001703A2003C98019822010020000012B2";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_11 = "0x000001B9F82F6FC2F4F50DFEA3CCE71D0EC3E5FF0000004CE32D1EB3CADA0984036C37277440A9FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_12 = "0x108841084209A4F291B934C153138701D9F1615710884108220562D04F1C01C80301003008702AB2";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_13 = "0x108843B6772F97C0F2F30D7E43BFDE3C2E82DFFF1088424E6A0ECF81E26109DBC363AE06D452B1FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_14 = "0x00000100330763F2783204A9931A0B01C9634B53000000001803C220439901F86200003010101430";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_15 = "0x000001B1F22E6F52EDF00D6E41BF5F2B9E02D7FF0000024BDE0CAE90C5D7193BD064B23653C09DFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_16 = "0x00000000340783E1722F2451601E8E0289E052D0000000001903C1F138953190420080104090222C";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_17 = "0x000000ACF21EC773E8EF2D1622BD5E1C2E60D9FF000002435F1D16A1CA592933B26732173443A5FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_18 = "0x00000024490B6490933636D80301002002406D5B000000002409236048A4249122010014800024B6";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_19 = "0x000002936D1FF7F2FFFF3FFED3B7C93B7DB2DBFF000001487F1FE7F1DBED3B7C936D8036D491B7FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1A = "0x000000003B080451833524B1600E0C0259B1545A000000001B042240441B01684000000008001BB5";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1B = "0x000003BF761F07A2EDF12DBE53C3E31C9690DFFF00000252E73D86F1D3ED1A044172BB07C4E3B3FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1C = "0x1088411042094C207A3114B1B237193321E05864104820001703C2403F9512780301800018000040";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1D = "0x110881DDF72F9770E16C2CD622BF5F0BBDD0BF7F10C862666C1D4EC2BF512913D26F3B16FC20957F";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1E = "0x00000000310783F075AE23E9000C0200E93246CC00000000140381E0369210C802018000080012A8";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1F = "0x000003A2EA2DD703DC693C45C3B1D72B2DD2C9750000013C5A2CAE82C6D7091B925D2B161BC39775";
    
endmodule
//
// Verilog Description of module PALETTE_RAM
//

module PALETTE_RAM (Clk, VCC_net, GND_net, C_5__N_1476, CGAH, \CGA[3] , 
            \CGA[2] , \CGA[1] , n9910, \DBIN[5] , \DBIN[4] , \DBIN[3] , 
            \DBIN[2] , \DBIN[1] , \DBIN[0] , C) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input Clk;
    input VCC_net;
    input GND_net;
    input C_5__N_1476;
    input CGAH;
    input \CGA[3] ;
    input \CGA[2] ;
    input \CGA[1] ;
    input n9910;
    input \DBIN[5] ;
    input \DBIN[4] ;
    input \DBIN[3] ;
    input \DBIN[2] ;
    input \DBIN[1] ;
    input \DBIN[0] ;
    output [5:0]C;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    DP8KC PALETTE_RAM_0_0_0 (.DIA0(\DBIN[0] ), .DIA1(\DBIN[1] ), .DIA2(\DBIN[2] ), 
          .DIA3(\DBIN[3] ), .DIA4(\DBIN[4] ), .DIA5(\DBIN[5] ), .DIA6(GND_net), 
          .DIA7(GND_net), .DIA8(GND_net), .ADA0(VCC_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(n9910), .ADA4(\CGA[1] ), .ADA5(\CGA[2] ), 
          .ADA6(\CGA[3] ), .ADA7(CGAH), .ADA8(GND_net), .ADA9(GND_net), 
          .ADA10(GND_net), .ADA11(GND_net), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(C_5__N_1476), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), 
          .ADB4(GND_net), .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), 
          .ADB8(GND_net), .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), 
          .ADB12(GND_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(GND_net), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(C[0]), .DOA1(C[1]), .DOA2(C[2]), .DOA3(C[3]), 
          .DOA4(C[4]), .DOA5(C[5])) /* synthesis MEM_LPC_FILE="PALETTE_RAM.lpc", MEM_INIT_FILE="INIT_ALL_0s", syn_instantiated=1, LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=100, LSE_LLINE=1575, LSE_RLINE=1575 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1575[13:100])
    defparam PALETTE_RAM_0_0_0.DATA_WIDTH_A = 9;
    defparam PALETTE_RAM_0_0_0.DATA_WIDTH_B = 9;
    defparam PALETTE_RAM_0_0_0.REGMODE_A = "NOREG";
    defparam PALETTE_RAM_0_0_0.REGMODE_B = "NOREG";
    defparam PALETTE_RAM_0_0_0.CSDECODE_A = "0b000";
    defparam PALETTE_RAM_0_0_0.CSDECODE_B = "0b111";
    defparam PALETTE_RAM_0_0_0.WRITEMODE_A = "NORMAL";
    defparam PALETTE_RAM_0_0_0.WRITEMODE_B = "NORMAL";
    defparam PALETTE_RAM_0_0_0.GSR = "ENABLED";
    defparam PALETTE_RAM_0_0_0.RESETMODE = "ASYNC";
    defparam PALETTE_RAM_0_0_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam PALETTE_RAM_0_0_0.INIT_DATA = "STATIC";
    defparam PALETTE_RAM_0_0_0.INITVAL_00 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_01 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_02 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_03 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_04 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_05 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_06 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_07 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_08 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_09 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    
endmodule
//
// Verilog Description of module PUR
// module not written out since it is a black-box. 
//

//
// Verilog Description of module OBJ_FIFO
//

module OBJ_FIFO (SEL_LATCH, n10442, CLIPOR, OB, PD_FIFO, Clk, ATR_IN0_2__N_1360, 
            Clk_enable_571, Clk_enable_68, ATR_IN1_2__N_1362, ATR_IN2_2__N_1363, 
            ATR_IN3_2__N_1364, ATR_IN4_2__N_1365, ATR_IN5_2__N_1366, ATR_IN6_2__N_1367, 
            ATR_IN7_2__N_1368, Clk_enable_173, O_HPOS, SH3_N_1381, SH5_N_1385, 
            Clk_enable_560, SH7_N_1390, SPR0HIT_LATCH, SH2, Clk_enable_247, 
            SH2_N_1372, PD_out_7, PD_out_0, PD_out_6, PD_out_1, PD_out_5, 
            PD_out_2, PD_out_4, PD_out_3, Clk_enable_543, \Hnn[5] , 
            \Hnn[4] , \Hnn[3] , ZCOL, Clk_enable_535, n5118, n10432, 
            nVIS, Clk_enable_467) /* synthesis syn_module_defined=1 */ ;
    output [7:0]SEL_LATCH;
    input n10442;
    input CLIPOR;
    input [7:0]OB;
    input PD_FIFO;
    input Clk;
    input ATR_IN0_2__N_1360;
    input Clk_enable_571;
    input Clk_enable_68;
    input ATR_IN1_2__N_1362;
    input ATR_IN2_2__N_1363;
    input ATR_IN3_2__N_1364;
    input ATR_IN4_2__N_1365;
    input ATR_IN5_2__N_1366;
    input ATR_IN6_2__N_1367;
    input ATR_IN7_2__N_1368;
    input Clk_enable_173;
    input O_HPOS;
    input SH3_N_1381;
    input SH5_N_1385;
    input Clk_enable_560;
    input SH7_N_1390;
    output SPR0HIT_LATCH;
    output SH2;
    input Clk_enable_247;
    input SH2_N_1372;
    input PD_out_7;
    input PD_out_0;
    input PD_out_6;
    input PD_out_1;
    input PD_out_5;
    input PD_out_2;
    input PD_out_4;
    input PD_out_3;
    input Clk_enable_543;
    input \Hnn[5] ;
    input \Hnn[4] ;
    input \Hnn[3] ;
    output [4:0]ZCOL;
    input Clk_enable_535;
    input n5118;
    input n10432;
    input nVIS;
    input Clk_enable_467;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire n9883;
    wire [7:0]SDATA;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1346[11:16])
    
    wire n4999, n5000;
    wire [7:0]EN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1336[11:13])
    wire [7:0]QP;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4809, n4806, n9952, n8817, n9880, n6670, n9843, n4825, 
        n6614, n9867, n9916, n9917;
    wire [7:0]CNT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire SH3, n10000, CNT1, ZH_FF, n9999, n10003, CNT1_adj_1786, 
        n10002, n10006, CNT1_adj_1787, n10005, n10009;
    wire [2:0]ATR0;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1331[10:14])
    wire [4:0]n344;
    wire [4:0]ZCOL_4__N_1337;
    
    wire n9275, n9008;
    wire [7:0]COL1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1348[16:20])
    
    wire n61, n59;
    wire [7:0]COL0;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1348[10:14])
    
    wire CNT1_adj_1788, n10008, n10012, CNT1_adj_1789, n10011, n10015, 
        CNT1_adj_1790, n10014, n10018, CNT1_adj_1791, n10017, n10021, 
        CNT1_adj_1792, n10020;
    wire [7:0]CNT_adj_2122;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire n10024, CNT1_adj_1794, ZH_FF_adj_1795, n10023, n10027, CNT1_adj_1797, 
        n10026, n10030, CNT1_adj_1799, n10029, n10033, CNT1_adj_1801, 
        n10032, n10036, CNT1_adj_1803, n10035;
    wire [7:0]QP_adj_2123;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN_adj_2124;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4615, n5001, n5002, n5003, n5004, n4613, n10039, CNT1_adj_1805, 
        n10038, n10042, CNT1_adj_1807, n10041, n5029, n5030, n10045, 
        CNT1_adj_1809, n10044;
    wire [7:0]CNT_adj_2125;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire n10048, CNT1_adj_1811, ZH_FF_adj_1812, n10047, n10051, n4607, 
        n4605, CNT1_adj_1814, n10050, n4601, n9882, n5005, n5006, 
        n4595, n4591, n9915;
    wire [7:0]QP_adj_2126;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN_adj_2127;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4707, n4703, n4699, n10054, n5007, n5008, n5009, n5010, 
        n4695, n4691, n5031, n5032, n5011, n5012, CNT1_adj_1832, 
        n10053, n10057, CNT1_adj_1834, n10056, n10060, CNT1_adj_1836, 
        n10059, n10063, CNT1_adj_1838, n10062, n10066, n4687, CNT1_adj_1842, 
        n10065, n10069, CNT1_adj_1844, n10068, n4683;
    wire [7:0]QP_adj_2128;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN_adj_2129;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4677, n6608;
    wire [7:0]CNT_adj_2130;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire n10072, n4673, n4661, CNT1_adj_1854, ZH_FF_adj_1855, n10071, 
        n4659, n10075, n4655, CNT1_adj_1861, n10074, n4649, n10078, 
        CNT1_adj_1865, n10077, n10081, CNT1_adj_1867, n10080, n10084, 
        CNT1_adj_1869, n10083, n4645, n10087, n9920;
    wire [2:0]ATR1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1331[16:20])
    wire [2:0]ATR2;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1331[22:26])
    
    wire n5013, n5014, CNT1_adj_1873, n10086, n10090, n5015, n5016, 
        n5017, n5018, CNT1_adj_1875, n10089, n10093, CNT1_adj_1877, 
        n10092;
    wire [7:0]CNT_adj_2131;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire n10096, CNT1_adj_1879, ZH_FF_adj_1880, n10095, n10099, CNT1_adj_1882, 
        n10098, n10102, CNT1_adj_1884, n10101, n10105, CNT1_adj_1886, 
        n10104, n6624, n9924, n9839;
    wire [7:0]PD_LATCH;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1328[21:29])
    
    wire n10108, CNT1_adj_1888, n10107, n9918, n10111, CNT1_adj_1890, 
        n10110, n10114, CNT1_adj_1892, n10113, n10117, CNT1_adj_1894, 
        n10116;
    wire [7:0]CNT_adj_2132;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire n10120, CNT1_adj_1896, ZH_FF_adj_1897, n10119;
    wire [2:0]ATR_IN0;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1330[10:17])
    wire [7:0]MIRR_MUX;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1333[11:19])
    
    wire n10123, CNT1_adj_1899, n10122, n10126, CNT1_adj_1901, n10125, 
        MIRR_LATCH, n10129;
    wire [2:0]ATR_IN1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1330[19:26])
    
    wire CNT1_adj_1903, n10128, n10132;
    wire [2:0]ATR_IN2;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1330[28:35])
    wire [2:0]ATR3;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1331[28:32])
    wire [2:0]ATR_IN3;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1330[37:44])
    wire [2:0]ATR4;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1331[34:38])
    wire [2:0]ATR_IN4;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1330[46:53])
    wire [2:0]ATR5;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1331[40:44])
    wire [2:0]ATR_IN5;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1330[55:62])
    wire [2:0]ATR6;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1331[46:50])
    wire [2:0]ATR_IN6;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1330[64:71])
    wire [2:0]ATR7;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1331[52:56])
    wire [2:0]ATR_IN7;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1330[73:80])
    wire [2:0]ZPOS;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1329[10:14])
    
    wire CNT1_adj_1905, n10131, n10135, CNT1_adj_1907, n10134, n10138, 
        CNT1_adj_1909, n10137, n10141;
    wire [7:0]QP_adj_2133;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN_adj_2134;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4803, CNT1_adj_1913, n10140;
    wire [7:0]CNT_adj_2135;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire n10144, CNT1_adj_1915, ZH_FF_adj_1916, n10143, n10147, CNT1_adj_1918, 
        n10146, n10150, CNT1_adj_1920, n10149, SPR_6__N_1274, n33;
    wire [4:0]n326;
    
    wire n10153, CNT1_adj_1922, n10152, n10156, CNT1_adj_1924, n10155, 
        n10159, CNT1_adj_1926, n10158, n10162, CNT1_adj_1928, n10161, 
        n10165, n8930, CNT1_adj_1930, n10164;
    wire [7:0]CNT_adj_2136;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1450[11:14])
    
    wire n10168, CNT1_adj_1932, ZH_FF_adj_1933, n10167, n8932, n10171, 
        CNT1_adj_1935, n10170, n10174, CNT1_adj_1937, n10173, n10177, 
        n4801, CNT1_adj_1941, n10176, n10180, CNT1_adj_1943, n10179, 
        n9840, n10183, CNT1_adj_1945, n10182, n10186, CNT1_adj_1947, 
        n10185, n10189, CNT1_adj_1949, n10188, SH5, SH7, n6551, 
        n8571, n4531, n4532, n4533, n4534, n4539, n4540, n4555, 
        n4556, n4559, n4560, n4563, n4564, n4567, n4568, n4571, 
        n4572, n4573, n4574, n4575, n4576, n4579, n4580, n4581, 
        n4582, n9986, n4583, n4584, n4587, n4588, n4592, n4596, 
        n4602, n4606, n4608, n4614, n4616, n4617, n4618, n4619, 
        n4620, n4623, n4624, n4627, n4628, n4633, n4634, n4635, 
        n4636, n4641, n4642, n4646, n4650, n4656, n4660, n4662, 
        n4674, n4678, n4684, n4688, n4692, n4696, n4700, n4704, 
        n4708, n4709, n4710, n4713, n4714, n4723, n4724, n4735, 
        n4736, n4747, n4748, n4757, n4758, n4765, n4766, n4777, 
        n4778, n4785, n4786, n4791, n4792, n4795, n4796, n4799, 
        n4800, n4802, n4804, n4807, n4810, n4826, n4827, n4828, 
        n4831, n4832, n4833, n4834, n4835, n4836, n4841, n4842, 
        n4843, n4844, n4845, n4846, n4941, n4942, n4943, n4944, 
        n4945, n4946, n4947, n4948, n9879;
    wire [7:0]QP_adj_2137;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN_adj_2138;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4975, n4973, n4971, n6552, n6525, n4969, n4967, n4965, 
        n4963;
    wire [7:0]QP_adj_2139;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN_adj_2140;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4961, n4959, n4957, n4955, n4953, n4951, n4949, n9881;
    wire [7:0]QP_adj_2141;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN_adj_2142;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4997, n4995, n4993, n4991;
    wire [7:0]QP_adj_2143;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN_adj_2144;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4989, n4987, n4985, n4983, n4981, n4979, n4977, n4978, 
        n9841, n4980, n9844;
    wire [7:0]QP_adj_2145;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN_adj_2146;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n9846, n9869, n9871, n9873, n9875, n5135, n3591, n3588, 
        n9877, n3585, n6429, n9842, n9845, n9848, n9870, n9872, 
        n9874, n9876, n9878, n9884;
    wire [7:0]QP_adj_2147;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN_adj_2148;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n5027, n5025, n5023, n5021, n5019;
    wire [7:0]QP_adj_2149;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN_adj_2150;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4982, n4984, n57, n4986;
    wire [4:0]n338;
    wire [4:0]ZCOL_4__N_1152;
    
    wire n9069;
    wire [4:0]n332;
    
    wire n4950, n4952, n4954, n4956, n4958, n4960, n4962, n4964, 
        n4966, n4968, n4970, n4972, n4974, n4976, n5028, n9912;
    wire [7:0]QP_adj_2151;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN_adj_2152;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n10190, n10187, n10184, n10181, n10178, n10175;
    wire [7:0]QP_adj_2153;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN_adj_2154;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n10172, n4988, n4990, n10169, n10166, n10163, n10160, 
        n10157, n10154, n10151, n10148, n10145, n10142, n10139, 
        n4992, n10136, n10133, n10130, n10127, n10124, n10121, 
        n10118, n10115, n10112, n10109, n10106, n9914, n10103;
    wire [7:0]QP_adj_2155;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN_adj_2156;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n10100, n10097, n4994, n10094, n10091, n10088, n10085, 
        n10082, n10079, n10076, n10073, n4998, n10070, n10067, 
        n10064, n10061, n4996, n10058, n10055, n5020, n5022, n10052, 
        n10049, n10046, n10043, n10040, n10037, n10034, n10031, 
        n10028, n5024, n10025, n10022, n10019, n10016, n10013, 
        n9919, n10010;
    wire [7:0]QP_adj_2157;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    wire [7:0]QS_IN_adj_2158;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n10007, n10004, n10001, n5026, Clk_enable_272, n3373, Clk_enable_271, 
        n3396, Clk_enable_270, n3422, n3426, Clk_enable_268, n3427, 
        Clk_enable_265, n3428, Clk_enable_262, Clk_enable_320, n3429;
    
    LUT4 i4491_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[1]), .C(SDATA[3]), 
         .D(n4999), .Z(n5000)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i4491_3_lut_4_lut.init = 16'hf780;
    LUT4 i4300_3_lut_4_lut (.A(n10442), .B(EN[3]), .C(QP[5]), .D(QS_IN[6]), 
         .Z(n4809)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i4300_3_lut_4_lut.init = 16'hf780;
    LUT4 i4297_3_lut_4_lut (.A(n10442), .B(EN[3]), .C(QP[6]), .D(QS_IN[7]), 
         .Z(n4806)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i4297_3_lut_4_lut.init = 16'hf780;
    LUT4 i8858_2_lut_rep_275_3_lut (.A(CLIPOR), .B(n9952), .C(n8817), 
         .Z(n9880)) /* synthesis lut_function=(!((B+(C))+!A)) */ ;
    defparam i8858_2_lut_rep_275_3_lut.init = 16'h0202;
    LUT4 i8859_2_lut_rep_238_3_lut_4_lut (.A(CLIPOR), .B(n9952), .C(n6670), 
         .D(n8817), .Z(n9843)) /* synthesis lut_function=(!((B+((D)+!C))+!A)) */ ;
    defparam i8859_2_lut_rep_238_3_lut_4_lut.init = 16'h0020;
    LUT4 i4316_3_lut_4_lut (.A(n10442), .B(EN[3]), .C(QP[4]), .D(QS_IN[5]), 
         .Z(n4825)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i4316_3_lut_4_lut.init = 16'hf780;
    LUT4 i8690_2_lut_rep_262_3_lut_3_lut_4_lut (.A(CLIPOR), .B(n9952), .C(n6614), 
         .D(n8817), .Z(n9867)) /* synthesis lut_function=(!((B+!(C+(D)))+!A)) */ ;
    defparam i8690_2_lut_rep_262_3_lut_3_lut_4_lut.init = 16'h2220;
    LUT4 i6165_2_lut_rep_311_3_lut (.A(CLIPOR), .B(n9952), .C(n6614), 
         .Z(n9916)) /* synthesis lut_function=(!((B+!(C))+!A)) */ ;
    defparam i6165_2_lut_rep_311_3_lut.init = 16'h2020;
    LUT4 i1_2_lut_rep_312_3_lut (.A(CLIPOR), .B(n9952), .C(n8817), .Z(n9917)) /* synthesis lut_function=(!((B+!(C))+!A)) */ ;
    defparam i1_2_lut_rep_312_3_lut.init = 16'h2020;
    LUT4 i4419_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[1]), .C(CNT[1]), 
         .D(SH3), .Z(n10000)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4419_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4419_3_lut_4_lut_else_4_lut (.A(CNT[1]), .B(CNT1), .C(ZH_FF), 
         .Z(n9999)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4419_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4399_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[4]), .C(CNT[4]), 
         .D(SH3), .Z(n10003)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4399_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4399_3_lut_4_lut_else_4_lut (.A(CNT[4]), .B(CNT1_adj_1786), .C(ZH_FF), 
         .Z(n10002)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4399_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4035_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[7]), .C(CNT[7]), 
         .D(SH3), .Z(n10006)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4035_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4035_3_lut_4_lut_else_4_lut (.A(CNT[7]), .B(CNT1_adj_1787), .C(ZH_FF), 
         .Z(n10005)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4035_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4027_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[6]), .C(CNT[6]), 
         .D(SH3), .Z(n10009)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4027_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 mux_158_i3_3_lut_4_lut (.A(CLIPOR), .B(n9952), .C(ATR0[0]), .D(n344[2]), 
         .Z(ZCOL_4__N_1337[2])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_158_i3_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_158_i5_3_lut_4_lut (.A(CLIPOR), .B(n9952), .C(ATR0[2]), .D(n344[4]), 
         .Z(ZCOL_4__N_1337[4])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_158_i5_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_158_i4_3_lut_4_lut (.A(CLIPOR), .B(n9952), .C(ATR0[1]), .D(n344[3]), 
         .Z(ZCOL_4__N_1337[3])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_158_i4_3_lut_4_lut.init = 16'hf780;
    LUT4 i8794_2_lut_3_lut (.A(CLIPOR), .B(n9952), .C(n9275), .Z(n9008)) /* synthesis lut_function=(A (B+(C))+!A (C)) */ ;
    defparam i8794_2_lut_3_lut.init = 16'hf8f8;
    LUT4 i77_3_lut_4_lut (.A(CLIPOR), .B(n9952), .C(COL1[0]), .D(n61), 
         .Z(n59)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam i77_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_158_i1_3_lut_4_lut (.A(CLIPOR), .B(n9952), .C(COL0[0]), .D(n344[0]), 
         .Z(ZCOL_4__N_1337[0])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_158_i1_3_lut_4_lut.init = 16'hf780;
    LUT4 i4027_3_lut_4_lut_else_4_lut (.A(CNT[6]), .B(CNT1_adj_1788), .C(ZH_FF), 
         .Z(n10008)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4027_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4421_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[5]), .C(CNT[5]), 
         .D(SH3), .Z(n10012)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4421_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4421_3_lut_4_lut_else_4_lut (.A(CNT[5]), .B(CNT1_adj_1789), .C(ZH_FF), 
         .Z(n10011)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4421_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4077_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[3]), .C(CNT[3]), 
         .D(SH3), .Z(n10015)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4077_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4077_3_lut_4_lut_else_4_lut (.A(CNT[3]), .B(CNT1_adj_1790), .C(ZH_FF), 
         .Z(n10014)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4077_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4409_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[0]), .C(CNT[0]), 
         .D(SH3), .Z(n10018)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4409_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4409_3_lut_4_lut_else_4_lut (.A(CNT[0]), .B(CNT1_adj_1791), .C(ZH_FF), 
         .Z(n10017)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4409_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4413_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[6]), .B(OB[2]), .C(CNT[2]), 
         .D(SH3), .Z(n10021)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4413_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4413_3_lut_4_lut_else_4_lut (.A(CNT[2]), .B(CNT1_adj_1792), .C(ZH_FF), 
         .Z(n10020)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[51:78])
    defparam i4413_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4349_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[7]), .C(CNT_adj_2122[7]), 
         .D(SH3), .Z(n10024)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4349_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4349_3_lut_4_lut_else_4_lut (.A(CNT_adj_2122[7]), .B(CNT1_adj_1794), 
         .C(ZH_FF_adj_1795), .Z(n10023)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4349_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4341_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[6]), .C(CNT_adj_2122[6]), 
         .D(SH3), .Z(n10027)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4341_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4341_3_lut_4_lut_else_4_lut (.A(CNT_adj_2122[6]), .B(CNT1_adj_1797), 
         .C(ZH_FF_adj_1795), .Z(n10026)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4341_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4339_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[5]), .C(CNT_adj_2122[5]), 
         .D(SH3), .Z(n10030)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4339_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4339_3_lut_4_lut_else_4_lut (.A(CNT_adj_2122[5]), .B(CNT1_adj_1799), 
         .C(ZH_FF_adj_1795), .Z(n10029)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4339_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4329_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[4]), .C(CNT_adj_2122[4]), 
         .D(SH3), .Z(n10033)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4329_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4329_3_lut_4_lut_else_4_lut (.A(CNT_adj_2122[4]), .B(CNT1_adj_1801), 
         .C(ZH_FF_adj_1795), .Z(n10032)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4329_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4308_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[3]), .C(CNT_adj_2122[3]), 
         .D(SH3), .Z(n10036)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4308_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4308_3_lut_4_lut_else_4_lut (.A(CNT_adj_2122[3]), .B(CNT1_adj_1803), 
         .C(ZH_FF_adj_1795), .Z(n10035)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4308_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4106_3_lut_4_lut (.A(n10442), .B(EN[6]), .C(QP_adj_2123[0]), 
         .D(QS_IN_adj_2124[1]), .Z(n4615)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i4106_3_lut_4_lut.init = 16'hf780;
    LUT4 i4493_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[1]), .C(SDATA[2]), 
         .D(n5001), .Z(n5002)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i4493_3_lut_4_lut.init = 16'hf780;
    LUT4 i4495_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[1]), .C(SDATA[1]), 
         .D(n5003), .Z(n5004)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i4495_3_lut_4_lut.init = 16'hf780;
    LUT4 i4104_3_lut_4_lut (.A(n10442), .B(EN[6]), .C(QP_adj_2123[1]), 
         .D(QS_IN_adj_2124[2]), .Z(n4613)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i4104_3_lut_4_lut.init = 16'hf780;
    LUT4 i4263_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[2]), .C(CNT_adj_2122[2]), 
         .D(SH3), .Z(n10039)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4263_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4263_3_lut_4_lut_else_4_lut (.A(CNT_adj_2122[2]), .B(CNT1_adj_1805), 
         .C(ZH_FF_adj_1795), .Z(n10038)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4263_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4231_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[0]), .C(CNT_adj_2122[0]), 
         .D(SH3), .Z(n10042)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4231_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4231_3_lut_4_lut_else_4_lut (.A(CNT_adj_2122[0]), .B(CNT1_adj_1807), 
         .C(ZH_FF_adj_1795), .Z(n10041)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4231_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4521_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[0]), .C(SDATA[2]), 
         .D(n5029), .Z(n5030)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i4521_3_lut_4_lut.init = 16'hf780;
    LUT4 i4243_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[0]), .B(OB[1]), .C(CNT_adj_2122[1]), 
         .D(SH3), .Z(n10045)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4243_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4243_3_lut_4_lut_else_4_lut (.A(CNT_adj_2122[1]), .B(CNT1_adj_1809), 
         .C(ZH_FF_adj_1795), .Z(n10044)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[51:78])
    defparam i4243_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4351_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[4]), .C(CNT_adj_2125[4]), 
         .D(SH3), .Z(n10048)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i4351_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4351_3_lut_4_lut_else_4_lut (.A(CNT_adj_2125[4]), .B(CNT1_adj_1811), 
         .C(ZH_FF_adj_1812), .Z(n10047)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i4351_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4345_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[3]), .C(CNT_adj_2125[3]), 
         .D(SH3), .Z(n10051)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i4345_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4098_3_lut_4_lut (.A(n10442), .B(EN[6]), .C(QP_adj_2123[2]), 
         .D(QS_IN_adj_2124[3]), .Z(n4607)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i4098_3_lut_4_lut.init = 16'hf780;
    LUT4 i4096_3_lut_4_lut (.A(n10442), .B(EN[6]), .C(QP_adj_2123[3]), 
         .D(QS_IN_adj_2124[4]), .Z(n4605)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i4096_3_lut_4_lut.init = 16'hf780;
    LUT4 i4345_3_lut_4_lut_else_4_lut (.A(CNT_adj_2125[3]), .B(CNT1_adj_1814), 
         .C(ZH_FF_adj_1812), .Z(n10050)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i4345_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4092_3_lut_4_lut (.A(n10442), .B(EN[6]), .C(QP_adj_2123[4]), 
         .D(QS_IN_adj_2124[5]), .Z(n4601)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i4092_3_lut_4_lut.init = 16'hf780;
    LUT4 i4497_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[0]), .C(SDATA[7]), 
         .D(n5005), .Z(n5006)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[53:80])
    defparam i4497_3_lut_4_lut.init = 16'hf780;
    LUT4 i4086_3_lut_4_lut (.A(n10442), .B(EN[6]), .C(QP_adj_2123[5]), 
         .D(QS_IN_adj_2124[6]), .Z(n4595)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i4086_3_lut_4_lut.init = 16'hf780;
    LUT4 i4082_3_lut_4_lut (.A(n10442), .B(EN[6]), .C(QP_adj_2123[6]), 
         .D(QS_IN_adj_2124[7]), .Z(n4591)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i4082_3_lut_4_lut.init = 16'hf780;
    LUT4 PCLK_I_0_313_2_lut_rep_310 (.A(n10442), .B(EN[5]), .Z(n9915)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[30:44])
    defparam PCLK_I_0_313_2_lut_rep_310.init = 16'h8888;
    LUT4 i4198_3_lut_4_lut (.A(n10442), .B(EN[5]), .C(QP_adj_2126[0]), 
         .D(QS_IN_adj_2127[1]), .Z(n4707)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[30:44])
    defparam i4198_3_lut_4_lut.init = 16'hf780;
    LUT4 i4194_3_lut_4_lut (.A(n10442), .B(EN[5]), .C(QP_adj_2126[1]), 
         .D(QS_IN_adj_2127[2]), .Z(n4703)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[30:44])
    defparam i4194_3_lut_4_lut.init = 16'hf780;
    LUT4 i4190_3_lut_4_lut (.A(n10442), .B(EN[5]), .C(QP_adj_2126[2]), 
         .D(QS_IN_adj_2127[3]), .Z(n4699)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[30:44])
    defparam i4190_3_lut_4_lut.init = 16'hf780;
    LUT4 i4331_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[2]), .C(CNT_adj_2125[2]), 
         .D(SH3), .Z(n10054)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i4331_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4499_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[0]), .C(SDATA[6]), 
         .D(n5007), .Z(n5008)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[53:80])
    defparam i4499_3_lut_4_lut.init = 16'hf780;
    LUT4 i4501_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[0]), .C(SDATA[5]), 
         .D(n5009), .Z(n5010)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[53:80])
    defparam i4501_3_lut_4_lut.init = 16'hf780;
    LUT4 i4186_3_lut_4_lut (.A(n10442), .B(EN[5]), .C(QP_adj_2126[3]), 
         .D(QS_IN_adj_2127[4]), .Z(n4695)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[30:44])
    defparam i4186_3_lut_4_lut.init = 16'hf780;
    LUT4 i4182_3_lut_4_lut (.A(n10442), .B(EN[5]), .C(QP_adj_2126[4]), 
         .D(QS_IN_adj_2127[5]), .Z(n4691)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[30:44])
    defparam i4182_3_lut_4_lut.init = 16'hf780;
    LUT4 i4523_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[0]), .C(SDATA[1]), 
         .D(n5031), .Z(n5032)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i4523_3_lut_4_lut.init = 16'hf780;
    LUT4 i4503_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[0]), .C(SDATA[4]), 
         .D(n5011), .Z(n5012)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[53:80])
    defparam i4503_3_lut_4_lut.init = 16'hf780;
    LUT4 i4331_3_lut_4_lut_else_4_lut (.A(CNT_adj_2125[2]), .B(CNT1_adj_1832), 
         .C(ZH_FF_adj_1812), .Z(n10053)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i4331_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4253_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[1]), .C(CNT_adj_2125[1]), 
         .D(SH3), .Z(n10057)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i4253_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4253_3_lut_4_lut_else_4_lut (.A(CNT_adj_2125[1]), .B(CNT1_adj_1834), 
         .C(ZH_FF_adj_1812), .Z(n10056)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i4253_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4223_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[0]), .C(CNT_adj_2125[0]), 
         .D(SH3), .Z(n10060)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i4223_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i6118_3_lut (.A(COL0[1]), .B(EN[1]), .C(COL1[1]), .Z(n6614)) /* synthesis lut_function=(A (B)+!A (B (C))) */ ;
    defparam i6118_3_lut.init = 16'hc8c8;
    LUT4 i4223_3_lut_4_lut_else_4_lut (.A(CNT_adj_2125[0]), .B(CNT1_adj_1836), 
         .C(ZH_FF_adj_1812), .Z(n10059)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i4223_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i3996_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[5]), .C(CNT_adj_2125[5]), 
         .D(SH3), .Z(n10063)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i3996_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i3996_3_lut_4_lut_else_4_lut (.A(CNT_adj_2125[5]), .B(CNT1_adj_1838), 
         .C(ZH_FF_adj_1812), .Z(n10062)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i3996_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4123_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[6]), .C(CNT_adj_2125[6]), 
         .D(SH3), .Z(n10066)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i4123_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4178_3_lut_4_lut (.A(n10442), .B(EN[5]), .C(QP_adj_2126[5]), 
         .D(QS_IN_adj_2127[6]), .Z(n4687)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[30:44])
    defparam i4178_3_lut_4_lut.init = 16'hf780;
    LUT4 i4123_3_lut_4_lut_else_4_lut (.A(CNT_adj_2125[6]), .B(CNT1_adj_1842), 
         .C(ZH_FF_adj_1812), .Z(n10065)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i4123_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4129_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[3]), .B(OB[7]), .C(CNT_adj_2125[7]), 
         .D(SH3), .Z(n10069)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i4129_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4129_3_lut_4_lut_else_4_lut (.A(CNT_adj_2125[7]), .B(CNT1_adj_1844), 
         .C(ZH_FF_adj_1812), .Z(n10068)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[51:78])
    defparam i4129_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4174_3_lut_4_lut (.A(n10442), .B(EN[5]), .C(QP_adj_2126[6]), 
         .D(QS_IN_adj_2127[7]), .Z(n4683)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[30:44])
    defparam i4174_3_lut_4_lut.init = 16'hf780;
    LUT4 i4168_3_lut_4_lut (.A(n10442), .B(EN[5]), .C(QP_adj_2128[0]), 
         .D(QS_IN_adj_2129[1]), .Z(n4677)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[30:44])
    defparam i4168_3_lut_4_lut.init = 16'hf780;
    LUT4 i6112_3_lut (.A(COL0[5]), .B(EN[5]), .C(COL1[5]), .Z(n6608)) /* synthesis lut_function=(A (B)+!A (B (C))) */ ;
    defparam i6112_3_lut.init = 16'hc8c8;
    LUT4 i4225_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[7]), .C(CNT_adj_2130[7]), 
         .D(SH3), .Z(n10072)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4225_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4164_3_lut_4_lut (.A(n10442), .B(EN[5]), .C(QP_adj_2128[1]), 
         .D(QS_IN_adj_2129[2]), .Z(n4673)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[30:44])
    defparam i4164_3_lut_4_lut.init = 16'hf780;
    LUT4 i4152_3_lut_4_lut (.A(n10442), .B(EN[5]), .C(QP_adj_2128[2]), 
         .D(QS_IN_adj_2129[3]), .Z(n4661)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[30:44])
    defparam i4152_3_lut_4_lut.init = 16'hf780;
    LUT4 i4225_3_lut_4_lut_else_4_lut (.A(CNT_adj_2130[7]), .B(CNT1_adj_1854), 
         .C(ZH_FF_adj_1855), .Z(n10071)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4225_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4150_3_lut_4_lut (.A(n10442), .B(EN[5]), .C(QP_adj_2128[3]), 
         .D(QS_IN_adj_2129[4]), .Z(n4659)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[30:44])
    defparam i4150_3_lut_4_lut.init = 16'hf780;
    LUT4 i4221_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[6]), .C(CNT_adj_2130[6]), 
         .D(SH3), .Z(n10075)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4221_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4146_3_lut_4_lut (.A(n10442), .B(EN[5]), .C(QP_adj_2128[4]), 
         .D(QS_IN_adj_2129[5]), .Z(n4655)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[30:44])
    defparam i4146_3_lut_4_lut.init = 16'hf780;
    LUT4 i4221_3_lut_4_lut_else_4_lut (.A(CNT_adj_2130[6]), .B(CNT1_adj_1861), 
         .C(ZH_FF_adj_1855), .Z(n10074)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4221_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4140_3_lut_4_lut (.A(n10442), .B(EN[5]), .C(QP_adj_2128[5]), 
         .D(QS_IN_adj_2129[6]), .Z(n4649)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[30:44])
    defparam i4140_3_lut_4_lut.init = 16'hf780;
    LUT4 i4217_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[5]), .C(CNT_adj_2130[5]), 
         .D(SH3), .Z(n10078)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4217_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4217_3_lut_4_lut_else_4_lut (.A(CNT_adj_2130[5]), .B(CNT1_adj_1865), 
         .C(ZH_FF_adj_1855), .Z(n10077)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4217_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4213_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[4]), .C(CNT_adj_2130[4]), 
         .D(SH3), .Z(n10081)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4213_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4213_3_lut_4_lut_else_4_lut (.A(CNT_adj_2130[4]), .B(CNT1_adj_1867), 
         .C(ZH_FF_adj_1855), .Z(n10080)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4213_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4211_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[3]), .C(CNT_adj_2130[3]), 
         .D(SH3), .Z(n10084)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4211_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4211_3_lut_4_lut_else_4_lut (.A(CNT_adj_2130[3]), .B(CNT1_adj_1869), 
         .C(ZH_FF_adj_1855), .Z(n10083)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4211_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4136_3_lut_4_lut (.A(n10442), .B(EN[5]), .C(QP_adj_2128[6]), 
         .D(QS_IN_adj_2129[7]), .Z(n4645)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[30:44])
    defparam i4136_3_lut_4_lut.init = 16'hf780;
    LUT4 i4209_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[2]), .C(CNT_adj_2130[2]), 
         .D(SH3), .Z(n10087)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4209_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 mux_157_i3_3_lut_4_lut (.A(n6614), .B(n9920), .C(ATR1[0]), .D(ATR2[0]), 
         .Z(n344[2])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_157_i3_3_lut_4_lut.init = 16'hf780;
    LUT4 i4505_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[0]), .C(SDATA[3]), 
         .D(n5013), .Z(n5014)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[53:80])
    defparam i4505_3_lut_4_lut.init = 16'hf780;
    LUT4 i4209_3_lut_4_lut_else_4_lut (.A(CNT_adj_2130[2]), .B(CNT1_adj_1873), 
         .C(ZH_FF_adj_1855), .Z(n10086)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4209_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4189_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[0]), .C(CNT_adj_2130[0]), 
         .D(SH3), .Z(n10090)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4189_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4507_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[0]), .C(SDATA[2]), 
         .D(n5015), .Z(n5016)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[53:80])
    defparam i4507_3_lut_4_lut.init = 16'hf780;
    LUT4 i4509_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[0]), .C(SDATA[1]), 
         .D(n5017), .Z(n5018)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[53:80])
    defparam i4509_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_157_i4_3_lut_4_lut (.A(n6614), .B(n9920), .C(ATR1[1]), .D(ATR2[1]), 
         .Z(n344[3])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_157_i4_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_157_i5_3_lut_4_lut (.A(n6614), .B(n9920), .C(ATR1[2]), .D(ATR2[2]), 
         .Z(n344[4])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_157_i5_3_lut_4_lut.init = 16'hf780;
    LUT4 i4189_3_lut_4_lut_else_4_lut (.A(CNT_adj_2130[0]), .B(CNT1_adj_1875), 
         .C(ZH_FF_adj_1855), .Z(n10089)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4189_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4203_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[1]), .B(OB[1]), .C(CNT_adj_2130[1]), 
         .D(SH3), .Z(n10093)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4203_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4203_3_lut_4_lut_else_4_lut (.A(CNT_adj_2130[1]), .B(CNT1_adj_1877), 
         .C(ZH_FF_adj_1855), .Z(n10092)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[51:78])
    defparam i4203_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4397_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[7]), .C(CNT_adj_2131[7]), 
         .D(SH3), .Z(n10096)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4397_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i2_4_lut (.A(COL0[3]), .B(EN[3]), .C(COL1[3]), .D(n6614), .Z(n6670)) /* synthesis lut_function=(!(A ((D)+!B)+!A (((D)+!C)+!B))) */ ;
    defparam i2_4_lut.init = 16'h00c8;
    LUT4 i4397_3_lut_4_lut_else_4_lut (.A(CNT_adj_2131[7]), .B(CNT1_adj_1879), 
         .C(ZH_FF_adj_1880), .Z(n10095)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4397_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4395_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[6]), .C(CNT_adj_2131[6]), 
         .D(SH3), .Z(n10099)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4395_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4395_3_lut_4_lut_else_4_lut (.A(CNT_adj_2131[6]), .B(CNT1_adj_1882), 
         .C(ZH_FF_adj_1880), .Z(n10098)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4395_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4069_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[5]), .C(CNT_adj_2131[5]), 
         .D(SH3), .Z(n10102)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4069_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4069_3_lut_4_lut_else_4_lut (.A(CNT_adj_2131[5]), .B(CNT1_adj_1884), 
         .C(ZH_FF_adj_1880), .Z(n10101)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4069_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4045_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[4]), .C(CNT_adj_2131[4]), 
         .D(SH3), .Z(n10105)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4045_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4045_3_lut_4_lut_else_4_lut (.A(CNT_adj_2131[4]), .B(CNT1_adj_1886), 
         .C(ZH_FF_adj_1880), .Z(n10104)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4045_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i79_3_lut_4_lut (.A(n6614), .B(n9920), .C(COL1[1]), .D(COL1[2]), 
         .Z(n61)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam i79_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_157_i1_3_lut_4_lut (.A(n6614), .B(n9920), .C(COL0[1]), .D(COL0[2]), 
         .Z(n344[0])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_157_i1_3_lut_4_lut.init = 16'hf780;
    LUT4 i2_4_lut_4_lut (.A(n8817), .B(n9920), .C(n6670), .D(n6614), 
         .Z(n6624)) /* synthesis lut_function=(!(A+((C+(D))+!B))) */ ;
    defparam i2_4_lut_4_lut.init = 16'h0004;
    LUT4 i8691_2_lut_rep_234_3_lut_4_lut_4_lut (.A(n8817), .B(n9920), .C(n9924), 
         .D(n6614), .Z(n9839)) /* synthesis lut_function=(A (B+(C))+!A (B (C+(D))+!B (C))) */ ;
    defparam i8691_2_lut_rep_234_3_lut_4_lut_4_lut.init = 16'hfcf8;
    LUT4 PD_FIFO_I_0_i2_2_lut (.A(PD_FIFO), .B(PD_LATCH[1]), .Z(SDATA[1])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i2_2_lut.init = 16'h8888;
    LUT4 i4425_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[1]), .C(CNT_adj_2131[1]), 
         .D(SH3), .Z(n10108)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4425_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4425_3_lut_4_lut_else_4_lut (.A(CNT_adj_2131[1]), .B(CNT1_adj_1888), 
         .C(ZH_FF_adj_1880), .Z(n10107)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4425_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 PCLK_I_0_315_2_lut_rep_313 (.A(n10442), .B(EN[4]), .Z(n9918)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam PCLK_I_0_315_2_lut_rep_313.init = 16'h8888;
    LUT4 PD_FIFO_I_0_i3_2_lut (.A(PD_FIFO), .B(PD_LATCH[2]), .Z(SDATA[2])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i3_2_lut.init = 16'h8888;
    LUT4 i4423_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[0]), .C(CNT_adj_2131[0]), 
         .D(SH3), .Z(n10111)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4423_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4423_3_lut_4_lut_else_4_lut (.A(CNT_adj_2131[0]), .B(CNT1_adj_1890), 
         .C(ZH_FF_adj_1880), .Z(n10110)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4423_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4411_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[3]), .C(CNT_adj_2131[3]), 
         .D(SH3), .Z(n10114)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4411_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4411_3_lut_4_lut_else_4_lut (.A(CNT_adj_2131[3]), .B(CNT1_adj_1892), 
         .C(ZH_FF_adj_1880), .Z(n10113)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4411_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4429_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[7]), .B(OB[2]), .C(CNT_adj_2131[2]), 
         .D(SH3), .Z(n10117)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4429_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4429_3_lut_4_lut_else_4_lut (.A(CNT_adj_2131[2]), .B(CNT1_adj_1894), 
         .C(ZH_FF_adj_1880), .Z(n10116)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[51:78])
    defparam i4429_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4185_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[7]), .C(CNT_adj_2132[7]), 
         .D(SH3), .Z(n10120)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4185_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4185_3_lut_4_lut_else_4_lut (.A(CNT_adj_2132[7]), .B(CNT1_adj_1896), 
         .C(ZH_FF_adj_1897), .Z(n10119)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4185_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    FD1P3AX ATR_IN0_i0_i0 (.D(OB[0]), .SP(ATR_IN0_2__N_1360), .CK(Clk), 
            .Q(ATR_IN0[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN0_i0_i0.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i0 (.D(MIRR_MUX[0]), .SP(Clk_enable_571), .CK(Clk), 
            .Q(PD_LATCH[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i0.GSR = "DISABLED";
    LUT4 i4177_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[6]), .C(CNT_adj_2132[6]), 
         .D(SH3), .Z(n10123)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4177_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4177_3_lut_4_lut_else_4_lut (.A(CNT_adj_2132[6]), .B(CNT1_adj_1899), 
         .C(ZH_FF_adj_1897), .Z(n10122)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4177_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4171_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[5]), .C(CNT_adj_2132[5]), 
         .D(SH3), .Z(n10126)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4171_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4171_3_lut_4_lut_else_4_lut (.A(CNT_adj_2132[5]), .B(CNT1_adj_1901), 
         .C(ZH_FF_adj_1897), .Z(n10125)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4171_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    FD1P3AX MIRR_LATCH_292 (.D(OB[6]), .SP(Clk_enable_68), .CK(Clk), .Q(MIRR_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam MIRR_LATCH_292.GSR = "DISABLED";
    LUT4 i4163_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[4]), .C(CNT_adj_2132[4]), 
         .D(SH3), .Z(n10129)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4163_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    FD1P3AX ATR0_i0_i0 (.D(ATR_IN0[0]), .SP(Clk_enable_571), .CK(Clk), 
            .Q(ATR0[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR0_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR1_i0_i0 (.D(ATR_IN1[0]), .SP(Clk_enable_571), .CK(Clk), 
            .Q(ATR1[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR1_i0_i0.GSR = "DISABLED";
    LUT4 i4163_3_lut_4_lut_else_4_lut (.A(CNT_adj_2132[4]), .B(CNT1_adj_1903), 
         .C(ZH_FF_adj_1897), .Z(n10128)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4163_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4158_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[3]), .C(CNT_adj_2132[3]), 
         .D(SH3), .Z(n10132)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4158_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    FD1P3AX ATR2_i0_i0 (.D(ATR_IN2[0]), .SP(Clk_enable_571), .CK(Clk), 
            .Q(ATR2[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR2_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR3_i0_i0 (.D(ATR_IN3[0]), .SP(Clk_enable_571), .CK(Clk), 
            .Q(ATR3[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR3_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR4_i0_i0 (.D(ATR_IN4[0]), .SP(Clk_enable_571), .CK(Clk), 
            .Q(ATR4[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR4_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR5_i0_i0 (.D(ATR_IN5[0]), .SP(Clk_enable_571), .CK(Clk), 
            .Q(ATR5[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR5_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR6_i0_i0 (.D(ATR_IN6[0]), .SP(Clk_enable_571), .CK(Clk), 
            .Q(ATR6[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR6_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR7_i0_i0 (.D(ATR_IN7[0]), .SP(Clk_enable_571), .CK(Clk), 
            .Q(ATR7[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR7_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN1_i0_i0 (.D(OB[0]), .SP(ATR_IN1_2__N_1362), .CK(Clk), 
            .Q(ATR_IN1[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN1_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN2_i0_i0 (.D(OB[0]), .SP(ATR_IN2_2__N_1363), .CK(Clk), 
            .Q(ATR_IN2[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN2_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN3_i0_i0 (.D(OB[0]), .SP(ATR_IN3_2__N_1364), .CK(Clk), 
            .Q(ATR_IN3[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN3_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN4_i0_i0 (.D(OB[0]), .SP(ATR_IN4_2__N_1365), .CK(Clk), 
            .Q(ATR_IN4[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN4_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN5_i0_i0 (.D(OB[0]), .SP(ATR_IN5_2__N_1366), .CK(Clk), 
            .Q(ATR_IN5[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN5_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN6_i0_i0 (.D(OB[0]), .SP(ATR_IN6_2__N_1367), .CK(Clk), 
            .Q(ATR_IN6[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN6_i0_i0.GSR = "DISABLED";
    FD1P3AX ATR_IN7_i0_i0 (.D(OB[0]), .SP(ATR_IN7_2__N_1368), .CK(Clk), 
            .Q(ATR_IN7[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN7_i0_i0.GSR = "DISABLED";
    FD1P3AX ZPOS_i0 (.D(O_HPOS), .SP(Clk_enable_173), .CK(Clk), .Q(ZPOS[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ZPOS_i0.GSR = "DISABLED";
    LUT4 i4158_3_lut_4_lut_else_4_lut (.A(CNT_adj_2132[3]), .B(CNT1_adj_1905), 
         .C(ZH_FF_adj_1897), .Z(n10131)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4158_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4145_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[2]), .C(CNT_adj_2132[2]), 
         .D(SH3), .Z(n10135)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4145_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4145_3_lut_4_lut_else_4_lut (.A(CNT_adj_2132[2]), .B(CNT1_adj_1907), 
         .C(ZH_FF_adj_1897), .Z(n10134)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4145_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4131_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[0]), .C(CNT_adj_2132[0]), 
         .D(SH3), .Z(n10138)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4131_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4131_3_lut_4_lut_else_4_lut (.A(CNT_adj_2132[0]), .B(CNT1_adj_1909), 
         .C(ZH_FF_adj_1897), .Z(n10137)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4131_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4135_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[2]), .B(OB[1]), .C(CNT_adj_2132[1]), 
         .D(SH3), .Z(n10141)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4135_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 PD_FIFO_I_0_i1_2_lut (.A(PD_FIFO), .B(PD_LATCH[0]), .Z(SDATA[0])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i1_2_lut.init = 16'h8888;
    LUT4 i4294_3_lut_4_lut (.A(n10442), .B(EN[4]), .C(QP_adj_2133[0]), 
         .D(QS_IN_adj_2134[1]), .Z(n4803)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i4294_3_lut_4_lut.init = 16'hf780;
    LUT4 i4135_3_lut_4_lut_else_4_lut (.A(CNT_adj_2132[1]), .B(CNT1_adj_1913), 
         .C(ZH_FF_adj_1897), .Z(n10140)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[51:78])
    defparam i4135_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i3987_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[7]), .C(CNT_adj_2135[7]), 
         .D(SH3), .Z(n10144)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i3987_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i3987_3_lut_4_lut_else_4_lut (.A(CNT_adj_2135[7]), .B(CNT1_adj_1915), 
         .C(ZH_FF_adj_1916), .Z(n10143)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i3987_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i3975_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[0]), .C(CNT_adj_2135[0]), 
         .D(SH3), .Z(n10147)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i3975_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i3975_3_lut_4_lut_else_4_lut (.A(CNT_adj_2135[0]), .B(CNT1_adj_1918), 
         .C(ZH_FF_adj_1916), .Z(n10146)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i3975_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4271_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[6]), .C(CNT_adj_2135[6]), 
         .D(SH3), .Z(n10150)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i4271_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4271_3_lut_4_lut_else_4_lut (.A(CNT_adj_2135[6]), .B(CNT1_adj_1920), 
         .C(ZH_FF_adj_1916), .Z(n10149)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i4271_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 mux_154_i3_4_lut (.A(ATR6[0]), .B(ATR7[0]), .C(SPR_6__N_1274), 
         .D(n33), .Z(n326[2])) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1383[20] 1385[28])
    defparam mux_154_i3_4_lut.init = 16'hca0a;
    LUT4 i4039_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[5]), .C(CNT_adj_2135[5]), 
         .D(SH3), .Z(n10153)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i4039_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4039_3_lut_4_lut_else_4_lut (.A(CNT_adj_2135[5]), .B(CNT1_adj_1922), 
         .C(ZH_FF_adj_1916), .Z(n10152)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i4039_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4033_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[2]), .C(CNT_adj_2135[2]), 
         .D(SH3), .Z(n10156)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i4033_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4033_3_lut_4_lut_else_4_lut (.A(CNT_adj_2135[2]), .B(CNT1_adj_1924), 
         .C(ZH_FF_adj_1916), .Z(n10155)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i4033_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4037_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[3]), .C(CNT_adj_2135[3]), 
         .D(SH3), .Z(n10159)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i4037_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4037_3_lut_4_lut_else_4_lut (.A(CNT_adj_2135[3]), .B(CNT1_adj_1926), 
         .C(ZH_FF_adj_1916), .Z(n10158)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i4037_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4367_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[1]), .C(CNT_adj_2135[1]), 
         .D(SH3), .Z(n10162)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i4367_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4367_3_lut_4_lut_else_4_lut (.A(CNT_adj_2135[1]), .B(CNT1_adj_1928), 
         .C(ZH_FF_adj_1916), .Z(n10161)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i4367_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4041_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[5]), .B(OB[4]), .C(CNT_adj_2135[4]), 
         .D(SH3), .Z(n10165)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i4041_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i1_4_lut (.A(COL0[6]), .B(n8930), .C(EN[6]), .D(COL1[6]), .Z(SPR_6__N_1274)) /* synthesis lut_function=(A (B+!(C))+!A (B+!(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1374[18:114])
    defparam i1_4_lut.init = 16'hcfdf;
    LUT4 i4041_3_lut_4_lut_else_4_lut (.A(CNT_adj_2135[4]), .B(CNT1_adj_1930), 
         .C(ZH_FF_adj_1916), .Z(n10164)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[51:78])
    defparam i4041_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4014_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[7]), .C(CNT_adj_2136[7]), 
         .D(SH3), .Z(n10168)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4014_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4014_3_lut_4_lut_else_4_lut (.A(CNT_adj_2136[7]), .B(CNT1_adj_1932), 
         .C(ZH_FF_adj_1933), .Z(n10167)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4014_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i2_4_lut_adj_430 (.A(SPR_6__N_1274), .B(COL1[7]), .C(n8932), 
         .D(COL0[7]), .Z(n33)) /* synthesis lut_function=(!((B (C)+!B (C+!(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1374[18:114])
    defparam i2_4_lut_adj_430.init = 16'h0a08;
    LUT4 i4267_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[6]), .C(CNT_adj_2136[6]), 
         .D(SH3), .Z(n10171)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4267_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4267_3_lut_4_lut_else_4_lut (.A(CNT_adj_2136[6]), .B(CNT1_adj_1935), 
         .C(ZH_FF_adj_1933), .Z(n10170)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4267_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4265_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[5]), .C(CNT_adj_2136[5]), 
         .D(SH3), .Z(n10174)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4265_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4265_3_lut_4_lut_else_4_lut (.A(CNT_adj_2136[5]), .B(CNT1_adj_1937), 
         .C(ZH_FF_adj_1933), .Z(n10173)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4265_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 PD_FIFO_I_0_i4_2_lut (.A(PD_FIFO), .B(PD_LATCH[3]), .Z(SDATA[3])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i4_2_lut.init = 16'h8888;
    LUT4 i1_2_lut (.A(EN[7]), .B(n8930), .Z(n8932)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1374[18:114])
    defparam i1_2_lut.init = 16'hdddd;
    LUT4 i4091_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[4]), .C(CNT_adj_2136[4]), 
         .D(SH3), .Z(n10177)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4091_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 PD_FIFO_I_0_i5_2_lut (.A(PD_FIFO), .B(PD_LATCH[4]), .Z(SDATA[4])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i5_2_lut.init = 16'h8888;
    LUT4 i4292_3_lut_4_lut (.A(n10442), .B(EN[4]), .C(QP_adj_2133[1]), 
         .D(QS_IN_adj_2134[2]), .Z(n4801)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i4292_3_lut_4_lut.init = 16'hf780;
    LUT4 i4091_3_lut_4_lut_else_4_lut (.A(CNT_adj_2136[4]), .B(CNT1_adj_1941), 
         .C(ZH_FF_adj_1933), .Z(n10176)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4091_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4357_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[3]), .C(CNT_adj_2136[3]), 
         .D(SH3), .Z(n10180)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4357_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4357_3_lut_4_lut_else_4_lut (.A(CNT_adj_2136[3]), .B(CNT1_adj_1943), 
         .C(ZH_FF_adj_1933), .Z(n10179)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4357_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i1_4_lut_adj_431 (.A(n9840), .B(n6614), .C(n6608), .D(n6670), 
         .Z(n8930)) /* synthesis lut_function=(A+!(B+((D)+!C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1374[18:114])
    defparam i1_4_lut_adj_431.init = 16'haaba;
    LUT4 i4355_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[2]), .C(CNT_adj_2136[2]), 
         .D(SH3), .Z(n10183)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4355_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4355_3_lut_4_lut_else_4_lut (.A(CNT_adj_2136[2]), .B(CNT1_adj_1945), 
         .C(ZH_FF_adj_1933), .Z(n10182)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4355_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 i4343_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[0]), .C(CNT_adj_2136[0]), 
         .D(SH3), .Z(n10186)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4343_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4343_3_lut_4_lut_else_4_lut (.A(CNT_adj_2136[0]), .B(CNT1_adj_1947), 
         .C(ZH_FF_adj_1933), .Z(n10185)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4343_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 mux_154_i4_4_lut (.A(ATR6[1]), .B(n33), .C(SPR_6__N_1274), .D(ATR7[1]), 
         .Z(n326[3])) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1383[20] 1385[28])
    defparam mux_154_i4_4_lut.init = 16'hca0a;
    LUT4 i4353_3_lut_4_lut_then_4_lut (.A(SEL_LATCH[4]), .B(OB[1]), .C(CNT_adj_2136[1]), 
         .D(SH3), .Z(n10189)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4353_3_lut_4_lut_then_4_lut.init = 16'hd8f0;
    LUT4 i4353_3_lut_4_lut_else_4_lut (.A(CNT_adj_2136[1]), .B(CNT1_adj_1949), 
         .C(ZH_FF_adj_1933), .Z(n10188)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[51:78])
    defparam i4353_3_lut_4_lut_else_4_lut.init = 16'hcaca;
    LUT4 mux_154_i5_4_lut (.A(ATR6[2]), .B(ATR7[2]), .C(SPR_6__N_1274), 
         .D(n33), .Z(n326[4])) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1383[20] 1385[28])
    defparam mux_154_i5_4_lut.init = 16'hca0a;
    FD1P3AX SH3_279 (.D(SH3_N_1381), .SP(Clk_enable_173), .CK(Clk), .Q(SH3));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SH3_279.GSR = "DISABLED";
    FD1P3AX SH5_280 (.D(SH5_N_1385), .SP(Clk_enable_173), .CK(Clk), .Q(SH5));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SH5_280.GSR = "DISABLED";
    FD1P3AX ZPOS_i2 (.D(ZPOS[1]), .SP(Clk_enable_173), .CK(Clk), .Q(ZPOS[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ZPOS_i2.GSR = "DISABLED";
    FD1P3AX ZPOS_i1 (.D(ZPOS[0]), .SP(Clk_enable_560), .CK(Clk), .Q(ZPOS[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ZPOS_i1.GSR = "DISABLED";
    FD1P3AX SH7_281 (.D(SH7_N_1390), .SP(Clk_enable_173), .CK(Clk), .Q(SH7));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SH7_281.GSR = "DISABLED";
    LUT4 i6055_4_lut (.A(COL1[6]), .B(COL1[7]), .C(SPR_6__N_1274), .D(n8932), 
         .Z(n6551)) /* synthesis lut_function=(!(A (B (C (D))+!B (C))+!A (((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1367[11:14])
    defparam i6055_4_lut.init = 16'h0aca;
    FD1P3AX ATR_IN7_i0_i2 (.D(OB[5]), .SP(ATR_IN7_2__N_1368), .CK(Clk), 
            .Q(ATR_IN7[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN7_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN7_i0_i1 (.D(OB[1]), .SP(ATR_IN7_2__N_1368), .CK(Clk), 
            .Q(ATR_IN7[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN7_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN6_i0_i2 (.D(OB[5]), .SP(ATR_IN6_2__N_1367), .CK(Clk), 
            .Q(ATR_IN6[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN6_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN6_i0_i1 (.D(OB[1]), .SP(ATR_IN6_2__N_1367), .CK(Clk), 
            .Q(ATR_IN6[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN6_i0_i1.GSR = "DISABLED";
    LUT4 i6126_3_lut_rep_347 (.A(COL0[0]), .B(EN[0]), .C(COL1[0]), .Z(n9952)) /* synthesis lut_function=(A (B)+!A (B (C))) */ ;
    defparam i6126_3_lut_rep_347.init = 16'hc8c8;
    LUT4 i5875_2_lut_rep_315_4_lut (.A(COL0[0]), .B(EN[0]), .C(COL1[0]), 
         .D(CLIPOR), .Z(n9920)) /* synthesis lut_function=(!(A (B+!(D))+!A (B (C+!(D))+!B !(D)))) */ ;
    defparam i5875_2_lut_rep_315_4_lut.init = 16'h3700;
    LUT4 i6173_2_lut_rep_319_4_lut (.A(COL0[0]), .B(EN[0]), .C(COL1[0]), 
         .D(CLIPOR), .Z(n9924)) /* synthesis lut_function=(A (B (D))+!A (B (C (D)))) */ ;
    defparam i6173_2_lut_rep_319_4_lut.init = 16'hc800;
    FD1P3AX SPR0HIT_LATCH_277 (.D(n9924), .SP(Clk_enable_560), .CK(Clk), 
            .Q(SPR0HIT_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SPR0HIT_LATCH_277.GSR = "DISABLED";
    LUT4 i11_4_lut (.A(COL0[6]), .B(COL0[7]), .C(SPR_6__N_1274), .D(n8932), 
         .Z(n8571)) /* synthesis lut_function=(!(A (B (C (D))+!B (C))+!A (((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1383[20] 1385[28])
    defparam i11_4_lut.init = 16'h0aca;
    FD1P3AX SH2_278 (.D(SH2_N_1372), .SP(Clk_enable_247), .CK(Clk), .Q(SH2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SH2_278.GSR = "DISABLED";
    LUT4 PD_7__I_0_i8_3_lut (.A(PD_out_7), .B(PD_out_0), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i8_3_lut.init = 16'hcaca;
    LUT4 PD_7__I_0_i7_3_lut (.A(PD_out_6), .B(PD_out_1), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i7_3_lut.init = 16'hcaca;
    FD1P3AX ATR_IN5_i0_i2 (.D(OB[5]), .SP(ATR_IN5_2__N_1366), .CK(Clk), 
            .Q(ATR_IN5[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN5_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN5_i0_i1 (.D(OB[1]), .SP(ATR_IN5_2__N_1366), .CK(Clk), 
            .Q(ATR_IN5[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN5_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN4_i0_i2 (.D(OB[5]), .SP(ATR_IN4_2__N_1365), .CK(Clk), 
            .Q(ATR_IN4[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN4_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN4_i0_i1 (.D(OB[1]), .SP(ATR_IN4_2__N_1365), .CK(Clk), 
            .Q(ATR_IN4[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN4_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN3_i0_i2 (.D(OB[5]), .SP(ATR_IN3_2__N_1364), .CK(Clk), 
            .Q(ATR_IN3[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN3_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN3_i0_i1 (.D(OB[1]), .SP(ATR_IN3_2__N_1364), .CK(Clk), 
            .Q(ATR_IN3[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN3_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN2_i0_i2 (.D(OB[5]), .SP(ATR_IN2_2__N_1363), .CK(Clk), 
            .Q(ATR_IN2[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN2_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN2_i0_i1 (.D(OB[1]), .SP(ATR_IN2_2__N_1363), .CK(Clk), 
            .Q(ATR_IN2[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN2_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN1_i0_i2 (.D(OB[5]), .SP(ATR_IN1_2__N_1362), .CK(Clk), 
            .Q(ATR_IN1[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN1_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN1_i0_i1 (.D(OB[1]), .SP(ATR_IN1_2__N_1362), .CK(Clk), 
            .Q(ATR_IN1[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN1_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR7_i0_i2 (.D(ATR_IN7[2]), .SP(Clk_enable_247), .CK(Clk), 
            .Q(ATR7[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR7_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR7_i0_i1 (.D(ATR_IN7[1]), .SP(Clk_enable_247), .CK(Clk), 
            .Q(ATR7[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR7_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR6_i0_i2 (.D(ATR_IN6[2]), .SP(Clk_enable_247), .CK(Clk), 
            .Q(ATR6[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR6_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR6_i0_i1 (.D(ATR_IN6[1]), .SP(Clk_enable_247), .CK(Clk), 
            .Q(ATR6[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR6_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR5_i0_i2 (.D(ATR_IN5[2]), .SP(Clk_enable_247), .CK(Clk), 
            .Q(ATR5[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR5_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR5_i0_i1 (.D(ATR_IN5[1]), .SP(Clk_enable_247), .CK(Clk), 
            .Q(ATR5[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR5_i0_i1.GSR = "DISABLED";
    LUT4 PD_7__I_0_i1_3_lut (.A(PD_out_0), .B(PD_out_7), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i1_3_lut.init = 16'hcaca;
    LUT4 PD_7__I_0_i6_3_lut (.A(PD_out_5), .B(PD_out_2), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i6_3_lut.init = 16'hcaca;
    FD1P3AX ATR4_i0_i2 (.D(ATR_IN4[2]), .SP(Clk_enable_247), .CK(Clk), 
            .Q(ATR4[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR4_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR4_i0_i1 (.D(ATR_IN4[1]), .SP(Clk_enable_247), .CK(Clk), 
            .Q(ATR4[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR4_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR3_i0_i2 (.D(ATR_IN3[2]), .SP(Clk_enable_247), .CK(Clk), 
            .Q(ATR3[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR3_i0_i2.GSR = "DISABLED";
    LUT4 PD_7__I_0_i5_3_lut (.A(PD_out_4), .B(PD_out_3), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i5_3_lut.init = 16'hcaca;
    FD1P3AX ATR3_i0_i1 (.D(ATR_IN3[1]), .SP(Clk_enable_247), .CK(Clk), 
            .Q(ATR3[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR3_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR2_i0_i2 (.D(ATR_IN2[2]), .SP(Clk_enable_247), .CK(Clk), 
            .Q(ATR2[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR2_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR2_i0_i1 (.D(ATR_IN2[1]), .SP(Clk_enable_247), .CK(Clk), 
            .Q(ATR2[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR2_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR1_i0_i2 (.D(ATR_IN1[2]), .SP(Clk_enable_543), .CK(Clk), 
            .Q(ATR1[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR1_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR1_i0_i1 (.D(ATR_IN1[1]), .SP(Clk_enable_543), .CK(Clk), 
            .Q(ATR1[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR1_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR0_i0_i2 (.D(ATR_IN0[2]), .SP(Clk_enable_543), .CK(Clk), 
            .Q(ATR0[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR0_i0_i2.GSR = "DISABLED";
    LUT4 PD_7__I_0_i4_3_lut (.A(PD_out_3), .B(PD_out_4), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i4_3_lut.init = 16'hcaca;
    FD1P3AX ATR0_i0_i1 (.D(ATR_IN0[1]), .SP(Clk_enable_543), .CK(Clk), 
            .Q(ATR0[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR0_i0_i1.GSR = "DISABLED";
    LUT4 PD_7__I_0_i3_3_lut (.A(PD_out_2), .B(PD_out_5), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i3_3_lut.init = 16'hcaca;
    LUT4 PD_7__I_0_i2_3_lut (.A(PD_out_1), .B(PD_out_6), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1334[24:96])
    defparam PD_7__I_0_i2_3_lut.init = 16'hcaca;
    FD1P3AX PD_LATCH_i0_i7 (.D(MIRR_MUX[7]), .SP(Clk_enable_543), .CK(Clk), 
            .Q(PD_LATCH[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i7.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i6 (.D(MIRR_MUX[6]), .SP(Clk_enable_543), .CK(Clk), 
            .Q(PD_LATCH[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i6.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i5 (.D(MIRR_MUX[5]), .SP(Clk_enable_543), .CK(Clk), 
            .Q(PD_LATCH[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i5.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i4 (.D(MIRR_MUX[4]), .SP(Clk_enable_543), .CK(Clk), 
            .Q(PD_LATCH[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i4.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i3 (.D(MIRR_MUX[3]), .SP(Clk_enable_543), .CK(Clk), 
            .Q(PD_LATCH[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i3.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i2 (.D(MIRR_MUX[2]), .SP(Clk_enable_543), .CK(Clk), 
            .Q(PD_LATCH[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i2.GSR = "DISABLED";
    FD1P3AX PD_LATCH_i0_i1 (.D(MIRR_MUX[1]), .SP(Clk_enable_543), .CK(Clk), 
            .Q(PD_LATCH[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam PD_LATCH_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_IN0_i0_i2 (.D(OB[5]), .SP(ATR_IN0_2__N_1360), .CK(Clk), 
            .Q(ATR_IN0[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN0_i0_i2.GSR = "DISABLED";
    FD1P3AX ATR_IN0_i0_i1 (.D(OB[1]), .SP(ATR_IN0_2__N_1360), .CK(Clk), 
            .Q(ATR_IN0[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam ATR_IN0_i0_i1.GSR = "DISABLED";
    LUT4 i4023_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[7]), .C(SDATA[7]), 
         .D(n4531), .Z(n4532)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1365[53:80])
    defparam i4023_3_lut_4_lut.init = 16'hf780;
    LUT4 i4025_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[7]), .C(SDATA[6]), 
         .D(n4533), .Z(n4534)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1365[53:80])
    defparam i4025_3_lut_4_lut.init = 16'hf780;
    LUT4 i4031_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[7]), .C(SDATA[5]), 
         .D(n4539), .Z(n4540)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1365[53:80])
    defparam i4031_3_lut_4_lut.init = 16'hf780;
    LUT4 i4047_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[7]), .C(SDATA[4]), 
         .D(n4555), .Z(n4556)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1365[53:80])
    defparam i4047_3_lut_4_lut.init = 16'hf780;
    LUT4 i4051_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[7]), .C(SDATA[3]), 
         .D(n4559), .Z(n4560)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1365[53:80])
    defparam i4051_3_lut_4_lut.init = 16'hf780;
    LUT4 i4055_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[7]), .C(SDATA[2]), 
         .D(n4563), .Z(n4564)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1365[53:80])
    defparam i4055_3_lut_4_lut.init = 16'hf780;
    LUT4 i4059_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[7]), .C(SDATA[1]), 
         .D(n4567), .Z(n4568)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1365[53:80])
    defparam i4059_3_lut_4_lut.init = 16'hf780;
    LUT4 i4063_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[7]), .C(SDATA[7]), 
         .D(n4571), .Z(n4572)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i4063_3_lut_4_lut.init = 16'hf780;
    LUT4 i4065_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[7]), .C(SDATA[6]), 
         .D(n4573), .Z(n4574)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i4065_3_lut_4_lut.init = 16'hf780;
    LUT4 i4067_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[7]), .C(SDATA[5]), 
         .D(n4575), .Z(n4576)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i4067_3_lut_4_lut.init = 16'hf780;
    LUT4 i4071_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[7]), .C(SDATA[4]), 
         .D(n4579), .Z(n4580)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i4071_3_lut_4_lut.init = 16'hf780;
    LUT4 i4073_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[7]), .C(SDATA[3]), 
         .D(n4581), .Z(n4582)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i4073_3_lut_4_lut.init = 16'hf780;
    LUT4 i5918_3_lut_rep_381 (.A(COL0[4]), .B(EN[4]), .C(COL1[4]), .Z(n9986)) /* synthesis lut_function=(A (B)+!A (B (C))) */ ;
    defparam i5918_3_lut_rep_381.init = 16'hc8c8;
    LUT4 i1_2_lut_rep_235_4_lut (.A(COL0[4]), .B(EN[4]), .C(COL1[4]), 
         .D(n6624), .Z(n9840)) /* synthesis lut_function=(A (B+!(D))+!A (B (C+!(D))+!B !(D))) */ ;
    defparam i1_2_lut_rep_235_4_lut.init = 16'hc8ff;
    LUT4 i4075_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[7]), .C(SDATA[2]), 
         .D(n4583), .Z(n4584)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i4075_3_lut_4_lut.init = 16'hf780;
    LUT4 i4079_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[7]), .C(SDATA[1]), 
         .D(n4587), .Z(n4588)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[53:80])
    defparam i4079_3_lut_4_lut.init = 16'hf780;
    LUT4 i4083_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[6]), .C(SDATA[7]), 
         .D(n4591), .Z(n4592)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1363[53:80])
    defparam i4083_3_lut_4_lut.init = 16'hf780;
    LUT4 i4087_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[6]), .C(SDATA[6]), 
         .D(n4595), .Z(n4596)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1363[53:80])
    defparam i4087_3_lut_4_lut.init = 16'hf780;
    LUT4 i4093_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[6]), .C(SDATA[5]), 
         .D(n4601), .Z(n4602)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1363[53:80])
    defparam i4093_3_lut_4_lut.init = 16'hf780;
    LUT4 i4097_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[6]), .C(SDATA[4]), 
         .D(n4605), .Z(n4606)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1363[53:80])
    defparam i4097_3_lut_4_lut.init = 16'hf780;
    LUT4 i4099_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[6]), .C(SDATA[3]), 
         .D(n4607), .Z(n4608)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1363[53:80])
    defparam i4099_3_lut_4_lut.init = 16'hf780;
    LUT4 i4105_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[6]), .C(SDATA[2]), 
         .D(n4613), .Z(n4614)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1363[53:80])
    defparam i4105_3_lut_4_lut.init = 16'hf780;
    LUT4 i4107_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[6]), .C(SDATA[1]), 
         .D(n4615), .Z(n4616)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1363[53:80])
    defparam i4107_3_lut_4_lut.init = 16'hf780;
    LUT4 i4109_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[6]), .C(SDATA[7]), 
         .D(n4617), .Z(n4618)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i4109_3_lut_4_lut.init = 16'hf780;
    LUT4 i4111_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[6]), .C(SDATA[6]), 
         .D(n4619), .Z(n4620)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i4111_3_lut_4_lut.init = 16'hf780;
    LUT4 i4115_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[6]), .C(SDATA[5]), 
         .D(n4623), .Z(n4624)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i4115_3_lut_4_lut.init = 16'hf780;
    LUT4 i4119_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[6]), .C(SDATA[4]), 
         .D(n4627), .Z(n4628)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i4119_3_lut_4_lut.init = 16'hf780;
    LUT4 i4125_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[6]), .C(SDATA[3]), 
         .D(n4633), .Z(n4634)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i4125_3_lut_4_lut.init = 16'hf780;
    LUT4 i4127_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[6]), .C(SDATA[2]), 
         .D(n4635), .Z(n4636)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i4127_3_lut_4_lut.init = 16'hf780;
    LUT4 i4133_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[6]), .C(SDATA[1]), 
         .D(n4641), .Z(n4642)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[53:80])
    defparam i4133_3_lut_4_lut.init = 16'hf780;
    LUT4 i4137_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[5]), .C(SDATA[7]), 
         .D(n4645), .Z(n4646)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i4137_3_lut_4_lut.init = 16'hf780;
    LUT4 i4141_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[5]), .C(SDATA[6]), 
         .D(n4649), .Z(n4650)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i4141_3_lut_4_lut.init = 16'hf780;
    LUT4 i4147_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[5]), .C(SDATA[5]), 
         .D(n4655), .Z(n4656)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i4147_3_lut_4_lut.init = 16'hf780;
    LUT4 i4151_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[5]), .C(SDATA[4]), 
         .D(n4659), .Z(n4660)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i4151_3_lut_4_lut.init = 16'hf780;
    LUT4 i4153_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[5]), .C(SDATA[3]), 
         .D(n4661), .Z(n4662)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i4153_3_lut_4_lut.init = 16'hf780;
    LUT4 i4165_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[5]), .C(SDATA[2]), 
         .D(n4673), .Z(n4674)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i4165_3_lut_4_lut.init = 16'hf780;
    LUT4 i4169_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[5]), .C(SDATA[1]), 
         .D(n4677), .Z(n4678)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1361[53:80])
    defparam i4169_3_lut_4_lut.init = 16'hf780;
    LUT4 i4175_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[5]), .C(SDATA[7]), 
         .D(n4683), .Z(n4684)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i4175_3_lut_4_lut.init = 16'hf780;
    LUT4 i4179_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[5]), .C(SDATA[6]), 
         .D(n4687), .Z(n4688)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i4179_3_lut_4_lut.init = 16'hf780;
    LUT4 i4183_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[5]), .C(SDATA[5]), 
         .D(n4691), .Z(n4692)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i4183_3_lut_4_lut.init = 16'hf780;
    LUT4 i4187_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[5]), .C(SDATA[4]), 
         .D(n4695), .Z(n4696)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i4187_3_lut_4_lut.init = 16'hf780;
    LUT4 i4191_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[5]), .C(SDATA[3]), 
         .D(n4699), .Z(n4700)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i4191_3_lut_4_lut.init = 16'hf780;
    LUT4 i4195_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[5]), .C(SDATA[2]), 
         .D(n4703), .Z(n4704)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i4195_3_lut_4_lut.init = 16'hf780;
    LUT4 i4199_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[5]), .C(SDATA[1]), 
         .D(n4707), .Z(n4708)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[53:80])
    defparam i4199_3_lut_4_lut.init = 16'hf780;
    LUT4 i4201_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[4]), .C(SDATA[7]), 
         .D(n4709), .Z(n4710)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1359[53:80])
    defparam i4201_3_lut_4_lut.init = 16'hf780;
    LUT4 i4205_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[4]), .C(SDATA[6]), 
         .D(n4713), .Z(n4714)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1359[53:80])
    defparam i4205_3_lut_4_lut.init = 16'hf780;
    LUT4 i4215_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[4]), .C(SDATA[5]), 
         .D(n4723), .Z(n4724)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1359[53:80])
    defparam i4215_3_lut_4_lut.init = 16'hf780;
    LUT4 i4227_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[4]), .C(SDATA[4]), 
         .D(n4735), .Z(n4736)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1359[53:80])
    defparam i4227_3_lut_4_lut.init = 16'hf780;
    LUT4 i4239_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[4]), .C(SDATA[3]), 
         .D(n4747), .Z(n4748)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1359[53:80])
    defparam i4239_3_lut_4_lut.init = 16'hf780;
    LUT4 i4249_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[4]), .C(SDATA[2]), 
         .D(n4757), .Z(n4758)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1359[53:80])
    defparam i4249_3_lut_4_lut.init = 16'hf780;
    LUT4 i4257_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[4]), .C(SDATA[1]), 
         .D(n4765), .Z(n4766)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1359[53:80])
    defparam i4257_3_lut_4_lut.init = 16'hf780;
    LUT4 i4269_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[4]), .C(SDATA[7]), 
         .D(n4777), .Z(n4778)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i4269_3_lut_4_lut.init = 16'hf780;
    LUT4 i4277_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[4]), .C(SDATA[6]), 
         .D(n4785), .Z(n4786)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i4277_3_lut_4_lut.init = 16'hf780;
    LUT4 i4283_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[4]), .C(SDATA[5]), 
         .D(n4791), .Z(n4792)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i4283_3_lut_4_lut.init = 16'hf780;
    LUT4 i4287_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[4]), .C(SDATA[4]), 
         .D(n4795), .Z(n4796)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i4287_3_lut_4_lut.init = 16'hf780;
    LUT4 i4291_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[4]), .C(SDATA[3]), 
         .D(n4799), .Z(n4800)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i4291_3_lut_4_lut.init = 16'hf780;
    LUT4 i4293_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[4]), .C(SDATA[2]), 
         .D(n4801), .Z(n4802)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i4293_3_lut_4_lut.init = 16'hf780;
    LUT4 i4295_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[4]), .C(SDATA[1]), 
         .D(n4803), .Z(n4804)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[53:80])
    defparam i4295_3_lut_4_lut.init = 16'hf780;
    LUT4 i4298_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[3]), .C(SDATA[7]), 
         .D(n4806), .Z(n4807)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1357[53:80])
    defparam i4298_3_lut_4_lut.init = 16'hf780;
    LUT4 i4301_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[3]), .C(SDATA[6]), 
         .D(n4809), .Z(n4810)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1357[53:80])
    defparam i4301_3_lut_4_lut.init = 16'hf780;
    LUT4 i4317_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[3]), .C(SDATA[5]), 
         .D(n4825), .Z(n4826)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1357[53:80])
    defparam i4317_3_lut_4_lut.init = 16'hf780;
    LUT4 i4319_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[3]), .C(SDATA[4]), 
         .D(n4827), .Z(n4828)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1357[53:80])
    defparam i4319_3_lut_4_lut.init = 16'hf780;
    LUT4 i4323_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[3]), .C(SDATA[3]), 
         .D(n4831), .Z(n4832)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1357[53:80])
    defparam i4323_3_lut_4_lut.init = 16'hf780;
    LUT4 i4325_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[3]), .C(SDATA[2]), 
         .D(n4833), .Z(n4834)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1357[53:80])
    defparam i4325_3_lut_4_lut.init = 16'hf780;
    LUT4 i4327_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[3]), .C(SDATA[1]), 
         .D(n4835), .Z(n4836)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1357[53:80])
    defparam i4327_3_lut_4_lut.init = 16'hf780;
    LUT4 i4333_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[3]), .C(SDATA[7]), 
         .D(n4841), .Z(n4842)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i4333_3_lut_4_lut.init = 16'hf780;
    LUT4 i4335_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[3]), .C(SDATA[6]), 
         .D(n4843), .Z(n4844)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i4335_3_lut_4_lut.init = 16'hf780;
    LUT4 i4337_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[3]), .C(SDATA[5]), 
         .D(n4845), .Z(n4846)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i4337_3_lut_4_lut.init = 16'hf780;
    LUT4 i4433_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[3]), .C(SDATA[4]), 
         .D(n4941), .Z(n4942)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i4433_3_lut_4_lut.init = 16'hf780;
    LUT4 i4435_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[3]), .C(SDATA[3]), 
         .D(n4943), .Z(n4944)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i4435_3_lut_4_lut.init = 16'hf780;
    LUT4 i4437_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[3]), .C(SDATA[2]), 
         .D(n4945), .Z(n4946)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i4437_3_lut_4_lut.init = 16'hf780;
    LUT4 i4439_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[3]), .C(SDATA[1]), 
         .D(n4947), .Z(n4948)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[53:80])
    defparam i4439_3_lut_4_lut.init = 16'hf780;
    LUT4 PCLK_I_0_319_2_lut_rep_274 (.A(n10442), .B(EN[2]), .Z(n9879)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam PCLK_I_0_319_2_lut_rep_274.init = 16'h8888;
    LUT4 i4466_3_lut_4_lut (.A(n10442), .B(EN[2]), .C(QP_adj_2137[0]), 
         .D(QS_IN_adj_2138[1]), .Z(n4975)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i4466_3_lut_4_lut.init = 16'hf780;
    LUT4 i4464_3_lut_4_lut (.A(n10442), .B(EN[2]), .C(QP_adj_2137[1]), 
         .D(QS_IN_adj_2138[2]), .Z(n4973)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i4464_3_lut_4_lut.init = 16'hf780;
    LUT4 i4462_3_lut_4_lut (.A(n10442), .B(EN[2]), .C(QP_adj_2137[2]), 
         .D(QS_IN_adj_2138[3]), .Z(n4971)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i4462_3_lut_4_lut.init = 16'hf780;
    LUT4 i6030_3_lut_4_lut (.A(n6670), .B(n9880), .C(COL1[3]), .D(n6552), 
         .Z(n6525)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1371[18:87])
    defparam i6030_3_lut_4_lut.init = 16'hf780;
    LUT4 i4460_3_lut_4_lut (.A(n10442), .B(EN[2]), .C(QP_adj_2137[3]), 
         .D(QS_IN_adj_2138[4]), .Z(n4969)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i4460_3_lut_4_lut.init = 16'hf780;
    LUT4 i4458_3_lut_4_lut (.A(n10442), .B(EN[2]), .C(QP_adj_2137[4]), 
         .D(QS_IN_adj_2138[5]), .Z(n4967)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i4458_3_lut_4_lut.init = 16'hf780;
    LUT4 i4456_3_lut_4_lut (.A(n10442), .B(EN[2]), .C(QP_adj_2137[5]), 
         .D(QS_IN_adj_2138[6]), .Z(n4965)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i4456_3_lut_4_lut.init = 16'hf780;
    LUT4 i4454_3_lut_4_lut (.A(n10442), .B(EN[2]), .C(QP_adj_2137[6]), 
         .D(QS_IN_adj_2138[7]), .Z(n4963)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i4454_3_lut_4_lut.init = 16'hf780;
    LUT4 i4452_3_lut_4_lut (.A(n10442), .B(EN[2]), .C(QP_adj_2139[0]), 
         .D(QS_IN_adj_2140[1]), .Z(n4961)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i4452_3_lut_4_lut.init = 16'hf780;
    LUT4 i4450_3_lut_4_lut (.A(n10442), .B(EN[2]), .C(QP_adj_2139[1]), 
         .D(QS_IN_adj_2140[2]), .Z(n4959)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i4450_3_lut_4_lut.init = 16'hf780;
    LUT4 i4448_3_lut_4_lut (.A(n10442), .B(EN[2]), .C(QP_adj_2139[2]), 
         .D(QS_IN_adj_2140[3]), .Z(n4957)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i4448_3_lut_4_lut.init = 16'hf780;
    LUT4 i4446_3_lut_4_lut (.A(n10442), .B(EN[2]), .C(QP_adj_2139[3]), 
         .D(QS_IN_adj_2140[4]), .Z(n4955)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i4446_3_lut_4_lut.init = 16'hf780;
    LUT4 i4444_3_lut_4_lut (.A(n10442), .B(EN[2]), .C(QP_adj_2139[4]), 
         .D(QS_IN_adj_2140[5]), .Z(n4953)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i4444_3_lut_4_lut.init = 16'hf780;
    LUT4 i4442_3_lut_4_lut (.A(n10442), .B(EN[2]), .C(QP_adj_2139[5]), 
         .D(QS_IN_adj_2140[6]), .Z(n4951)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i4442_3_lut_4_lut.init = 16'hf780;
    LUT4 i4440_3_lut_4_lut (.A(n10442), .B(EN[2]), .C(QP_adj_2139[6]), 
         .D(QS_IN_adj_2140[7]), .Z(n4949)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[30:44])
    defparam i4440_3_lut_4_lut.init = 16'hf780;
    LUT4 PCLK_I_0_321_2_lut_rep_276 (.A(n10442), .B(EN[1]), .Z(n9881)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam PCLK_I_0_321_2_lut_rep_276.init = 16'h8888;
    LUT4 i4494_3_lut_4_lut (.A(n10442), .B(EN[1]), .C(QP_adj_2141[0]), 
         .D(QS_IN_adj_2142[1]), .Z(n5003)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i4494_3_lut_4_lut.init = 16'hf780;
    LUT4 i4492_3_lut_4_lut (.A(n10442), .B(EN[1]), .C(QP_adj_2141[1]), 
         .D(QS_IN_adj_2142[2]), .Z(n5001)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i4492_3_lut_4_lut.init = 16'hf780;
    LUT4 i4490_3_lut_4_lut (.A(n10442), .B(EN[1]), .C(QP_adj_2141[2]), 
         .D(QS_IN_adj_2142[3]), .Z(n4999)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i4490_3_lut_4_lut.init = 16'hf780;
    LUT4 i4488_3_lut_4_lut (.A(n10442), .B(EN[1]), .C(QP_adj_2141[3]), 
         .D(QS_IN_adj_2142[4]), .Z(n4997)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i4488_3_lut_4_lut.init = 16'hf780;
    LUT4 i4486_3_lut_4_lut (.A(n10442), .B(EN[1]), .C(QP_adj_2141[4]), 
         .D(QS_IN_adj_2142[5]), .Z(n4995)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i4486_3_lut_4_lut.init = 16'hf780;
    LUT4 i4484_3_lut_4_lut (.A(n10442), .B(EN[1]), .C(QP_adj_2141[5]), 
         .D(QS_IN_adj_2142[6]), .Z(n4993)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i4484_3_lut_4_lut.init = 16'hf780;
    LUT4 i4482_3_lut_4_lut (.A(n10442), .B(EN[1]), .C(QP_adj_2141[6]), 
         .D(QS_IN_adj_2142[7]), .Z(n4991)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i4482_3_lut_4_lut.init = 16'hf780;
    LUT4 i4480_3_lut_4_lut (.A(n10442), .B(EN[1]), .C(QP_adj_2143[0]), 
         .D(QS_IN_adj_2144[1]), .Z(n4989)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i4480_3_lut_4_lut.init = 16'hf780;
    LUT4 i4478_3_lut_4_lut (.A(n10442), .B(EN[1]), .C(QP_adj_2143[1]), 
         .D(QS_IN_adj_2144[2]), .Z(n4987)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i4478_3_lut_4_lut.init = 16'hf780;
    LUT4 i4476_3_lut_4_lut (.A(n10442), .B(EN[1]), .C(QP_adj_2143[2]), 
         .D(QS_IN_adj_2144[3]), .Z(n4985)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i4476_3_lut_4_lut.init = 16'hf780;
    LUT4 i4474_3_lut_4_lut (.A(n10442), .B(EN[1]), .C(QP_adj_2143[3]), 
         .D(QS_IN_adj_2144[4]), .Z(n4983)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i4474_3_lut_4_lut.init = 16'hf780;
    LUT4 i4472_3_lut_4_lut (.A(n10442), .B(EN[1]), .C(QP_adj_2143[4]), 
         .D(QS_IN_adj_2144[5]), .Z(n4981)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i4472_3_lut_4_lut.init = 16'hf780;
    LUT4 i4470_3_lut_4_lut (.A(n10442), .B(EN[1]), .C(QP_adj_2143[5]), 
         .D(QS_IN_adj_2144[6]), .Z(n4979)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i4470_3_lut_4_lut.init = 16'hf780;
    LUT4 i4468_3_lut_4_lut (.A(n10442), .B(EN[1]), .C(QP_adj_2143[6]), 
         .D(QS_IN_adj_2144[7]), .Z(n4977)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[30:44])
    defparam i4468_3_lut_4_lut.init = 16'hf780;
    LUT4 i4469_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[1]), .C(SDATA[7]), 
         .D(n4977), .Z(n4978)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1353[53:80])
    defparam i4469_3_lut_4_lut.init = 16'hf780;
    LUT4 PCLK_I_0_355_2_lut_rep_277 (.A(n10442), .B(SH7), .Z(n9882)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[54:64])
    defparam PCLK_I_0_355_2_lut_rep_277.init = 16'h8888;
    LUT4 COL1_7__N_1253_I_0_328_2_lut_rep_236_3_lut (.A(n10442), .B(SH7), 
         .C(SEL_LATCH[2]), .Z(n9841)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[54:64])
    defparam COL1_7__N_1253_I_0_328_2_lut_rep_236_3_lut.init = 16'h8080;
    LUT4 i4290_3_lut_4_lut (.A(n10442), .B(EN[4]), .C(QP_adj_2133[2]), 
         .D(QS_IN_adj_2134[3]), .Z(n4799)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i4290_3_lut_4_lut.init = 16'hf780;
    LUT4 i4286_3_lut_4_lut (.A(n10442), .B(EN[4]), .C(QP_adj_2133[3]), 
         .D(QS_IN_adj_2134[4]), .Z(n4795)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i4286_3_lut_4_lut.init = 16'hf780;
    LUT4 i4471_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[1]), .C(SDATA[6]), 
         .D(n4979), .Z(n4980)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1353[53:80])
    defparam i4471_3_lut_4_lut.init = 16'hf780;
    LUT4 i4282_3_lut_4_lut (.A(n10442), .B(EN[4]), .C(QP_adj_2133[4]), 
         .D(QS_IN_adj_2134[5]), .Z(n4791)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i4282_3_lut_4_lut.init = 16'hf780;
    LUT4 COL1_7__N_1253_I_0_329_2_lut_rep_239_3_lut (.A(n10442), .B(SH7), 
         .C(SEL_LATCH[1]), .Z(n9844)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[54:64])
    defparam COL1_7__N_1253_I_0_329_2_lut_rep_239_3_lut.init = 16'h8080;
    LUT4 i4276_3_lut_4_lut (.A(n10442), .B(EN[4]), .C(QP_adj_2133[5]), 
         .D(QS_IN_adj_2134[6]), .Z(n4785)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i4276_3_lut_4_lut.init = 16'hf780;
    LUT4 i4268_3_lut_4_lut (.A(n10442), .B(EN[4]), .C(QP_adj_2133[6]), 
         .D(QS_IN_adj_2134[7]), .Z(n4777)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i4268_3_lut_4_lut.init = 16'hf780;
    LUT4 i4256_3_lut_4_lut (.A(n10442), .B(EN[4]), .C(QP_adj_2145[0]), 
         .D(QS_IN_adj_2146[1]), .Z(n4765)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i4256_3_lut_4_lut.init = 16'hf780;
    LUT4 COL1_7__N_1253_I_0_2_lut_rep_241_3_lut (.A(n10442), .B(SH7), .C(SEL_LATCH[0]), 
         .Z(n9846)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[54:64])
    defparam COL1_7__N_1253_I_0_2_lut_rep_241_3_lut.init = 16'h8080;
    LUT4 COL1_7__I_314_2_lut_rep_264_3_lut (.A(n10442), .B(SH7), .C(SEL_LATCH[7]), 
         .Z(n9869)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[54:64])
    defparam COL1_7__I_314_2_lut_rep_264_3_lut.init = 16'h8080;
    LUT4 COL1_7__N_1253_I_0_324_2_lut_rep_266_3_lut (.A(n10442), .B(SH7), 
         .C(SEL_LATCH[6]), .Z(n9871)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[54:64])
    defparam COL1_7__N_1253_I_0_324_2_lut_rep_266_3_lut.init = 16'h8080;
    LUT4 COL1_7__N_1253_I_0_325_2_lut_rep_268_3_lut (.A(n10442), .B(SH7), 
         .C(SEL_LATCH[5]), .Z(n9873)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[54:64])
    defparam COL1_7__N_1253_I_0_325_2_lut_rep_268_3_lut.init = 16'h8080;
    LUT4 COL1_7__N_1253_I_0_326_2_lut_rep_270_3_lut (.A(n10442), .B(SH7), 
         .C(SEL_LATCH[4]), .Z(n9875)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[54:64])
    defparam COL1_7__N_1253_I_0_326_2_lut_rep_270_3_lut.init = 16'h8080;
    LUT4 i8951_2_lut (.A(n10442), .B(\Hnn[5] ), .Z(n5135)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i8951_2_lut.init = 16'h1111;
    LUT4 i1_2_lut_adj_432 (.A(\Hnn[4] ), .B(\Hnn[3] ), .Z(n3591)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1405[27:43])
    defparam i1_2_lut_adj_432.init = 16'h8888;
    LUT4 i1_2_lut_adj_433 (.A(\Hnn[4] ), .B(\Hnn[3] ), .Z(n3588)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1404[26:43])
    defparam i1_2_lut_adj_433.init = 16'h2222;
    LUT4 COL1_7__N_1253_I_0_327_2_lut_rep_272_3_lut (.A(n10442), .B(SH7), 
         .C(SEL_LATCH[3]), .Z(n9877)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[54:64])
    defparam COL1_7__N_1253_I_0_327_2_lut_rep_272_3_lut.init = 16'h8080;
    LUT4 i1_2_lut_adj_434 (.A(\Hnn[3] ), .B(\Hnn[4] ), .Z(n3585)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1403[27:43])
    defparam i1_2_lut_adj_434.init = 16'h2222;
    LUT4 i8823_2_lut (.A(\Hnn[3] ), .B(\Hnn[4] ), .Z(n6429)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i8823_2_lut.init = 16'h1111;
    LUT4 PCLK_I_0_310_2_lut_rep_278 (.A(n10442), .B(SH5), .Z(n9883)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[54:64])
    defparam PCLK_I_0_310_2_lut_rep_278.init = 16'h8888;
    LUT4 COL0_7__N_1237_I_0_320_2_lut_rep_237_3_lut (.A(n10442), .B(SH5), 
         .C(SEL_LATCH[2]), .Z(n9842)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[54:64])
    defparam COL0_7__N_1237_I_0_320_2_lut_rep_237_3_lut.init = 16'h8080;
    LUT4 COL0_7__N_1237_I_0_322_2_lut_rep_240_3_lut (.A(n10442), .B(SH5), 
         .C(SEL_LATCH[1]), .Z(n9845)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[54:64])
    defparam COL0_7__N_1237_I_0_322_2_lut_rep_240_3_lut.init = 16'h8080;
    LUT4 COL0_7__N_1237_I_0_2_lut_rep_243_3_lut (.A(n10442), .B(SH5), .C(SEL_LATCH[0]), 
         .Z(n9848)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[54:64])
    defparam COL0_7__N_1237_I_0_2_lut_rep_243_3_lut.init = 16'h8080;
    LUT4 COL0_7__I_313_2_lut_rep_265_3_lut (.A(n10442), .B(SH5), .C(SEL_LATCH[7]), 
         .Z(n9870)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[54:64])
    defparam COL0_7__I_313_2_lut_rep_265_3_lut.init = 16'h8080;
    LUT4 COL0_7__N_1237_I_0_312_2_lut_rep_267_3_lut (.A(n10442), .B(SH5), 
         .C(SEL_LATCH[6]), .Z(n9872)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[54:64])
    defparam COL0_7__N_1237_I_0_312_2_lut_rep_267_3_lut.init = 16'h8080;
    LUT4 COL0_7__N_1237_I_0_314_2_lut_rep_269_3_lut (.A(n10442), .B(SH5), 
         .C(SEL_LATCH[5]), .Z(n9874)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[54:64])
    defparam COL0_7__N_1237_I_0_314_2_lut_rep_269_3_lut.init = 16'h8080;
    LUT4 COL0_7__N_1237_I_0_316_2_lut_rep_271_3_lut (.A(n10442), .B(SH5), 
         .C(SEL_LATCH[4]), .Z(n9876)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[54:64])
    defparam COL0_7__N_1237_I_0_316_2_lut_rep_271_3_lut.init = 16'h8080;
    LUT4 COL0_7__N_1237_I_0_318_2_lut_rep_273_3_lut (.A(n10442), .B(SH5), 
         .C(SEL_LATCH[3]), .Z(n9878)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[54:64])
    defparam COL0_7__N_1237_I_0_318_2_lut_rep_273_3_lut.init = 16'h8080;
    LUT4 PCLK_I_0_323_2_lut_rep_279 (.A(n10442), .B(EN[0]), .Z(n9884)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam PCLK_I_0_323_2_lut_rep_279.init = 16'h8888;
    LUT4 i4522_3_lut_4_lut (.A(n10442), .B(EN[0]), .C(QP_adj_2147[0]), 
         .D(QS_IN_adj_2148[1]), .Z(n5031)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i4522_3_lut_4_lut.init = 16'hf780;
    LUT4 i4520_3_lut_4_lut (.A(n10442), .B(EN[0]), .C(QP_adj_2147[1]), 
         .D(QS_IN_adj_2148[2]), .Z(n5029)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i4520_3_lut_4_lut.init = 16'hf780;
    LUT4 i4518_3_lut_4_lut (.A(n10442), .B(EN[0]), .C(QP_adj_2147[2]), 
         .D(QS_IN_adj_2148[3]), .Z(n5027)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i4518_3_lut_4_lut.init = 16'hf780;
    LUT4 i4516_3_lut_4_lut (.A(n10442), .B(EN[0]), .C(QP_adj_2147[3]), 
         .D(QS_IN_adj_2148[4]), .Z(n5025)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i4516_3_lut_4_lut.init = 16'hf780;
    LUT4 i4514_3_lut_4_lut (.A(n10442), .B(EN[0]), .C(QP_adj_2147[4]), 
         .D(QS_IN_adj_2148[5]), .Z(n5023)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i4514_3_lut_4_lut.init = 16'hf780;
    LUT4 i4512_3_lut_4_lut (.A(n10442), .B(EN[0]), .C(QP_adj_2147[5]), 
         .D(QS_IN_adj_2148[6]), .Z(n5021)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i4512_3_lut_4_lut.init = 16'hf780;
    LUT4 i4510_3_lut_4_lut (.A(n10442), .B(EN[0]), .C(QP_adj_2147[6]), 
         .D(QS_IN_adj_2148[7]), .Z(n5019)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i4510_3_lut_4_lut.init = 16'hf780;
    LUT4 i4508_3_lut_4_lut (.A(n10442), .B(EN[0]), .C(QP_adj_2149[0]), 
         .D(QS_IN_adj_2150[1]), .Z(n5017)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i4508_3_lut_4_lut.init = 16'hf780;
    LUT4 i4506_3_lut_4_lut (.A(n10442), .B(EN[0]), .C(QP_adj_2149[1]), 
         .D(QS_IN_adj_2150[2]), .Z(n5015)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i4506_3_lut_4_lut.init = 16'hf780;
    LUT4 i4504_3_lut_4_lut (.A(n10442), .B(EN[0]), .C(QP_adj_2149[2]), 
         .D(QS_IN_adj_2150[3]), .Z(n5013)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i4504_3_lut_4_lut.init = 16'hf780;
    LUT4 i4502_3_lut_4_lut (.A(n10442), .B(EN[0]), .C(QP_adj_2149[3]), 
         .D(QS_IN_adj_2150[4]), .Z(n5011)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i4502_3_lut_4_lut.init = 16'hf780;
    LUT4 i4500_3_lut_4_lut (.A(n10442), .B(EN[0]), .C(QP_adj_2149[4]), 
         .D(QS_IN_adj_2150[5]), .Z(n5009)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i4500_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_FIFO_I_0_i8_2_lut (.A(PD_FIFO), .B(PD_LATCH[7]), .Z(SDATA[7])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i8_2_lut.init = 16'h8888;
    LUT4 i4498_3_lut_4_lut (.A(n10442), .B(EN[0]), .C(QP_adj_2149[5]), 
         .D(QS_IN_adj_2150[6]), .Z(n5007)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i4498_3_lut_4_lut.init = 16'hf780;
    LUT4 i4496_3_lut_4_lut (.A(n10442), .B(EN[0]), .C(QP_adj_2149[6]), 
         .D(QS_IN_adj_2150[7]), .Z(n5005)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[30:44])
    defparam i4496_3_lut_4_lut.init = 16'hf780;
    LUT4 i4473_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[1]), .C(SDATA[5]), 
         .D(n4981), .Z(n4982)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1353[53:80])
    defparam i4473_3_lut_4_lut.init = 16'hf780;
    LUT4 i4475_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[1]), .C(SDATA[4]), 
         .D(n4983), .Z(n4984)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1353[53:80])
    defparam i4475_3_lut_4_lut.init = 16'hf780;
    LUT4 i8650_3_lut_4_lut (.A(n9924), .B(n9867), .C(n59), .D(n6551), 
         .Z(n57)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1378[20] 1385[28])
    defparam i8650_3_lut_4_lut.init = 16'hf1e0;
    LUT4 i4477_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[1]), .C(SDATA[3]), 
         .D(n4985), .Z(n4986)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1353[53:80])
    defparam i4477_3_lut_4_lut.init = 16'hf780;
    L6MUX21 ZCOL_4__I_0_i3 (.D0(n338[2]), .D1(ZCOL_4__N_1152[2]), .SD(n9008), 
            .Z(ZCOL[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;
    L6MUX21 ZCOL_4__I_0_i4 (.D0(n338[3]), .D1(ZCOL_4__N_1152[3]), .SD(n9008), 
            .Z(ZCOL[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;
    LUT4 i8645_3_lut_4_lut (.A(n9924), .B(n9867), .C(ZCOL_4__N_1337[0]), 
         .D(n8571), .Z(ZCOL_4__N_1152[0])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1378[20] 1385[28])
    defparam i8645_3_lut_4_lut.init = 16'hf1e0;
    LUT4 i8793_4_lut_4_lut (.A(n9843), .B(n9069), .C(n9917), .D(n9916), 
         .Z(n9275)) /* synthesis lut_function=(A (C+(D))+!A (B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1371[18:87])
    defparam i8793_4_lut_4_lut.init = 16'hfff4;
    LUT4 i8519_3_lut_4_lut_3_lut (.A(n9986), .B(n6624), .C(n6608), .Z(n9069)) /* synthesis lut_function=(!(A (B)+!A (B (C)))) */ ;
    defparam i8519_3_lut_4_lut_3_lut.init = 16'h3737;
    LUT4 i6056_3_lut_4_lut (.A(n9986), .B(n6624), .C(COL1[4]), .D(COL1[5]), 
         .Z(n6552)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam i6056_3_lut_4_lut.init = 16'hf780;
    L6MUX21 ZCOL_4__I_0_i5 (.D0(n338[4]), .D1(ZCOL_4__N_1152[4]), .SD(n9008), 
            .Z(ZCOL[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;
    LUT4 mux_155_i1_3_lut_4_lut (.A(n9986), .B(n6624), .C(COL0[4]), .D(COL0[5]), 
         .Z(n332[0])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_155_i1_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_155_i3_3_lut_4_lut (.A(n9986), .B(n6624), .C(ATR4[0]), .D(ATR5[0]), 
         .Z(n332[2])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_155_i3_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_155_i4_3_lut_4_lut (.A(n9986), .B(n6624), .C(ATR4[1]), .D(ATR5[1]), 
         .Z(n332[3])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_155_i4_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_155_i5_3_lut_4_lut (.A(n9986), .B(n6624), .C(ATR4[2]), .D(ATR5[2]), 
         .Z(n332[4])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;
    defparam mux_155_i5_3_lut_4_lut.init = 16'hf780;
    PFUMX ZCOL_4__I_359_i3 (.BLUT(n326[2]), .ALUT(ZCOL_4__N_1337[2]), .C0(n9839), 
          .Z(ZCOL_4__N_1152[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;
    PFUMX ZCOL_4__I_359_i4 (.BLUT(n326[3]), .ALUT(ZCOL_4__N_1337[3]), .C0(n9839), 
          .Z(ZCOL_4__N_1152[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;
    PFUMX ZCOL_4__I_359_i5 (.BLUT(n326[4]), .ALUT(ZCOL_4__N_1337[4]), .C0(n9839), 
          .Z(ZCOL_4__N_1152[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;
    LUT4 i4441_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[2]), .C(SDATA[7]), 
         .D(n4949), .Z(n4950)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1355[53:80])
    defparam i4441_3_lut_4_lut.init = 16'hf780;
    LUT4 i4443_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[2]), .C(SDATA[6]), 
         .D(n4951), .Z(n4952)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1355[53:80])
    defparam i4443_3_lut_4_lut.init = 16'hf780;
    PFUMX i20 (.BLUT(n6525), .ALUT(n57), .C0(n9008), .Z(ZCOL[1]));
    LUT4 i4445_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[2]), .C(SDATA[5]), 
         .D(n4953), .Z(n4954)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1355[53:80])
    defparam i4445_3_lut_4_lut.init = 16'hf780;
    PFUMX ZCOL_4__I_0_i1 (.BLUT(n338[0]), .ALUT(ZCOL_4__N_1152[0]), .C0(n9008), 
          .Z(ZCOL[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;
    PFUMX mux_156_i3 (.BLUT(n332[2]), .ALUT(ATR3[0]), .C0(n9843), .Z(n338[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;
    LUT4 i4447_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[2]), .C(SDATA[4]), 
         .D(n4955), .Z(n4956)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1355[53:80])
    defparam i4447_3_lut_4_lut.init = 16'hf780;
    PFUMX mux_156_i4 (.BLUT(n332[3]), .ALUT(ATR3[1]), .C0(n9843), .Z(n338[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;
    LUT4 i4449_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[2]), .C(SDATA[3]), 
         .D(n4957), .Z(n4958)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1355[53:80])
    defparam i4449_3_lut_4_lut.init = 16'hf780;
    LUT4 i4451_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[2]), .C(SDATA[2]), 
         .D(n4959), .Z(n4960)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1355[53:80])
    defparam i4451_3_lut_4_lut.init = 16'hf780;
    LUT4 i4453_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[2]), .C(SDATA[1]), 
         .D(n4961), .Z(n4962)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1355[53:80])
    defparam i4453_3_lut_4_lut.init = 16'hf780;
    PFUMX mux_156_i5 (.BLUT(n332[4]), .ALUT(ATR3[2]), .C0(n9843), .Z(n338[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;
    LUT4 i4455_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[2]), .C(SDATA[7]), 
         .D(n4963), .Z(n4964)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i4455_3_lut_4_lut.init = 16'hf780;
    LUT4 i4457_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[2]), .C(SDATA[6]), 
         .D(n4965), .Z(n4966)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i4457_3_lut_4_lut.init = 16'hf780;
    LUT4 i4459_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[2]), .C(SDATA[5]), 
         .D(n4967), .Z(n4968)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i4459_3_lut_4_lut.init = 16'hf780;
    LUT4 i4461_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[2]), .C(SDATA[4]), 
         .D(n4969), .Z(n4970)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i4461_3_lut_4_lut.init = 16'hf780;
    LUT4 i4463_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[2]), .C(SDATA[3]), 
         .D(n4971), .Z(n4972)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i4463_3_lut_4_lut.init = 16'hf780;
    LUT4 i4465_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[2]), .C(SDATA[2]), 
         .D(n4973), .Z(n4974)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i4465_3_lut_4_lut.init = 16'hf780;
    LUT4 i4467_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[2]), .C(SDATA[1]), 
         .D(n4975), .Z(n4976)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[53:80])
    defparam i4467_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_156_i1_3_lut_4_lut (.A(n6670), .B(n9880), .C(COL0[3]), .D(n332[0]), 
         .Z(n338[0])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1371[18:87])
    defparam mux_156_i1_3_lut_4_lut.init = 16'hf780;
    LUT4 i2_4_lut_adj_435 (.A(EN[2]), .B(COL0[2]), .C(n6614), .D(COL1[2]), 
         .Z(n8817)) /* synthesis lut_function=(!((B (C)+!B (C+!(D)))+!A)) */ ;
    defparam i2_4_lut_adj_435.init = 16'h0a08;
    LUT4 i4519_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[0]), .C(SDATA[3]), 
         .D(n5027), .Z(n5028)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i4519_3_lut_4_lut.init = 16'hf780;
    LUT4 PCLK_I_0_309_2_lut_rep_307 (.A(n10442), .B(EN[7]), .Z(n9912)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam PCLK_I_0_309_2_lut_rep_307.init = 16'h8888;
    LUT4 i4318_3_lut_4_lut (.A(n10442), .B(EN[3]), .C(QP[3]), .D(QS_IN[4]), 
         .Z(n4827)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i4318_3_lut_4_lut.init = 16'hf780;
    LUT4 i4078_3_lut_4_lut (.A(n10442), .B(EN[7]), .C(QP_adj_2151[0]), 
         .D(QS_IN_adj_2152[1]), .Z(n4587)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i4078_3_lut_4_lut.init = 16'hf780;
    PFUMX i9161 (.BLUT(n10188), .ALUT(n10189), .C0(n10442), .Z(n10190));
    LUT4 i4074_3_lut_4_lut (.A(n10442), .B(EN[7]), .C(QP_adj_2151[1]), 
         .D(QS_IN_adj_2152[2]), .Z(n4583)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i4074_3_lut_4_lut.init = 16'hf780;
    PFUMX i9159 (.BLUT(n10185), .ALUT(n10186), .C0(n10442), .Z(n10187));
    LUT4 i4072_3_lut_4_lut (.A(n10442), .B(EN[7]), .C(QP_adj_2151[2]), 
         .D(QS_IN_adj_2152[3]), .Z(n4581)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i4072_3_lut_4_lut.init = 16'hf780;
    PFUMX i9157 (.BLUT(n10182), .ALUT(n10183), .C0(n10442), .Z(n10184));
    LUT4 i4070_3_lut_4_lut (.A(n10442), .B(EN[7]), .C(QP_adj_2151[3]), 
         .D(QS_IN_adj_2152[4]), .Z(n4579)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i4070_3_lut_4_lut.init = 16'hf780;
    PFUMX i9155 (.BLUT(n10179), .ALUT(n10180), .C0(n10442), .Z(n10181));
    PFUMX i9153 (.BLUT(n10176), .ALUT(n10177), .C0(n10442), .Z(n10178));
    LUT4 i4066_3_lut_4_lut (.A(n10442), .B(EN[7]), .C(QP_adj_2151[4]), 
         .D(QS_IN_adj_2152[5]), .Z(n4575)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i4066_3_lut_4_lut.init = 16'hf780;
    LUT4 i4064_3_lut_4_lut (.A(n10442), .B(EN[7]), .C(QP_adj_2151[5]), 
         .D(QS_IN_adj_2152[6]), .Z(n4573)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i4064_3_lut_4_lut.init = 16'hf780;
    PFUMX i9151 (.BLUT(n10173), .ALUT(n10174), .C0(n10442), .Z(n10175));
    LUT4 i4062_3_lut_4_lut (.A(n10442), .B(EN[7]), .C(QP_adj_2151[6]), 
         .D(QS_IN_adj_2152[7]), .Z(n4571)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i4062_3_lut_4_lut.init = 16'hf780;
    LUT4 i4058_3_lut_4_lut (.A(n10442), .B(EN[7]), .C(QP_adj_2153[0]), 
         .D(QS_IN_adj_2154[1]), .Z(n4567)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i4058_3_lut_4_lut.init = 16'hf780;
    PFUMX i9149 (.BLUT(n10170), .ALUT(n10171), .C0(n10442), .Z(n10172));
    LUT4 i4479_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[1]), .C(SDATA[2]), 
         .D(n4987), .Z(n4988)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1353[53:80])
    defparam i4479_3_lut_4_lut.init = 16'hf780;
    LUT4 i4054_3_lut_4_lut (.A(n10442), .B(EN[7]), .C(QP_adj_2153[1]), 
         .D(QS_IN_adj_2154[2]), .Z(n4563)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i4054_3_lut_4_lut.init = 16'hf780;
    LUT4 i4481_3_lut_4_lut (.A(n9882), .B(SEL_LATCH[1]), .C(SDATA[1]), 
         .D(n4989), .Z(n4990)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1353[53:80])
    defparam i4481_3_lut_4_lut.init = 16'hf780;
    PFUMX i9147 (.BLUT(n10167), .ALUT(n10168), .C0(n10442), .Z(n10169));
    LUT4 i4050_3_lut_4_lut (.A(n10442), .B(EN[7]), .C(QP_adj_2153[2]), 
         .D(QS_IN_adj_2154[3]), .Z(n4559)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i4050_3_lut_4_lut.init = 16'hf780;
    PFUMX i9145 (.BLUT(n10164), .ALUT(n10165), .C0(n10442), .Z(n10166));
    LUT4 i4046_3_lut_4_lut (.A(n10442), .B(EN[7]), .C(QP_adj_2153[3]), 
         .D(QS_IN_adj_2154[4]), .Z(n4555)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i4046_3_lut_4_lut.init = 16'hf780;
    PFUMX i9143 (.BLUT(n10161), .ALUT(n10162), .C0(n10442), .Z(n10163));
    LUT4 i4030_3_lut_4_lut (.A(n10442), .B(EN[7]), .C(QP_adj_2153[4]), 
         .D(QS_IN_adj_2154[5]), .Z(n4539)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i4030_3_lut_4_lut.init = 16'hf780;
    PFUMX i9141 (.BLUT(n10158), .ALUT(n10159), .C0(n10442), .Z(n10160));
    LUT4 i4024_3_lut_4_lut (.A(n10442), .B(EN[7]), .C(QP_adj_2153[5]), 
         .D(QS_IN_adj_2154[6]), .Z(n4533)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i4024_3_lut_4_lut.init = 16'hf780;
    PFUMX i9139 (.BLUT(n10155), .ALUT(n10156), .C0(n10442), .Z(n10157));
    LUT4 i4022_3_lut_4_lut (.A(n10442), .B(EN[7]), .C(QP_adj_2153[6]), 
         .D(QS_IN_adj_2154[7]), .Z(n4531)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[30:44])
    defparam i4022_3_lut_4_lut.init = 16'hf780;
    PFUMX i9137 (.BLUT(n10152), .ALUT(n10153), .C0(n10442), .Z(n10154));
    PFUMX i9135 (.BLUT(n10149), .ALUT(n10150), .C0(n10442), .Z(n10151));
    PFUMX i9133 (.BLUT(n10146), .ALUT(n10147), .C0(n10442), .Z(n10148));
    PFUMX i9131 (.BLUT(n10143), .ALUT(n10144), .C0(n10442), .Z(n10145));
    PFUMX i9129 (.BLUT(n10140), .ALUT(n10141), .C0(n10442), .Z(n10142));
    PFUMX i9127 (.BLUT(n10137), .ALUT(n10138), .C0(n10442), .Z(n10139));
    LUT4 i4483_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[1]), .C(SDATA[7]), 
         .D(n4991), .Z(n4992)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i4483_3_lut_4_lut.init = 16'hf780;
    PFUMX i9125 (.BLUT(n10134), .ALUT(n10135), .C0(n10442), .Z(n10136));
    PFUMX i9123 (.BLUT(n10131), .ALUT(n10132), .C0(n10442), .Z(n10133));
    PFUMX i9121 (.BLUT(n10128), .ALUT(n10129), .C0(n10442), .Z(n10130));
    PFUMX i9119 (.BLUT(n10125), .ALUT(n10126), .C0(n10442), .Z(n10127));
    PFUMX i9117 (.BLUT(n10122), .ALUT(n10123), .C0(n10442), .Z(n10124));
    FD1P3IX SEL_LATCH_i0_i7 (.D(n3591), .SP(Clk_enable_535), .CD(n5135), 
            .CK(Clk), .Q(SEL_LATCH[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i7.GSR = "DISABLED";
    FD1P3IX SEL_LATCH_i0_i6 (.D(n3588), .SP(Clk_enable_535), .CD(n5135), 
            .CK(Clk), .Q(SEL_LATCH[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i6.GSR = "DISABLED";
    FD1P3IX SEL_LATCH_i0_i5 (.D(n3585), .SP(Clk_enable_535), .CD(n5135), 
            .CK(Clk), .Q(SEL_LATCH[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i5.GSR = "DISABLED";
    FD1P3IX SEL_LATCH_i0_i4 (.D(n6429), .SP(Clk_enable_535), .CD(n5135), 
            .CK(Clk), .Q(SEL_LATCH[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i4.GSR = "DISABLED";
    FD1P3IX SEL_LATCH_i0_i3 (.D(n3591), .SP(Clk_enable_535), .CD(n5118), 
            .CK(Clk), .Q(SEL_LATCH[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i3.GSR = "DISABLED";
    FD1P3IX SEL_LATCH_i0_i2 (.D(n3588), .SP(Clk_enable_535), .CD(n5118), 
            .CK(Clk), .Q(SEL_LATCH[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i2.GSR = "DISABLED";
    FD1P3IX SEL_LATCH_i0_i1 (.D(n3585), .SP(Clk_enable_535), .CD(n5118), 
            .CK(Clk), .Q(SEL_LATCH[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i1.GSR = "DISABLED";
    PFUMX i9115 (.BLUT(n10119), .ALUT(n10120), .C0(n10442), .Z(n10121));
    PFUMX i9113 (.BLUT(n10116), .ALUT(n10117), .C0(n10442), .Z(n10118));
    PFUMX i9111 (.BLUT(n10113), .ALUT(n10114), .C0(n10442), .Z(n10115));
    FD1P3IX SEL_LATCH_i0_i0 (.D(n6429), .SP(Clk_enable_543), .CD(n5118), 
            .CK(Clk), .Q(SEL_LATCH[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=402, LSE_RLINE=417 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1388[8] 1426[26])
    defparam SEL_LATCH_i0_i0.GSR = "DISABLED";
    PFUMX i9109 (.BLUT(n10110), .ALUT(n10111), .C0(n10442), .Z(n10112));
    PFUMX i9107 (.BLUT(n10107), .ALUT(n10108), .C0(n10442), .Z(n10109));
    PFUMX i9105 (.BLUT(n10104), .ALUT(n10105), .C0(n10442), .Z(n10106));
    LUT4 PCLK_I_0_311_2_lut_rep_309 (.A(n10442), .B(EN[6]), .Z(n9914)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam PCLK_I_0_311_2_lut_rep_309.init = 16'h8888;
    PFUMX i9103 (.BLUT(n10101), .ALUT(n10102), .C0(n10442), .Z(n10103));
    LUT4 i4132_3_lut_4_lut (.A(n10442), .B(EN[6]), .C(QP_adj_2155[0]), 
         .D(QS_IN_adj_2156[1]), .Z(n4641)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i4132_3_lut_4_lut.init = 16'hf780;
    PFUMX i9101 (.BLUT(n10098), .ALUT(n10099), .C0(n10442), .Z(n10100));
    LUT4 i4126_3_lut_4_lut (.A(n10442), .B(EN[6]), .C(QP_adj_2155[1]), 
         .D(QS_IN_adj_2156[2]), .Z(n4635)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i4126_3_lut_4_lut.init = 16'hf780;
    PFUMX i9099 (.BLUT(n10095), .ALUT(n10096), .C0(n10442), .Z(n10097));
    LUT4 i4485_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[1]), .C(SDATA[6]), 
         .D(n4993), .Z(n4994)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i4485_3_lut_4_lut.init = 16'hf780;
    PFUMX i9097 (.BLUT(n10092), .ALUT(n10093), .C0(n10442), .Z(n10094));
    LUT4 i4124_3_lut_4_lut (.A(n10442), .B(EN[6]), .C(QP_adj_2155[2]), 
         .D(QS_IN_adj_2156[3]), .Z(n4633)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i4124_3_lut_4_lut.init = 16'hf780;
    PFUMX i9095 (.BLUT(n10089), .ALUT(n10090), .C0(n10442), .Z(n10091));
    LUT4 i4118_3_lut_4_lut (.A(n10442), .B(EN[6]), .C(QP_adj_2155[3]), 
         .D(QS_IN_adj_2156[4]), .Z(n4627)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i4118_3_lut_4_lut.init = 16'hf780;
    PFUMX i9093 (.BLUT(n10086), .ALUT(n10087), .C0(n10442), .Z(n10088));
    LUT4 i4114_3_lut_4_lut (.A(n10442), .B(EN[6]), .C(QP_adj_2155[4]), 
         .D(QS_IN_adj_2156[5]), .Z(n4623)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i4114_3_lut_4_lut.init = 16'hf780;
    PFUMX i9091 (.BLUT(n10083), .ALUT(n10084), .C0(n10442), .Z(n10085));
    LUT4 i4108_3_lut_4_lut (.A(n10442), .B(EN[6]), .C(QP_adj_2155[6]), 
         .D(QS_IN_adj_2156[7]), .Z(n4617)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i4108_3_lut_4_lut.init = 16'hf780;
    PFUMX i9089 (.BLUT(n10080), .ALUT(n10081), .C0(n10442), .Z(n10082));
    PFUMX i9087 (.BLUT(n10077), .ALUT(n10078), .C0(n10442), .Z(n10079));
    PFUMX i9085 (.BLUT(n10074), .ALUT(n10075), .C0(n10442), .Z(n10076));
    PFUMX i9083 (.BLUT(n10071), .ALUT(n10072), .C0(n10442), .Z(n10073));
    LUT4 i4489_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[1]), .C(SDATA[4]), 
         .D(n4997), .Z(n4998)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i4489_3_lut_4_lut.init = 16'hf780;
    PFUMX i9081 (.BLUT(n10068), .ALUT(n10069), .C0(n10442), .Z(n10070));
    LUT4 i4248_3_lut_4_lut (.A(n10442), .B(EN[4]), .C(QP_adj_2145[1]), 
         .D(QS_IN_adj_2146[2]), .Z(n4757)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i4248_3_lut_4_lut.init = 16'hf780;
    PFUMX i9079 (.BLUT(n10065), .ALUT(n10066), .C0(n10442), .Z(n10067));
    LUT4 i4238_3_lut_4_lut (.A(n10442), .B(EN[4]), .C(QP_adj_2145[2]), 
         .D(QS_IN_adj_2146[3]), .Z(n4747)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i4238_3_lut_4_lut.init = 16'hf780;
    LUT4 i4226_3_lut_4_lut (.A(n10442), .B(EN[4]), .C(QP_adj_2145[3]), 
         .D(QS_IN_adj_2146[4]), .Z(n4735)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i4226_3_lut_4_lut.init = 16'hf780;
    PFUMX i9077 (.BLUT(n10062), .ALUT(n10063), .C0(n10442), .Z(n10064));
    LUT4 i4214_3_lut_4_lut (.A(n10442), .B(EN[4]), .C(QP_adj_2145[4]), 
         .D(QS_IN_adj_2146[5]), .Z(n4723)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i4214_3_lut_4_lut.init = 16'hf780;
    LUT4 i4204_3_lut_4_lut (.A(n10442), .B(EN[4]), .C(QP_adj_2145[5]), 
         .D(QS_IN_adj_2146[6]), .Z(n4713)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i4204_3_lut_4_lut.init = 16'hf780;
    PFUMX i9075 (.BLUT(n10059), .ALUT(n10060), .C0(n10442), .Z(n10061));
    LUT4 i4110_3_lut_4_lut (.A(n10442), .B(EN[6]), .C(QP_adj_2155[5]), 
         .D(QS_IN_adj_2156[6]), .Z(n4619)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[30:44])
    defparam i4110_3_lut_4_lut.init = 16'hf780;
    LUT4 i4487_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[1]), .C(SDATA[5]), 
         .D(n4995), .Z(n4996)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[53:80])
    defparam i4487_3_lut_4_lut.init = 16'hf780;
    PFUMX i9073 (.BLUT(n10056), .ALUT(n10057), .C0(n10442), .Z(n10058));
    LUT4 PD_FIFO_I_0_i6_2_lut (.A(PD_FIFO), .B(PD_LATCH[5]), .Z(SDATA[5])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i6_2_lut.init = 16'h8888;
    PFUMX i9071 (.BLUT(n10053), .ALUT(n10054), .C0(n10442), .Z(n10055));
    LUT4 i4511_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[0]), .C(SDATA[7]), 
         .D(n5019), .Z(n5020)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i4511_3_lut_4_lut.init = 16'hf780;
    LUT4 i4513_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[0]), .C(SDATA[6]), 
         .D(n5021), .Z(n5022)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i4513_3_lut_4_lut.init = 16'hf780;
    PFUMX i9069 (.BLUT(n10050), .ALUT(n10051), .C0(n10442), .Z(n10052));
    PFUMX i9067 (.BLUT(n10047), .ALUT(n10048), .C0(n10442), .Z(n10049));
    PFUMX i9065 (.BLUT(n10044), .ALUT(n10045), .C0(n10442), .Z(n10046));
    PFUMX i9063 (.BLUT(n10041), .ALUT(n10042), .C0(n10442), .Z(n10043));
    PFUMX i9061 (.BLUT(n10038), .ALUT(n10039), .C0(n10442), .Z(n10040));
    PFUMX i9059 (.BLUT(n10035), .ALUT(n10036), .C0(n10442), .Z(n10037));
    PFUMX i9057 (.BLUT(n10032), .ALUT(n10033), .C0(n10442), .Z(n10034));
    LUT4 i4200_3_lut_4_lut (.A(n10442), .B(EN[4]), .C(QP_adj_2145[6]), 
         .D(QS_IN_adj_2146[7]), .Z(n4709)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[30:44])
    defparam i4200_3_lut_4_lut.init = 16'hf780;
    PFUMX i9055 (.BLUT(n10029), .ALUT(n10030), .C0(n10442), .Z(n10031));
    PFUMX i9053 (.BLUT(n10026), .ALUT(n10027), .C0(n10442), .Z(n10028));
    LUT4 i4515_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[0]), .C(SDATA[5]), 
         .D(n5023), .Z(n5024)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i4515_3_lut_4_lut.init = 16'hf780;
    PFUMX i9051 (.BLUT(n10023), .ALUT(n10024), .C0(n10442), .Z(n10025));
    PFUMX i9049 (.BLUT(n10020), .ALUT(n10021), .C0(n10442), .Z(n10022));
    PFUMX i9047 (.BLUT(n10017), .ALUT(n10018), .C0(n10442), .Z(n10019));
    PFUMX i9045 (.BLUT(n10014), .ALUT(n10015), .C0(n10442), .Z(n10016));
    LUT4 PD_FIFO_I_0_i7_2_lut (.A(PD_FIFO), .B(PD_LATCH[6]), .Z(SDATA[6])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1347[21:51])
    defparam PD_FIFO_I_0_i7_2_lut.init = 16'h8888;
    PFUMX i9043 (.BLUT(n10011), .ALUT(n10012), .C0(n10442), .Z(n10013));
    LUT4 PCLK_I_0_317_2_lut_rep_314 (.A(n10442), .B(EN[3]), .Z(n9919)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam PCLK_I_0_317_2_lut_rep_314.init = 16'h8888;
    PFUMX i9041 (.BLUT(n10008), .ALUT(n10009), .C0(n10442), .Z(n10010));
    LUT4 i4438_3_lut_4_lut (.A(n10442), .B(EN[3]), .C(QP_adj_2157[0]), 
         .D(QS_IN_adj_2158[1]), .Z(n4947)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i4438_3_lut_4_lut.init = 16'hf780;
    PFUMX i9039 (.BLUT(n10005), .ALUT(n10006), .C0(n10442), .Z(n10007));
    LUT4 i4436_3_lut_4_lut (.A(n10442), .B(EN[3]), .C(QP_adj_2157[1]), 
         .D(QS_IN_adj_2158[2]), .Z(n4945)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i4436_3_lut_4_lut.init = 16'hf780;
    PFUMX i9037 (.BLUT(n10002), .ALUT(n10003), .C0(n10442), .Z(n10004));
    LUT4 i4434_3_lut_4_lut (.A(n10442), .B(EN[3]), .C(QP_adj_2157[2]), 
         .D(QS_IN_adj_2158[3]), .Z(n4943)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i4434_3_lut_4_lut.init = 16'hf780;
    PFUMX i9035 (.BLUT(n9999), .ALUT(n10000), .C0(n10442), .Z(n10001));
    LUT4 i4432_3_lut_4_lut (.A(n10442), .B(EN[3]), .C(QP_adj_2157[3]), 
         .D(QS_IN_adj_2158[4]), .Z(n4941)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i4432_3_lut_4_lut.init = 16'hf780;
    LUT4 i4336_3_lut_4_lut (.A(n10442), .B(EN[3]), .C(QP_adj_2157[4]), 
         .D(QS_IN_adj_2158[5]), .Z(n4845)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i4336_3_lut_4_lut.init = 16'hf780;
    LUT4 i4334_3_lut_4_lut (.A(n10442), .B(EN[3]), .C(QP_adj_2157[5]), 
         .D(QS_IN_adj_2158[6]), .Z(n4843)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i4334_3_lut_4_lut.init = 16'hf780;
    LUT4 i4332_3_lut_4_lut (.A(n10442), .B(EN[3]), .C(QP_adj_2157[6]), 
         .D(QS_IN_adj_2158[7]), .Z(n4841)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i4332_3_lut_4_lut.init = 16'hf780;
    LUT4 i4517_3_lut_4_lut (.A(n9883), .B(SEL_LATCH[0]), .C(SDATA[4]), 
         .D(n5025), .Z(n5026)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[53:80])
    defparam i4517_3_lut_4_lut.init = 16'hf780;
    LUT4 i4326_3_lut_4_lut (.A(n10442), .B(EN[3]), .C(QP[0]), .D(QS_IN[1]), 
         .Z(n4835)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i4326_3_lut_4_lut.init = 16'hf780;
    LUT4 i4324_3_lut_4_lut (.A(n10442), .B(EN[3]), .C(QP[1]), .D(QS_IN[2]), 
         .Z(n4833)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i4324_3_lut_4_lut.init = 16'hf780;
    LUT4 i4322_3_lut_4_lut (.A(n10442), .B(EN[3]), .C(QP[2]), .D(QS_IN[3]), 
         .Z(n4831)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[30:44])
    defparam i4322_3_lut_4_lut.init = 16'hf780;
    FIFO_HPOSCNT EN_7__I_0_330 (.ZH_FF(ZH_FF_adj_1880), .Clk(Clk), .Clk_enable_272(Clk_enable_272), 
            .n10432(n10432), .\EN[7] (EN[7]), .Clk_enable_543(Clk_enable_543), 
            .n10442(n10442), .n3373(n3373), .CNT({CNT_adj_2131}), .nVIS(nVIS), 
            .\SEL_LATCH[7] (SEL_LATCH[7]), .SH3(SH3), .CNT1(CNT1_adj_1882), 
            .n10100(n10100), .CNT1_adj_112(CNT1_adj_1884), .n10103(n10103), 
            .CNT1_adj_113(CNT1_adj_1886), .n10106(n10106), .CNT1_adj_114(CNT1_adj_1892), 
            .n10115(n10115), .n10118(n10118), .CNT1_adj_115(CNT1_adj_1894), 
            .CNT1_adj_116(CNT1_adj_1888), .n10109(n10109), .CNT1_adj_117(CNT1_adj_1890), 
            .n10112(n10112), .CNT1_adj_118(CNT1_adj_1879), .n10097(n10097)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1344[14:103])
    FIFO_HPOSCNT_U78 EN_6__I_0_333 (.nVIS(nVIS), .ZH_FF(ZH_FF), .\EN[6] (EN[6]), 
            .Clk(Clk), .Clk_enable_247(Clk_enable_247), .Clk_enable_271(Clk_enable_271), 
            .n10432(n10432), .n10442(n10442), .n3396(n3396), .CNT({CNT}), 
            .\SEL_LATCH[6] (SEL_LATCH[6]), .SH3(SH3), .CNT1(CNT1_adj_1788), 
            .n10010(n10010), .CNT1_adj_100(CNT1_adj_1789), .n10013(n10013), 
            .CNT1_adj_101(CNT1_adj_1786), .n10004(n10004), .CNT1_adj_102(CNT1_adj_1790), 
            .n10016(n10016), .n10022(n10022), .CNT1_adj_103(CNT1_adj_1792), 
            .CNT1_adj_104(CNT1), .n10001(n10001), .CNT1_adj_105(CNT1_adj_1791), 
            .n10019(n10019), .CNT1_adj_106(CNT1_adj_1787), .n10007(n10007)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1343[14:103])
    FIFO_HPOSCNT_U79 EN_5__I_0_336 (.nVIS(nVIS), .ZH_FF(ZH_FF_adj_1916), 
            .\EN[5] (EN[5]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .Clk_enable_270(Clk_enable_270), .n10432(n10432), .n10442(n10442), 
            .n3422(n3422), .CNT({CNT_adj_2135}), .\SEL_LATCH[5] (SEL_LATCH[5]), 
            .SH3(SH3), .CNT1(CNT1_adj_1920), .n10151(n10151), .CNT1_adj_88(CNT1_adj_1922), 
            .n10154(n10154), .CNT1_adj_89(CNT1_adj_1930), .n10166(n10166), 
            .CNT1_adj_90(CNT1_adj_1926), .n10160(n10160), .CNT1_adj_91(CNT1_adj_1924), 
            .n10157(n10157), .CNT1_adj_92(CNT1_adj_1928), .n10163(n10163), 
            .n10148(n10148), .CNT1_adj_93(CNT1_adj_1918), .CNT1_adj_94(CNT1_adj_1915), 
            .n10145(n10145)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1342[14:103])
    FIFO_HPOSCNT_U80 EN_4__I_0_339 (.\EN[4] (EN[4]), .Clk(Clk), .Clk_enable_173(Clk_enable_173), 
            .n10442(n10442), .n3426(n3426), .CNT({CNT_adj_2136}), .ZH_FF(ZH_FF_adj_1933), 
            .Clk_enable_268(Clk_enable_268), .n10432(n10432), .nVIS(nVIS), 
            .\SEL_LATCH[4] (SEL_LATCH[4]), .SH3(SH3), .CNT1(CNT1_adj_1935), 
            .n10172(n10172), .CNT1_adj_76(CNT1_adj_1937), .n10175(n10175), 
            .CNT1_adj_77(CNT1_adj_1941), .n10178(n10178), .CNT1_adj_78(CNT1_adj_1943), 
            .n10181(n10181), .CNT1_adj_79(CNT1_adj_1945), .n10184(n10184), 
            .CNT1_adj_80(CNT1_adj_1949), .n10190(n10190), .CNT1_adj_81(CNT1_adj_1947), 
            .n10187(n10187), .CNT1_adj_82(CNT1_adj_1932), .n10169(n10169)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1341[14:103])
    FIFO_HPOSCNT_U81 EN_3__I_0_342 (.\EN[3] (EN[3]), .Clk(Clk), .Clk_enable_571(Clk_enable_571), 
            .n10442(n10442), .n3427(n3427), .CNT({CNT_adj_2125}), .ZH_FF(ZH_FF_adj_1812), 
            .Clk_enable_265(Clk_enable_265), .n10432(n10432), .\SEL_LATCH[3] (SEL_LATCH[3]), 
            .SH3(SH3), .nVIS(nVIS), .CNT1(CNT1_adj_1842), .n10067(n10067), 
            .n10064(n10064), .CNT1_adj_64(CNT1_adj_1838), .CNT1_adj_65(CNT1_adj_1811), 
            .n10049(n10049), .CNT1_adj_66(CNT1_adj_1814), .n10052(n10052), 
            .CNT1_adj_67(CNT1_adj_1832), .n10055(n10055), .CNT1_adj_68(CNT1_adj_1834), 
            .n10058(n10058), .CNT1_adj_69(CNT1_adj_1836), .n10061(n10061), 
            .CNT1_adj_70(CNT1_adj_1844), .n10070(n10070)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1340[14:103])
    FIFO_HPOSCNT_U82 EN_2__I_0_345 (.\EN[2] (EN[2]), .Clk(Clk), .Clk_enable_571(Clk_enable_571), 
            .n10442(n10442), .n3428(n3428), .CNT({CNT_adj_2132}), .ZH_FF(ZH_FF_adj_1897), 
            .Clk_enable_262(Clk_enable_262), .n10432(n10432), .nVIS(nVIS), 
            .\SEL_LATCH[2] (SEL_LATCH[2]), .SH3(SH3), .CNT1(CNT1_adj_1899), 
            .n10124(n10124), .CNT1_adj_52(CNT1_adj_1901), .n10127(n10127), 
            .CNT1_adj_53(CNT1_adj_1903), .n10130(n10130), .CNT1_adj_54(CNT1_adj_1905), 
            .n10133(n10133), .CNT1_adj_55(CNT1_adj_1907), .n10136(n10136), 
            .CNT1_adj_56(CNT1_adj_1913), .n10142(n10142), .CNT1_adj_57(CNT1_adj_1909), 
            .n10139(n10139), .CNT1_adj_58(CNT1_adj_1896), .n10121(n10121)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1339[14:103])
    FIFO_HPOSCNT_U83 EN_1__I_0_348 (.\EN[1] (EN[1]), .Clk(Clk), .Clk_enable_571(Clk_enable_571), 
            .nVIS(nVIS), .ZH_FF(ZH_FF_adj_1855), .Clk_enable_320(Clk_enable_320), 
            .n10432(n10432), .CNT({CNT_adj_2130}), .n10442(n10442), .\SEL_LATCH[1] (SEL_LATCH[1]), 
            .SH3(SH3), .n3429(n3429), .CNT1(CNT1_adj_1861), .n10076(n10076), 
            .CNT1_adj_40(CNT1_adj_1865), .n10079(n10079), .CNT1_adj_41(CNT1_adj_1867), 
            .n10082(n10082), .CNT1_adj_42(CNT1_adj_1869), .n10085(n10085), 
            .CNT1_adj_43(CNT1_adj_1873), .n10088(n10088), .CNT1_adj_44(CNT1_adj_1877), 
            .n10094(n10094), .CNT1_adj_45(CNT1_adj_1875), .n10091(n10091), 
            .CNT1_adj_46(CNT1_adj_1854), .n10073(n10073)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1338[14:103])
    FIFO_HPOSCNT_U84 EN_0__I_0_351 (.\EN[0] (EN[0]), .Clk(Clk), .Clk_enable_571(Clk_enable_571), 
            .ZH_FF(ZH_FF_adj_1795), .nVIS(nVIS), .n10442(n10442), .\SEL_LATCH[0] (SEL_LATCH[0]), 
            .SH3(SH3), .CNT({CNT_adj_2122}), .\ZPOS[2] (ZPOS[2]), .n3428(n3428), 
            .Clk_enable_262(Clk_enable_262), .n3427(n3427), .Clk_enable_265(Clk_enable_265), 
            .n3426(n3426), .Clk_enable_268(Clk_enable_268), .n3422(n3422), 
            .Clk_enable_270(Clk_enable_270), .n3396(n3396), .Clk_enable_271(Clk_enable_271), 
            .n3373(n3373), .Clk_enable_272(Clk_enable_272), .n3429(n3429), 
            .Clk_enable_320(Clk_enable_320), .CNT1(CNT1_adj_1797), .n10028(n10028), 
            .CNT1_adj_28(CNT1_adj_1799), .n10031(n10031), .CNT1_adj_29(CNT1_adj_1801), 
            .n10034(n10034), .CNT1_adj_30(CNT1_adj_1803), .n10037(n10037), 
            .CNT1_adj_31(CNT1_adj_1805), .n10040(n10040), .CNT1_adj_32(CNT1_adj_1809), 
            .n10046(n10046), .CNT1_adj_33(CNT1_adj_1807), .n10043(n10043), 
            .CNT1_adj_34(CNT1_adj_1794), .n10025(n10025)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1337[14:103])
    SHIFTREG COL1_7__I_0 (.\SDATA[0] (SDATA[0]), .n9869(n9869), .n9912(n9912), 
            .\QP[0] (QP_adj_2153[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP_adj_2153[1]), .Clk_enable_535(Clk_enable_535), .\QS_IN[1] (QS_IN_adj_2154[1]), 
            .\QP[2] (QP_adj_2153[2]), .\QS_IN[2] (QS_IN_adj_2154[2]), .\QP[3] (QP_adj_2153[3]), 
            .\QS_IN[3] (QS_IN_adj_2154[3]), .\QP[4] (QP_adj_2153[4]), .\QS_IN[4] (QS_IN_adj_2154[4]), 
            .\QP[5] (QP_adj_2153[5]), .\QS_IN[5] (QS_IN_adj_2154[5]), .\QP[6] (QP_adj_2153[6]), 
            .\QS_IN[6] (QS_IN_adj_2154[6]), .\COL1[7] (COL1[7]), .\QS_IN[7] (QS_IN_adj_2154[7]), 
            .n4568(n4568), .n4564(n4564), .n4560(n4560), .n4556(n4556), 
            .n4540(n4540), .n4534(n4534), .n4532(n4532)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1365[10:105])
    SHIFTREG_U85 COL1_6__I_0 (.\SDATA[0] (SDATA[0]), .n9871(n9871), .n9914(n9914), 
            .\QP[0] (QP_adj_2123[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP_adj_2123[1]), .Clk_enable_535(Clk_enable_535), .\QS_IN[1] (QS_IN_adj_2124[1]), 
            .\QP[2] (QP_adj_2123[2]), .\QS_IN[2] (QS_IN_adj_2124[2]), .\QP[3] (QP_adj_2123[3]), 
            .\QS_IN[3] (QS_IN_adj_2124[3]), .\QP[4] (QP_adj_2123[4]), .\QS_IN[4] (QS_IN_adj_2124[4]), 
            .\QP[5] (QP_adj_2123[5]), .\QS_IN[5] (QS_IN_adj_2124[5]), .\QP[6] (QP_adj_2123[6]), 
            .\QS_IN[6] (QS_IN_adj_2124[6]), .\COL1[6] (COL1[6]), .\QS_IN[7] (QS_IN_adj_2124[7]), 
            .n4616(n4616), .n4614(n4614), .n4608(n4608), .n4606(n4606), 
            .n4602(n4602), .n4596(n4596), .n4592(n4592)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1363[10:105])
    SHIFTREG_U86 COL1_5__I_0 (.\SDATA[0] (SDATA[0]), .n9873(n9873), .n9915(n9915), 
            .\QP[0] (QP_adj_2128[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP_adj_2128[1]), .Clk_enable_535(Clk_enable_535), .\QS_IN[1] (QS_IN_adj_2129[1]), 
            .\QP[2] (QP_adj_2128[2]), .\QS_IN[2] (QS_IN_adj_2129[2]), .\QP[3] (QP_adj_2128[3]), 
            .\QS_IN[3] (QS_IN_adj_2129[3]), .\QP[4] (QP_adj_2128[4]), .\QS_IN[4] (QS_IN_adj_2129[4]), 
            .\QP[5] (QP_adj_2128[5]), .\QS_IN[5] (QS_IN_adj_2129[5]), .\QP[6] (QP_adj_2128[6]), 
            .\QS_IN[6] (QS_IN_adj_2129[6]), .\COL1[5] (COL1[5]), .\QS_IN[7] (QS_IN_adj_2129[7]), 
            .n4678(n4678), .n4674(n4674), .n4662(n4662), .n4660(n4660), 
            .n4656(n4656), .n4650(n4650), .n4646(n4646)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1361[10:105])
    SHIFTREG_U87 COL1_4__I_0 (.\SDATA[0] (SDATA[0]), .n9875(n9875), .n9918(n9918), 
            .\QP[0] (QP_adj_2145[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP_adj_2145[1]), .Clk_enable_467(Clk_enable_467), .\QS_IN[1] (QS_IN_adj_2146[1]), 
            .\QP[2] (QP_adj_2145[2]), .\QS_IN[2] (QS_IN_adj_2146[2]), .\QP[3] (QP_adj_2145[3]), 
            .\QS_IN[3] (QS_IN_adj_2146[3]), .\QP[4] (QP_adj_2145[4]), .\QS_IN[4] (QS_IN_adj_2146[4]), 
            .\QP[5] (QP_adj_2145[5]), .\QS_IN[5] (QS_IN_adj_2146[5]), .\QP[6] (QP_adj_2145[6]), 
            .\QS_IN[6] (QS_IN_adj_2146[6]), .\COL1[4] (COL1[4]), .\QS_IN[7] (QS_IN_adj_2146[7]), 
            .n4766(n4766), .n4758(n4758), .n4748(n4748), .n4736(n4736), 
            .n4724(n4724), .n4714(n4714), .n4710(n4710)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1359[10:105])
    SHIFTREG_U88 COL1_3__I_0 (.\SDATA[0] (SDATA[0]), .n9877(n9877), .n9919(n9919), 
            .\QP[0] (QP[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP[1]), .Clk_enable_467(Clk_enable_467), .\QS_IN[1] (QS_IN[1]), 
            .\QP[2] (QP[2]), .\QS_IN[2] (QS_IN[2]), .\QP[3] (QP[3]), .\QS_IN[3] (QS_IN[3]), 
            .\QP[4] (QP[4]), .\QS_IN[4] (QS_IN[4]), .\QP[5] (QP[5]), .\QS_IN[5] (QS_IN[5]), 
            .\QP[6] (QP[6]), .\QS_IN[6] (QS_IN[6]), .\COL1[3] (COL1[3]), 
            .\QS_IN[7] (QS_IN[7]), .n4836(n4836), .n4834(n4834), .n4832(n4832), 
            .n4828(n4828), .n4826(n4826), .n4810(n4810), .n4807(n4807)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1357[10:105])
    SHIFTREG_U89 COL1_2__I_0 (.\SDATA[0] (SDATA[0]), .n9841(n9841), .n9879(n9879), 
            .\QP[0] (QP_adj_2139[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP_adj_2139[1]), .Clk_enable_467(Clk_enable_467), .\QS_IN[1] (QS_IN_adj_2140[1]), 
            .\QP[2] (QP_adj_2139[2]), .\QS_IN[2] (QS_IN_adj_2140[2]), .\QP[3] (QP_adj_2139[3]), 
            .\QS_IN[3] (QS_IN_adj_2140[3]), .\QP[4] (QP_adj_2139[4]), .\QS_IN[4] (QS_IN_adj_2140[4]), 
            .\QP[5] (QP_adj_2139[5]), .\QS_IN[5] (QS_IN_adj_2140[5]), .\QP[6] (QP_adj_2139[6]), 
            .\QS_IN[6] (QS_IN_adj_2140[6]), .\COL1[2] (COL1[2]), .\QS_IN[7] (QS_IN_adj_2140[7]), 
            .n4962(n4962), .n4960(n4960), .n4958(n4958), .n4956(n4956), 
            .n4954(n4954), .n4952(n4952), .n4950(n4950)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1355[10:105])
    SHIFTREG_U90 COL1_1__I_0 (.\QP[0] (QP_adj_2143[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP_adj_2143[1]), .Clk_enable_543(Clk_enable_543), .\QS_IN[1] (QS_IN_adj_2144[1]), 
            .\QP[2] (QP_adj_2143[2]), .\QS_IN[2] (QS_IN_adj_2144[2]), .\QP[3] (QP_adj_2143[3]), 
            .\QS_IN[3] (QS_IN_adj_2144[3]), .\QP[4] (QP_adj_2143[4]), .\QS_IN[4] (QS_IN_adj_2144[4]), 
            .\QP[5] (QP_adj_2143[5]), .Clk_enable_467(Clk_enable_467), .\QS_IN[5] (QS_IN_adj_2144[5]), 
            .\QP[6] (QP_adj_2143[6]), .\QS_IN[6] (QS_IN_adj_2144[6]), .\COL1[1] (COL1[1]), 
            .\QS_IN[7] (QS_IN_adj_2144[7]), .n4990(n4990), .n4988(n4988), 
            .n4986(n4986), .n4984(n4984), .n4982(n4982), .n4980(n4980), 
            .n4978(n4978), .\SDATA[0] (SDATA[0]), .n9844(n9844), .n9881(n9881)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1353[10:105])
    SHIFTREG_U91 COL1_0__I_0 (.\SDATA[0] (SDATA[0]), .n9846(n9846), .n9884(n9884), 
            .\QP[0] (QP_adj_2149[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP_adj_2149[1]), .Clk_enable_543(Clk_enable_543), .\QS_IN[1] (QS_IN_adj_2150[1]), 
            .\QP[2] (QP_adj_2149[2]), .\QS_IN[2] (QS_IN_adj_2150[2]), .\QP[3] (QP_adj_2149[3]), 
            .\QS_IN[3] (QS_IN_adj_2150[3]), .\QP[4] (QP_adj_2149[4]), .\QS_IN[4] (QS_IN_adj_2150[4]), 
            .\QP[5] (QP_adj_2149[5]), .\QS_IN[5] (QS_IN_adj_2150[5]), .\QP[6] (QP_adj_2149[6]), 
            .\QS_IN[6] (QS_IN_adj_2150[6]), .\COL1[0] (COL1[0]), .\QS_IN[7] (QS_IN_adj_2150[7]), 
            .n5018(n5018), .n5016(n5016), .n5014(n5014), .n5012(n5012), 
            .n5010(n5010), .n5008(n5008), .n5006(n5006)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1351[10:105])
    SHIFTREG_U92 COL0_7__I_0_331 (.\SDATA[0] (SDATA[0]), .n9870(n9870), 
            .n9912(n9912), .\QP[0] (QP_adj_2151[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP_adj_2151[1]), .Clk_enable_535(Clk_enable_535), .\QS_IN[1] (QS_IN_adj_2152[1]), 
            .\QP[2] (QP_adj_2151[2]), .\QS_IN[2] (QS_IN_adj_2152[2]), .\QP[3] (QP_adj_2151[3]), 
            .\QS_IN[3] (QS_IN_adj_2152[3]), .\QP[4] (QP_adj_2151[4]), .\QS_IN[4] (QS_IN_adj_2152[4]), 
            .\QP[5] (QP_adj_2151[5]), .\QS_IN[5] (QS_IN_adj_2152[5]), .\QP[6] (QP_adj_2151[6]), 
            .\QS_IN[6] (QS_IN_adj_2152[6]), .\COL0[7] (COL0[7]), .\QS_IN[7] (QS_IN_adj_2152[7]), 
            .n4588(n4588), .n4584(n4584), .n4582(n4582), .n4580(n4580), 
            .n4576(n4576), .n4574(n4574), .n4572(n4572)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1364[10:105])
    SHIFTREG_U93 COL0_6__I_0_334 (.\SDATA[0] (SDATA[0]), .n9872(n9872), 
            .n9914(n9914), .\QP[0] (QP_adj_2155[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP_adj_2155[1]), .Clk_enable_535(Clk_enable_535), .\QS_IN[1] (QS_IN_adj_2156[1]), 
            .\QP[2] (QP_adj_2155[2]), .\QS_IN[2] (QS_IN_adj_2156[2]), .\QP[3] (QP_adj_2155[3]), 
            .\QS_IN[3] (QS_IN_adj_2156[3]), .\QP[4] (QP_adj_2155[4]), .\QS_IN[4] (QS_IN_adj_2156[4]), 
            .\QP[5] (QP_adj_2155[5]), .\QS_IN[5] (QS_IN_adj_2156[5]), .\QP[6] (QP_adj_2155[6]), 
            .\QS_IN[6] (QS_IN_adj_2156[6]), .\COL0[6] (COL0[6]), .\QS_IN[7] (QS_IN_adj_2156[7]), 
            .n4642(n4642), .n4636(n4636), .n4634(n4634), .n4628(n4628), 
            .n4624(n4624), .n4620(n4620), .n4618(n4618)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1362[10:105])
    SHIFTREG_U94 COL0_5__I_0_337 (.\SDATA[0] (SDATA[0]), .n9874(n9874), 
            .n9915(n9915), .\QP[0] (QP_adj_2126[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP_adj_2126[1]), .Clk_enable_467(Clk_enable_467), .\QS_IN[1] (QS_IN_adj_2127[1]), 
            .\QP[2] (QP_adj_2126[2]), .\QS_IN[2] (QS_IN_adj_2127[2]), .\QP[3] (QP_adj_2126[3]), 
            .\QS_IN[3] (QS_IN_adj_2127[3]), .\QP[4] (QP_adj_2126[4]), .\QS_IN[4] (QS_IN_adj_2127[4]), 
            .\QP[5] (QP_adj_2126[5]), .\QS_IN[5] (QS_IN_adj_2127[5]), .\QP[6] (QP_adj_2126[6]), 
            .Clk_enable_535(Clk_enable_535), .\QS_IN[6] (QS_IN_adj_2127[6]), 
            .\COL0[5] (COL0[5]), .\QS_IN[7] (QS_IN_adj_2127[7]), .n4708(n4708), 
            .n4704(n4704), .n4700(n4700), .n4696(n4696), .n4692(n4692), 
            .n4688(n4688), .n4684(n4684)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1360[10:105])
    SHIFTREG_U95 COL0_4__I_0_340 (.\SDATA[0] (SDATA[0]), .n9876(n9876), 
            .n9918(n9918), .\QP[0] (QP_adj_2133[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP_adj_2133[1]), .Clk_enable_467(Clk_enable_467), .\QS_IN[1] (QS_IN_adj_2134[1]), 
            .\QP[2] (QP_adj_2133[2]), .\QS_IN[2] (QS_IN_adj_2134[2]), .\QP[3] (QP_adj_2133[3]), 
            .\QS_IN[3] (QS_IN_adj_2134[3]), .\QP[4] (QP_adj_2133[4]), .\QS_IN[4] (QS_IN_adj_2134[4]), 
            .\QP[5] (QP_adj_2133[5]), .\QS_IN[5] (QS_IN_adj_2134[5]), .\QP[6] (QP_adj_2133[6]), 
            .\QS_IN[6] (QS_IN_adj_2134[6]), .\COL0[4] (COL0[4]), .\QS_IN[7] (QS_IN_adj_2134[7]), 
            .n4804(n4804), .n4802(n4802), .n4800(n4800), .n4796(n4796), 
            .n4792(n4792), .n4786(n4786), .n4778(n4778)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1358[10:105])
    SHIFTREG_U96 COL0_3__I_0_343 (.\SDATA[0] (SDATA[0]), .n9878(n9878), 
            .n9919(n9919), .\QP[0] (QP_adj_2157[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP_adj_2157[1]), .Clk_enable_467(Clk_enable_467), .\QS_IN[1] (QS_IN_adj_2158[1]), 
            .\QP[2] (QP_adj_2157[2]), .\QS_IN[2] (QS_IN_adj_2158[2]), .\QP[3] (QP_adj_2157[3]), 
            .\QS_IN[3] (QS_IN_adj_2158[3]), .\QP[4] (QP_adj_2157[4]), .\QS_IN[4] (QS_IN_adj_2158[4]), 
            .\QP[5] (QP_adj_2157[5]), .\QS_IN[5] (QS_IN_adj_2158[5]), .\QP[6] (QP_adj_2157[6]), 
            .\QS_IN[6] (QS_IN_adj_2158[6]), .\COL0[3] (COL0[3]), .\QS_IN[7] (QS_IN_adj_2158[7]), 
            .n4948(n4948), .n4946(n4946), .n4944(n4944), .n4942(n4942), 
            .n4846(n4846), .n4844(n4844), .n4842(n4842)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1356[10:105])
    SHIFTREG_U97 COL0_2__I_0_346 (.\QP[0] (QP_adj_2137[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP_adj_2137[1]), .Clk_enable_467(Clk_enable_467), .\QS_IN[1] (QS_IN_adj_2138[1]), 
            .\QP[2] (QP_adj_2137[2]), .\QS_IN[2] (QS_IN_adj_2138[2]), .\QP[3] (QP_adj_2137[3]), 
            .\QS_IN[3] (QS_IN_adj_2138[3]), .\QP[4] (QP_adj_2137[4]), .\QS_IN[4] (QS_IN_adj_2138[4]), 
            .\QP[5] (QP_adj_2137[5]), .\QS_IN[5] (QS_IN_adj_2138[5]), .\QP[6] (QP_adj_2137[6]), 
            .\QS_IN[6] (QS_IN_adj_2138[6]), .\COL0[2] (COL0[2]), .\QS_IN[7] (QS_IN_adj_2138[7]), 
            .n4976(n4976), .n4974(n4974), .n4972(n4972), .n4970(n4970), 
            .n4968(n4968), .n4966(n4966), .n4964(n4964), .\SDATA[0] (SDATA[0]), 
            .n9842(n9842), .n9879(n9879)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1354[10:105])
    SHIFTREG_U98 COL0_1__I_0_349 (.\QP[0] (QP_adj_2141[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP_adj_2141[1]), .Clk_enable_543(Clk_enable_543), .\QS_IN[1] (QS_IN_adj_2142[1]), 
            .\QP[2] (QP_adj_2141[2]), .\QS_IN[2] (QS_IN_adj_2142[2]), .\QP[3] (QP_adj_2141[3]), 
            .\QS_IN[3] (QS_IN_adj_2142[3]), .\QP[4] (QP_adj_2141[4]), .\QS_IN[4] (QS_IN_adj_2142[4]), 
            .\QP[5] (QP_adj_2141[5]), .\QS_IN[5] (QS_IN_adj_2142[5]), .\QP[6] (QP_adj_2141[6]), 
            .\QS_IN[6] (QS_IN_adj_2142[6]), .\COL0[1] (COL0[1]), .\QS_IN[7] (QS_IN_adj_2142[7]), 
            .n5004(n5004), .n5002(n5002), .n5000(n5000), .n4998(n4998), 
            .n4996(n4996), .n4994(n4994), .n4992(n4992), .\SDATA[0] (SDATA[0]), 
            .n9845(n9845), .n9881(n9881)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1352[10:105])
    SHIFTREG_U99 COL0_0__I_0_352 (.\SDATA[0] (SDATA[0]), .n9848(n9848), 
            .n9884(n9884), .\QP[0] (QP_adj_2147[0]), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .\QP[1] (QP_adj_2147[1]), .Clk_enable_543(Clk_enable_543), .\QS_IN[1] (QS_IN_adj_2148[1]), 
            .\QP[2] (QP_adj_2147[2]), .\QS_IN[2] (QS_IN_adj_2148[2]), .\QP[3] (QP_adj_2147[3]), 
            .\QS_IN[3] (QS_IN_adj_2148[3]), .\QP[4] (QP_adj_2147[4]), .\QS_IN[4] (QS_IN_adj_2148[4]), 
            .\QP[5] (QP_adj_2147[5]), .\QS_IN[5] (QS_IN_adj_2148[5]), .\QP[6] (QP_adj_2147[6]), 
            .\QS_IN[6] (QS_IN_adj_2148[6]), .\COL0[0] (COL0[0]), .\QS_IN[7] (QS_IN_adj_2148[7]), 
            .n5032(n5032), .n5030(n5030), .n5028(n5028), .n5026(n5026), 
            .n5024(n5024), .n5022(n5022), .n5020(n5020)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1350[10:105])
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT
//

module FIFO_HPOSCNT (ZH_FF, Clk, Clk_enable_272, n10432, \EN[7] , 
            Clk_enable_543, n10442, n3373, CNT, nVIS, \SEL_LATCH[7] , 
            SH3, CNT1, n10100, CNT1_adj_112, n10103, CNT1_adj_113, 
            n10106, CNT1_adj_114, n10115, n10118, CNT1_adj_115, CNT1_adj_116, 
            n10109, CNT1_adj_117, n10112, CNT1_adj_118, n10097) /* synthesis syn_module_defined=1 */ ;
    output ZH_FF;
    input Clk;
    input Clk_enable_272;
    input n10432;
    output \EN[7] ;
    input Clk_enable_543;
    input n10442;
    output n3373;
    output [7:0]CNT;
    input nVIS;
    input \SEL_LATCH[7] ;
    input SH3;
    output CNT1;
    input n10100;
    output CNT1_adj_112;
    input n10103;
    output CNT1_adj_113;
    input n10106;
    output CNT1_adj_114;
    input n10115;
    input n10118;
    output CNT1_adj_115;
    output CNT1_adj_116;
    input n10109;
    output CNT1_adj_117;
    input n10112;
    output CNT1_adj_118;
    input n10097;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire ZH_FF_N_1401, EN_N_1395, n14, n10, CNT_7__N_1392, CNT1_N_565, 
        CNT1_N_565_adj_1775, n9855, CNT1_N_565_adj_1776, n9895, CNT1_N_565_adj_1778, 
        CNT1_N_565_adj_1780, n9935, n9970, CNT1_N_565_adj_1782;
    
    FD1P3IX ZH_FF_36 (.D(n10432), .SP(Clk_enable_272), .CD(ZH_FF_N_1401), 
            .CK(Clk), .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(Clk_enable_543), .CK(Clk), .Q(\EN[7] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 PCLK_I_0_40_2_lut (.A(n10442), .B(n3373), .Z(ZH_FF_N_1401)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1456[15:36])
    defparam PCLK_I_0_40_2_lut.init = 16'h2222;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3373)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 i8920_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i8920_2_lut.init = 16'h1111;
    LUT4 i8917_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n10442), .B(ZH_FF), .C(\SEL_LATCH[7] ), 
         .D(SH3), .Z(CNT_7__N_1392)) /* synthesis lut_function=(!(A (C (D))+!A (B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1449[16:33])
    defparam i8917_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h1bbb;
    COUNTER FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565), .\CNT[6] (CNT[6]), .n10100(n10100)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U0 FIFOCNT_5 (.CNT1(CNT1_adj_112), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1775), .\CNT[5] (CNT[5]), .n9855(n9855), 
            .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_565_adj_111(CNT1_N_565_adj_1776), 
            .n10103(n10103)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U1 FIFOCNT_4 (.\CNT[4] (CNT[4]), .n9895(n9895), .\CNT[6] (CNT[6]), 
            .\CNT[5] (CNT[5]), .CNT1_N_565(CNT1_N_565), .CNT1(CNT1_adj_113), 
            .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), .CNT1_N_565_adj_110(CNT1_N_565_adj_1778), 
            .n10106(n10106)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U2 FIFOCNT_3 (.CNT1(CNT1_adj_114), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1780), .\CNT[3] (CNT[3]), .n10115(n10115), 
            .n9935(n9935), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_565_adj_109(CNT1_N_565_adj_1775)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U3 FIFOCNT_2 (.\CNT[2] (CNT[2]), .n9970(n9970), .\CNT[4] (CNT[4]), 
            .\CNT[3] (CNT[3]), .n9855(n9855), .CNT1_N_565(CNT1_N_565_adj_1778), 
            .Clk(Clk), .n10118(n10118), .CNT1(CNT1_adj_115), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565_adj_108(CNT1_N_565_adj_1782)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U4 FIFOCNT_1 (.CNT1(CNT1_adj_116), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[1] (CNT[1]), .n10109(n10109), .\CNT[0] (CNT[0]), .n9970(n9970), 
            .\CNT[2] (CNT[2]), .n9935(n9935), .\CNT[3] (CNT[3]), .CNT1_N_565(CNT1_N_565_adj_1780), 
            .CNT1_N_565_adj_107(CNT1_N_565_adj_1782), .n9895(n9895)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U5 FIFOCNT_0 (.CNT1(CNT1_adj_117), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[0] (CNT[0]), .n10112(n10112)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U6 CNT_7__I_0_39 (.CNT1(CNT1_adj_118), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1776), .\CNT[7] (CNT[7]), .n10097(n10097)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER
//

module COUNTER (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[6] , n10100) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[6] ;
    input n10100;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10100), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U0
//

module COUNTER_U0 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[5] , 
            n9855, \CNT[6] , \CNT[7] , CNT1_N_565_adj_111, n10103) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[5] ;
    input n9855;
    input \CNT[6] ;
    input \CNT[7] ;
    output CNT1_N_565_adj_111;
    input n10103;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n9855), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_565_adj_111)) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    FD1S3AX CNT_14 (.D(n10103), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U1
//

module COUNTER_U1 (\CNT[4] , n9895, \CNT[6] , \CNT[5] , CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1392, CNT1_N_565_adj_110, n10106) /* synthesis syn_module_defined=1 */ ;
    output \CNT[4] ;
    input n9895;
    input \CNT[6] ;
    input \CNT[5] ;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565_adj_110;
    input n10106;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n9895), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_110), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10106), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U2
//

module COUNTER_U2 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[3] , 
            n10115, n9935, \CNT[5] , \CNT[4] , CNT1_N_565_adj_109) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[3] ;
    input n10115;
    input n9935;
    input \CNT[5] ;
    input \CNT[4] ;
    output CNT1_N_565_adj_109;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10115), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n9935), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_565_adj_109)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U3
//

module COUNTER_U3 (\CNT[2] , n9970, \CNT[4] , \CNT[3] , n9855, CNT1_N_565, 
            Clk, n10118, CNT1, CNT_7__N_1392, CNT1_N_565_adj_108) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input n9970;
    input \CNT[4] ;
    input \CNT[3] ;
    output n9855;
    output CNT1_N_565;
    input Clk;
    input n10118;
    output CNT1;
    input CNT_7__N_1392;
    input CNT1_N_565_adj_108;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    LUT4 i6221_2_lut_rep_250_3_lut_4_lut (.A(\CNT[2] ), .B(n9970), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n9855)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6221_2_lut_rep_250_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n9970), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1S3AX CNT_14 (.D(n10118), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_108), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U4
//

module COUNTER_U4 (CNT1, Clk, CNT_7__N_1392, \CNT[1] , n10109, \CNT[0] , 
            n9970, \CNT[2] , n9935, \CNT[3] , CNT1_N_565, CNT1_N_565_adj_107, 
            n9895) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[1] ;
    input n10109;
    input \CNT[0] ;
    output n9970;
    input \CNT[2] ;
    output n9935;
    input \CNT[3] ;
    output CNT1_N_565;
    output CNT1_N_565_adj_107;
    output n9895;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10109), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i6018_2_lut_rep_365 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n9970)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i6018_2_lut_rep_365.init = 16'heeee;
    LUT4 i6144_2_lut_rep_330_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n9935)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i6144_2_lut_rep_330_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565_adj_107)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i6189_2_lut_rep_290_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n9895)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6189_2_lut_rep_290_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U5
//

module COUNTER_U5 (CNT1, Clk, CNT_7__N_1392, \CNT[0] , n10112) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[0] ;
    input n10112;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10112), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module COUNTER_U6
//

module COUNTER_U6 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[7] , 
            n10097) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[7] ;
    input n10097;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10097), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U78
//

module FIFO_HPOSCNT_U78 (nVIS, ZH_FF, \EN[6] , Clk, Clk_enable_247, 
            Clk_enable_271, n10432, n10442, n3396, CNT, \SEL_LATCH[6] , 
            SH3, CNT1, n10010, CNT1_adj_100, n10013, CNT1_adj_101, 
            n10004, CNT1_adj_102, n10016, n10022, CNT1_adj_103, CNT1_adj_104, 
            n10001, CNT1_adj_105, n10019, CNT1_adj_106, n10007) /* synthesis syn_module_defined=1 */ ;
    input nVIS;
    output ZH_FF;
    output \EN[6] ;
    input Clk;
    input Clk_enable_247;
    input Clk_enable_271;
    input n10432;
    input n10442;
    output n3396;
    output [7:0]CNT;
    input \SEL_LATCH[6] ;
    input SH3;
    output CNT1;
    input n10010;
    output CNT1_adj_100;
    input n10013;
    output CNT1_adj_101;
    input n10004;
    output CNT1_adj_102;
    input n10016;
    input n10022;
    output CNT1_adj_103;
    output CNT1_adj_104;
    input n10001;
    output CNT1_adj_105;
    input n10019;
    output CNT1_adj_106;
    input n10007;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire EN_N_1395, ZH_FF_N_1401, n14, n10, CNT_7__N_1392, CNT1_N_565, 
        n9849, CNT1_N_565_adj_1756, CNT1_N_565_adj_1758, n9885, CNT1_N_565_adj_1760, 
        CNT1_N_565_adj_1762, n9921, n9946, CNT1_N_565_adj_1764;
    
    LUT4 i8915_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i8915_2_lut.init = 16'h1111;
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(Clk_enable_247), .CK(Clk), .Q(\EN[6] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    FD1P3IX ZH_FF_36 (.D(n10432), .SP(Clk_enable_271), .CD(ZH_FF_N_1401), 
            .CK(Clk), .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    LUT4 PCLK_I_0_40_2_lut (.A(n10442), .B(n3396), .Z(ZH_FF_N_1401)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1456[15:36])
    defparam PCLK_I_0_40_2_lut.init = 16'h2222;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3396)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 i8911_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n10442), .B(ZH_FF), .C(\SEL_LATCH[6] ), 
         .D(SH3), .Z(CNT_7__N_1392)) /* synthesis lut_function=(!(A (C (D))+!A (B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1449[16:33])
    defparam i8911_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h1bbb;
    COUNTER_U7 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565), .\CNT[6] (CNT[6]), .n10010(n10010)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U8 FIFOCNT_5 (.\CNT[5] (CNT[5]), .n9849(n9849), .\CNT[6] (CNT[6]), 
            .\CNT[7] (CNT[7]), .CNT1_N_565(CNT1_N_565_adj_1756), .CNT1(CNT1_adj_100), 
            .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), .CNT1_N_565_adj_99(CNT1_N_565_adj_1758), 
            .n10013(n10013)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U9 FIFOCNT_4 (.\CNT[4] (CNT[4]), .n9885(n9885), .\CNT[6] (CNT[6]), 
            .\CNT[5] (CNT[5]), .CNT1_N_565(CNT1_N_565), .CNT1(CNT1_adj_101), 
            .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), .CNT1_N_565_adj_98(CNT1_N_565_adj_1760), 
            .n10004(n10004)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U10 FIFOCNT_3 (.CNT1(CNT1_adj_102), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1762), .\CNT[3] (CNT[3]), .n10016(n10016), 
            .n9921(n9921), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_565_adj_97(CNT1_N_565_adj_1758)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U11 FIFOCNT_2 (.\CNT[2] (CNT[2]), .n9946(n9946), .\CNT[4] (CNT[4]), 
            .\CNT[3] (CNT[3]), .n9849(n9849), .CNT1_N_565(CNT1_N_565_adj_1760), 
            .Clk(Clk), .n10022(n10022), .CNT1(CNT1_adj_103), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565_adj_96(CNT1_N_565_adj_1764)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U12 FIFOCNT_1 (.CNT1(CNT1_adj_104), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .n9946(n9946), .\CNT[2] (CNT[2]), 
            .n9921(n9921), .CNT1_N_565(CNT1_N_565_adj_1764), .\CNT[3] (CNT[3]), 
            .n9885(n9885), .CNT1_N_565_adj_95(CNT1_N_565_adj_1762), .n10001(n10001)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U13 FIFOCNT_0 (.CNT1(CNT1_adj_105), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[0] (CNT[0]), .n10019(n10019)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U14 CNT_7__I_0_39 (.CNT1(CNT1_adj_106), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1756), .\CNT[7] (CNT[7]), .n10007(n10007)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U7
//

module COUNTER_U7 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[6] , 
            n10010) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[6] ;
    input n10010;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10010), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U8
//

module COUNTER_U8 (\CNT[5] , n9849, \CNT[6] , \CNT[7] , CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1392, CNT1_N_565_adj_99, n10013) /* synthesis syn_module_defined=1 */ ;
    output \CNT[5] ;
    input n9849;
    input \CNT[6] ;
    input \CNT[7] ;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565_adj_99;
    input n10013;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n9849), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_99), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10013), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U9
//

module COUNTER_U9 (\CNT[4] , n9885, \CNT[6] , \CNT[5] , CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1392, CNT1_N_565_adj_98, n10004) /* synthesis syn_module_defined=1 */ ;
    output \CNT[4] ;
    input n9885;
    input \CNT[6] ;
    input \CNT[5] ;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565_adj_98;
    input n10004;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n9885), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_98), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10004), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U10
//

module COUNTER_U10 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[3] , 
            n10016, n9921, \CNT[5] , \CNT[4] , CNT1_N_565_adj_97) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[3] ;
    input n10016;
    input n9921;
    input \CNT[5] ;
    input \CNT[4] ;
    output CNT1_N_565_adj_97;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10016), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n9921), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_565_adj_97)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U11
//

module COUNTER_U11 (\CNT[2] , n9946, \CNT[4] , \CNT[3] , n9849, CNT1_N_565, 
            Clk, n10022, CNT1, CNT_7__N_1392, CNT1_N_565_adj_96) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input n9946;
    input \CNT[4] ;
    input \CNT[3] ;
    output n9849;
    output CNT1_N_565;
    input Clk;
    input n10022;
    output CNT1;
    input CNT_7__N_1392;
    input CNT1_N_565_adj_96;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    LUT4 i6219_2_lut_rep_244_3_lut_4_lut (.A(\CNT[2] ), .B(n9946), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n9849)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6219_2_lut_rep_244_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n9946), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1S3AX CNT_14 (.D(n10022), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_96), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U12
//

module COUNTER_U12 (CNT1, Clk, CNT_7__N_1392, \CNT[1] , \CNT[0] , 
            n9946, \CNT[2] , n9921, CNT1_N_565, \CNT[3] , n9885, 
            CNT1_N_565_adj_95, n10001) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[1] ;
    input \CNT[0] ;
    output n9946;
    input \CNT[2] ;
    output n9921;
    output CNT1_N_565;
    input \CNT[3] ;
    output n9885;
    output CNT1_N_565_adj_95;
    input n10001;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i6014_2_lut_rep_341 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n9946)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i6014_2_lut_rep_341.init = 16'heeee;
    LUT4 i6142_2_lut_rep_316_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n9921)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i6142_2_lut_rep_316_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i6187_2_lut_rep_280_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n9885)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6187_2_lut_rep_280_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_565_adj_95)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1S3AX CNT_14 (.D(n10001), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U13
//

module COUNTER_U13 (CNT1, Clk, CNT_7__N_1392, \CNT[0] , n10019) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[0] ;
    input n10019;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10019), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module COUNTER_U14
//

module COUNTER_U14 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[7] , 
            n10007) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[7] ;
    input n10007;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10007), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U79
//

module FIFO_HPOSCNT_U79 (nVIS, ZH_FF, \EN[5] , Clk, Clk_enable_247, 
            Clk_enable_270, n10432, n10442, n3422, CNT, \SEL_LATCH[5] , 
            SH3, CNT1, n10151, CNT1_adj_88, n10154, CNT1_adj_89, 
            n10166, CNT1_adj_90, n10160, CNT1_adj_91, n10157, CNT1_adj_92, 
            n10163, n10148, CNT1_adj_93, CNT1_adj_94, n10145) /* synthesis syn_module_defined=1 */ ;
    input nVIS;
    output ZH_FF;
    output \EN[5] ;
    input Clk;
    input Clk_enable_247;
    input Clk_enable_270;
    input n10432;
    input n10442;
    output n3422;
    output [7:0]CNT;
    input \SEL_LATCH[5] ;
    input SH3;
    output CNT1;
    input n10151;
    output CNT1_adj_88;
    input n10154;
    output CNT1_adj_89;
    input n10166;
    output CNT1_adj_90;
    input n10160;
    output CNT1_adj_91;
    input n10157;
    output CNT1_adj_92;
    input n10163;
    input n10148;
    output CNT1_adj_93;
    output CNT1_adj_94;
    input n10145;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire EN_N_1395, ZH_FF_N_1401, n14, n10, CNT_7__N_1392, CNT1_N_565, 
        CNT1_N_565_adj_1739, n9857, CNT1_N_565_adj_1740, CNT1_N_565_adj_1742, 
        n9898, CNT1_N_565_adj_1744, n9929, n9960, CNT1_N_565_adj_1746;
    
    LUT4 i8909_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i8909_2_lut.init = 16'h1111;
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(Clk_enable_247), .CK(Clk), .Q(\EN[5] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    FD1P3IX ZH_FF_36 (.D(n10432), .SP(Clk_enable_270), .CD(ZH_FF_N_1401), 
            .CK(Clk), .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    LUT4 PCLK_I_0_40_2_lut (.A(n10442), .B(n3422), .Z(ZH_FF_N_1401)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1456[15:36])
    defparam PCLK_I_0_40_2_lut.init = 16'h2222;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3422)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 i8903_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n10442), .B(ZH_FF), .C(\SEL_LATCH[5] ), 
         .D(SH3), .Z(CNT_7__N_1392)) /* synthesis lut_function=(!(A (C (D))+!A (B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1449[16:33])
    defparam i8903_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h1bbb;
    COUNTER_U15 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565), .\CNT[6] (CNT[6]), .n10151(n10151)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U16 FIFOCNT_5 (.CNT1(CNT1_adj_88), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1739), .\CNT[5] (CNT[5]), .n10154(n10154), 
            .n9857(n9857), .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_565_adj_87(CNT1_N_565_adj_1740)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U17 FIFOCNT_4 (.CNT1(CNT1_adj_89), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1742), .\CNT[4] (CNT[4]), .n10166(n10166), 
            .n9898(n9898), .\CNT[6] (CNT[6]), .\CNT[5] (CNT[5]), .CNT1_N_565_adj_86(CNT1_N_565)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U18 FIFOCNT_3 (.CNT1(CNT1_adj_90), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1744), .\CNT[3] (CNT[3]), .n10160(n10160), 
            .n9929(n9929), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_565_adj_85(CNT1_N_565_adj_1739)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U19 FIFOCNT_2 (.\CNT[2] (CNT[2]), .n9960(n9960), .\CNT[4] (CNT[4]), 
            .\CNT[3] (CNT[3]), .n9857(n9857), .CNT1_N_565(CNT1_N_565_adj_1742), 
            .CNT1(CNT1_adj_91), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565_adj_84(CNT1_N_565_adj_1746), .n10157(n10157)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U20 FIFOCNT_1 (.CNT1(CNT1_adj_92), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .n9960(n9960), .\CNT[2] (CNT[2]), 
            .n9929(n9929), .CNT1_N_565(CNT1_N_565_adj_1746), .\CNT[3] (CNT[3]), 
            .n9898(n9898), .CNT1_N_565_adj_83(CNT1_N_565_adj_1744), .n10163(n10163)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U21 FIFOCNT_0 (.\CNT[0] (CNT[0]), .Clk(Clk), .n10148(n10148), 
            .CNT1(CNT1_adj_93), .CNT_7__N_1392(CNT_7__N_1392)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U22 CNT_7__I_0_39 (.CNT1(CNT1_adj_94), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1740), .\CNT[7] (CNT[7]), .n10145(n10145)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U15
//

module COUNTER_U15 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[6] , 
            n10151) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[6] ;
    input n10151;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10151), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U16
//

module COUNTER_U16 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[5] , 
            n10154, n9857, \CNT[6] , \CNT[7] , CNT1_N_565_adj_87) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[5] ;
    input n10154;
    input n9857;
    input \CNT[6] ;
    input \CNT[7] ;
    output CNT1_N_565_adj_87;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10154), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n9857), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_565_adj_87)) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    
endmodule
//
// Verilog Description of module COUNTER_U17
//

module COUNTER_U17 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[4] , 
            n10166, n9898, \CNT[6] , \CNT[5] , CNT1_N_565_adj_86) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[4] ;
    input n10166;
    input n9898;
    input \CNT[6] ;
    input \CNT[5] ;
    output CNT1_N_565_adj_86;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10166), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n9898), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_565_adj_86)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U18
//

module COUNTER_U18 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[3] , 
            n10160, n9929, \CNT[5] , \CNT[4] , CNT1_N_565_adj_85) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[3] ;
    input n10160;
    input n9929;
    input \CNT[5] ;
    input \CNT[4] ;
    output CNT1_N_565_adj_85;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10160), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n9929), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_565_adj_85)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U19
//

module COUNTER_U19 (\CNT[2] , n9960, \CNT[4] , \CNT[3] , n9857, CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1392, CNT1_N_565_adj_84, n10157) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input n9960;
    input \CNT[4] ;
    input \CNT[3] ;
    output n9857;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565_adj_84;
    input n10157;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    LUT4 i6217_2_lut_rep_252_3_lut_4_lut (.A(\CNT[2] ), .B(n9960), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n9857)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6217_2_lut_rep_252_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n9960), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_84), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10157), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U20
//

module COUNTER_U20 (CNT1, Clk, CNT_7__N_1392, \CNT[1] , \CNT[0] , 
            n9960, \CNT[2] , n9929, CNT1_N_565, \CNT[3] , n9898, 
            CNT1_N_565_adj_83, n10163) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[1] ;
    input \CNT[0] ;
    output n9960;
    input \CNT[2] ;
    output n9929;
    output CNT1_N_565;
    input \CNT[3] ;
    output n9898;
    output CNT1_N_565_adj_83;
    input n10163;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i6012_2_lut_rep_355 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n9960)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i6012_2_lut_rep_355.init = 16'heeee;
    LUT4 i6140_2_lut_rep_324_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n9929)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i6140_2_lut_rep_324_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i6185_2_lut_rep_293_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n9898)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6185_2_lut_rep_293_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_565_adj_83)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1S3AX CNT_14 (.D(n10163), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U21
//

module COUNTER_U21 (\CNT[0] , Clk, n10148, CNT1, CNT_7__N_1392) /* synthesis syn_module_defined=1 */ ;
    output \CNT[0] ;
    input Clk;
    input n10148;
    output CNT1;
    input CNT_7__N_1392;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    FD1S3AX CNT_14 (.D(n10148), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module COUNTER_U22
//

module COUNTER_U22 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[7] , 
            n10145) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[7] ;
    input n10145;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10145), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U80
//

module FIFO_HPOSCNT_U80 (\EN[4] , Clk, Clk_enable_173, n10442, n3426, 
            CNT, ZH_FF, Clk_enable_268, n10432, nVIS, \SEL_LATCH[4] , 
            SH3, CNT1, n10172, CNT1_adj_76, n10175, CNT1_adj_77, 
            n10178, CNT1_adj_78, n10181, CNT1_adj_79, n10184, CNT1_adj_80, 
            n10190, CNT1_adj_81, n10187, CNT1_adj_82, n10169) /* synthesis syn_module_defined=1 */ ;
    output \EN[4] ;
    input Clk;
    input Clk_enable_173;
    input n10442;
    output n3426;
    output [7:0]CNT;
    output ZH_FF;
    input Clk_enable_268;
    input n10432;
    input nVIS;
    input \SEL_LATCH[4] ;
    input SH3;
    output CNT1;
    input n10172;
    output CNT1_adj_76;
    input n10175;
    output CNT1_adj_77;
    input n10178;
    output CNT1_adj_78;
    input n10181;
    output CNT1_adj_79;
    input n10184;
    output CNT1_adj_80;
    input n10190;
    output CNT1_adj_81;
    input n10187;
    output CNT1_adj_82;
    input n10169;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire EN_N_1395, ZH_FF_N_1401, n14, n10, CNT_7__N_1392, CNT1_N_565, 
        CNT1_N_565_adj_1721, n9854, CNT1_N_565_adj_1722, CNT1_N_565_adj_1724, 
        n9893, CNT1_N_565_adj_1726, n9926, n9949, CNT1_N_565_adj_1728;
    
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(Clk_enable_173), .CK(Clk), .Q(\EN[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 PCLK_I_0_40_2_lut (.A(n10442), .B(n3426), .Z(ZH_FF_N_1401)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1456[15:36])
    defparam PCLK_I_0_40_2_lut.init = 16'h2222;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3426)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    FD1P3IX ZH_FF_36 (.D(n10432), .SP(Clk_enable_268), .CD(ZH_FF_N_1401), 
            .CK(Clk), .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 i8901_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i8901_2_lut.init = 16'h1111;
    LUT4 i8897_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n10442), .B(ZH_FF), .C(\SEL_LATCH[4] ), 
         .D(SH3), .Z(CNT_7__N_1392)) /* synthesis lut_function=(!(A (C (D))+!A (B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1449[16:33])
    defparam i8897_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h1bbb;
    COUNTER_U23 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565), .\CNT[6] (CNT[6]), .n10172(n10172)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U24 FIFOCNT_5 (.CNT1(CNT1_adj_76), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1721), .\CNT[5] (CNT[5]), .n10175(n10175), 
            .n9854(n9854), .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_565_adj_75(CNT1_N_565_adj_1722)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U25 FIFOCNT_4 (.CNT1(CNT1_adj_77), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1724), .\CNT[4] (CNT[4]), .n10178(n10178), 
            .n9893(n9893), .\CNT[6] (CNT[6]), .\CNT[5] (CNT[5]), .CNT1_N_565_adj_74(CNT1_N_565)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U26 FIFOCNT_3 (.CNT1(CNT1_adj_78), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1726), .\CNT[3] (CNT[3]), .n10181(n10181), 
            .n9926(n9926), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_565_adj_73(CNT1_N_565_adj_1721)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U27 FIFOCNT_2 (.\CNT[2] (CNT[2]), .n9949(n9949), .\CNT[4] (CNT[4]), 
            .\CNT[3] (CNT[3]), .n9854(n9854), .CNT1_N_565(CNT1_N_565_adj_1724), 
            .CNT1(CNT1_adj_79), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565_adj_72(CNT1_N_565_adj_1728), .n10184(n10184)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U28 FIFOCNT_1 (.\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .n9949(n9949), 
            .\CNT[2] (CNT[2]), .n9926(n9926), .CNT1_N_565(CNT1_N_565_adj_1728), 
            .\CNT[3] (CNT[3]), .n9893(n9893), .CNT1_N_565_adj_71(CNT1_N_565_adj_1726), 
            .CNT1(CNT1_adj_80), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .n10190(n10190)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U29 FIFOCNT_0 (.\CNT[0] (CNT[0]), .CNT1(CNT1_adj_81), .Clk(Clk), 
            .CNT_7__N_1392(CNT_7__N_1392), .n10187(n10187)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U30 CNT_7__I_0_39 (.CNT1(CNT1_adj_82), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1722), .\CNT[7] (CNT[7]), .n10169(n10169)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U23
//

module COUNTER_U23 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[6] , 
            n10172) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[6] ;
    input n10172;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10172), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U24
//

module COUNTER_U24 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[5] , 
            n10175, n9854, \CNT[6] , \CNT[7] , CNT1_N_565_adj_75) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[5] ;
    input n10175;
    input n9854;
    input \CNT[6] ;
    input \CNT[7] ;
    output CNT1_N_565_adj_75;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10175), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n9854), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_565_adj_75)) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    
endmodule
//
// Verilog Description of module COUNTER_U25
//

module COUNTER_U25 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[4] , 
            n10178, n9893, \CNT[6] , \CNT[5] , CNT1_N_565_adj_74) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[4] ;
    input n10178;
    input n9893;
    input \CNT[6] ;
    input \CNT[5] ;
    output CNT1_N_565_adj_74;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10178), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n9893), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_565_adj_74)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U26
//

module COUNTER_U26 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[3] , 
            n10181, n9926, \CNT[5] , \CNT[4] , CNT1_N_565_adj_73) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[3] ;
    input n10181;
    input n9926;
    input \CNT[5] ;
    input \CNT[4] ;
    output CNT1_N_565_adj_73;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10181), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n9926), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_565_adj_73)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U27
//

module COUNTER_U27 (\CNT[2] , n9949, \CNT[4] , \CNT[3] , n9854, CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1392, CNT1_N_565_adj_72, n10184) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input n9949;
    input \CNT[4] ;
    input \CNT[3] ;
    output n9854;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565_adj_72;
    input n10184;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    LUT4 i6215_2_lut_rep_249_3_lut_4_lut (.A(\CNT[2] ), .B(n9949), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n9854)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6215_2_lut_rep_249_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n9949), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_72), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10184), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U28
//

module COUNTER_U28 (\CNT[1] , \CNT[0] , n9949, \CNT[2] , n9926, CNT1_N_565, 
            \CNT[3] , n9893, CNT1_N_565_adj_71, CNT1, Clk, CNT_7__N_1392, 
            n10190) /* synthesis syn_module_defined=1 */ ;
    output \CNT[1] ;
    input \CNT[0] ;
    output n9949;
    input \CNT[2] ;
    output n9926;
    output CNT1_N_565;
    input \CNT[3] ;
    output n9893;
    output CNT1_N_565_adj_71;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input n10190;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i6009_2_lut_rep_344 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n9949)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i6009_2_lut_rep_344.init = 16'heeee;
    LUT4 i6138_2_lut_rep_321_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n9926)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i6138_2_lut_rep_321_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i6183_2_lut_rep_288_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n9893)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6183_2_lut_rep_288_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_565_adj_71)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10190), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U29
//

module COUNTER_U29 (\CNT[0] , CNT1, Clk, CNT_7__N_1392, n10187) /* synthesis syn_module_defined=1 */ ;
    output \CNT[0] ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input n10187;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10187), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U30
//

module COUNTER_U30 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[7] , 
            n10169) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[7] ;
    input n10169;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10169), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U81
//

module FIFO_HPOSCNT_U81 (\EN[3] , Clk, Clk_enable_571, n10442, n3427, 
            CNT, ZH_FF, Clk_enable_265, n10432, \SEL_LATCH[3] , SH3, 
            nVIS, CNT1, n10067, n10064, CNT1_adj_64, CNT1_adj_65, 
            n10049, CNT1_adj_66, n10052, CNT1_adj_67, n10055, CNT1_adj_68, 
            n10058, CNT1_adj_69, n10061, CNT1_adj_70, n10070) /* synthesis syn_module_defined=1 */ ;
    output \EN[3] ;
    input Clk;
    input Clk_enable_571;
    input n10442;
    output n3427;
    output [7:0]CNT;
    output ZH_FF;
    input Clk_enable_265;
    input n10432;
    input \SEL_LATCH[3] ;
    input SH3;
    input nVIS;
    output CNT1;
    input n10067;
    input n10064;
    output CNT1_adj_64;
    output CNT1_adj_65;
    input n10049;
    output CNT1_adj_66;
    input n10052;
    output CNT1_adj_67;
    input n10055;
    output CNT1_adj_68;
    input n10058;
    output CNT1_adj_69;
    input n10061;
    output CNT1_adj_70;
    input n10070;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire EN_N_1395, ZH_FF_N_1401, n14, n10, CNT_7__N_1392, CNT1_N_565, 
        CNT1_N_565_adj_1703, n9858, CNT1_N_565_adj_1704, CNT1_N_565_adj_1706, 
        n9903, CNT1_N_565_adj_1708, n9934, n9968, CNT1_N_565_adj_1710;
    
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(Clk_enable_571), .CK(Clk), .Q(\EN[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 PCLK_I_0_40_2_lut (.A(n10442), .B(n3427), .Z(ZH_FF_N_1401)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1456[15:36])
    defparam PCLK_I_0_40_2_lut.init = 16'h2222;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3427)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    FD1P3IX ZH_FF_36 (.D(n10432), .SP(Clk_enable_265), .CD(ZH_FF_N_1401), 
            .CK(Clk), .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    LUT4 i8892_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n10442), .B(ZH_FF), .C(\SEL_LATCH[3] ), 
         .D(SH3), .Z(CNT_7__N_1392)) /* synthesis lut_function=(!(A (C (D))+!A (B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1449[16:33])
    defparam i8892_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h1bbb;
    LUT4 i8895_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i8895_2_lut.init = 16'h1111;
    COUNTER_U31 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565), .\CNT[6] (CNT[6]), .n10067(n10067)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U32 FIFOCNT_5 (.\CNT[5] (CNT[5]), .Clk(Clk), .n10064(n10064), 
            .CNT1(CNT1_adj_64), .CNT_7__N_1392(CNT_7__N_1392), .CNT1_N_565(CNT1_N_565_adj_1703), 
            .n9858(n9858), .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_565_adj_63(CNT1_N_565_adj_1704)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U33 FIFOCNT_4 (.CNT1(CNT1_adj_65), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1706), .\CNT[4] (CNT[4]), .n9903(n9903), 
            .\CNT[6] (CNT[6]), .\CNT[5] (CNT[5]), .CNT1_N_565_adj_62(CNT1_N_565), 
            .n10049(n10049)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U34 FIFOCNT_3 (.CNT1(CNT1_adj_66), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1708), .\CNT[3] (CNT[3]), .n10052(n10052), 
            .n9934(n9934), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_565_adj_61(CNT1_N_565_adj_1703)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U35 FIFOCNT_2 (.\CNT[2] (CNT[2]), .n9968(n9968), .\CNT[4] (CNT[4]), 
            .\CNT[3] (CNT[3]), .CNT1_N_565(CNT1_N_565_adj_1706), .n9858(n9858), 
            .CNT1(CNT1_adj_67), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565_adj_60(CNT1_N_565_adj_1710), .n10055(n10055)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U36 FIFOCNT_1 (.\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .n9968(n9968), 
            .\CNT[2] (CNT[2]), .n9934(n9934), .CNT1_N_565(CNT1_N_565_adj_1710), 
            .\CNT[3] (CNT[3]), .n9903(n9903), .CNT1_N_565_adj_59(CNT1_N_565_adj_1708), 
            .CNT1(CNT1_adj_68), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .n10058(n10058)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U37 FIFOCNT_0 (.CNT1(CNT1_adj_69), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[0] (CNT[0]), .n10061(n10061)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U38 CNT_7__I_0_39 (.CNT1(CNT1_adj_70), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1704), .\CNT[7] (CNT[7]), .n10070(n10070)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U31
//

module COUNTER_U31 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[6] , 
            n10067) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[6] ;
    input n10067;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10067), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U32
//

module COUNTER_U32 (\CNT[5] , Clk, n10064, CNT1, CNT_7__N_1392, CNT1_N_565, 
            n9858, \CNT[6] , \CNT[7] , CNT1_N_565_adj_63) /* synthesis syn_module_defined=1 */ ;
    output \CNT[5] ;
    input Clk;
    input n10064;
    output CNT1;
    input CNT_7__N_1392;
    input CNT1_N_565;
    input n9858;
    input \CNT[6] ;
    input \CNT[7] ;
    output CNT1_N_565_adj_63;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1S3AX CNT_14 (.D(n10064), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n9858), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_565_adj_63)) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    
endmodule
//
// Verilog Description of module COUNTER_U33
//

module COUNTER_U33 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[4] , 
            n9903, \CNT[6] , \CNT[5] , CNT1_N_565_adj_62, n10049) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[4] ;
    input n9903;
    input \CNT[6] ;
    input \CNT[5] ;
    output CNT1_N_565_adj_62;
    input n10049;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n9903), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_565_adj_62)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1S3AX CNT_14 (.D(n10049), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U34
//

module COUNTER_U34 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[3] , 
            n10052, n9934, \CNT[5] , \CNT[4] , CNT1_N_565_adj_61) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[3] ;
    input n10052;
    input n9934;
    input \CNT[5] ;
    input \CNT[4] ;
    output CNT1_N_565_adj_61;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10052), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n9934), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_565_adj_61)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U35
//

module COUNTER_U35 (\CNT[2] , n9968, \CNT[4] , \CNT[3] , CNT1_N_565, 
            n9858, CNT1, Clk, CNT_7__N_1392, CNT1_N_565_adj_60, n10055) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input n9968;
    input \CNT[4] ;
    input \CNT[3] ;
    output CNT1_N_565;
    output n9858;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565_adj_60;
    input n10055;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n9968), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    LUT4 i6213_2_lut_rep_253_3_lut_4_lut (.A(\CNT[2] ), .B(n9968), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n9858)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6213_2_lut_rep_253_3_lut_4_lut.init = 16'hfffe;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_60), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10055), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U36
//

module COUNTER_U36 (\CNT[1] , \CNT[0] , n9968, \CNT[2] , n9934, CNT1_N_565, 
            \CNT[3] , n9903, CNT1_N_565_adj_59, CNT1, Clk, CNT_7__N_1392, 
            n10058) /* synthesis syn_module_defined=1 */ ;
    output \CNT[1] ;
    input \CNT[0] ;
    output n9968;
    input \CNT[2] ;
    output n9934;
    output CNT1_N_565;
    input \CNT[3] ;
    output n9903;
    output CNT1_N_565_adj_59;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input n10058;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_adj_1697;
    
    LUT4 i6004_2_lut_rep_363 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n9968)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i6004_2_lut_rep_363.init = 16'heeee;
    LUT4 i6136_2_lut_rep_329_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n9934)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i6136_2_lut_rep_329_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i6181_2_lut_rep_298_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n9903)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6181_2_lut_rep_298_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_565_adj_59)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_adj_1697)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1697), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10058), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U37
//

module COUNTER_U37 (CNT1, Clk, CNT_7__N_1392, \CNT[0] , n10061) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[0] ;
    input n10061;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10061), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module COUNTER_U38
//

module COUNTER_U38 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[7] , 
            n10070) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[7] ;
    input n10070;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10070), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U82
//

module FIFO_HPOSCNT_U82 (\EN[2] , Clk, Clk_enable_571, n10442, n3428, 
            CNT, ZH_FF, Clk_enable_262, n10432, nVIS, \SEL_LATCH[2] , 
            SH3, CNT1, n10124, CNT1_adj_52, n10127, CNT1_adj_53, 
            n10130, CNT1_adj_54, n10133, CNT1_adj_55, n10136, CNT1_adj_56, 
            n10142, CNT1_adj_57, n10139, CNT1_adj_58, n10121) /* synthesis syn_module_defined=1 */ ;
    output \EN[2] ;
    input Clk;
    input Clk_enable_571;
    input n10442;
    output n3428;
    output [7:0]CNT;
    output ZH_FF;
    input Clk_enable_262;
    input n10432;
    input nVIS;
    input \SEL_LATCH[2] ;
    input SH3;
    output CNT1;
    input n10124;
    output CNT1_adj_52;
    input n10127;
    output CNT1_adj_53;
    input n10130;
    output CNT1_adj_54;
    input n10133;
    output CNT1_adj_55;
    input n10136;
    output CNT1_adj_56;
    input n10142;
    output CNT1_adj_57;
    input n10139;
    output CNT1_adj_58;
    input n10121;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire EN_N_1395, ZH_FF_N_1401, n14, n10, CNT_7__N_1392, CNT1_N_565, 
        CNT1_N_565_adj_1685, n9861, CNT1_N_565_adj_1686, n9902, CNT1_N_565_adj_1688, 
        CNT1_N_565_adj_1690, n9933, n9965, CNT1_N_565_adj_1692;
    
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(Clk_enable_571), .CK(Clk), .Q(\EN[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 PCLK_I_0_40_2_lut (.A(n10442), .B(n3428), .Z(ZH_FF_N_1401)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1456[15:36])
    defparam PCLK_I_0_40_2_lut.init = 16'h2222;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3428)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    FD1P3IX ZH_FF_36 (.D(n10432), .SP(Clk_enable_262), .CD(ZH_FF_N_1401), 
            .CK(Clk), .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    LUT4 i8890_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i8890_2_lut.init = 16'h1111;
    LUT4 i8886_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n10442), .B(ZH_FF), .C(\SEL_LATCH[2] ), 
         .D(SH3), .Z(CNT_7__N_1392)) /* synthesis lut_function=(!(A (C (D))+!A (B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1449[16:33])
    defparam i8886_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h1bbb;
    COUNTER_U39 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565), .\CNT[6] (CNT[6]), .n10124(n10124)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U40 FIFOCNT_5 (.CNT1(CNT1_adj_52), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1685), .\CNT[5] (CNT[5]), .n10127(n10127), 
            .n9861(n9861), .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_565_adj_51(CNT1_N_565_adj_1686)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U41 FIFOCNT_4 (.\CNT[4] (CNT[4]), .n9902(n9902), .\CNT[6] (CNT[6]), 
            .\CNT[5] (CNT[5]), .CNT1_N_565(CNT1_N_565), .CNT1(CNT1_adj_53), 
            .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), .CNT1_N_565_adj_50(CNT1_N_565_adj_1688), 
            .n10130(n10130)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U42 FIFOCNT_3 (.CNT1(CNT1_adj_54), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1690), .\CNT[3] (CNT[3]), .n10133(n10133), 
            .n9933(n9933), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_565_adj_49(CNT1_N_565_adj_1685)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U43 FIFOCNT_2 (.\CNT[2] (CNT[2]), .n9965(n9965), .\CNT[4] (CNT[4]), 
            .\CNT[3] (CNT[3]), .n9861(n9861), .CNT1_N_565(CNT1_N_565_adj_1688), 
            .CNT1(CNT1_adj_55), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565_adj_48(CNT1_N_565_adj_1692), .n10136(n10136)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U44 FIFOCNT_1 (.\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .n9965(n9965), 
            .\CNT[2] (CNT[2]), .n9933(n9933), .CNT1_N_565(CNT1_N_565_adj_1692), 
            .\CNT[3] (CNT[3]), .n9902(n9902), .CNT1_N_565_adj_47(CNT1_N_565_adj_1690), 
            .CNT1(CNT1_adj_56), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .n10142(n10142)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U45 FIFOCNT_0 (.CNT1(CNT1_adj_57), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[0] (CNT[0]), .n10139(n10139)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U46 CNT_7__I_0_39 (.CNT1(CNT1_adj_58), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1686), .\CNT[7] (CNT[7]), .n10121(n10121)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U39
//

module COUNTER_U39 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[6] , 
            n10124) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[6] ;
    input n10124;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10124), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U40
//

module COUNTER_U40 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[5] , 
            n10127, n9861, \CNT[6] , \CNT[7] , CNT1_N_565_adj_51) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[5] ;
    input n10127;
    input n9861;
    input \CNT[6] ;
    input \CNT[7] ;
    output CNT1_N_565_adj_51;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10127), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n9861), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_565_adj_51)) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    
endmodule
//
// Verilog Description of module COUNTER_U41
//

module COUNTER_U41 (\CNT[4] , n9902, \CNT[6] , \CNT[5] , CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1392, CNT1_N_565_adj_50, n10130) /* synthesis syn_module_defined=1 */ ;
    output \CNT[4] ;
    input n9902;
    input \CNT[6] ;
    input \CNT[5] ;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565_adj_50;
    input n10130;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n9902), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_50), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10130), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U42
//

module COUNTER_U42 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[3] , 
            n10133, n9933, \CNT[5] , \CNT[4] , CNT1_N_565_adj_49) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[3] ;
    input n10133;
    input n9933;
    input \CNT[5] ;
    input \CNT[4] ;
    output CNT1_N_565_adj_49;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10133), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n9933), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_565_adj_49)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U43
//

module COUNTER_U43 (\CNT[2] , n9965, \CNT[4] , \CNT[3] , n9861, CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1392, CNT1_N_565_adj_48, n10136) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input n9965;
    input \CNT[4] ;
    input \CNT[3] ;
    output n9861;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565_adj_48;
    input n10136;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    LUT4 i6211_2_lut_rep_256_3_lut_4_lut (.A(\CNT[2] ), .B(n9965), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n9861)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6211_2_lut_rep_256_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n9965), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_48), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10136), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U44
//

module COUNTER_U44 (\CNT[1] , \CNT[0] , n9965, \CNT[2] , n9933, CNT1_N_565, 
            \CNT[3] , n9902, CNT1_N_565_adj_47, CNT1, Clk, CNT_7__N_1392, 
            n10142) /* synthesis syn_module_defined=1 */ ;
    output \CNT[1] ;
    input \CNT[0] ;
    output n9965;
    input \CNT[2] ;
    output n9933;
    output CNT1_N_565;
    input \CNT[3] ;
    output n9902;
    output CNT1_N_565_adj_47;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input n10142;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_adj_1679;
    
    LUT4 i5999_2_lut_rep_360 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n9965)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i5999_2_lut_rep_360.init = 16'heeee;
    LUT4 i6134_2_lut_rep_328_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n9933)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i6134_2_lut_rep_328_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i6179_2_lut_rep_297_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n9902)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6179_2_lut_rep_297_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_565_adj_47)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1679), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10142), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_adj_1679)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U45
//

module COUNTER_U45 (CNT1, Clk, CNT_7__N_1392, \CNT[0] , n10139) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[0] ;
    input n10139;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10139), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module COUNTER_U46
//

module COUNTER_U46 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[7] , 
            n10121) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[7] ;
    input n10121;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10121), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U83
//

module FIFO_HPOSCNT_U83 (\EN[1] , Clk, Clk_enable_571, nVIS, ZH_FF, 
            Clk_enable_320, n10432, CNT, n10442, \SEL_LATCH[1] , SH3, 
            n3429, CNT1, n10076, CNT1_adj_40, n10079, CNT1_adj_41, 
            n10082, CNT1_adj_42, n10085, CNT1_adj_43, n10088, CNT1_adj_44, 
            n10094, CNT1_adj_45, n10091, CNT1_adj_46, n10073) /* synthesis syn_module_defined=1 */ ;
    output \EN[1] ;
    input Clk;
    input Clk_enable_571;
    input nVIS;
    output ZH_FF;
    input Clk_enable_320;
    input n10432;
    output [7:0]CNT;
    input n10442;
    input \SEL_LATCH[1] ;
    input SH3;
    output n3429;
    output CNT1;
    input n10076;
    output CNT1_adj_40;
    input n10079;
    output CNT1_adj_41;
    input n10082;
    output CNT1_adj_42;
    input n10085;
    output CNT1_adj_43;
    input n10088;
    output CNT1_adj_44;
    input n10094;
    output CNT1_adj_45;
    input n10091;
    output CNT1_adj_46;
    input n10073;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire EN_N_1395, ZH_FF_N_1401, n10, CNT_7__N_1392, n14, CNT1_N_565, 
        CNT1_N_565_adj_1667, n9862, CNT1_N_565_adj_1668, n9904, CNT1_N_565_adj_1670, 
        CNT1_N_565_adj_1672, n9936, n9971, CNT1_N_565_adj_1674;
    
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(Clk_enable_571), .CK(Clk), .Q(\EN[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    LUT4 i8884_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i8884_2_lut.init = 16'h1111;
    FD1P3IX ZH_FF_36 (.D(n10432), .SP(Clk_enable_320), .CD(ZH_FF_N_1401), 
            .CK(Clk), .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 i8880_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n10442), .B(ZH_FF), .C(\SEL_LATCH[1] ), 
         .D(SH3), .Z(CNT_7__N_1392)) /* synthesis lut_function=(!(A (C (D))+!A (B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1449[16:33])
    defparam i8880_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h1bbb;
    LUT4 PCLK_I_0_40_2_lut (.A(n10442), .B(n3429), .Z(ZH_FF_N_1401)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1456[15:36])
    defparam PCLK_I_0_40_2_lut.init = 16'h2222;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3429)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    COUNTER_U47 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565), .\CNT[6] (CNT[6]), .n10076(n10076)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U48 FIFOCNT_5 (.CNT1(CNT1_adj_40), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1667), .\CNT[5] (CNT[5]), .n10079(n10079), 
            .n9862(n9862), .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_565_adj_39(CNT1_N_565_adj_1668)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U49 FIFOCNT_4 (.\CNT[4] (CNT[4]), .n9904(n9904), .\CNT[6] (CNT[6]), 
            .\CNT[5] (CNT[5]), .CNT1_N_565(CNT1_N_565), .CNT1(CNT1_adj_41), 
            .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), .CNT1_N_565_adj_38(CNT1_N_565_adj_1670), 
            .n10082(n10082)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U50 FIFOCNT_3 (.CNT1(CNT1_adj_42), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1672), .\CNT[3] (CNT[3]), .n10085(n10085), 
            .n9936(n9936), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_565_adj_37(CNT1_N_565_adj_1667)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U51 FIFOCNT_2 (.\CNT[2] (CNT[2]), .n9971(n9971), .\CNT[4] (CNT[4]), 
            .\CNT[3] (CNT[3]), .n9862(n9862), .CNT1_N_565(CNT1_N_565_adj_1670), 
            .CNT1(CNT1_adj_43), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565_adj_36(CNT1_N_565_adj_1674), .n10088(n10088)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U52 FIFOCNT_1 (.\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .n9971(n9971), 
            .\CNT[2] (CNT[2]), .n9936(n9936), .CNT1_N_565(CNT1_N_565_adj_1674), 
            .\CNT[3] (CNT[3]), .n9904(n9904), .CNT1_N_565_adj_35(CNT1_N_565_adj_1672), 
            .CNT1(CNT1_adj_44), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .n10094(n10094)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U53 FIFOCNT_0 (.CNT1(CNT1_adj_45), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[0] (CNT[0]), .n10091(n10091)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U54 CNT_7__I_0_39 (.CNT1(CNT1_adj_46), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1668), .\CNT[7] (CNT[7]), .n10073(n10073)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U47
//

module COUNTER_U47 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[6] , 
            n10076) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[6] ;
    input n10076;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10076), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U48
//

module COUNTER_U48 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[5] , 
            n10079, n9862, \CNT[6] , \CNT[7] , CNT1_N_565_adj_39) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[5] ;
    input n10079;
    input n9862;
    input \CNT[6] ;
    input \CNT[7] ;
    output CNT1_N_565_adj_39;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10079), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n9862), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_565_adj_39)) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    
endmodule
//
// Verilog Description of module COUNTER_U49
//

module COUNTER_U49 (\CNT[4] , n9904, \CNT[6] , \CNT[5] , CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1392, CNT1_N_565_adj_38, n10082) /* synthesis syn_module_defined=1 */ ;
    output \CNT[4] ;
    input n9904;
    input \CNT[6] ;
    input \CNT[5] ;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565_adj_38;
    input n10082;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n9904), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_38), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10082), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U50
//

module COUNTER_U50 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[3] , 
            n10085, n9936, \CNT[5] , \CNT[4] , CNT1_N_565_adj_37) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[3] ;
    input n10085;
    input n9936;
    input \CNT[5] ;
    input \CNT[4] ;
    output CNT1_N_565_adj_37;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10085), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n9936), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_565_adj_37)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U51
//

module COUNTER_U51 (\CNT[2] , n9971, \CNT[4] , \CNT[3] , n9862, CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1392, CNT1_N_565_adj_36, n10088) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input n9971;
    input \CNT[4] ;
    input \CNT[3] ;
    output n9862;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565_adj_36;
    input n10088;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    LUT4 i6209_2_lut_rep_257_3_lut_4_lut (.A(\CNT[2] ), .B(n9971), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n9862)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6209_2_lut_rep_257_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n9971), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_36), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10088), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U52
//

module COUNTER_U52 (\CNT[1] , \CNT[0] , n9971, \CNT[2] , n9936, CNT1_N_565, 
            \CNT[3] , n9904, CNT1_N_565_adj_35, CNT1, Clk, CNT_7__N_1392, 
            n10094) /* synthesis syn_module_defined=1 */ ;
    output \CNT[1] ;
    input \CNT[0] ;
    output n9971;
    input \CNT[2] ;
    output n9936;
    output CNT1_N_565;
    input \CNT[3] ;
    output n9904;
    output CNT1_N_565_adj_35;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input n10094;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_adj_1661;
    
    LUT4 i5996_2_lut_rep_366 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n9971)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i5996_2_lut_rep_366.init = 16'heeee;
    LUT4 i6132_2_lut_rep_331_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n9936)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i6132_2_lut_rep_331_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i6177_2_lut_rep_299_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n9904)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6177_2_lut_rep_299_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_565_adj_35)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1661), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10094), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_adj_1661)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    
endmodule
//
// Verilog Description of module COUNTER_U53
//

module COUNTER_U53 (CNT1, Clk, CNT_7__N_1392, \CNT[0] , n10091) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[0] ;
    input n10091;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10091), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module COUNTER_U54
//

module COUNTER_U54 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[7] , 
            n10073) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[7] ;
    input n10073;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10073), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U84
//

module FIFO_HPOSCNT_U84 (\EN[0] , Clk, Clk_enable_571, ZH_FF, nVIS, 
            n10442, \SEL_LATCH[0] , SH3, CNT, \ZPOS[2] , n3428, 
            Clk_enable_262, n3427, Clk_enable_265, n3426, Clk_enable_268, 
            n3422, Clk_enable_270, n3396, Clk_enable_271, n3373, Clk_enable_272, 
            n3429, Clk_enable_320, CNT1, n10028, CNT1_adj_28, n10031, 
            CNT1_adj_29, n10034, CNT1_adj_30, n10037, CNT1_adj_31, 
            n10040, CNT1_adj_32, n10046, CNT1_adj_33, n10043, CNT1_adj_34, 
            n10025) /* synthesis syn_module_defined=1 */ ;
    output \EN[0] ;
    input Clk;
    input Clk_enable_571;
    output ZH_FF;
    input nVIS;
    input n10442;
    input \SEL_LATCH[0] ;
    input SH3;
    output [7:0]CNT;
    input \ZPOS[2] ;
    input n3428;
    output Clk_enable_262;
    input n3427;
    output Clk_enable_265;
    input n3426;
    output Clk_enable_268;
    input n3422;
    output Clk_enable_270;
    input n3396;
    output Clk_enable_271;
    input n3373;
    output Clk_enable_272;
    input n3429;
    output Clk_enable_320;
    output CNT1;
    input n10028;
    output CNT1_adj_28;
    input n10031;
    output CNT1_adj_29;
    input n10034;
    output CNT1_adj_30;
    input n10037;
    output CNT1_adj_31;
    input n10040;
    output CNT1_adj_32;
    input n10046;
    output CNT1_adj_33;
    input n10043;
    output CNT1_adj_34;
    input n10025;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire EN_N_1395, Clk_enable_129, ZH_FF_N_1401, CNT_7__N_1392, n14, 
        n10, n3430, CNT1_N_565, CNT1_N_565_adj_1649, n9865, CNT1_N_565_adj_1650, 
        CNT1_N_565_adj_1652, n9906, CNT1_N_565_adj_1654, n9940, n9982, 
        CNT1_N_565_adj_1656;
    
    FD1P3AX EN_37 (.D(EN_N_1395), .SP(Clk_enable_571), .CK(Clk), .Q(\EN[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam EN_37.GSR = "DISABLED";
    FD1P3AX ZH_FF_36 (.D(ZH_FF_N_1401), .SP(Clk_enable_129), .CK(Clk), 
            .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1455[8] 1459[27])
    defparam ZH_FF_36.GSR = "DISABLED";
    LUT4 i8878_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1395)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1458[27:44])
    defparam i8878_2_lut.init = 16'h1111;
    LUT4 i8874_2_lut_2_lut_3_lut_4_lut_4_lut (.A(n10442), .B(ZH_FF), .C(\SEL_LATCH[0] ), 
         .D(SH3), .Z(CNT_7__N_1392)) /* synthesis lut_function=(!(A (C (D))+!A (B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1449[16:33])
    defparam i8874_2_lut_2_lut_3_lut_4_lut_4_lut.init = 16'h1bbb;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n3430)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1457[32:46])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 i5974_2_lut_3_lut (.A(n10442), .B(\ZPOS[2] ), .C(n3428), .Z(Clk_enable_262)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i5974_2_lut_3_lut.init = 16'h8080;
    LUT4 i5978_2_lut_3_lut (.A(n10442), .B(\ZPOS[2] ), .C(n3427), .Z(Clk_enable_265)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i5978_2_lut_3_lut.init = 16'h8080;
    LUT4 i5980_2_lut_3_lut (.A(n10442), .B(\ZPOS[2] ), .C(n3426), .Z(Clk_enable_268)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i5980_2_lut_3_lut.init = 16'h8080;
    LUT4 i5982_2_lut_3_lut (.A(n10442), .B(\ZPOS[2] ), .C(n3422), .Z(Clk_enable_270)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i5982_2_lut_3_lut.init = 16'h8080;
    LUT4 i5984_2_lut_3_lut (.A(n10442), .B(\ZPOS[2] ), .C(n3396), .Z(Clk_enable_271)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i5984_2_lut_3_lut.init = 16'h8080;
    LUT4 i5989_2_lut_3_lut (.A(n10442), .B(\ZPOS[2] ), .C(n3373), .Z(Clk_enable_272)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i5989_2_lut_3_lut.init = 16'h8080;
    LUT4 i5972_2_lut_3_lut (.A(n10442), .B(\ZPOS[2] ), .C(n3429), .Z(Clk_enable_320)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i5972_2_lut_3_lut.init = 16'h8080;
    LUT4 i8906_2_lut_2_lut (.A(n10442), .B(n3430), .Z(ZH_FF_N_1401)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1456[15:36])
    defparam i8906_2_lut_2_lut.init = 16'hdddd;
    LUT4 n6463_bdd_3_lut_4_lut_3_lut (.A(n10442), .B(n3430), .C(\ZPOS[2] ), 
         .Z(Clk_enable_129)) /* synthesis lut_function=(A ((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1456[15:36])
    defparam n6463_bdd_3_lut_4_lut_3_lut.init = 16'ha2a2;
    COUNTER_U55 FIFOCNT_6 (.CNT1(CNT1), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565), .\CNT[6] (CNT[6]), .n10028(n10028)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U56 FIFOCNT_5 (.CNT1(CNT1_adj_28), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1649), .\CNT[5] (CNT[5]), .n10031(n10031), 
            .n9865(n9865), .\CNT[6] (CNT[6]), .\CNT[7] (CNT[7]), .CNT1_N_565_adj_27(CNT1_N_565_adj_1650)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U57 FIFOCNT_4 (.CNT1(CNT1_adj_29), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1652), .\CNT[4] (CNT[4]), .n10034(n10034), 
            .n9906(n9906), .\CNT[6] (CNT[6]), .\CNT[5] (CNT[5]), .CNT1_N_565_adj_26(CNT1_N_565)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U58 FIFOCNT_3 (.CNT1(CNT1_adj_30), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1654), .\CNT[3] (CNT[3]), .n10037(n10037), 
            .n9940(n9940), .\CNT[5] (CNT[5]), .\CNT[4] (CNT[4]), .CNT1_N_565_adj_25(CNT1_N_565_adj_1649)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U59 FIFOCNT_2 (.\CNT[2] (CNT[2]), .n9982(n9982), .\CNT[4] (CNT[4]), 
            .\CNT[3] (CNT[3]), .n9865(n9865), .CNT1_N_565(CNT1_N_565_adj_1652), 
            .CNT1(CNT1_adj_31), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565_adj_24(CNT1_N_565_adj_1656), .n10040(n10040)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U60 FIFOCNT_1 (.\CNT[1] (CNT[1]), .\CNT[0] (CNT[0]), .CNT1(CNT1_adj_32), 
            .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), .n10046(n10046), 
            .n9982(n9982), .\CNT[2] (CNT[2]), .n9940(n9940), .CNT1_N_565(CNT1_N_565_adj_1656), 
            .\CNT[3] (CNT[3]), .n9906(n9906), .CNT1_N_565_adj_23(CNT1_N_565_adj_1654)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U61 FIFOCNT_0 (.CNT1(CNT1_adj_33), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .\CNT[0] (CNT[0]), .n10043(n10043)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    COUNTER_U62 CNT_7__I_0_39 (.CNT1(CNT1_adj_34), .Clk(Clk), .CNT_7__N_1392(CNT_7__N_1392), 
            .CNT1_N_565(CNT1_N_565_adj_1650), .\CNT[7] (CNT[7]), .n10025(n10025)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1453[9:116])
    
endmodule
//
// Verilog Description of module COUNTER_U55
//

module COUNTER_U55 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[6] , 
            n10028) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[6] ;
    input n10028;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10028), .CK(Clk), .Q(\CNT[6] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U56
//

module COUNTER_U56 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[5] , 
            n10031, n9865, \CNT[6] , \CNT[7] , CNT1_N_565_adj_27) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[5] ;
    input n10031;
    input n9865;
    input \CNT[6] ;
    input \CNT[7] ;
    output CNT1_N_565_adj_27;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10031), .CK(Clk), .Q(\CNT[5] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_3_lut_4_lut (.A(\CNT[5] ), .B(n9865), .C(\CNT[6] ), .D(\CNT[7] ), 
         .Z(CNT1_N_565_adj_27)) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    
endmodule
//
// Verilog Description of module COUNTER_U57
//

module COUNTER_U57 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[4] , 
            n10034, n9906, \CNT[6] , \CNT[5] , CNT1_N_565_adj_26) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[4] ;
    input n10034;
    input n9906;
    input \CNT[6] ;
    input \CNT[5] ;
    output CNT1_N_565_adj_26;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10034), .CK(Clk), .Q(\CNT[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[4] ), .B(n9906), .C(\CNT[6] ), 
         .D(\CNT[5] ), .Z(CNT1_N_565_adj_26)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U58
//

module COUNTER_U58 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[3] , 
            n10037, n9940, \CNT[5] , \CNT[4] , CNT1_N_565_adj_25) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[3] ;
    input n10037;
    input n9940;
    input \CNT[5] ;
    input \CNT[4] ;
    output CNT1_N_565_adj_25;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10037), .CK(Clk), .Q(\CNT[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[3] ), .B(n9940), .C(\CNT[5] ), 
         .D(\CNT[4] ), .Z(CNT1_N_565_adj_25)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U59
//

module COUNTER_U59 (\CNT[2] , n9982, \CNT[4] , \CNT[3] , n9865, CNT1_N_565, 
            CNT1, Clk, CNT_7__N_1392, CNT1_N_565_adj_24, n10040) /* synthesis syn_module_defined=1 */ ;
    output \CNT[2] ;
    input n9982;
    input \CNT[4] ;
    input \CNT[3] ;
    output n9865;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565_adj_24;
    input n10040;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    LUT4 i6207_2_lut_rep_260_3_lut_4_lut (.A(\CNT[2] ), .B(n9982), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(n9865)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6207_2_lut_rep_260_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[2] ), .B(n9982), .C(\CNT[4] ), 
         .D(\CNT[3] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_24), .SP(CNT_7__N_1392), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10040), .CK(Clk), .Q(\CNT[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U60
//

module COUNTER_U60 (\CNT[1] , \CNT[0] , CNT1, Clk, CNT_7__N_1392, 
            n10046, n9982, \CNT[2] , n9940, CNT1_N_565, \CNT[3] , 
            n9906, CNT1_N_565_adj_23) /* synthesis syn_module_defined=1 */ ;
    output \CNT[1] ;
    input \CNT[0] ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input n10046;
    output n9982;
    input \CNT[2] ;
    output n9940;
    output CNT1_N_565;
    input \CNT[3] ;
    output n9906;
    output CNT1_N_565_adj_23;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c;
    
    LUT4 i1_2_lut (.A(\CNT[1] ), .B(\CNT[0] ), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10046), .CK(Clk), .Q(\CNT[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i5992_2_lut_rep_377 (.A(\CNT[1] ), .B(\CNT[0] ), .Z(n9982)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i5992_2_lut_rep_377.init = 16'heeee;
    LUT4 i6130_2_lut_rep_335_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), 
         .Z(n9940)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i6130_2_lut_rep_335_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i6175_2_lut_rep_301_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(n9906)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i6175_2_lut_rep_301_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut (.A(\CNT[1] ), .B(\CNT[0] ), .C(\CNT[3] ), 
         .D(\CNT[2] ), .Z(CNT1_N_565_adj_23)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hf0e1;
    
endmodule
//
// Verilog Description of module COUNTER_U61
//

module COUNTER_U61 (CNT1, Clk, CNT_7__N_1392, \CNT[0] , n10043) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    output \CNT[0] ;
    input n10043;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT_N_562;
    
    FD1P3AX CNT1_15 (.D(CNT_N_562), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_18_1_lut (.A(\CNT[0] ), .Z(CNT_N_562)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[35:39])
    defparam CNT_I_0_18_1_lut.init = 16'h5555;
    FD1S3AX CNT_14 (.D(n10043), .CK(Clk), .Q(\CNT[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U62
//

module COUNTER_U62 (CNT1, Clk, CNT_7__N_1392, CNT1_N_565, \CNT[7] , 
            n10025) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input CNT_7__N_1392;
    input CNT1_N_565;
    output \CNT[7] ;
    input n10025;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(CNT_7__N_1392), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n10025), .CK(Clk), .Q(\CNT[7] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG
//

module SHIFTREG (\SDATA[0] , n9869, n9912, \QP[0] , Clk, Clk_enable_247, 
            \QP[1] , Clk_enable_535, \QS_IN[1] , \QP[2] , \QS_IN[2] , 
            \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , \QP[5] , \QS_IN[5] , 
            \QP[6] , \QS_IN[6] , \COL1[7] , \QS_IN[7] , n4568, n4564, 
            n4560, n4556, n4540, n4534, n4532) /* synthesis syn_module_defined=1 */ ;
    input \SDATA[0] ;
    input n9869;
    input n9912;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_535;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[7] ;
    output \QS_IN[7] ;
    input n4568;
    input n4564;
    input n4560;
    input n4556;
    input n4540;
    input n4534;
    input n4532;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4868;
    
    LUT4 i4359_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9869), .D(n9912), 
         .Z(n4868)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4359_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4868), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_535), .CK(Clk), .Q(\COL1[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n4568), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n4564), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n4560), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n4556), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n4540), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n4534), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n4532), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1365, LSE_RLINE=1365 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U85
//

module SHIFTREG_U85 (\SDATA[0] , n9871, n9914, \QP[0] , Clk, Clk_enable_247, 
            \QP[1] , Clk_enable_535, \QS_IN[1] , \QP[2] , \QS_IN[2] , 
            \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , \QP[5] , \QS_IN[5] , 
            \QP[6] , \QS_IN[6] , \COL1[6] , \QS_IN[7] , n4616, n4614, 
            n4608, n4606, n4602, n4596, n4592) /* synthesis syn_module_defined=1 */ ;
    input \SDATA[0] ;
    input n9871;
    input n9914;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_535;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[6] ;
    output \QS_IN[7] ;
    input n4616;
    input n4614;
    input n4608;
    input n4606;
    input n4602;
    input n4596;
    input n4592;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4872;
    
    LUT4 i4363_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9871), .D(n9914), 
         .Z(n4872)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4363_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4872), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_535), .CK(Clk), .Q(\COL1[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n4616), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n4614), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n4608), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n4606), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n4602), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n4596), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n4592), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1363, LSE_RLINE=1363 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U86
//

module SHIFTREG_U86 (\SDATA[0] , n9873, n9915, \QP[0] , Clk, Clk_enable_247, 
            \QP[1] , Clk_enable_535, \QS_IN[1] , \QP[2] , \QS_IN[2] , 
            \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , \QP[5] , \QS_IN[5] , 
            \QP[6] , \QS_IN[6] , \COL1[5] , \QS_IN[7] , n4678, n4674, 
            n4662, n4660, n4656, n4650, n4646) /* synthesis syn_module_defined=1 */ ;
    input \SDATA[0] ;
    input n9873;
    input n9915;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_535;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[5] ;
    output \QS_IN[7] ;
    input n4678;
    input n4674;
    input n4662;
    input n4660;
    input n4656;
    input n4650;
    input n4646;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4878;
    
    LUT4 i4369_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9873), .D(n9915), 
         .Z(n4878)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4369_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4878), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_535), .CK(Clk), .Q(\COL1[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n4678), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n4674), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n4662), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n4660), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n4656), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n4650), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n4646), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1361, LSE_RLINE=1361 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U87
//

module SHIFTREG_U87 (\SDATA[0] , n9875, n9918, \QP[0] , Clk, Clk_enable_247, 
            \QP[1] , Clk_enable_467, \QS_IN[1] , \QP[2] , \QS_IN[2] , 
            \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , \QP[5] , \QS_IN[5] , 
            \QP[6] , \QS_IN[6] , \COL1[4] , \QS_IN[7] , n4766, n4758, 
            n4748, n4736, n4724, n4714, n4710) /* synthesis syn_module_defined=1 */ ;
    input \SDATA[0] ;
    input n9875;
    input n9918;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_467;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[4] ;
    output \QS_IN[7] ;
    input n4766;
    input n4758;
    input n4748;
    input n4736;
    input n4724;
    input n4714;
    input n4710;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4882;
    
    LUT4 i4373_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9875), .D(n9918), 
         .Z(n4882)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4373_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4882), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_467), .CK(Clk), .Q(\COL1[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n4766), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n4758), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n4748), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n4736), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n4724), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n4714), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n4710), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1359, LSE_RLINE=1359 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U88
//

module SHIFTREG_U88 (\SDATA[0] , n9877, n9919, \QP[0] , Clk, Clk_enable_247, 
            \QP[1] , Clk_enable_467, \QS_IN[1] , \QP[2] , \QS_IN[2] , 
            \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , \QP[5] , \QS_IN[5] , 
            \QP[6] , \QS_IN[6] , \COL1[3] , \QS_IN[7] , n4836, n4834, 
            n4832, n4828, n4826, n4810, n4807) /* synthesis syn_module_defined=1 */ ;
    input \SDATA[0] ;
    input n9877;
    input n9919;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_467;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[3] ;
    output \QS_IN[7] ;
    input n4836;
    input n4834;
    input n4832;
    input n4828;
    input n4826;
    input n4810;
    input n4807;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4886;
    
    LUT4 i4377_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9877), .D(n9919), 
         .Z(n4886)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4377_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4886), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_467), .CK(Clk), .Q(\COL1[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n4836), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n4834), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n4832), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n4828), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n4826), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n4810), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n4807), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1357, LSE_RLINE=1357 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U89
//

module SHIFTREG_U89 (\SDATA[0] , n9841, n9879, \QP[0] , Clk, Clk_enable_247, 
            \QP[1] , Clk_enable_467, \QS_IN[1] , \QP[2] , \QS_IN[2] , 
            \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , \QP[5] , \QS_IN[5] , 
            \QP[6] , \QS_IN[6] , \COL1[2] , \QS_IN[7] , n4962, n4960, 
            n4958, n4956, n4954, n4952, n4950) /* synthesis syn_module_defined=1 */ ;
    input \SDATA[0] ;
    input n9841;
    input n9879;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_467;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[2] ;
    output \QS_IN[7] ;
    input n4962;
    input n4960;
    input n4958;
    input n4956;
    input n4954;
    input n4952;
    input n4950;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4890;
    
    LUT4 i4381_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9841), .D(n9879), 
         .Z(n4890)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4381_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4890), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_467), .CK(Clk), .Q(\COL1[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n4962), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n4960), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n4958), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n4956), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n4954), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n4952), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n4950), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1355, LSE_RLINE=1355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U90
//

module SHIFTREG_U90 (\QP[0] , Clk, Clk_enable_247, \QP[1] , Clk_enable_543, 
            \QS_IN[1] , \QP[2] , \QS_IN[2] , \QP[3] , \QS_IN[3] , 
            \QP[4] , \QS_IN[4] , \QP[5] , Clk_enable_467, \QS_IN[5] , 
            \QP[6] , \QS_IN[6] , \COL1[1] , \QS_IN[7] , n4990, n4988, 
            n4986, n4984, n4982, n4980, n4978, \SDATA[0] , n9844, 
            n9881) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_543;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    input Clk_enable_467;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[1] ;
    output \QS_IN[7] ;
    input n4990;
    input n4988;
    input n4986;
    input n4984;
    input n4982;
    input n4980;
    input n4978;
    input \SDATA[0] ;
    input n9844;
    input n9881;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4894;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4894), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_467), .CK(Clk), .Q(\COL1[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n4990), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n4988), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n4986), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n4984), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n4982), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n4980), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n4978), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1353, LSE_RLINE=1353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    LUT4 i4385_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9844), .D(n9881), 
         .Z(n4894)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4385_4_lut.init = 16'hc0ca;
    
endmodule
//
// Verilog Description of module SHIFTREG_U91
//

module SHIFTREG_U91 (\SDATA[0] , n9846, n9884, \QP[0] , Clk, Clk_enable_247, 
            \QP[1] , Clk_enable_543, \QS_IN[1] , \QP[2] , \QS_IN[2] , 
            \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , \QP[5] , \QS_IN[5] , 
            \QP[6] , \QS_IN[6] , \COL1[0] , \QS_IN[7] , n5018, n5016, 
            n5014, n5012, n5010, n5008, n5006) /* synthesis syn_module_defined=1 */ ;
    input \SDATA[0] ;
    input n9846;
    input n9884;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_543;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL1[0] ;
    output \QS_IN[7] ;
    input n5018;
    input n5016;
    input n5014;
    input n5012;
    input n5010;
    input n5008;
    input n5006;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4898;
    
    LUT4 i4389_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9846), .D(n9884), 
         .Z(n4898)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4389_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4898), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_543), .CK(Clk), .Q(\COL1[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5018), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5016), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5014), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5012), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5010), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5008), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5006), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1351, LSE_RLINE=1351 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U92
//

module SHIFTREG_U92 (\SDATA[0] , n9870, n9912, \QP[0] , Clk, Clk_enable_247, 
            \QP[1] , Clk_enable_535, \QS_IN[1] , \QP[2] , \QS_IN[2] , 
            \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , \QP[5] , \QS_IN[5] , 
            \QP[6] , \QS_IN[6] , \COL0[7] , \QS_IN[7] , n4588, n4584, 
            n4582, n4580, n4576, n4574, n4572) /* synthesis syn_module_defined=1 */ ;
    input \SDATA[0] ;
    input n9870;
    input n9912;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_535;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL0[7] ;
    output \QS_IN[7] ;
    input n4588;
    input n4584;
    input n4582;
    input n4580;
    input n4576;
    input n4574;
    input n4572;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4870;
    
    LUT4 i4361_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9870), .D(n9912), 
         .Z(n4870)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4361_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4870), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_535), .CK(Clk), .Q(\COL0[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n4588), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n4584), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n4582), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n4580), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n4576), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n4574), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n4572), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1364, LSE_RLINE=1364 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U93
//

module SHIFTREG_U93 (\SDATA[0] , n9872, n9914, \QP[0] , Clk, Clk_enable_247, 
            \QP[1] , Clk_enable_535, \QS_IN[1] , \QP[2] , \QS_IN[2] , 
            \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , \QP[5] , \QS_IN[5] , 
            \QP[6] , \QS_IN[6] , \COL0[6] , \QS_IN[7] , n4642, n4636, 
            n4634, n4628, n4624, n4620, n4618) /* synthesis syn_module_defined=1 */ ;
    input \SDATA[0] ;
    input n9872;
    input n9914;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_535;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL0[6] ;
    output \QS_IN[7] ;
    input n4642;
    input n4636;
    input n4634;
    input n4628;
    input n4624;
    input n4620;
    input n4618;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4874;
    
    LUT4 i4365_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9872), .D(n9914), 
         .Z(n4874)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4365_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4874), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_535), .CK(Clk), .Q(\COL0[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n4642), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n4636), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n4634), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n4628), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n4624), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n4620), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n4618), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1362, LSE_RLINE=1362 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U94
//

module SHIFTREG_U94 (\SDATA[0] , n9874, n9915, \QP[0] , Clk, Clk_enable_247, 
            \QP[1] , Clk_enable_467, \QS_IN[1] , \QP[2] , \QS_IN[2] , 
            \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , \QP[5] , \QS_IN[5] , 
            \QP[6] , Clk_enable_535, \QS_IN[6] , \COL0[5] , \QS_IN[7] , 
            n4708, n4704, n4700, n4696, n4692, n4688, n4684) /* synthesis syn_module_defined=1 */ ;
    input \SDATA[0] ;
    input n9874;
    input n9915;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_467;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    input Clk_enable_535;
    output \QS_IN[6] ;
    output \COL0[5] ;
    output \QS_IN[7] ;
    input n4708;
    input n4704;
    input n4700;
    input n4696;
    input n4692;
    input n4688;
    input n4684;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4880;
    
    LUT4 i4371_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9874), .D(n9915), 
         .Z(n4880)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4371_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4880), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_535), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_535), .CK(Clk), .Q(\COL0[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n4708), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n4704), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n4700), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n4696), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n4692), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n4688), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n4684), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1360, LSE_RLINE=1360 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U95
//

module SHIFTREG_U95 (\SDATA[0] , n9876, n9918, \QP[0] , Clk, Clk_enable_247, 
            \QP[1] , Clk_enable_467, \QS_IN[1] , \QP[2] , \QS_IN[2] , 
            \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , \QP[5] , \QS_IN[5] , 
            \QP[6] , \QS_IN[6] , \COL0[4] , \QS_IN[7] , n4804, n4802, 
            n4800, n4796, n4792, n4786, n4778) /* synthesis syn_module_defined=1 */ ;
    input \SDATA[0] ;
    input n9876;
    input n9918;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_467;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL0[4] ;
    output \QS_IN[7] ;
    input n4804;
    input n4802;
    input n4800;
    input n4796;
    input n4792;
    input n4786;
    input n4778;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4884;
    
    LUT4 i4375_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9876), .D(n9918), 
         .Z(n4884)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4375_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4884), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_467), .CK(Clk), .Q(\COL0[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n4804), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n4802), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n4800), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n4796), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n4792), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n4786), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n4778), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1358, LSE_RLINE=1358 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U96
//

module SHIFTREG_U96 (\SDATA[0] , n9878, n9919, \QP[0] , Clk, Clk_enable_247, 
            \QP[1] , Clk_enable_467, \QS_IN[1] , \QP[2] , \QS_IN[2] , 
            \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , \QP[5] , \QS_IN[5] , 
            \QP[6] , \QS_IN[6] , \COL0[3] , \QS_IN[7] , n4948, n4946, 
            n4944, n4942, n4846, n4844, n4842) /* synthesis syn_module_defined=1 */ ;
    input \SDATA[0] ;
    input n9878;
    input n9919;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_467;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL0[3] ;
    output \QS_IN[7] ;
    input n4948;
    input n4946;
    input n4944;
    input n4942;
    input n4846;
    input n4844;
    input n4842;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4888;
    
    LUT4 i4379_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9878), .D(n9919), 
         .Z(n4888)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4379_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4888), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_467), .CK(Clk), .Q(\COL0[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n4948), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n4946), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n4944), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n4942), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n4846), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n4844), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n4842), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1356, LSE_RLINE=1356 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U97
//

module SHIFTREG_U97 (\QP[0] , Clk, Clk_enable_247, \QP[1] , Clk_enable_467, 
            \QS_IN[1] , \QP[2] , \QS_IN[2] , \QP[3] , \QS_IN[3] , 
            \QP[4] , \QS_IN[4] , \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , 
            \COL0[2] , \QS_IN[7] , n4976, n4974, n4972, n4970, n4968, 
            n4966, n4964, \SDATA[0] , n9842, n9879) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_467;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL0[2] ;
    output \QS_IN[7] ;
    input n4976;
    input n4974;
    input n4972;
    input n4970;
    input n4968;
    input n4966;
    input n4964;
    input \SDATA[0] ;
    input n9842;
    input n9879;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4892;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4892), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_467), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_467), .CK(Clk), .Q(\COL0[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n4976), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n4974), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n4972), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n4970), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n4968), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n4966), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n4964), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1354, LSE_RLINE=1354 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    LUT4 i4383_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9842), .D(n9879), 
         .Z(n4892)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4383_4_lut.init = 16'hc0ca;
    
endmodule
//
// Verilog Description of module SHIFTREG_U98
//

module SHIFTREG_U98 (\QP[0] , Clk, Clk_enable_247, \QP[1] , Clk_enable_543, 
            \QS_IN[1] , \QP[2] , \QS_IN[2] , \QP[3] , \QS_IN[3] , 
            \QP[4] , \QS_IN[4] , \QP[5] , \QS_IN[5] , \QP[6] , \QS_IN[6] , 
            \COL0[1] , \QS_IN[7] , n5004, n5002, n5000, n4998, n4996, 
            n4994, n4992, \SDATA[0] , n9845, n9881) /* synthesis syn_module_defined=1 */ ;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_543;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL0[1] ;
    output \QS_IN[7] ;
    input n5004;
    input n5002;
    input n5000;
    input n4998;
    input n4996;
    input n4994;
    input n4992;
    input \SDATA[0] ;
    input n9845;
    input n9881;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4896;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4896), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_543), .CK(Clk), .Q(\COL0[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5004), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5002), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5000), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n4998), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n4996), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n4994), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n4992), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1352, LSE_RLINE=1352 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    LUT4 i4387_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9845), .D(n9881), 
         .Z(n4896)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4387_4_lut.init = 16'hc0ca;
    
endmodule
//
// Verilog Description of module SHIFTREG_U99
//

module SHIFTREG_U99 (\SDATA[0] , n9848, n9884, \QP[0] , Clk, Clk_enable_247, 
            \QP[1] , Clk_enable_543, \QS_IN[1] , \QP[2] , \QS_IN[2] , 
            \QP[3] , \QS_IN[3] , \QP[4] , \QS_IN[4] , \QP[5] , \QS_IN[5] , 
            \QP[6] , \QS_IN[6] , \COL0[0] , \QS_IN[7] , n5032, n5030, 
            n5028, n5026, n5024, n5022, n5020) /* synthesis syn_module_defined=1 */ ;
    input \SDATA[0] ;
    input n9848;
    input n9884;
    output \QP[0] ;
    input Clk;
    input Clk_enable_247;
    output \QP[1] ;
    input Clk_enable_543;
    output \QS_IN[1] ;
    output \QP[2] ;
    output \QS_IN[2] ;
    output \QP[3] ;
    output \QS_IN[3] ;
    output \QP[4] ;
    output \QS_IN[4] ;
    output \QP[5] ;
    output \QS_IN[5] ;
    output \QP[6] ;
    output \QS_IN[6] ;
    output \COL0[0] ;
    output \QS_IN[7] ;
    input n5032;
    input n5030;
    input n5028;
    input n5026;
    input n5024;
    input n5022;
    input n5020;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4900;
    
    LUT4 i4391_4_lut (.A(QS_IN[0]), .B(\SDATA[0] ), .C(n9848), .D(n9884), 
         .Z(n4900)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4391_4_lut.init = 16'hc0ca;
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_247), .CK(Clk), .Q(\QP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4900), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_543), .CK(Clk), .Q(\QP[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_543), .CK(Clk), .Q(\COL0[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5032), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5030), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5028), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5026), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5024), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5022), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5020), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=105, LSE_LLINE=1350, LSE_RLINE=1350 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module TIMING_GENERATOR
//

module TIMING_GENERATOR (nVIS, Clk, Clk_enable_511, Clk_enable_563, 
            \Hn[1] , F_NT, \Hnn[0] , \Hn[0] , Clk_enable_571, S_EV, 
            Vo, n9980, VSYNC, RC, n25, VSET, ODDEVEN, nRES_N_15, 
            CLIP_OUT, THO, \PAMUX_7__N_859[1] , \PAMUX_7__N_859[2] , 
            \TVO[2] , \PAMUX_7__N_859[3] , \TVO[3] , \PAMUX_7__N_859[4] , 
            \TVO[0] , \TVO[4] , \PAMUX_7__N_859[5] , \PAMUX_7__N_859[0] , 
            \H[8] , n9942, O_HPOS, E_EV, I_OAM2, n9984, BLNK_FF, 
            TVO1, n8813, TVZ, n9981, \Hn[2] , n8992, n3533, n9830, 
            n9826, NTV_IN, NTVDO, n9863, \W4Q[4] , \W4Q[2] , OAMQ_7__N_1041, 
            TVZB, OVZ, SPR_OV, n9828, n10442, n5110, OAP_N_1091, 
            Clk_enable_47, n9901, nRD_c, I1_32, n9868, CNT1_N_565, 
            NFO_OUT, n9944, n9938, Clk_enable_267, n9838, FTA_OUT, 
            Clk_enable_560, OMFG, RESCL, RESCL_IN, Clk_enable_113, 
            n38, HC, Clk_enable_173, HC_N_237, H_LINE5_N_453, n9897, 
            BGCLIP, CLIP_B_N_247, n8933, R2DB, n4, n3985, n8599, 
            OMV_LATCH, n9983, nEVAL, n9923, nPICTURE, PAR_O, SH2_N_1372, 
            SH3_N_1381, SH7_N_1390, SH5_N_1385, OMSTEP_1__N_1053, n9889, 
            n4_adj_22, n4016, n9925, Clk_enable_543, Clk_enable_393, 
            \Hnn[5] , \Hnn[4] , \Hnn[3] , N_HB, SYNC_c, H_LINE23_N_478, 
            n8831, VBL_EN, INT_c, n6362, MODE_c, Clk_enable_535, 
            n3689, n8475, DENDY_c, Clk_enable_561, Clk_enable_247, 
            Vo_7__N_212, H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    output nVIS;
    input Clk;
    input Clk_enable_511;
    input Clk_enable_563;
    output \Hn[1] ;
    output F_NT;
    output \Hnn[0] ;
    output \Hn[0] ;
    input Clk_enable_571;
    output S_EV;
    output [7:0]Vo;
    input n9980;
    output VSYNC;
    output RC;
    input n25;
    output [2:0]VSET;
    output [1:0]ODDEVEN;
    input nRES_N_15;
    output CLIP_OUT;
    input [4:0]THO;
    output \PAMUX_7__N_859[1] ;
    output \PAMUX_7__N_859[2] ;
    input \TVO[2] ;
    output \PAMUX_7__N_859[3] ;
    input \TVO[3] ;
    output \PAMUX_7__N_859[4] ;
    input \TVO[0] ;
    input \TVO[4] ;
    output \PAMUX_7__N_859[5] ;
    output \PAMUX_7__N_859[0] ;
    output \H[8] ;
    input n9942;
    output O_HPOS;
    output E_EV;
    output I_OAM2;
    input n9984;
    output BLNK_FF;
    input TVO1;
    input n8813;
    output TVZ;
    input n9981;
    output \Hn[2] ;
    output n8992;
    input n3533;
    output n9830;
    output n9826;
    input NTV_IN;
    input NTVDO;
    output n9863;
    input \W4Q[4] ;
    input \W4Q[2] ;
    output OAMQ_7__N_1041;
    output TVZB;
    input OVZ;
    input SPR_OV;
    output n9828;
    input n10442;
    output n5110;
    output OAP_N_1091;
    input Clk_enable_47;
    output n9901;
    output nRD_c;
    input I1_32;
    output n9868;
    output CNT1_N_565;
    output NFO_OUT;
    output n9944;
    output n9938;
    output Clk_enable_267;
    output n9838;
    output FTA_OUT;
    input Clk_enable_560;
    output OMFG;
    output RESCL;
    output RESCL_IN;
    input Clk_enable_113;
    input n38;
    output HC;
    input Clk_enable_173;
    input HC_N_237;
    output H_LINE5_N_453;
    input n9897;
    input BGCLIP;
    output CLIP_B_N_247;
    input n8933;
    output [2:0]R2DB;
    input n4;
    output n3985;
    output n8599;
    input OMV_LATCH;
    input n9983;
    output nEVAL;
    output n9923;
    output nPICTURE;
    output PAR_O;
    output SH2_N_1372;
    output SH3_N_1381;
    output SH7_N_1390;
    output SH5_N_1385;
    output OMSTEP_1__N_1053;
    input n9889;
    input n4_adj_22;
    output n4016;
    output n9925;
    input Clk_enable_543;
    input Clk_enable_393;
    output \Hnn[5] ;
    output \Hnn[4] ;
    output \Hnn[3] ;
    output N_HB;
    output SYNC_c;
    output H_LINE23_N_478;
    output n8831;
    input VBL_EN;
    output INT_c;
    input n6362;
    input MODE_c;
    input Clk_enable_535;
    output n3689;
    input n8475;
    input DENDY_c;
    input Clk_enable_561;
    input Clk_enable_247;
    input Vo_7__N_212;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire NVIS_IN_N_258;
    wire [5:0]Hnn;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(72[11:14])
    
    wire FNT_IN, SEV_IN, H_LINE2_N_446, CLIP1, CLIP1_N_346, V_LINE0N_N_487, 
        n9701, n10430, VSYNCo_N_326, VSET_0__N_231;
    wire [8:0]V;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(737[14:15])
    
    wire n9951, n7, n8892, n9727, VC_LATCH_N_218;
    wire [1:0]ODDEVEN_c;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(706[10:17])
    
    wire CLIP_OUT_N_338, FAT_IN, n9969, n9963, n9931, n9927;
    wire [8:0]H;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(737[11:12])
    
    wire n9852, n9962, n9853, n9964, n8862, n8863, n9957, H_LINE6_N_460, 
        HPOS_IN, n9741, EEV_IN, IOAM2_IN, VB_FF, NVIS_IN_N_261, 
        n9859, n9956, n9894, n9932, BPORCH_FF_N_420, n9860, n9896, 
        V_LINE2N_N_527, PEN_FF_N_423, n9342, n9888, Clk_enable_552, 
        FTB_OUT, FTA_IN_N_379, FTB_IN_N_373, HSYNCo, FPORCH_FF_N_316, 
        VSYNC_adj_1625, VSYNC_N_408, PICT1, BPORCH_FF, PICT2, PEN_FF, 
        INT_FF, CLIP2, CLIP2_N_343, EVAL_IN, H_LINE7_N_468, PARO_IN, 
        PARO_IN_N_359, NVIS_IN, FNT_IN_N_364, FAT_IN_N_282, FTA_IN, 
        FTA_IN_N_376, FTB_IN, FTB_IN_N_367, NFO1, NFO1_N_382, NFO2, 
        n13, n8805, Clk_enable_557, nEVAL_N_251, HIN5, n9891, n9742, 
        N_HB_N_300, Clk_enable_556, n9953, n8810, n9856, n3656, 
        n9958, n9159, n9959, n6, V_8__N_515, ODDEVEN_0__N_221, VSET_1__N_226;
    wire [2:0]VSET_c;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(731[10:14])
    
    wire VSET_0__N_229;
    wire [5:0]Hn;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(675[16:18])
    
    wire FPORCH_FF, n12, n1, n9725, V_LINE0P_N_505, V_LINE3N_N_533, 
        n8954, n6_adj_1627, Clk_enable_554, Clk_enable_553, Clk_enable_555, 
        CNT1_N_565_adj_1628, CNT1_N_565_adj_1629, CNT1_N_565_adj_1630, 
        n9827, CNT1_N_565_adj_1631, n9829, n9831, CNT1_N_565_adj_1632, 
        CNT1_N_565_adj_1633, n9833, CNT1_N_565_adj_1634, n9836, n9851, 
        CNT1_N_565_adj_1635, CNT1_N_565_adj_1636, CNT1_N_565_adj_1637, 
        CNT1_N_565_adj_1638, n9908, CNT1_N_565_adj_1639, CNT1_N_565_adj_1640, 
        n9955, CNT1_N_565_adj_1641;
    
    FD1P3AX nVIS_648 (.D(NVIS_IN_N_258), .SP(Clk_enable_511), .CK(Clk), 
            .Q(nVIS));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam nVIS_648.GSR = "DISABLED";
    FD1P3AX Hnn_i0_i1 (.D(\Hn[1] ), .SP(Clk_enable_563), .CK(Clk), .Q(Hnn[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hnn_i0_i1.GSR = "DISABLED";
    FD1P3AX F_NT_649 (.D(FNT_IN), .SP(Clk_enable_511), .CK(Clk), .Q(F_NT));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam F_NT_649.GSR = "DISABLED";
    FD1P3AX Hnn_i0_i0 (.D(\Hn[0] ), .SP(Clk_enable_563), .CK(Clk), .Q(\Hnn[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hnn_i0_i0.GSR = "DISABLED";
    FD1P3AX SEV_IN_663 (.D(H_LINE2_N_446), .SP(Clk_enable_571), .CK(Clk), 
            .Q(SEV_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam SEV_IN_663.GSR = "DISABLED";
    FD1P3AX S_EV_641 (.D(SEV_IN), .SP(Clk_enable_563), .CK(Clk), .Q(S_EV));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam S_EV_641.GSR = "DISABLED";
    FD1P3AX CLIP1_664 (.D(CLIP1_N_346), .SP(Clk_enable_571), .CK(Clk), 
            .Q(CLIP1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam CLIP1_664.GSR = "DISABLED";
    LUT4 V_LINE0N_N_487_bdd_4_lut (.A(V_LINE0N_N_487), .B(Vo[0]), .C(n9701), 
         .D(n9980), .Z(n10430)) /* synthesis lut_function=(!(A ((D)+!C)+!A (B ((D)+!C)+!B !(C+(D))))) */ ;
    defparam V_LINE0N_N_487_bdd_4_lut.init = 16'h11f0;
    FD1S3AX VSYNC_FF_636 (.D(VSYNCo_N_326), .CK(Clk), .Q(VSYNC)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam VSYNC_FF_636.GSR = "DISABLED";
    FD1S3AX RC_637 (.D(n25), .CK(Clk), .Q(RC)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam RC_637.GSR = "DISABLED";
    FD1P3AX VSET_i0 (.D(VSET_0__N_231), .SP(Clk_enable_571), .CK(Clk), 
            .Q(VSET[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam VSET_i0.GSR = "DISABLED";
    LUT4 i2_2_lut_3_lut_4_lut (.A(V[8]), .B(n9951), .C(Vo[4]), .D(Vo[5]), 
         .Z(n7)) /* synthesis lut_function=((B+(C+(D)))+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(763[22:43])
    defparam i2_2_lut_3_lut_4_lut.init = 16'hfffd;
    LUT4 PD_nOE_c_bdd_2_lut_8994_3_lut_4_lut (.A(V[8]), .B(n9951), .C(n8892), 
         .D(n9727), .Z(VC_LATCH_N_218)) /* synthesis lut_function=(!((B+!(C (D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(763[22:43])
    defparam PD_nOE_c_bdd_2_lut_8994_3_lut_4_lut.init = 16'h2000;
    FD1P3IX ODDEVEN_i0 (.D(ODDEVEN_c[1]), .SP(V[8]), .CD(nRES_N_15), .CK(Clk), 
            .Q(ODDEVEN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam ODDEVEN_i0.GSR = "DISABLED";
    FD1P3AX CLIP_OUT_642 (.D(CLIP_OUT_N_338), .SP(Clk_enable_563), .CK(Clk), 
            .Q(CLIP_OUT));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam CLIP_OUT_642.GSR = "DISABLED";
    LUT4 mux_67_i2_3_lut_4_lut (.A(FAT_IN), .B(n9969), .C(THO[1]), .D(THO[3]), 
         .Z(\PAMUX_7__N_859[1] )) /* synthesis lut_function=(A (B (C)+!B (D))+!A (C)) */ ;
    defparam mux_67_i2_3_lut_4_lut.init = 16'hf2d0;
    LUT4 mux_67_i3_3_lut_4_lut (.A(FAT_IN), .B(n9969), .C(THO[2]), .D(THO[4]), 
         .Z(\PAMUX_7__N_859[2] )) /* synthesis lut_function=(A (B (C)+!B (D))+!A (C)) */ ;
    defparam mux_67_i3_3_lut_4_lut.init = 16'hf2d0;
    LUT4 mux_67_i4_3_lut_4_lut (.A(FAT_IN), .B(n9969), .C(THO[3]), .D(\TVO[2] ), 
         .Z(\PAMUX_7__N_859[3] )) /* synthesis lut_function=(A (B (C)+!B (D))+!A (C)) */ ;
    defparam mux_67_i4_3_lut_4_lut.init = 16'hf2d0;
    LUT4 mux_67_i5_3_lut_4_lut (.A(FAT_IN), .B(n9969), .C(THO[4]), .D(\TVO[3] ), 
         .Z(\PAMUX_7__N_859[4] )) /* synthesis lut_function=(A (B (C)+!B (D))+!A (C)) */ ;
    defparam mux_67_i5_3_lut_4_lut.init = 16'hf2d0;
    LUT4 mux_67_i6_3_lut_4_lut (.A(FAT_IN), .B(n9969), .C(\TVO[0] ), .D(\TVO[4] ), 
         .Z(\PAMUX_7__N_859[5] )) /* synthesis lut_function=(A (B (C)+!B (D))+!A (C)) */ ;
    defparam mux_67_i6_3_lut_4_lut.init = 16'hf2d0;
    LUT4 mux_67_i1_3_lut_4_lut (.A(FAT_IN), .B(n9969), .C(THO[0]), .D(THO[2]), 
         .Z(\PAMUX_7__N_859[0] )) /* synthesis lut_function=(A (B (C)+!B (D))+!A (C)) */ ;
    defparam mux_67_i1_3_lut_4_lut.init = 16'hf2d0;
    LUT4 i8675_3_lut_rep_247_4_lut_4_lut (.A(n9963), .B(n9931), .C(n9927), 
         .D(H[5]), .Z(n9852)) /* synthesis lut_function=(!(A+((C+(D))+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(750[19:93])
    defparam i8675_3_lut_rep_247_4_lut_4_lut.init = 16'h0004;
    LUT4 i1_2_lut_rep_248_3_lut_4_lut (.A(H[6]), .B(n9962), .C(H[4]), 
         .D(H[5]), .Z(n9853)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(751[22:43])
    defparam i1_2_lut_rep_248_3_lut_4_lut.init = 16'hfffe;
    LUT4 i2_3_lut_4_lut (.A(H[2]), .B(n9964), .C(H[5]), .D(n8862), .Z(n8863)) /* synthesis lut_function=(A (B (C (D)))) */ ;
    defparam i2_3_lut_4_lut.init = 16'h8000;
    LUT4 i8684_2_lut_3_lut_4_lut_4_lut (.A(n9957), .B(n8863), .C(\H[8] ), 
         .D(n9942), .Z(H_LINE6_N_460)) /* synthesis lut_function=(!(A+((C+(D))+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(837[23:56])
    defparam i8684_2_lut_3_lut_4_lut_4_lut.init = 16'h0004;
    FD1P3AX O_HPOS_643 (.D(HPOS_IN), .SP(Clk_enable_563), .CK(Clk), .Q(O_HPOS));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam O_HPOS_643.GSR = "DISABLED";
    LUT4 V_LINE0P_N_512_bdd_4_lut_8999 (.A(Vo[4]), .B(Vo[5]), .C(n9980), 
         .D(Vo[1]), .Z(n9741)) /* synthesis lut_function=(!(A ((C+!(D))+!B)+!A (B+((D)+!C)))) */ ;
    defparam V_LINE0P_N_512_bdd_4_lut_8999.init = 16'h0810;
    FD1P3AX E_EV_645 (.D(EEV_IN), .SP(Clk_enable_563), .CK(Clk), .Q(E_EV));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam E_EV_645.GSR = "DISABLED";
    FD1P3AX I_OAM2_646 (.D(IOAM2_IN), .SP(Clk_enable_563), .CK(Clk), .Q(I_OAM2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam I_OAM2_646.GSR = "DISABLED";
    LUT4 i1_3_lut_4_lut (.A(n9984), .B(BLNK_FF), .C(TVO1), .D(n8813), 
         .Z(TVZ)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(788[15:30])
    defparam i1_3_lut_4_lut.init = 16'h0200;
    LUT4 i8976_2_lut_3_lut_4_lut (.A(n9984), .B(BLNK_FF), .C(n9981), .D(\Hn[2] ), 
         .Z(n8992)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(788[15:30])
    defparam i8976_2_lut_3_lut_4_lut.init = 16'hf2f0;
    LUT4 OMFG_N_1057_I_0_2_lut_rep_221_3_lut_4_lut (.A(n9984), .B(BLNK_FF), 
         .C(n3533), .D(n9830), .Z(n9826)) /* synthesis lut_function=((B+(C+(D)))+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(788[15:30])
    defparam OMFG_N_1057_I_0_2_lut_rep_221_3_lut_4_lut.init = 16'hfffd;
    LUT4 FV_IN_I_0_3_lut_rep_258_4_lut (.A(n9984), .B(BLNK_FF), .C(NTV_IN), 
         .D(NTVDO), .Z(n9863)) /* synthesis lut_function=(A ((C (D))+!B)+!A (C (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(788[15:30])
    defparam FV_IN_I_0_3_lut_rep_258_4_lut.init = 16'hf222;
    LUT4 i2_3_lut_4_lut_adj_408 (.A(n9984), .B(BLNK_FF), .C(\W4Q[4] ), 
         .D(\W4Q[2] ), .Z(OAMQ_7__N_1041)) /* synthesis lut_function=(!(A ((C+!(D))+!B)+!A (C+!(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(788[15:30])
    defparam i2_3_lut_4_lut_adj_408.init = 16'h0d00;
    LUT4 i8729_2_lut_3_lut_4_lut (.A(n9984), .B(BLNK_FF), .C(VB_FF), .D(\H[8] ), 
         .Z(NVIS_IN_N_261)) /* synthesis lut_function=(!((B+((D)+!C))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(788[15:30])
    defparam i8729_2_lut_3_lut_4_lut.init = 16'h0020;
    LUT4 i8724_2_lut_rep_254_3_lut_3_lut_4_lut (.A(n9984), .B(BLNK_FF), 
         .C(\H[8] ), .D(n9957), .Z(n9859)) /* synthesis lut_function=(!((B+(C+(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(788[15:30])
    defparam i8724_2_lut_rep_254_3_lut_3_lut_4_lut.init = 16'h0002;
    LUT4 i2_3_lut_4_lut_adj_409 (.A(n9984), .B(BLNK_FF), .C(TVO1), .D(n8813), 
         .Z(TVZB)) /* synthesis lut_function=(A (B (C (D)))+!A (C (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(788[15:30])
    defparam i2_3_lut_4_lut_adj_409.init = 16'hd000;
    LUT4 i1_2_lut_rep_223_4_lut (.A(OVZ), .B(n9956), .C(SPR_OV), .D(n3533), 
         .Z(n9828)) /* synthesis lut_function=(A (D)+!A (B (D)+!B ((D)+!C))) */ ;
    defparam i1_2_lut_rep_223_4_lut.init = 16'hff01;
    LUT4 i4601_2_lut_3_lut_4_lut (.A(n9984), .B(BLNK_FF), .C(n10442), 
         .D(\Hn[2] ), .Z(n5110)) /* synthesis lut_function=(!((B+!(C (D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(788[15:30])
    defparam i4601_2_lut_3_lut_4_lut.init = 16'h2000;
    LUT4 i8749_3_lut_4_lut (.A(H[4]), .B(n9894), .C(n9932), .D(H[0]), 
         .Z(BPORCH_FF_N_420)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(751[22:75])
    defparam i8749_3_lut_4_lut.init = 16'h0001;
    LUT4 OAP_I_299_3_lut_4_lut (.A(n9984), .B(BLNK_FF), .C(nVIS), .D(\Hnn[0] ), 
         .Z(OAP_N_1091)) /* synthesis lut_function=(!((B+!(C+(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(788[15:30])
    defparam OAP_I_299_3_lut_4_lut.init = 16'h2220;
    LUT4 i1_2_lut_rep_255_3_lut_4_lut (.A(n9984), .B(BLNK_FF), .C(H[7]), 
         .D(\H[8] ), .Z(n9860)) /* synthesis lut_function=((B+(C+!(D)))+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(788[15:30])
    defparam i1_2_lut_rep_255_3_lut_4_lut.init = 16'hfdff;
    LUT4 PD_RB_I_0_3_lut_rep_296_4_lut (.A(n9984), .B(BLNK_FF), .C(\Hnn[0] ), 
         .D(Clk_enable_47), .Z(n9901)) /* synthesis lut_function=(A (B (D)+!B (C+(D)))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(788[15:30])
    defparam PD_RB_I_0_3_lut_rep_296_4_lut.init = 16'hff20;
    LUT4 nRD_I_0_1_lut_3_lut_4_lut (.A(n9984), .B(BLNK_FF), .C(\Hnn[0] ), 
         .D(Clk_enable_47), .Z(nRD_c)) /* synthesis lut_function=(!(A (B (D)+!B (C+(D)))+!A (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(788[15:30])
    defparam nRD_I_0_1_lut_3_lut_4_lut.init = 16'h00df;
    LUT4 CNT_I_0_19_2_lut_rep_263_3_lut_4_lut (.A(n9984), .B(BLNK_FF), .C(THO[0]), 
         .D(I1_32), .Z(n9868)) /* synthesis lut_function=(!(A (B ((D)+!C)+!B !(C))+!A ((D)+!C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(788[15:30])
    defparam CNT_I_0_19_2_lut_rep_263_3_lut_4_lut.init = 16'h20f0;
    LUT4 i8860_4_lut_4_lut (.A(n9896), .B(n9980), .C(V_LINE2N_N_527), 
         .D(PEN_FF_N_423), .Z(n9342)) /* synthesis lut_function=(A (((D)+!C)+!B)+!A ((D)+!C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(859[10:40])
    defparam i8860_4_lut_4_lut.init = 16'hff2f;
    LUT4 i1_2_lut_3_lut_4_lut (.A(n9984), .B(BLNK_FF), .C(THO[0]), .D(I1_32), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(A (B (C (D)+!C !(D))+!B !(C))+!A (C (D)+!C !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(788[15:30])
    defparam i1_2_lut_3_lut_4_lut.init = 16'hd20f;
    LUT4 i8868_3_lut_4_lut_4_lut (.A(n9896), .B(n10442), .C(n9888), .D(Vo[0]), 
         .Z(Clk_enable_552)) /* synthesis lut_function=(!(A (B)+!A (B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(859[10:40])
    defparam i8868_3_lut_4_lut_4_lut.init = 16'h2223;
    LUT4 FTB_OUT_I_0_715_2_lut_rep_339 (.A(FTB_OUT), .B(NFO_OUT), .Z(n9944)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(778[16:37])
    defparam FTB_OUT_I_0_715_2_lut_rep_339.init = 16'heeee;
    LUT4 Hnn0_I_0_2_lut_rep_333_3_lut (.A(FTB_OUT), .B(NFO_OUT), .C(\Hnn[0] ), 
         .Z(n9938)) /* synthesis lut_function=(!(A+(B+!(C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(778[16:37])
    defparam Hnn0_I_0_2_lut_rep_333_3_lut.init = 16'h1010;
    LUT4 PD_SR_N_683_I_0_2_lut_rep_229_3_lut_3_lut_4_lut (.A(FTB_OUT), .B(NFO_OUT), 
         .C(\Hnn[0] ), .D(n10442), .Z(Clk_enable_267)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(778[16:37])
    defparam PD_SR_N_683_I_0_2_lut_rep_229_3_lut_3_lut_4_lut.init = 16'h0010;
    LUT4 i5911_2_lut_rep_233_2_lut_3_lut_4_lut_4_lut (.A(FTB_OUT), .B(NFO_OUT), 
         .C(n10442), .D(\Hnn[0] ), .Z(n9838)) /* synthesis lut_function=(A (B+(C))+!A (B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(778[16:37])
    defparam i5911_2_lut_rep_233_2_lut_3_lut_4_lut_4_lut.init = 16'hfdfc;
    FD1P3AX FTA_OUT_650 (.D(FTA_IN_N_379), .SP(Clk_enable_563), .CK(Clk), 
            .Q(FTA_OUT));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam FTA_OUT_650.GSR = "DISABLED";
    FD1P3AX FTB_OUT_651 (.D(FTB_IN_N_373), .SP(Clk_enable_560), .CK(Clk), 
            .Q(FTB_OUT));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam FTB_OUT_651.GSR = "DISABLED";
    FD1P3AX NFO_OUT_652 (.D(n9969), .SP(Clk_enable_560), .CK(Clk), .Q(NFO_OUT));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam NFO_OUT_652.GSR = "DISABLED";
    FD1P3AX HSYNC_654 (.D(FPORCH_FF_N_316), .SP(Clk_enable_560), .CK(Clk), 
            .Q(HSYNCo));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam HSYNC_654.GSR = "DISABLED";
    FD1P3AX VSYNC_655 (.D(VSYNC_N_408), .SP(Clk_enable_560), .CK(Clk), 
            .Q(VSYNC_adj_1625));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam VSYNC_655.GSR = "DISABLED";
    FD1P3AX PICT1_656 (.D(BPORCH_FF), .SP(Clk_enable_563), .CK(Clk), .Q(PICT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam PICT1_656.GSR = "DISABLED";
    FD1P3AX PICT2_657 (.D(PEN_FF), .SP(Clk_enable_563), .CK(Clk), .Q(PICT2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam PICT2_657.GSR = "DISABLED";
    LUT4 OMFG_I_0_1_lut_2_lut_4_lut (.A(OVZ), .B(n9956), .C(SPR_OV), .D(n3533), 
         .Z(OMFG)) /* synthesis lut_function=(!(A (D)+!A (B (D)+!B ((D)+!C)))) */ ;
    defparam OMFG_I_0_1_lut_2_lut_4_lut.init = 16'h00fe;
    FD1P3AX RESCL_658 (.D(RESCL_IN), .SP(Clk_enable_563), .CK(Clk), .Q(RESCL));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam RESCL_658.GSR = "DISABLED";
    FD1P3AX INT_FF_638 (.D(n38), .SP(Clk_enable_113), .CK(Clk), .Q(INT_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam INT_FF_638.GSR = "DISABLED";
    FD1P3AX HC_660 (.D(HC_N_237), .SP(Clk_enable_173), .CK(Clk), .Q(HC));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam HC_660.GSR = "DISABLED";
    FD1P3AX CLIP2_665 (.D(CLIP2_N_343), .SP(Clk_enable_173), .CK(Clk), 
            .Q(CLIP2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam CLIP2_665.GSR = "DISABLED";
    FD1P3AX HPOS_IN_666 (.D(H_LINE5_N_453), .SP(Clk_enable_173), .CK(Clk), 
            .Q(HPOS_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam HPOS_IN_666.GSR = "DISABLED";
    FD1P3AX EVAL_IN_667 (.D(H_LINE6_N_460), .SP(Clk_enable_173), .CK(Clk), 
            .Q(EVAL_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam EVAL_IN_667.GSR = "DISABLED";
    FD1P3AX EEV_IN_668 (.D(H_LINE7_N_468), .SP(Clk_enable_173), .CK(Clk), 
            .Q(EEV_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam EEV_IN_668.GSR = "DISABLED";
    FD1P3AX IOAM2_IN_669 (.D(n9859), .SP(Clk_enable_173), .CK(Clk), .Q(IOAM2_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam IOAM2_IN_669.GSR = "DISABLED";
    FD1P3AX PARO_IN_670 (.D(PARO_IN_N_359), .SP(Clk_enable_173), .CK(Clk), 
            .Q(PARO_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam PARO_IN_670.GSR = "DISABLED";
    FD1P3AX NVIS_IN_671 (.D(NVIS_IN_N_261), .SP(Clk_enable_173), .CK(Clk), 
            .Q(NVIS_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam NVIS_IN_671.GSR = "DISABLED";
    FD1P3AX FNT_IN_672 (.D(FNT_IN_N_364), .SP(Clk_enable_173), .CK(Clk), 
            .Q(FNT_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam FNT_IN_672.GSR = "DISABLED";
    FD1P3AX FAT_IN_673 (.D(FAT_IN_N_282), .SP(Clk_enable_173), .CK(Clk), 
            .Q(FAT_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam FAT_IN_673.GSR = "DISABLED";
    FD1P3AX FTA_IN_674 (.D(FTA_IN_N_376), .SP(Clk_enable_173), .CK(Clk), 
            .Q(FTA_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam FTA_IN_674.GSR = "DISABLED";
    FD1P3AX FTB_IN_675 (.D(FTB_IN_N_367), .SP(Clk_enable_173), .CK(Clk), 
            .Q(FTB_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam FTB_IN_675.GSR = "DISABLED";
    FD1P3AX NFO1_676 (.D(NFO1_N_382), .SP(Clk_enable_173), .CK(Clk), .Q(NFO1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam NFO1_676.GSR = "DISABLED";
    FD1P3AX NFO2_677 (.D(n9897), .SP(Clk_enable_173), .CK(Clk), .Q(NFO2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam NFO2_677.GSR = "DISABLED";
    LUT4 i8670_2_lut (.A(CLIP_OUT), .B(BGCLIP), .Z(CLIP_B_N_247)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(735[17:39])
    defparam i8670_2_lut.init = 16'h1111;
    FD1P3AX RESCL_IN_685 (.D(VC_LATCH_N_218), .SP(Clk_enable_173), .CK(Clk), 
            .Q(RESCL_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam RESCL_IN_685.GSR = "DISABLED";
    LUT4 i1_4_lut (.A(RESCL), .B(n8933), .C(R2DB[0]), .D(n4), .Z(n3985)) /* synthesis lut_function=(!(A+!(B (C)+!B (C+!(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam i1_4_lut.init = 16'h5051;
    LUT4 i1_4_lut_adj_410 (.A(I_OAM2), .B(SPR_OV), .C(n10442), .D(n13), 
         .Z(n8599)) /* synthesis lut_function=(!(A+!(B+(C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam i1_4_lut_adj_410.init = 16'h5444;
    LUT4 i1_4_lut_adj_411 (.A(OMV_LATCH), .B(\Hn[0] ), .C(n9983), .D(n4), 
         .Z(n13)) /* synthesis lut_function=(!(A (B (C)+!B (C (D)))+!A (B+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam i1_4_lut_adj_411.init = 16'h0a3b;
    LUT4 i8853_4_lut_4_lut (.A(n9852), .B(n9853), .C(n10442), .D(n8805), 
         .Z(Clk_enable_557)) /* synthesis lut_function=(!(A (C)+!A (B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(750[19:93])
    defparam i8853_4_lut_4_lut.init = 16'h0a0b;
    FD1P3AX nEVAL_644 (.D(nEVAL_N_251), .SP(Clk_enable_560), .CK(Clk), 
            .Q(nEVAL));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam nEVAL_644.GSR = "DISABLED";
    LUT4 i3_4_lut (.A(H[2]), .B(H[0]), .C(H[4]), .D(n8862), .Z(HIN5)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(739[15:47])
    defparam i3_4_lut.init = 16'h8000;
    LUT4 i1_2_lut_rep_346 (.A(Vo[7]), .B(Vo[6]), .Z(n9951)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(763[22:43])
    defparam i1_2_lut_rep_346.init = 16'heeee;
    LUT4 i1_2_lut_rep_318_3_lut (.A(Vo[7]), .B(Vo[6]), .C(V[8]), .Z(n9923)) /* synthesis lut_function=(A+(B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(763[22:43])
    defparam i1_2_lut_rep_318_3_lut.init = 16'hefef;
    LUT4 V_LINE0P_I_160_2_lut_rep_286_3_lut_4_lut (.A(Vo[7]), .B(Vo[6]), 
         .C(Vo[5]), .D(V[8]), .Z(n9891)) /* synthesis lut_function=(A+(B+(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(763[22:43])
    defparam V_LINE0P_I_160_2_lut_rep_286_3_lut_4_lut.init = 16'hfeff;
    LUT4 n9741_bdd_2_lut_3_lut_4_lut (.A(Vo[7]), .B(Vo[6]), .C(n9741), 
         .D(V[8]), .Z(n9742)) /* synthesis lut_function=(!(A+(B+!(C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(763[22:43])
    defparam n9741_bdd_2_lut_3_lut_4_lut.init = 16'h1000;
    LUT4 i1_2_lut (.A(H[1]), .B(H[3]), .Z(n8862)) /* synthesis lut_function=(A (B)) */ ;
    defparam i1_2_lut.init = 16'h8888;
    LUT4 i8856_3_lut_3_lut (.A(n9852), .B(n10442), .C(N_HB_N_300), .Z(Clk_enable_556)) /* synthesis lut_function=(!(A (B)+!A (B+(C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(750[19:93])
    defparam i8856_3_lut_3_lut.init = 16'h2323;
    LUT4 i1_2_lut_3_lut (.A(Vo[0]), .B(Vo[2]), .C(Vo[3]), .Z(n8892)) /* synthesis lut_function=(!(((C)+!B)+!A)) */ ;
    defparam i1_2_lut_3_lut.init = 16'h0808;
    LUT4 i1_2_lut_rep_348 (.A(Vo[1]), .B(Vo[2]), .Z(n9953)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(768[22:75])
    defparam i1_2_lut_rep_348.init = 16'heeee;
    LUT4 i1_2_lut_rep_283_3_lut (.A(Vo[1]), .B(Vo[2]), .C(V_LINE0N_N_487), 
         .Z(n9888)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(768[22:75])
    defparam i1_2_lut_rep_283_3_lut.init = 16'hfefe;
    LUT4 i2_3_lut_4_lut_adj_412 (.A(Vo[1]), .B(Vo[2]), .C(Vo[3]), .D(Vo[0]), 
         .Z(n8810)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(768[22:75])
    defparam i2_3_lut_4_lut_adj_412.init = 16'hfffe;
    LUT4 i8702_2_lut_rep_251_3_lut_4_lut (.A(Vo[1]), .B(Vo[2]), .C(Vo[0]), 
         .D(V_LINE0N_N_487), .Z(n9856)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(768[22:75])
    defparam i8702_2_lut_rep_251_3_lut_4_lut.init = 16'h0001;
    LUT4 PICT1_I_0_729_2_lut (.A(PICT1), .B(PICT2), .Z(nPICTURE)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(787[19:32])
    defparam PICT1_I_0_729_2_lut.init = 16'heeee;
    LUT4 i2_3_lut_4_lut_adj_413 (.A(Hnn[1]), .B(Hnn[2]), .C(PAR_O), .D(\Hnn[0] ), 
         .Z(SH2_N_1372)) /* synthesis lut_function=(!((B+((D)+!C))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam i2_3_lut_4_lut_adj_413.init = 16'h0020;
    LUT4 i1_2_lut_3_lut_4_lut_adj_414 (.A(\Hnn[0] ), .B(PAR_O), .C(Hnn[2]), 
         .D(Hnn[1]), .Z(SH3_N_1381)) /* synthesis lut_function=(!(((C+!(D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam i1_2_lut_3_lut_4_lut_adj_414.init = 16'h0800;
    LUT4 i1_2_lut_3_lut_4_lut_adj_415 (.A(\Hnn[0] ), .B(PAR_O), .C(Hnn[1]), 
         .D(Hnn[2]), .Z(SH7_N_1390)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam i1_2_lut_3_lut_4_lut_adj_415.init = 16'h8000;
    LUT4 i1_2_lut_3_lut_4_lut_adj_416 (.A(\Hnn[0] ), .B(PAR_O), .C(Hnn[1]), 
         .D(Hnn[2]), .Z(SH5_N_1385)) /* synthesis lut_function=(!(((C+!(D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam i1_2_lut_3_lut_4_lut_adj_416.init = 16'h0800;
    LUT4 i1_2_lut_rep_351 (.A(nVIS), .B(I_OAM2), .Z(n9956)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i1_2_lut_rep_351.init = 16'heeee;
    LUT4 i8973_3_lut_rep_225_4_lut (.A(nVIS), .B(I_OAM2), .C(SPR_OV), 
         .D(OVZ), .Z(n9830)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;
    defparam i8973_3_lut_rep_225_4_lut.init = 16'h0001;
    LUT4 i8806_2_lut_3_lut (.A(nVIS), .B(I_OAM2), .C(\Hnn[0] ), .Z(OMSTEP_1__N_1053)) /* synthesis lut_function=(A+(B+!(C))) */ ;
    defparam i8806_2_lut_3_lut.init = 16'hefef;
    LUT4 i1_2_lut_rep_352 (.A(H[7]), .B(H[6]), .Z(n9957)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(752[23:43])
    defparam i1_2_lut_rep_352.init = 16'heeee;
    LUT4 i8718_3_lut_4_lut (.A(H[7]), .B(H[6]), .C(H[4]), .D(n3656), 
         .Z(CLIP1_N_346)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(752[23:43])
    defparam i8718_3_lut_4_lut.init = 16'h0001;
    LUT4 i1_2_lut_rep_353 (.A(H[4]), .B(H[6]), .Z(n9958)) /* synthesis lut_function=(A+!(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(844[24:61])
    defparam i1_2_lut_rep_353.init = 16'hbbbb;
    LUT4 i8678_3_lut_4_lut (.A(H[4]), .B(H[6]), .C(n9159), .D(n9959), 
         .Z(H_LINE2_N_446)) /* synthesis lut_function=(!(A+(((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(844[24:61])
    defparam i8678_3_lut_4_lut.init = 16'h0040;
    LUT4 i1_2_lut_rep_354 (.A(H[2]), .B(H[1]), .Z(n9959)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(840[24:48])
    defparam i1_2_lut_rep_354.init = 16'heeee;
    LUT4 i8733_2_lut_2_lut_3_lut_4_lut (.A(H[2]), .B(H[1]), .C(BLNK_FF), 
         .D(n9984), .Z(FNT_IN_N_364)) /* synthesis lut_function=(!(A+(B+(C+!(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(840[24:48])
    defparam i8733_2_lut_2_lut_3_lut_4_lut.init = 16'h0100;
    LUT4 i2_3_lut_4_lut_adj_417 (.A(H[2]), .B(H[1]), .C(H[0]), .D(H[3]), 
         .Z(n8805)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(840[24:48])
    defparam i2_3_lut_4_lut_adj_417.init = 16'hfffe;
    FD1P3AX PAR_O_647 (.D(PARO_IN), .SP(Clk_enable_560), .CK(Clk), .Q(PAR_O));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam PAR_O_647.GSR = "DISABLED";
    LUT4 N_HB_I_60_2_lut_rep_357 (.A(\H[8] ), .B(H[7]), .Z(n9962)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(761[22:35])
    defparam N_HB_I_60_2_lut_rep_357.init = 16'hdddd;
    LUT4 i1_2_lut_rep_322_3_lut (.A(\H[8] ), .B(H[7]), .C(H[6]), .Z(n9927)) /* synthesis lut_function=((B+(C))+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(761[22:35])
    defparam i1_2_lut_rep_322_3_lut.init = 16'hfdfd;
    LUT4 i1_2_lut_rep_289_3_lut_4_lut (.A(\H[8] ), .B(H[7]), .C(H[5]), 
         .D(H[6]), .Z(n9894)) /* synthesis lut_function=((B+(C+(D)))+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(761[22:35])
    defparam i1_2_lut_rep_289_3_lut_4_lut.init = 16'hfffd;
    LUT4 i1_2_lut_rep_358 (.A(H[3]), .B(H[1]), .Z(n9963)) /* synthesis lut_function=(A+!(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(750[20:93])
    defparam i1_2_lut_rep_358.init = 16'hbbbb;
    LUT4 i1_2_lut_rep_327_3_lut (.A(H[3]), .B(H[1]), .C(H[2]), .Z(n9932)) /* synthesis lut_function=(A+((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(750[20:93])
    defparam i1_2_lut_rep_327_3_lut.init = 16'hfbfb;
    LUT4 i1_2_lut_3_lut_4_lut_adj_418 (.A(H[3]), .B(H[1]), .C(n9964), 
         .D(H[2]), .Z(n6)) /* synthesis lut_function=(A+(((D)+!C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(750[20:93])
    defparam i1_2_lut_3_lut_4_lut_adj_418.init = 16'hffbf;
    LUT4 i5906_2_lut_rep_359 (.A(H[4]), .B(H[0]), .Z(n9964)) /* synthesis lut_function=(A (B)) */ ;
    defparam i5906_2_lut_rep_359.init = 16'h8888;
    LUT4 i6106_2_lut_rep_326_3_lut (.A(H[4]), .B(H[0]), .C(H[2]), .Z(n9931)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i6106_2_lut_rep_326_3_lut.init = 16'h8080;
    LUT4 i8706_2_lut_rep_364 (.A(NFO1), .B(NFO2), .Z(n9969)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(776[28:44])
    defparam i8706_2_lut_rep_364.init = 16'h1111;
    LUT4 i1_4_lut_adj_419 (.A(RESCL), .B(R2DB[1]), .C(n9889), .D(n4_adj_22), 
         .Z(n4016)) /* synthesis lut_function=(!(A+!(B+!(C+(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam i1_4_lut_adj_419.init = 16'h4445;
    LUT4 NVIS_IN_I_0_1_lut (.A(NVIS_IN), .Z(NVIS_IN_N_258)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(814[23:31])
    defparam NVIS_IN_I_0_1_lut.init = 16'h5555;
    LUT4 i5881_2_lut_rep_320_3_lut (.A(NFO1), .B(NFO2), .C(FAT_IN), .Z(n9925)) /* synthesis lut_function=(A (C)+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(776[28:44])
    defparam i5881_2_lut_rep_320_3_lut.init = 16'he0e0;
    LUT4 MODE_N_21_bdd_4_lut_8993 (.A(Vo[4]), .B(n9891), .C(Vo[3]), .D(Vo[0]), 
         .Z(n9701)) /* synthesis lut_function=(!(A+(B+!(C (D))))) */ ;
    defparam MODE_N_21_bdd_4_lut_8993.init = 16'h1000;
    FD1P3AX ODDEVEN_i1 (.D(ODDEVEN_0__N_221), .SP(V_8__N_515), .CK(Clk), 
            .Q(ODDEVEN_c[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam ODDEVEN_i1.GSR = "DISABLED";
    FD1P3AX VSET_i2 (.D(VSET_1__N_226), .SP(Clk_enable_543), .CK(Clk), 
            .Q(VSET[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam VSET_i2.GSR = "DISABLED";
    FD1P3AX VSET_i1 (.D(VSET_0__N_229), .SP(Clk_enable_393), .CK(Clk), 
            .Q(VSET_c[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam VSET_i1.GSR = "DISABLED";
    FD1P3AX Hn_i0_i0 (.D(H[0]), .SP(Clk_enable_543), .CK(Clk), .Q(\Hn[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hn_i0_i0.GSR = "DISABLED";
    LUT4 FTA_IN_I_0_1_lut (.A(FTA_IN), .Z(FTA_IN_N_379)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(816[17:24])
    defparam FTA_IN_I_0_1_lut.init = 16'h5555;
    FD1P3AX Hnn_i0_i5 (.D(Hn[5]), .SP(Clk_enable_563), .CK(Clk), .Q(\Hnn[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hnn_i0_i5.GSR = "DISABLED";
    FD1P3AX Hnn_i0_i4 (.D(Hn[4]), .SP(Clk_enable_563), .CK(Clk), .Q(\Hnn[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hnn_i0_i4.GSR = "DISABLED";
    FD1P3AX Hnn_i0_i3 (.D(Hn[3]), .SP(Clk_enable_563), .CK(Clk), .Q(\Hnn[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hnn_i0_i3.GSR = "DISABLED";
    FD1P3AX Hnn_i0_i2 (.D(\Hn[2] ), .SP(Clk_enable_563), .CK(Clk), .Q(Hnn[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hnn_i0_i2.GSR = "DISABLED";
    LUT4 FTB_IN_I_0_1_lut (.A(FTB_IN), .Z(FTB_IN_N_373)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(817[23:30])
    defparam FTB_IN_I_0_1_lut.init = 16'h5555;
    LUT4 FPORCH_FF_I_0_1_lut (.A(FPORCH_FF), .Z(FPORCH_FF_N_316)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(820[23:33])
    defparam FPORCH_FF_I_0_1_lut.init = 16'h5555;
    LUT4 i8714_2_lut (.A(N_HB), .B(VSYNC), .Z(VSYNC_N_408)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(821[23:43])
    defparam i8714_2_lut.init = 16'h1111;
    LUT4 HSYNCo_I_0_702_2_lut (.A(HSYNCo), .B(VSYNC_adj_1625), .Z(SYNC_c)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(786[15:28])
    defparam HSYNCo_I_0_702_2_lut.init = 16'heeee;
    LUT4 i6_4_lut (.A(n3656), .B(n12), .C(H[2]), .D(H[6]), .Z(H_LINE23_N_478)) /* synthesis lut_function=(A+(B+!(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(761[20:93])
    defparam i6_4_lut.init = 16'hefff;
    LUT4 i5_4_lut (.A(H[0]), .B(H[1]), .C(n9962), .D(H[4]), .Z(n12)) /* synthesis lut_function=(A+(B+(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(761[20:93])
    defparam i5_4_lut.init = 16'hfeff;
    LUT4 i8682_4_lut (.A(H[5]), .B(n9860), .C(H[6]), .D(n6), .Z(H_LINE5_N_453)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(753[19:101])
    defparam i8682_4_lut.init = 16'h0010;
    LUT4 i8720_2_lut (.A(\H[8] ), .B(VB_FF), .Z(CLIP2_N_343)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(833[23:41])
    defparam i8720_2_lut.init = 16'h4444;
    LUT4 i1_4_lut_adj_420 (.A(VSYNC), .B(n8831), .C(n1), .D(N_HB), .Z(VSYNCo_N_326)) /* synthesis lut_function=(A (B+(C+!(D)))+!A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(796[10] 799[24])
    defparam i1_4_lut_adj_420.init = 16'hecee;
    LUT4 i8689_4_lut (.A(n9942), .B(H[6]), .C(H[7]), .D(n8863), .Z(H_LINE7_N_468)) /* synthesis lut_function=(!(A+!(B (C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(755[19:93])
    defparam i8689_4_lut.init = 16'h4000;
    LUT4 V_8__I_0_1_lut (.A(V[8]), .Z(V_8__N_515)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(763[22:27])
    defparam V_8__I_0_1_lut.init = 16'h5555;
    LUT4 ODDEVEN_0__I_0_1_lut (.A(ODDEVEN[0]), .Z(ODDEVEN_0__N_221)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(828[49:60])
    defparam ODDEVEN_0__I_0_1_lut.init = 16'h5555;
    LUT4 VSET_1__I_0_1_lut (.A(VSET_c[1]), .Z(VSET_1__N_226)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(862[22:30])
    defparam VSET_1__I_0_1_lut.init = 16'h5555;
    LUT4 VBL_EN_I_0_2_lut (.A(VBL_EN), .B(INT_FF), .Z(INT_c)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(790[14:29])
    defparam VBL_EN_I_0_2_lut.init = 16'h8888;
    LUT4 VSET_0__I_0_1_lut (.A(VSET[0]), .Z(VSET_0__N_229)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(803[25:33])
    defparam VSET_0__I_0_1_lut.init = 16'h5555;
    LUT4 n3724_bdd_4_lut (.A(n9932), .B(H[5]), .C(H[7]), .D(H[6]), .Z(n9725)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam n3724_bdd_4_lut.init = 16'hfffe;
    LUT4 i8677_4_lut (.A(H[7]), .B(H[0]), .C(n9897), .D(n3656), .Z(n9159)) /* synthesis lut_function=(!(A+(((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(752[19:101])
    defparam i8677_4_lut.init = 16'h0040;
    LUT4 i1_2_lut_adj_421 (.A(H[3]), .B(H[5]), .Z(n3656)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(761[20:93])
    defparam i1_2_lut_adj_421.init = 16'heeee;
    LUT4 i1_4_lut_adj_422 (.A(Vo[1]), .B(V_LINE0P_N_505), .C(n6362), .D(V_LINE0N_N_487), 
         .Z(n1)) /* synthesis lut_function=(A (B ((D)+!C))+!A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(796[10] 799[24])
    defparam i1_4_lut_adj_422.init = 16'hcc4c;
    LUT4 i3_4_lut_adj_423 (.A(n9980), .B(n9891), .C(Vo[4]), .D(n8810), 
         .Z(V_LINE0P_N_505)) /* synthesis lut_function=(A+(B+((D)+!C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(763[20:101])
    defparam i3_4_lut_adj_423.init = 16'hffef;
    LUT4 MODE_N_21_bdd_4_lut_9018 (.A(n9980), .B(Vo[4]), .C(Vo[5]), .D(Vo[1]), 
         .Z(n9727)) /* synthesis lut_function=(!(A (B+(C+(D)))+!A !(B (C (D))))) */ ;
    defparam MODE_N_21_bdd_4_lut_9018.init = 16'h4002;
    LUT4 i8735_2_lut (.A(H[2]), .B(H[1]), .Z(FAT_IN_N_282)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(841[17:34])
    defparam i8735_2_lut.init = 16'h4444;
    LUT4 i1_2_lut_3_lut_4_lut_adj_424 (.A(V_LINE0N_N_487), .B(n9953), .C(n9980), 
         .D(Vo[0]), .Z(V_LINE3N_N_533)) /* synthesis lut_function=(A+(B+!(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(768[22:75])
    defparam i1_2_lut_3_lut_4_lut_adj_424.init = 16'hefff;
    LUT4 i8434_2_lut_3_lut_4_lut (.A(V_LINE0N_N_487), .B(n9953), .C(MODE_c), 
         .D(Vo[0]), .Z(n8954)) /* synthesis lut_function=(A+(B+(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(768[22:75])
    defparam i8434_2_lut_3_lut_4_lut.init = 16'hfeff;
    LUT4 i8737_2_lut (.A(H[2]), .B(H[1]), .Z(FTA_IN_N_376)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(842[17:34])
    defparam i8737_2_lut.init = 16'h2222;
    LUT4 Vo_0__bdd_3_lut_4_lut (.A(V_LINE0N_N_487), .B(n9953), .C(n9980), 
         .D(Vo[0]), .Z(PEN_FF_N_423)) /* synthesis lut_function=(!(A+(B+!(C (D)+!C !(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(768[22:75])
    defparam Vo_0__bdd_3_lut_4_lut.init = 16'h1001;
    LUT4 i5892_2_lut (.A(H[2]), .B(H[1]), .Z(FTB_IN_N_367)) /* synthesis lut_function=(A (B)) */ ;
    defparam i5892_2_lut.init = 16'h8888;
    LUT4 i1_2_lut_adj_425 (.A(Vo[5]), .B(V[8]), .Z(n6_adj_1627)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(763[22:43])
    defparam i1_2_lut_adj_425.init = 16'heeee;
    LUT4 i8862_2_lut (.A(n9342), .B(n10442), .Z(Clk_enable_554)) /* synthesis lut_function=(!((B)+!A)) */ ;
    defparam i8862_2_lut.init = 16'h2222;
    LUT4 i8865_4_lut_4_lut (.A(n10442), .B(n9742), .C(n8892), .D(n9856), 
         .Z(Clk_enable_553)) /* synthesis lut_function=(!(A+!(B (C+(D))+!B (D)))) */ ;
    defparam i8865_4_lut_4_lut.init = 16'h5540;
    LUT4 i8758_4_lut_rep_291 (.A(Vo[4]), .B(n9951), .C(n8810), .D(n6_adj_1627), 
         .Z(n9896)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(859[10:40])
    defparam i8758_4_lut_rep_291.init = 16'h0001;
    LUT4 i4_4_lut (.A(n7), .B(Vo[1]), .C(Vo[3]), .D(n6362), .Z(V_LINE2N_N_527)) /* synthesis lut_function=(A+(B+(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(765[22:59])
    defparam i4_4_lut.init = 16'hfeff;
    FD1P3AX Hn_i0_i1 (.D(H[1]), .SP(Clk_enable_535), .CK(Clk), .Q(\Hn[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hn_i0_i1.GSR = "DISABLED";
    FD1P3AX Hn_i0_i2 (.D(H[2]), .SP(Clk_enable_535), .CK(Clk), .Q(\Hn[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hn_i0_i2.GSR = "DISABLED";
    FD1P3AX Hn_i0_i3 (.D(H[3]), .SP(Clk_enable_535), .CK(Clk), .Q(Hn[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hn_i0_i3.GSR = "DISABLED";
    FD1P3AX Hn_i0_i4 (.D(H[4]), .SP(Clk_enable_535), .CK(Clk), .Q(Hn[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hn_i0_i4.GSR = "DISABLED";
    FD1P3AX Hn_i0_i5 (.D(H[5]), .SP(Clk_enable_535), .CK(Clk), .Q(Hn[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=235, LSE_RLINE=276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam Hn_i0_i5.GSR = "DISABLED";
    LUT4 i2_4_lut (.A(n3689), .B(Vo[7]), .C(Vo[4]), .D(Vo[6]), .Z(V_LINE0N_N_487)) /* synthesis lut_function=(A+!(B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(762[22:59])
    defparam i2_4_lut.init = 16'hbfff;
    LUT4 i8936_4_lut (.A(n10442), .B(H[0]), .C(H[4]), .D(n9725), .Z(Clk_enable_555)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;
    defparam i8936_4_lut.init = 16'h0001;
    LUT4 i8727_2_lut_3_lut_4_lut (.A(n9942), .B(\H[8] ), .C(H[6]), .D(H[7]), 
         .Z(PARO_IN_N_359)) /* synthesis lut_function=(!(A+((C+(D))+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(753[23:35])
    defparam i8727_2_lut_3_lut_4_lut.init = 16'h0004;
    LUT4 i8740_3_lut_4_lut (.A(n9942), .B(\H[8] ), .C(H[5]), .D(n9958), 
         .Z(NFO1_N_382)) /* synthesis lut_function=(!(A+((C+(D))+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(753[23:35])
    defparam i8740_3_lut_4_lut.init = 16'h0004;
    LUT4 i3_4_lut_adj_426 (.A(n8805), .B(H[4]), .C(H[5]), .D(n9927), 
         .Z(N_HB_N_300)) /* synthesis lut_function=(A+(((D)+!C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(761[20:93])
    defparam i3_4_lut_adj_426.init = 16'hffbf;
    LUT4 i8711_3_lut (.A(EEV_IN), .B(EVAL_IN), .C(HPOS_IN), .Z(nEVAL_N_251)) /* synthesis lut_function=(!(A+(B+(C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(810[23:54])
    defparam i8711_3_lut.init = 16'h0101;
    LUT4 i1_2_lut_adj_427 (.A(Vo[3]), .B(Vo[5]), .Z(n3689)) /* synthesis lut_function=(A+!(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(773[22:51])
    defparam i1_2_lut_adj_427.init = 16'hbbbb;
    LUT4 i2_4_lut_adj_428 (.A(Vo[2]), .B(N_HB), .C(n10430), .D(Vo[1]), 
         .Z(n8831)) /* synthesis lut_function=(!((((D)+!C)+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(796[10] 799[24])
    defparam i2_4_lut_adj_428.init = 16'h0080;
    LUT4 i2_4_lut_adj_429 (.A(n8475), .B(V_LINE3N_N_533), .C(DENDY_c), 
         .D(n8954), .Z(VSET_0__N_231)) /* synthesis lut_function=(!(A (B ((D)+!C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(861[22:52])
    defparam i2_4_lut_adj_429.init = 16'h77f7;
    LUT4 i8708_2_lut (.A(CLIP1), .B(CLIP2), .Z(CLIP_OUT_N_338)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(808[23:42])
    defparam i8708_2_lut.init = 16'h4444;
    FD1P3AX VB_FF_684 (.D(n9896), .SP(Clk_enable_552), .CK(Clk), .Q(VB_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam VB_FF_684.GSR = "DISABLED";
    FD1P3AX BLNK_FF_683 (.D(n9856), .SP(Clk_enable_553), .CK(Clk), .Q(BLNK_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam BLNK_FF_683.GSR = "DISABLED";
    FD1P3AX PEN_FF_682 (.D(PEN_FF_N_423), .SP(Clk_enable_554), .CK(Clk), 
            .Q(PEN_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam PEN_FF_682.GSR = "DISABLED";
    FD1P3AX BPORCH_FF_681 (.D(BPORCH_FF_N_420), .SP(Clk_enable_555), .CK(Clk), 
            .Q(BPORCH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam BPORCH_FF_681.GSR = "DISABLED";
    FD1P3AX N_HB_680 (.D(n9852), .SP(Clk_enable_556), .CK(Clk), .Q(N_HB));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam N_HB_680.GSR = "DISABLED";
    FD1P3AX FPORCH_FF_678 (.D(n9852), .SP(Clk_enable_557), .CK(Clk), .Q(FPORCH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam FPORCH_FF_678.GSR = "DISABLED";
    FD1P3AX R2DB7_639 (.D(INT_FF), .SP(Clk_enable_561), .CK(Clk), .Q(R2DB[2]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(792[8] 864[26])
    defparam R2DB7_639.GSR = "DISABLED";
    COUNTER_U111 Vo_7__I_0_736 (.Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .CNT1_N_565(CNT1_N_565_adj_1628), .\Vo[7] (Vo[7]), .Clk_enable_393(Clk_enable_393), 
            .Vo_7__N_212(Vo_7__N_212)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U112 VCNT_8 (.Clk(Clk), .Clk_enable_247(Clk_enable_247), .CNT1_N_565(CNT1_N_565_adj_1629), 
            .\V[8] (V[8]), .Clk_enable_393(Clk_enable_393), .Vo_7__N_212(Vo_7__N_212)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U113 VCNT_6 (.Clk(Clk), .Clk_enable_247(Clk_enable_247), .CNT1_N_565(CNT1_N_565_adj_1630), 
            .\Vo[6] (Vo[6]), .n9827(n9827), .\Vo[7] (Vo[7]), .\V[8] (V[8]), 
            .CNT1_N_565_adj_21(CNT1_N_565_adj_1629), .Clk_enable_393(Clk_enable_393), 
            .Vo_7__N_212(Vo_7__N_212)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U114 VCNT_5 (.Clk(Clk), .Clk_enable_247(Clk_enable_247), .CNT1_N_565(CNT1_N_565_adj_1631), 
            .\Vo[5] (Vo[5]), .n9829(n9829), .\Vo[7] (Vo[7]), .\Vo[6] (Vo[6]), 
            .CNT1_N_565_adj_20(CNT1_N_565_adj_1628), .Clk_enable_560(Clk_enable_560), 
            .Vo_7__N_212(Vo_7__N_212)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U115 VCNT_4 (.\Vo[4] (Vo[4]), .n9831(n9831), .\Vo[6] (Vo[6]), 
            .\Vo[5] (Vo[5]), .CNT1_N_565(CNT1_N_565_adj_1630), .Clk(Clk), 
            .Clk_enable_247(Clk_enable_247), .CNT1_N_565_adj_19(CNT1_N_565_adj_1632), 
            .Clk_enable_393(Clk_enable_393), .Vo_7__N_212(Vo_7__N_212)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U116 VCNT_3 (.Clk(Clk), .Clk_enable_247(Clk_enable_247), .CNT1_N_565(CNT1_N_565_adj_1633), 
            .\Vo[3] (Vo[3]), .n9833(n9833), .\Vo[5] (Vo[5]), .\Vo[4] (Vo[4]), 
            .n9827(n9827), .CNT1_N_565_adj_18(CNT1_N_565_adj_1631), .Clk_enable_393(Clk_enable_393), 
            .Vo_7__N_212(Vo_7__N_212)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U117 VCNT_2 (.Clk(Clk), .Clk_enable_247(Clk_enable_247), .CNT1_N_565(CNT1_N_565_adj_1634), 
            .\Vo[2] (Vo[2]), .Clk_enable_393(Clk_enable_393), .Vo_7__N_212(Vo_7__N_212), 
            .n9836(n9836), .\Vo[4] (Vo[4]), .\Vo[3] (Vo[3]), .n9829(n9829), 
            .CNT1_N_565_adj_17(CNT1_N_565_adj_1632)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U118 VCNT_1 (.\Vo[1] (Vo[1]), .n9851(n9851), .\Vo[3] (Vo[3]), 
            .\Vo[2] (Vo[2]), .n9831(n9831), .CNT1_N_565(CNT1_N_565_adj_1633), 
            .Clk(Clk), .Clk_enable_247(Clk_enable_247), .CNT1_N_565_adj_16(CNT1_N_565_adj_1635), 
            .Clk_enable_393(Clk_enable_393), .Vo_7__N_212(Vo_7__N_212)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U119 VCNT_0 (.\Vo[0] (Vo[0]), .H_LINE23_N_478(H_LINE23_N_478), 
            .n9851(n9851), .\Vo[1] (Vo[1]), .n9836(n9836), .CNT1_N_565(CNT1_N_565_adj_1635), 
            .\Vo[2] (Vo[2]), .n9833(n9833), .CNT1_N_565_adj_15(CNT1_N_565_adj_1634), 
            .Clk(Clk), .Clk_enable_247(Clk_enable_247), .Clk_enable_560(Clk_enable_560), 
            .Vo_7__N_212(Vo_7__N_212)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(744[9:127])
    COUNTER_U120 H_8__I_0_700 (.Clk(Clk), .Clk_enable_571(Clk_enable_571), 
            .CNT1_N_565(CNT1_N_565_adj_1636), .\H[8] (\H[8] ), .Clk_enable_560(Clk_enable_560), 
            .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U121 HCNT_7 (.Clk(Clk), .Clk_enable_247(Clk_enable_247), .CNT1_N_565(CNT1_N_565_adj_1637), 
            .\H[7] (H[7]), .Clk_enable_560(Clk_enable_560), .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U122 HCNT_6 (.Clk(Clk), .Clk_enable_247(Clk_enable_247), .CNT1_N_565(CNT1_N_565_adj_1638), 
            .\H[6] (H[6]), .n9908(n9908), .\H[7] (H[7]), .\H[8] (\H[8] ), 
            .CNT1_N_565_adj_14(CNT1_N_565_adj_1636), .Clk_enable_560(Clk_enable_560), 
            .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U123 HCNT_5 (.\H[5] (H[5]), .HIN5(HIN5), .Clk(Clk), .Clk_enable_247(Clk_enable_247), 
            .n9908(n9908), .\H[7] (H[7]), .\H[6] (H[6]), .CNT1_N_565(CNT1_N_565_adj_1637), 
            .CNT1_N_565_adj_13(CNT1_N_565_adj_1638), .Clk_enable_560(Clk_enable_560), 
            .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U124 HCNT_4 (.\H[4] (H[4]), .Clk(Clk), .Clk_enable_563(Clk_enable_563), 
            .H_8__N_233(H_8__N_233), .Clk_enable_247(Clk_enable_247), .CNT1_N_565(CNT1_N_565_adj_1639)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U125 HCNT_3 (.Clk(Clk), .Clk_enable_173(Clk_enable_173), .CNT1_N_565(CNT1_N_565_adj_1640), 
            .\H[3] (H[3]), .Clk_enable_560(Clk_enable_560), .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U126 HCNT_2 (.\H[2] (H[2]), .n9955(n9955), .\H[3] (H[3]), 
            .\H[4] (H[4]), .CNT1_N_565(CNT1_N_565_adj_1639), .Clk(Clk), 
            .Clk_enable_247(Clk_enable_247), .CNT1_N_565_adj_12(CNT1_N_565_adj_1641), 
            .Clk_enable_393(Clk_enable_393), .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U127 HCNT_1 (.Clk(Clk), .Clk_enable_247(Clk_enable_247), .\H[1] (H[1]), 
            .\H[0] (H[0]), .n9955(n9955), .\H[3] (H[3]), .\H[2] (H[2]), 
            .CNT1_N_565(CNT1_N_565_adj_1640), .CNT1_N_565_adj_11(CNT1_N_565_adj_1641), 
            .Clk_enable_563(Clk_enable_563), .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    COUNTER_U128 HCNT_0 (.Clk(Clk), .Clk_enable_247(Clk_enable_247), .\H[0] (H[0]), 
            .Clk_enable_393(Clk_enable_393), .H_8__N_233(H_8__N_233)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(743[9:127])
    
endmodule
//
// Verilog Description of module COUNTER_U111
//

module COUNTER_U111 (Clk, Clk_enable_247, CNT1_N_565, \Vo[7] , Clk_enable_393, 
            Vo_7__N_212) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_247;
    input CNT1_N_565;
    output \Vo[7] ;
    input Clk_enable_393;
    input Vo_7__N_212;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_247), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_393), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[7] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U112
//

module COUNTER_U112 (Clk, Clk_enable_247, CNT1_N_565, \V[8] , Clk_enable_393, 
            Vo_7__N_212) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_247;
    input CNT1_N_565;
    output \V[8] ;
    input Clk_enable_393;
    input Vo_7__N_212;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_247), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_393), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\V[8] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U113
//

module COUNTER_U113 (Clk, Clk_enable_247, CNT1_N_565, \Vo[6] , n9827, 
            \Vo[7] , \V[8] , CNT1_N_565_adj_21, Clk_enable_393, Vo_7__N_212) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_247;
    input CNT1_N_565;
    output \Vo[6] ;
    input n9827;
    input \Vo[7] ;
    input \V[8] ;
    output CNT1_N_565_adj_21;
    input Clk_enable_393;
    input Vo_7__N_212;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_247), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_3_lut_4_lut (.A(\Vo[6] ), .B(n9827), .C(\Vo[7] ), .D(\V[8] ), 
         .Z(CNT1_N_565_adj_21)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_3_lut_4_lut.init = 16'h7f80;
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_393), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[6] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U114
//

module COUNTER_U114 (Clk, Clk_enable_247, CNT1_N_565, \Vo[5] , n9829, 
            \Vo[7] , \Vo[6] , CNT1_N_565_adj_20, Clk_enable_560, Vo_7__N_212) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_247;
    input CNT1_N_565;
    output \Vo[5] ;
    input n9829;
    input \Vo[7] ;
    input \Vo[6] ;
    output CNT1_N_565_adj_20;
    input Clk_enable_560;
    input Vo_7__N_212;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_247), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\Vo[5] ), .B(n9829), .C(\Vo[7] ), 
         .D(\Vo[6] ), .Z(CNT1_N_565_adj_20)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h78f0;
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_560), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[5] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U115
//

module COUNTER_U115 (\Vo[4] , n9831, \Vo[6] , \Vo[5] , CNT1_N_565, 
            Clk, Clk_enable_247, CNT1_N_565_adj_19, Clk_enable_393, 
            Vo_7__N_212) /* synthesis syn_module_defined=1 */ ;
    output \Vo[4] ;
    input n9831;
    input \Vo[6] ;
    input \Vo[5] ;
    output CNT1_N_565;
    input Clk;
    input Clk_enable_247;
    input CNT1_N_565_adj_19;
    input Clk_enable_393;
    input Vo_7__N_212;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\Vo[4] ), .B(n9831), .C(\Vo[6] ), 
         .D(\Vo[5] ), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h78f0;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_19), .SP(Clk_enable_247), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_393), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U116
//

module COUNTER_U116 (Clk, Clk_enable_247, CNT1_N_565, \Vo[3] , n9833, 
            \Vo[5] , \Vo[4] , n9827, CNT1_N_565_adj_18, Clk_enable_393, 
            Vo_7__N_212) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_247;
    input CNT1_N_565;
    output \Vo[3] ;
    input n9833;
    input \Vo[5] ;
    input \Vo[4] ;
    output n9827;
    output CNT1_N_565_adj_18;
    input Clk_enable_393;
    input Vo_7__N_212;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_247), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_19_2_lut_rep_222_3_lut_4_lut (.A(\Vo[3] ), .B(n9833), .C(\Vo[5] ), 
         .D(\Vo[4] ), .Z(n9827)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_rep_222_3_lut_4_lut.init = 16'h8000;
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\Vo[3] ), .B(n9833), .C(\Vo[5] ), 
         .D(\Vo[4] ), .Z(CNT1_N_565_adj_18)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h78f0;
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_393), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U117
//

module COUNTER_U117 (Clk, Clk_enable_247, CNT1_N_565, \Vo[2] , Clk_enable_393, 
            Vo_7__N_212, n9836, \Vo[4] , \Vo[3] , n9829, CNT1_N_565_adj_17) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_247;
    input CNT1_N_565;
    output \Vo[2] ;
    input Clk_enable_393;
    input Vo_7__N_212;
    input n9836;
    input \Vo[4] ;
    input \Vo[3] ;
    output n9829;
    output CNT1_N_565_adj_17;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_247), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_393), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 CNT_I_0_19_2_lut_rep_224_3_lut_4_lut (.A(\Vo[2] ), .B(n9836), .C(\Vo[4] ), 
         .D(\Vo[3] ), .Z(n9829)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_rep_224_3_lut_4_lut.init = 16'h8000;
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\Vo[2] ), .B(n9836), .C(\Vo[4] ), 
         .D(\Vo[3] ), .Z(CNT1_N_565_adj_17)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h78f0;
    
endmodule
//
// Verilog Description of module COUNTER_U118
//

module COUNTER_U118 (\Vo[1] , n9851, \Vo[3] , \Vo[2] , n9831, CNT1_N_565, 
            Clk, Clk_enable_247, CNT1_N_565_adj_16, Clk_enable_393, 
            Vo_7__N_212) /* synthesis syn_module_defined=1 */ ;
    output \Vo[1] ;
    input n9851;
    input \Vo[3] ;
    input \Vo[2] ;
    output n9831;
    output CNT1_N_565;
    input Clk;
    input Clk_enable_247;
    input CNT1_N_565_adj_16;
    input Clk_enable_393;
    input Vo_7__N_212;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    LUT4 CNT_I_0_19_2_lut_rep_226_3_lut_4_lut (.A(\Vo[1] ), .B(n9851), .C(\Vo[3] ), 
         .D(\Vo[2] ), .Z(n9831)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_rep_226_3_lut_4_lut.init = 16'h8000;
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\Vo[1] ), .B(n9851), .C(\Vo[3] ), 
         .D(\Vo[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h78f0;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_16), .SP(Clk_enable_247), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_393), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U119
//

module COUNTER_U119 (\Vo[0] , H_LINE23_N_478, n9851, \Vo[1] , n9836, 
            CNT1_N_565, \Vo[2] , n9833, CNT1_N_565_adj_15, Clk, Clk_enable_247, 
            Clk_enable_560, Vo_7__N_212) /* synthesis syn_module_defined=1 */ ;
    output \Vo[0] ;
    input H_LINE23_N_478;
    output n9851;
    input \Vo[1] ;
    output n9836;
    output CNT1_N_565;
    input \Vo[2] ;
    output n9833;
    output CNT1_N_565_adj_15;
    input Clk;
    input Clk_enable_247;
    input Clk_enable_560;
    input Vo_7__N_212;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c, CNT1;
    
    LUT4 i1_2_lut (.A(\Vo[0] ), .B(H_LINE23_N_478), .Z(CNT1_N_565_c)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 CNT_I_0_19_2_lut_rep_246 (.A(\Vo[0] ), .B(H_LINE23_N_478), .Z(n9851)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_rep_246.init = 16'h2222;
    LUT4 CNT_I_0_19_2_lut_rep_231_3_lut (.A(\Vo[0] ), .B(H_LINE23_N_478), 
         .C(\Vo[1] ), .Z(n9836)) /* synthesis lut_function=(!((B+!(C))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_rep_231_3_lut.init = 16'h2020;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\Vo[0] ), .B(H_LINE23_N_478), .C(\Vo[1] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(A (B (C)+!B !(C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'hd2d2;
    LUT4 CNT_I_0_19_2_lut_rep_228_3_lut_4_lut (.A(\Vo[0] ), .B(H_LINE23_N_478), 
         .C(\Vo[2] ), .D(\Vo[1] ), .Z(n9833)) /* synthesis lut_function=(!((B+!(C (D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_rep_228_3_lut_4_lut.init = 16'h2000;
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\Vo[0] ), .B(H_LINE23_N_478), .C(\Vo[2] ), 
         .D(\Vo[1] ), .Z(CNT1_N_565_adj_15)) /* synthesis lut_function=(A (B (C)+!B !(C (D)+!C !(D)))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'hd2f0;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(Clk_enable_247), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_560), .CD(Vo_7__N_212), .CK(Clk), 
            .Q(\Vo[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U120
//

module COUNTER_U120 (Clk, Clk_enable_571, CNT1_N_565, \H[8] , Clk_enable_560, 
            H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_571;
    input CNT1_N_565;
    output \H[8] ;
    input Clk_enable_560;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_571), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_560), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[8] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U121
//

module COUNTER_U121 (Clk, Clk_enable_247, CNT1_N_565, \H[7] , Clk_enable_560, 
            H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_247;
    input CNT1_N_565;
    output \H[7] ;
    input Clk_enable_560;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_247), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_560), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[7] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U122
//

module COUNTER_U122 (Clk, Clk_enable_247, CNT1_N_565, \H[6] , n9908, 
            \H[7] , \H[8] , CNT1_N_565_adj_14, Clk_enable_560, H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_247;
    input CNT1_N_565;
    output \H[6] ;
    input n9908;
    input \H[7] ;
    input \H[8] ;
    output CNT1_N_565_adj_14;
    input Clk_enable_560;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_247), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_3_lut_4_lut (.A(\H[6] ), .B(n9908), .C(\H[7] ), .D(\H[8] ), 
         .Z(CNT1_N_565_adj_14)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_3_lut_4_lut.init = 16'h7f80;
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_560), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[6] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U123
//

module COUNTER_U123 (\H[5] , HIN5, Clk, Clk_enable_247, n9908, \H[7] , 
            \H[6] , CNT1_N_565, CNT1_N_565_adj_13, Clk_enable_560, H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    output \H[5] ;
    input HIN5;
    input Clk;
    input Clk_enable_247;
    output n9908;
    input \H[7] ;
    input \H[6] ;
    output CNT1_N_565;
    output CNT1_N_565_adj_13;
    input Clk_enable_560;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_c, CNT1;
    
    LUT4 CNT_I_0_2_lut (.A(\H[5] ), .B(HIN5), .Z(CNT1_N_565_c)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(Clk_enable_247), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_19_2_lut_rep_303 (.A(\H[5] ), .B(HIN5), .Z(n9908)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_rep_303.init = 16'h8888;
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\H[5] ), .B(HIN5), .C(\H[7] ), 
         .D(\H[6] ), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h78f0;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\H[5] ), .B(HIN5), .C(\H[6] ), .Z(CNT1_N_565_adj_13)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_560), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[5] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U124
//

module COUNTER_U124 (\H[4] , Clk, Clk_enable_563, H_8__N_233, Clk_enable_247, 
            CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    output \H[4] ;
    input Clk;
    input Clk_enable_563;
    input H_8__N_233;
    input Clk_enable_247;
    input CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_563), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_247), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U125
//

module COUNTER_U125 (Clk, Clk_enable_173, CNT1_N_565, \H[3] , Clk_enable_560, 
            H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_173;
    input CNT1_N_565;
    output \H[3] ;
    input Clk_enable_560;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_173), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_560), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U126
//

module COUNTER_U126 (\H[2] , n9955, \H[3] , \H[4] , CNT1_N_565, Clk, 
            Clk_enable_247, CNT1_N_565_adj_12, Clk_enable_393, H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    output \H[2] ;
    input n9955;
    input \H[3] ;
    input \H[4] ;
    output CNT1_N_565;
    input Clk;
    input Clk_enable_247;
    input CNT1_N_565_adj_12;
    input Clk_enable_393;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    LUT4 CNT_I_0_3_lut_4_lut (.A(\H[2] ), .B(n9955), .C(\H[3] ), .D(\H[4] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_3_lut_4_lut.init = 16'h7f80;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_12), .SP(Clk_enable_247), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_393), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U127
//

module COUNTER_U127 (Clk, Clk_enable_247, \H[1] , \H[0] , n9955, \H[3] , 
            \H[2] , CNT1_N_565, CNT1_N_565_adj_11, Clk_enable_563, H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_247;
    output \H[1] ;
    input \H[0] ;
    output n9955;
    input \H[3] ;
    input \H[2] ;
    output CNT1_N_565;
    output CNT1_N_565_adj_11;
    input Clk_enable_563;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, CNT1_N_565_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565_c), .SP(Clk_enable_247), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_19_2_lut_rep_350 (.A(\H[1] ), .B(\H[0] ), .Z(n9955)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_rep_350.init = 16'h8888;
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\H[1] ), .B(\H[0] ), .C(\H[3] ), 
         .D(\H[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h78f0;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\H[1] ), .B(\H[0] ), .C(\H[2] ), .Z(CNT1_N_565_adj_11)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    LUT4 CNT_I_0_2_lut (.A(\H[1] ), .B(\H[0] ), .Z(CNT1_N_565_c)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_563), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U128
//

module COUNTER_U128 (Clk, Clk_enable_247, \H[0] , Clk_enable_393, H_8__N_233) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_247;
    output \H[0] ;
    input Clk_enable_393;
    input H_8__N_233;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, H_0__N_404;
    
    FD1P3AX CNT1_15 (.D(H_0__N_404), .SP(Clk_enable_247), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_393), .CD(H_8__N_233), .CK(Clk), 
            .Q(\H[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 H_0__I_0_1_lut (.A(\H[0] ), .Z(H_0__N_404)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(753[94:99])
    defparam H_0__I_0_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module OBJ_EVAL
//

module OBJ_EVAL (Clk, Clk_enable_571, OVZ, Clk_enable_84, n9830, SPR0_EV1, 
            SPR0_EV1_N_984, Clk_enable_563, Vo, OB_R, GND_net, Clk_enable_173, 
            TAL_LATCH_N_890, OV, SPR0_EV, n2282, n3533, Clk_enable_562, 
            n9942, n6437, O8_16, n10442, PD_FIFO) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_571;
    output OVZ;
    input Clk_enable_84;
    input n9830;
    output SPR0_EV1;
    input SPR0_EV1_N_984;
    input Clk_enable_563;
    input [7:0]Vo;
    input [7:0]OB_R;
    input GND_net;
    input Clk_enable_173;
    input TAL_LATCH_N_890;
    output [3:0]OV;
    output SPR0_EV;
    input n2282;
    output n3533;
    input Clk_enable_562;
    input n9942;
    output n6437;
    input O8_16;
    input n10442;
    output PD_FIFO;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [1:0]PDFIFO;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1190[10:16])
    wire [5:0]CLATCH;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1188[10:16])
    
    wire n8217;
    wire [7:0]OVS;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1193[11:14])
    
    wire n8216, n8215, n8214, OVZ_N_991, n10, n8, PD_FIFO_N_979, 
        PDFIFO_0__N_978;
    
    FD1P3AX PDFIFO_i0_i0 (.D(OVZ), .SP(Clk_enable_571), .CK(Clk), .Q(PDFIFO[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam PDFIFO_i0_i0.GSR = "DISABLED";
    FD1P3AX CLATCH_i0 (.D(n9830), .SP(Clk_enable_84), .CK(Clk), .Q(CLATCH[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam CLATCH_i0.GSR = "DISABLED";
    FD1P3AX SPR0_EV1_57 (.D(n9830), .SP(SPR0_EV1_N_984), .CK(Clk), .Q(SPR0_EV1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam SPR0_EV1_57.GSR = "DISABLED";
    FD1P3AX CLATCH_i5 (.D(CLATCH[4]), .SP(Clk_enable_563), .CK(Clk), .Q(CLATCH[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam CLATCH_i5.GSR = "DISABLED";
    FD1P3AX CLATCH_i4 (.D(CLATCH[3]), .SP(Clk_enable_84), .CK(Clk), .Q(CLATCH[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam CLATCH_i4.GSR = "DISABLED";
    FD1P3AX CLATCH_i3 (.D(CLATCH[2]), .SP(Clk_enable_563), .CK(Clk), .Q(CLATCH[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam CLATCH_i3.GSR = "DISABLED";
    FD1P3AX CLATCH_i2 (.D(CLATCH[1]), .SP(Clk_enable_84), .CK(Clk), .Q(CLATCH[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam CLATCH_i2.GSR = "DISABLED";
    FD1P3AX CLATCH_i1 (.D(CLATCH[0]), .SP(Clk_enable_563), .CK(Clk), .Q(CLATCH[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam CLATCH_i1.GSR = "DISABLED";
    CCU2D V_7__I_0_add_2_9 (.A0(Vo[7]), .B0(OB_R[7]), .C0(GND_net), .D0(GND_net), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n8217), 
          .S0(OVS[7]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1194[19:40])
    defparam V_7__I_0_add_2_9.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_9.INIT1 = 16'h0000;
    defparam V_7__I_0_add_2_9.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_9.INJECT1_1 = "NO";
    FD1P3AX PDFIFO_i0_i1 (.D(TAL_LATCH_N_890), .SP(Clk_enable_173), .CK(Clk), 
            .Q(PDFIFO[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=358, LSE_RLINE=376 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam PDFIFO_i0_i1.GSR = "DISABLED";
    CCU2D V_7__I_0_add_2_7 (.A0(Vo[5]), .B0(OB_R[5]), .C0(GND_net), .D0(GND_net), 
          .A1(Vo[6]), .B1(OB_R[6]), .C1(GND_net), .D1(GND_net), .CIN(n8216), 
          .COUT(n8217), .S0(OVS[5]), .S1(OVS[6]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1194[19:40])
    defparam V_7__I_0_add_2_7.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_7.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_7.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_7.INJECT1_1 = "NO";
    CCU2D V_7__I_0_add_2_5 (.A0(Vo[3]), .B0(OB_R[3]), .C0(GND_net), .D0(GND_net), 
          .A1(Vo[4]), .B1(OB_R[4]), .C1(GND_net), .D1(GND_net), .CIN(n8215), 
          .COUT(n8216), .S0(OV[3]), .S1(OVS[4]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1194[19:40])
    defparam V_7__I_0_add_2_5.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_5.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_5.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_5.INJECT1_1 = "NO";
    FD1S3AX SPR0_EV_58 (.D(n2282), .CK(Clk), .Q(SPR0_EV));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam SPR0_EV_58.GSR = "DISABLED";
    CCU2D V_7__I_0_add_2_3 (.A0(Vo[1]), .B0(OB_R[1]), .C0(GND_net), .D0(GND_net), 
          .A1(Vo[2]), .B1(OB_R[2]), .C1(GND_net), .D1(GND_net), .CIN(n8214), 
          .COUT(n8215), .S0(OV[1]), .S1(OV[2]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1194[19:40])
    defparam V_7__I_0_add_2_3.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_3.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_3.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_3.INJECT1_1 = "NO";
    LUT4 i8832_2_lut_2_lut_3_lut_4_lut (.A(n9830), .B(n3533), .C(Clk_enable_562), 
         .D(n9942), .Z(n6437)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1199[18:51])
    defparam i8832_2_lut_2_lut_3_lut_4_lut.init = 16'h0010;
    CCU2D V_7__I_0_add_2_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(Vo[0]), .B1(OB_R[0]), .C1(GND_net), .D1(GND_net), 
          .COUT(n8214), .S1(OV[0]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1194[19:40])
    defparam V_7__I_0_add_2_1.INIT0 = 16'h0000;
    defparam V_7__I_0_add_2_1.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_1.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_1.INJECT1_1 = "NO";
    LUT4 i2_3_lut (.A(CLATCH[1]), .B(CLATCH[3]), .C(CLATCH[5]), .Z(n3533)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1199[18:51])
    defparam i2_3_lut.init = 16'hfefe;
    LUT4 i1_4_lut (.A(n3533), .B(OVZ_N_991), .C(n10), .D(OVS[5]), .Z(OVZ)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1199[18:51])
    defparam i1_4_lut.init = 16'hfffe;
    LUT4 OVZ_I_282_2_lut (.A(O8_16), .B(OV[3]), .Z(OVZ_N_991)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1196[94:113])
    defparam OVZ_I_282_2_lut.init = 16'h4444;
    LUT4 i4_4_lut (.A(OVS[7]), .B(n8), .C(OB_R[7]), .D(Vo[7]), .Z(n10)) /* synthesis lut_function=(A+(B+!((D)+!C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1199[18:51])
    defparam i4_4_lut.init = 16'heefe;
    LUT4 i2_2_lut (.A(OVS[6]), .B(OVS[4]), .Z(n8)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1199[18:51])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 i8788_2_lut (.A(n10442), .B(PDFIFO[1]), .Z(PD_FIFO_N_979)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1208[15:36])
    defparam i8788_2_lut.init = 16'h2222;
    LUT4 PDFIFO_0__I_0_1_lut (.A(PDFIFO[0]), .Z(PDFIFO_0__N_978)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1208[49:59])
    defparam PDFIFO_0__I_0_1_lut.init = 16'h5555;
    FD1P3AX PD_FIFO_56 (.D(PDFIFO_0__N_978), .SP(PD_FIFO_N_979), .CK(Clk), 
            .Q(PD_FIFO));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1202[8] 1212[27])
    defparam PD_FIFO_56.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module LOCAL_BUS_CONTROL
//

module LOCAL_BUS_CONTROL (DB_PARR, Clk, Clk_enable_563, n9981, R7, 
            W7, Clk_enable_47, n10442, E_EV, n9866, n10432, n9754, 
            n9752, n8933, ALE_c, Clk_enable_560, n9942, OMFG_LATCH, 
            OVF_LATCH, n4, n9941, RC, Clk_enable_86, n9907, PAMUX_7__N_851, 
            DBIN, \PAMUX[7] , Clk_enable_393, \Hn[1] , \TP[3] , Clk_enable_543, 
            \TP[1] , TH_MUX, nWR_c, \TP[2] , \PAMUX[6] , \TP[4] , 
            \TP[0] , PA11_c_11, PA12_c_12, PA8_c_8, PA13_c_13, PA9_c_9, 
            PA10_c_10, n9975, Clk_enable_542, XRB_N_606) /* synthesis syn_module_defined=1 */ ;
    output DB_PARR;
    input Clk;
    input Clk_enable_563;
    output n9981;
    input R7;
    input W7;
    output Clk_enable_47;
    input n10442;
    input E_EV;
    output n9866;
    input n10432;
    input n9754;
    output n9752;
    input n8933;
    output ALE_c;
    input Clk_enable_560;
    input n9942;
    input OMFG_LATCH;
    input OVF_LATCH;
    output n4;
    output n9941;
    input RC;
    output Clk_enable_86;
    output n9907;
    input [7:0]PAMUX_7__N_851;
    input [7:0]DBIN;
    output \PAMUX[7] ;
    input Clk_enable_393;
    input \Hn[1] ;
    input \TP[3] ;
    input Clk_enable_543;
    input \TP[1] ;
    output TH_MUX;
    output nWR_c;
    input \TP[2] ;
    output \PAMUX[6] ;
    input \TP[4] ;
    input \TP[0] ;
    input PA11_c_11;
    input PA12_c_12;
    input PA8_c_8;
    input PA13_c_13;
    input PA9_c_9;
    input PA10_c_10;
    input n9975;
    output Clk_enable_542;
    output XRB_N_606;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire R7_FF, R7Q_2__N_575;
    wire [4:0]R7Q;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(894[10:13])
    wire [4:0]W7Q;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(895[10:13])
    
    wire W7Q_2__N_587, W7_FF, W7Q_3__N_580, BLNK_LATCH, Clk_enable_216, 
        W7Q_2__N_583, R7Q_3__N_568, R7Q_2__N_571, n12;
    
    FD1P3AX DB_PARR_46 (.D(n9981), .SP(Clk_enable_563), .CK(Clk), .Q(DB_PARR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1582[8] 1632[26])
    defparam DB_PARR_46.GSR = "DISABLED";
    LUT4 R7_FF_I_0_84_2_lut (.A(R7_FF), .B(R7), .Z(R7Q_2__N_575)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(916[56:67])
    defparam R7_FF_I_0_84_2_lut.init = 16'h2222;
    FD1P3AX R7Q_i0 (.D(R7Q_2__N_575), .SP(Clk_enable_563), .CK(Clk), .Q(R7Q[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam R7Q_i0.GSR = "DISABLED";
    FD1P3AX W7Q_i0 (.D(W7Q_2__N_587), .SP(Clk_enable_563), .CK(Clk), .Q(W7Q[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam W7Q_i0.GSR = "DISABLED";
    LUT4 W7_FF_I_0_83_2_lut (.A(W7_FF), .B(W7), .Z(W7Q_2__N_587)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(917[56:67])
    defparam W7_FF_I_0_83_2_lut.init = 16'h2222;
    LUT4 Z_TV_1__I_246_2_lut_rep_261_3_lut_4_lut (.A(Clk_enable_47), .B(DB_PARR), 
         .C(n10442), .D(E_EV), .Z(n9866)) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C+!(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(900[17:36])
    defparam Z_TV_1__I_246_2_lut_rep_261_3_lut_4_lut.init = 16'hf0f1;
    FD1P3IX W7_FF_69 (.D(n10432), .SP(W7), .CD(W7Q_3__N_580), .CK(Clk), 
            .Q(W7_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam W7_FF_69.GSR = "DISABLED";
    PFUMX i9000 (.BLUT(n9754), .ALUT(n9752), .C0(n8933), .Z(ALE_c));
    FD1P3AX BLNK_LATCH_70 (.D(n9942), .SP(Clk_enable_560), .CK(Clk), .Q(BLNK_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam BLNK_LATCH_70.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(OMFG_LATCH), .B(OVF_LATCH), .Z(n4)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(906[65:76])
    defparam i1_2_lut.init = 16'heeee;
    FD1P3AX R7_FF_68 (.D(R7Q[3]), .SP(Clk_enable_216), .CK(Clk), .Q(R7_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam R7_FF_68.GSR = "DISABLED";
    LUT4 i8767_2_lut_rep_362 (.A(R7Q[4]), .B(R7Q[2]), .Z(Clk_enable_47)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(901[17:38])
    defparam i8767_2_lut_rep_362.init = 16'h2222;
    LUT4 i1_2_lut_rep_336_3_lut (.A(R7Q[4]), .B(R7Q[2]), .C(DB_PARR), 
         .Z(n9941)) /* synthesis lut_function=(A ((C)+!B)+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(901[17:38])
    defparam i1_2_lut_rep_336_3_lut.init = 16'hf2f2;
    LUT4 i708_2_lut_3_lut (.A(R7Q[4]), .B(R7Q[2]), .C(RC), .Z(Clk_enable_86)) /* synthesis lut_function=(A ((C)+!B)+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(901[17:38])
    defparam i708_2_lut_3_lut.init = 16'hf2f2;
    LUT4 i1_2_lut_rep_302_3_lut_4_lut (.A(R7Q[4]), .B(R7Q[2]), .C(E_EV), 
         .D(DB_PARR), .Z(n9907)) /* synthesis lut_function=(A ((C+(D))+!B)+!A (C+(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(901[17:38])
    defparam i1_2_lut_rep_302_3_lut_4_lut.init = 16'hfff2;
    LUT4 W7Q_3__I_0_79_1_lut (.A(W7Q[3]), .Z(W7Q_3__N_580)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(917[39:46])
    defparam W7Q_3__I_0_79_1_lut.init = 16'h5555;
    LUT4 i8774_2_lut_rep_376 (.A(W7Q[3]), .B(W7Q[1]), .Z(n9981)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(902[17:38])
    defparam i8774_2_lut_rep_376.init = 16'h1111;
    LUT4 PAMUX_7__I_0_i8_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(PAMUX_7__N_851[7]), 
         .D(DBIN[7]), .Z(\PAMUX[7] )) /* synthesis lut_function=(A (C)+!A (B (C)+!B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(902[17:38])
    defparam PAMUX_7__I_0_i8_3_lut_4_lut.init = 16'hf1e0;
    FD1P3AX W7Q_i4 (.D(W7Q_3__N_580), .SP(Clk_enable_393), .CK(Clk), .Q(W7Q[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam W7Q_i4.GSR = "DISABLED";
    LUT4 PAMUX_7__I_244_i4_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(DBIN[3]), 
         .D(\Hn[1] ), .Z(PAMUX_7__N_851[3])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(902[17:38])
    defparam PAMUX_7__I_244_i4_3_lut_4_lut.init = 16'hfe10;
    LUT4 PAMUX_7__I_244_i5_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(DBIN[4]), 
         .D(\TP[3] ), .Z(PAMUX_7__N_851[4])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(902[17:38])
    defparam PAMUX_7__I_244_i5_3_lut_4_lut.init = 16'hfe10;
    FD1P3AX W7Q_i3 (.D(W7Q_2__N_583), .SP(Clk_enable_543), .CK(Clk), .Q(W7Q[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam W7Q_i3.GSR = "DISABLED";
    FD1P3AX W7Q_i2 (.D(W7Q[1]), .SP(Clk_enable_393), .CK(Clk), .Q(W7Q[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam W7Q_i2.GSR = "DISABLED";
    LUT4 PAMUX_7__I_244_i2_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(DBIN[1]), 
         .D(\TP[1] ), .Z(PAMUX_7__N_851[1])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(902[17:38])
    defparam PAMUX_7__I_244_i2_3_lut_4_lut.init = 16'hfe10;
    LUT4 DB_PAR_N_593_I_0_2_lut_2_lut_3_lut (.A(W7Q[3]), .B(W7Q[1]), .C(TH_MUX), 
         .Z(nWR_c)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(902[17:38])
    defparam DB_PAR_N_593_I_0_2_lut_2_lut_3_lut.init = 16'hfefe;
    FD1P3AX W7Q_i1 (.D(W7Q[0]), .SP(Clk_enable_543), .CK(Clk), .Q(W7Q[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam W7Q_i1.GSR = "DISABLED";
    LUT4 PAMUX_7__I_244_i3_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(DBIN[2]), 
         .D(\TP[2] ), .Z(PAMUX_7__N_851[2])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(902[17:38])
    defparam PAMUX_7__I_244_i3_3_lut_4_lut.init = 16'hfe10;
    FD1P3AX R7Q_i4 (.D(R7Q_3__N_568), .SP(Clk_enable_393), .CK(Clk), .Q(R7Q[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam R7Q_i4.GSR = "DISABLED";
    LUT4 PAMUX_7__I_0_i7_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(PAMUX_7__N_851[6]), 
         .D(DBIN[6]), .Z(\PAMUX[6] )) /* synthesis lut_function=(A (C)+!A (B (C)+!B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(902[17:38])
    defparam PAMUX_7__I_0_i7_3_lut_4_lut.init = 16'hf1e0;
    FD1P3AX R7Q_i3 (.D(R7Q_2__N_571), .SP(Clk_enable_543), .CK(Clk), .Q(R7Q[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam R7Q_i3.GSR = "DISABLED";
    FD1P3AX R7Q_i2 (.D(R7Q[1]), .SP(Clk_enable_393), .CK(Clk), .Q(R7Q[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam R7Q_i2.GSR = "DISABLED";
    LUT4 PAMUX_7__I_244_i6_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(DBIN[5]), 
         .D(\TP[4] ), .Z(PAMUX_7__N_851[5])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(902[17:38])
    defparam PAMUX_7__I_244_i6_3_lut_4_lut.init = 16'hfe10;
    FD1P3AX R7Q_i1 (.D(R7Q[0]), .SP(Clk_enable_543), .CK(Clk), .Q(R7Q[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=19, LSE_RCOL=2, LSE_LLINE=279, LSE_RLINE=297 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(908[8] 923[27])
    defparam R7Q_i1.GSR = "DISABLED";
    LUT4 PAMUX_7__I_244_i1_3_lut_4_lut (.A(W7Q[3]), .B(W7Q[1]), .C(DBIN[0]), 
         .D(\TP[0] ), .Z(PAMUX_7__N_851[0])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(902[17:38])
    defparam PAMUX_7__I_244_i1_3_lut_4_lut.init = 16'hfe10;
    LUT4 i1_2_lut_adj_407 (.A(R7), .B(R7Q[3]), .Z(Clk_enable_216)) /* synthesis lut_function=(A+!(B)) */ ;
    defparam i1_2_lut_adj_407.init = 16'hbbbb;
    LUT4 W7Q_2__I_0_1_lut (.A(W7Q[2]), .Z(W7Q_2__N_583)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(906[50:57])
    defparam W7Q_2__I_0_1_lut.init = 16'h5555;
    LUT4 R7Q_3__I_0_1_lut (.A(R7Q[3]), .Z(R7Q_3__N_568)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(916[39:46])
    defparam R7Q_3__I_0_1_lut.init = 16'h5555;
    LUT4 R7Q_2__I_0_1_lut (.A(R7Q[2]), .Z(R7Q_2__N_571)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(906[26:33])
    defparam R7Q_2__I_0_1_lut.init = 16'h5555;
    LUT4 i6_4_lut (.A(PA11_c_11), .B(n12), .C(PA12_c_12), .D(PA8_c_8), 
         .Z(TH_MUX)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(899[17:85])
    defparam i6_4_lut.init = 16'h8000;
    LUT4 i5_4_lut (.A(PA13_c_13), .B(PA9_c_9), .C(PA10_c_10), .D(BLNK_LATCH), 
         .Z(n12)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(899[17:85])
    defparam i5_4_lut.init = 16'h8000;
    LUT4 i8978_3_lut_3_lut_4_lut (.A(E_EV), .B(n9941), .C(n9975), .D(n10442), 
         .Z(Clk_enable_542)) /* synthesis lut_function=(!(A (D)+!A (B (D)+!B ((D)+!C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(900[17:36])
    defparam i8978_3_lut_3_lut_4_lut.init = 16'h00fe;
    LUT4 R7_N_577_I_0_2_lut (.A(R7), .B(TH_MUX), .Z(XRB_N_606)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(905[15:31])
    defparam R7_N_577_I_0_2_lut.init = 16'hdddd;
    LUT4 n8933_bdd_4_lut (.A(W7Q[4]), .B(R7Q[2]), .C(W7Q[2]), .D(R7Q[4]), 
         .Z(n9752)) /* synthesis lut_function=(!(A ((D)+!B)+!A !(B (C+!(D))+!B (C)))) */ ;
    defparam n8933_bdd_4_lut.init = 16'h50dc;
    
endmodule
//
// Verilog Description of module REGISTER_SELECT
//

module REGISTER_SELECT (Clk, A_c_0, RnWR, RnW_c, nDBER, DB_nOE_c_c, 
            W5_1, W5_2, W6_1, W6_2, A_c_2, A_c_1, R2, DBIN, 
            DB_out_0, W0, W1, nRES_c, SUBCLK_c, SUB_1__N_16, W3, 
            R4, W4, R7, W7, Clk_enable_518, RC, TH_4__N_776, DB_out_1, 
            DB_out_2, DB_out_3, DB_out_4, DB_out_5, DB_out_6, DB_out_7, 
            \VSET[2] , n38, \VSET[0] , n10442, Clk_enable_113, RESCL, 
            H_LINE23_N_478, n6, H_LINE5_N_453, HC_N_237, DB_DIR_c, 
            n76, XRB_N_606, \PD_R[6] , \Do_7__N_163[6] , \R2DB[1] , 
            n9899, Clk_enable_561, n25, nRES_N_15) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input A_c_0;
    output RnWR;
    input RnW_c;
    output nDBER;
    input DB_nOE_c_c;
    output W5_1;
    output W5_2;
    output W6_1;
    output W6_2;
    input A_c_2;
    input A_c_1;
    output R2;
    output [7:0]DBIN;
    input DB_out_0;
    output W0;
    output W1;
    input nRES_c;
    input SUBCLK_c;
    output SUB_1__N_16;
    output W3;
    output R4;
    output W4;
    output R7;
    output W7;
    output Clk_enable_518;
    input RC;
    output TH_4__N_776;
    input DB_out_1;
    input DB_out_2;
    input DB_out_3;
    input DB_out_4;
    input DB_out_5;
    input DB_out_6;
    input DB_out_7;
    input \VSET[2] ;
    output n38;
    input \VSET[0] ;
    input n10442;
    output Clk_enable_113;
    input RESCL;
    input H_LINE23_N_478;
    input n6;
    input H_LINE5_N_453;
    output HC_N_237;
    output DB_DIR_c;
    input n76;
    input XRB_N_606;
    input \PD_R[6] ;
    output \Do_7__N_163[6] ;
    input \R2DB[1] ;
    input n9899;
    output Clk_enable_561;
    output n25;
    output nRES_N_15;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [2:0]ADR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(523[10:13])
    
    wire W5_1_N_68, W5_2_N_72, W6_1_N_80, W6_2_N_85, n9974, n9973, 
        DWR2, n9978, n9977, DWR1, Clk_enable_89, DWR2_N_74, Clk_enable_91, 
        DBIN_7__N_33, R2_N_56, W0_N_41, W1_N_53, W3_N_60, R4_N_67, 
        W4_N_63, R7_N_90, W7_N_87, n5;
    
    FD1S3AX ADR_i0 (.D(A_c_0), .CK(Clk), .Q(ADR[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam ADR_i0.GSR = "DISABLED";
    FD1S3AX RnWR_132 (.D(RnW_c), .CK(Clk), .Q(RnWR)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam RnWR_132.GSR = "DISABLED";
    FD1S3AX nDBER_133 (.D(DB_nOE_c_c), .CK(Clk), .Q(nDBER)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam nDBER_133.GSR = "DISABLED";
    FD1S3AX W5_1_140 (.D(W5_1_N_68), .CK(Clk), .Q(W5_1)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W5_1_140.GSR = "DISABLED";
    FD1S3AX W5_2_141 (.D(W5_2_N_72), .CK(Clk), .Q(W5_2)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W5_2_141.GSR = "DISABLED";
    FD1S3AX W6_1_142 (.D(W6_1_N_80), .CK(Clk), .Q(W6_1)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W6_1_142.GSR = "DISABLED";
    FD1S3AX W6_2_143 (.D(W6_2_N_85), .CK(Clk), .Q(W6_2)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W6_2_143.GSR = "DISABLED";
    LUT4 i1_2_lut_4_lut (.A(n9974), .B(n9973), .C(nDBER), .D(DWR2), 
         .Z(W6_1_N_80)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(545[18:44])
    defparam i1_2_lut_4_lut.init = 16'h0200;
    LUT4 i1_2_lut_4_lut_adj_396 (.A(n9974), .B(n9973), .C(nDBER), .D(DWR2), 
         .Z(W6_2_N_85)) /* synthesis lut_function=(!((B+(C+(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(545[18:44])
    defparam i1_2_lut_4_lut_adj_396.init = 16'h0002;
    LUT4 i1_2_lut_4_lut_adj_397 (.A(nDBER), .B(n9978), .C(n9977), .D(DWR2), 
         .Z(W5_1_N_68)) /* synthesis lut_function=(!(A+!(B (C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(536[17:34])
    defparam i1_2_lut_4_lut_adj_397.init = 16'h4000;
    FD1S3AX ADR_i2 (.D(A_c_2), .CK(Clk), .Q(ADR[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam ADR_i2.GSR = "DISABLED";
    LUT4 i1_2_lut_4_lut_adj_398 (.A(nDBER), .B(n9978), .C(n9977), .D(DWR2), 
         .Z(W5_2_N_72)) /* synthesis lut_function=(!(A+(((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(536[17:34])
    defparam i1_2_lut_4_lut_adj_398.init = 16'h0040;
    FD1S3AX ADR_i1 (.D(A_c_1), .CK(Clk), .Q(ADR[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam ADR_i1.GSR = "DISABLED";
    FD1P3JX DWR1_146 (.D(DWR2_N_74), .SP(Clk_enable_89), .PD(R2), .CK(Clk), 
            .Q(DWR1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DWR1_146.GSR = "DISABLED";
    FD1P3JX DWR2_147 (.D(DWR1), .SP(Clk_enable_91), .PD(R2), .CK(Clk), 
            .Q(DWR2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DWR2_147.GSR = "DISABLED";
    FD1P3AX DBIN_i0_i0 (.D(DB_out_0), .SP(DBIN_7__N_33), .CK(Clk), .Q(DBIN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i0.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(RnWR), .B(ADR[0]), .C(ADR[2]), .D(ADR[1]), 
         .Z(R2_N_56)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(536[17:34])
    defparam i1_2_lut_3_lut_4_lut.init = 16'h0200;
    FD1S3IX W0_134 (.D(W0_N_41), .CK(Clk), .CD(nDBER), .Q(W0));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W0_134.GSR = "DISABLED";
    FD1S3IX W1_135 (.D(W1_N_53), .CK(Clk), .CD(nDBER), .Q(W1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W1_135.GSR = "DISABLED";
    FD1S3IX R2_136 (.D(R2_N_56), .CK(Clk), .CD(nDBER), .Q(R2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam R2_136.GSR = "DISABLED";
    LUT4 i1_2_lut (.A(nRES_c), .B(SUBCLK_c), .Z(SUB_1__N_16)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(40[7:11])
    defparam i1_2_lut.init = 16'h2222;
    FD1S3IX W3_137 (.D(W3_N_60), .CK(Clk), .CD(nDBER), .Q(W3));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W3_137.GSR = "DISABLED";
    FD1S3IX R4_138 (.D(R4_N_67), .CK(Clk), .CD(nDBER), .Q(R4));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam R4_138.GSR = "DISABLED";
    FD1S3IX W4_139 (.D(W4_N_63), .CK(Clk), .CD(nDBER), .Q(W4));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W4_139.GSR = "DISABLED";
    FD1S3IX R7_144 (.D(R7_N_90), .CK(Clk), .CD(nDBER), .Q(R7));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam R7_144.GSR = "DISABLED";
    FD1S3IX W7_145 (.D(W7_N_87), .CK(Clk), .CD(nDBER), .Q(W7));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam W7_145.GSR = "DISABLED";
    LUT4 i1_2_lut_rep_367 (.A(W6_2), .B(W5_1), .Z(Clk_enable_518)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(548[15:40])
    defparam i1_2_lut_rep_367.init = 16'heeee;
    LUT4 i3379_1_lut_3_lut_4_lut (.A(W6_2), .B(W5_1), .C(W5_2), .D(W6_1), 
         .Z(Clk_enable_91)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(548[15:40])
    defparam i3379_1_lut_3_lut_4_lut.init = 16'h0001;
    LUT4 i2_3_lut_rep_332_4_lut (.A(W6_2), .B(W5_1), .C(W5_2), .D(W6_1), 
         .Z(Clk_enable_89)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(548[15:40])
    defparam i2_3_lut_rep_332_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut (.A(W6_2), .B(W5_1), .C(RC), .Z(TH_4__N_776)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(548[15:40])
    defparam i1_2_lut_3_lut.init = 16'hfefe;
    LUT4 i5923_2_lut_rep_368 (.A(RnWR), .B(ADR[0]), .Z(n9973)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i5923_2_lut_rep_368.init = 16'heeee;
    LUT4 i8687_2_lut_2_lut_3_lut_4_lut (.A(RnWR), .B(ADR[0]), .C(ADR[1]), 
         .D(ADR[2]), .Z(W0_N_41)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;
    defparam i8687_2_lut_2_lut_3_lut_4_lut.init = 16'h0001;
    LUT4 ADR_2__I_0_2_lut_rep_369 (.A(ADR[2]), .B(ADR[1]), .Z(n9974)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(542[18:34])
    defparam ADR_2__I_0_2_lut_rep_369.init = 16'h8888;
    LUT4 i1_2_lut_3_lut_4_lut_adj_399 (.A(ADR[2]), .B(ADR[1]), .C(RnWR), 
         .D(ADR[0]), .Z(W7_N_87)) /* synthesis lut_function=(!(((C+!(D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(542[18:34])
    defparam i1_2_lut_3_lut_4_lut_adj_399.init = 16'h0800;
    LUT4 i1_2_lut_3_lut_4_lut_adj_400 (.A(ADR[2]), .B(ADR[1]), .C(RnWR), 
         .D(ADR[0]), .Z(R7_N_90)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(542[18:34])
    defparam i1_2_lut_3_lut_4_lut_adj_400.init = 16'h8000;
    LUT4 ADR_2__I_0_154_2_lut_rep_372 (.A(ADR[2]), .B(ADR[1]), .Z(n9977)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(539[18:34])
    defparam ADR_2__I_0_154_2_lut_rep_372.init = 16'h2222;
    LUT4 i1_2_lut_3_lut_4_lut_adj_401 (.A(ADR[2]), .B(ADR[1]), .C(ADR[0]), 
         .D(RnWR), .Z(W4_N_63)) /* synthesis lut_function=(!((B+(C+(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(539[18:34])
    defparam i1_2_lut_3_lut_4_lut_adj_401.init = 16'h0002;
    LUT4 i1_2_lut_3_lut_4_lut_adj_402 (.A(ADR[2]), .B(ADR[1]), .C(ADR[0]), 
         .D(RnWR), .Z(R4_N_67)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(539[18:34])
    defparam i1_2_lut_3_lut_4_lut_adj_402.init = 16'h0200;
    LUT4 i1_2_lut_rep_373 (.A(RnWR), .B(ADR[0]), .Z(n9978)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(536[17:34])
    defparam i1_2_lut_rep_373.init = 16'h4444;
    LUT4 i1_2_lut_3_lut_4_lut_adj_403 (.A(RnWR), .B(ADR[0]), .C(ADR[1]), 
         .D(ADR[2]), .Z(W1_N_53)) /* synthesis lut_function=(!(A+((C+(D))+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(536[17:34])
    defparam i1_2_lut_3_lut_4_lut_adj_403.init = 16'h0004;
    LUT4 i1_2_lut_3_lut_4_lut_adj_404 (.A(RnWR), .B(ADR[0]), .C(ADR[2]), 
         .D(ADR[1]), .Z(W3_N_60)) /* synthesis lut_function=(!(A+((C+!(D))+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(536[17:34])
    defparam i1_2_lut_3_lut_4_lut_adj_404.init = 16'h0400;
    LUT4 DWR2_I_0_1_lut (.A(DWR2), .Z(DWR2_N_74)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(541[64:69])
    defparam DWR2_I_0_1_lut.init = 16'h5555;
    LUT4 i8662_2_lut (.A(DB_nOE_c_c), .B(RnW_c), .Z(DBIN_7__N_33)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i8662_2_lut.init = 16'h1111;
    FD1P3AX DBIN_i0_i1 (.D(DB_out_1), .SP(DBIN_7__N_33), .CK(Clk), .Q(DBIN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i1.GSR = "DISABLED";
    FD1P3AX DBIN_i0_i2 (.D(DB_out_2), .SP(DBIN_7__N_33), .CK(Clk), .Q(DBIN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i2.GSR = "DISABLED";
    FD1P3AX DBIN_i0_i3 (.D(DB_out_3), .SP(DBIN_7__N_33), .CK(Clk), .Q(DBIN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i3.GSR = "DISABLED";
    FD1P3AX DBIN_i0_i4 (.D(DB_out_4), .SP(DBIN_7__N_33), .CK(Clk), .Q(DBIN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i4.GSR = "DISABLED";
    FD1P3AX DBIN_i0_i5 (.D(DB_out_5), .SP(DBIN_7__N_33), .CK(Clk), .Q(DBIN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i5.GSR = "DISABLED";
    FD1P3AX DBIN_i0_i6 (.D(DB_out_6), .SP(DBIN_7__N_33), .CK(Clk), .Q(DBIN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i6.GSR = "DISABLED";
    FD1P3AX DBIN_i0_i7 (.D(DB_out_7), .SP(DBIN_7__N_33), .CK(Clk), .Q(DBIN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=167, LSE_RLINE=187 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam DBIN_i0_i7.GSR = "DISABLED";
    LUT4 i1_4_lut (.A(\VSET[2] ), .B(n38), .C(\VSET[0] ), .D(n10442), 
         .Z(Clk_enable_113)) /* synthesis lut_function=(!(A (B)+!A !((C (D))+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(70[6:11])
    defparam i1_4_lut.init = 16'h7333;
    LUT4 i8924_2_lut (.A(RESCL), .B(R2), .Z(n38)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam i8924_2_lut.init = 16'h1111;
    LUT4 i1_4_lut_adj_405 (.A(RESCL), .B(H_LINE23_N_478), .C(n6), .D(H_LINE5_N_453), 
         .Z(HC_N_237)) /* synthesis lut_function=(A (B (C+!(D)))+!A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(129[6:11])
    defparam i1_4_lut_adj_405.init = 16'hc4cc;
    LUT4 RnW_I_0_1_lut (.A(RnW_c), .Z(DB_DIR_c)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(146[18:22])
    defparam RnW_I_0_1_lut.init = 16'h5555;
    LUT4 i3_4_lut (.A(n5), .B(n76), .C(XRB_N_606), .D(\PD_R[6] ), .Z(\Do_7__N_163[6] )) /* synthesis lut_function=(A+(B+!(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(143[6:10])
    defparam i3_4_lut.init = 16'hefee;
    LUT4 i1_4_lut_adj_406 (.A(\R2DB[1] ), .B(n9899), .C(R2), .D(DBIN[6]), 
         .Z(n5)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(143[6:10])
    defparam i1_4_lut_adj_406.init = 16'heca0;
    LUT4 i4591_1_lut (.A(R2), .Z(Clk_enable_561)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(530[8] 552[26])
    defparam i4591_1_lut.init = 16'h5555;
    LUT4 i8930_3_lut (.A(RC), .B(nRES_c), .C(RESCL), .Z(n25)) /* synthesis lut_function=(!(A (B (C))+!A (B))) */ ;
    defparam i8930_3_lut.init = 16'h3b3b;
    LUT4 i7590_1_lut (.A(nRES_c), .Z(nRES_N_15)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(40[7:11])
    defparam i7590_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module CLK_DIV
//

module CLK_DIV (MCLK_c, SUB_1__N_16, SUBCLK_c, Clk2_N_24, DIV_2__N_10, 
            n9980, \DIV[1] , Clk_enable_153, Clk_enable_393, Clk_enable_535, 
            Clk_enable_157, Clk_enable_160, Clk_enable_162, Clk_enable_78, 
            n10442, Clk_enable_511, Clk_enable_563, Clk_enable_560, 
            HC, H_8__N_233, Clk_enable_150, SPR0_EV, SPR0HIT_LATCH, 
            R2DB6_N_1437, n4, Clk_enable_571, Clk_enable_173, Clk_enable_247, 
            nRES_c, Clk_enable_543, RESCL_IN, Vo_7__N_212, nVIS, n9889, 
            OAMCTR2, SPR_OV, n8, Clk_enable_467, \Hn[0] , n8933, 
            \OAM1ADR[7] , \CNT1[7] , n9983, n5081, \OSTEP[0] , OAM2STEP_N_1107, 
            OAM2STEP_N_1104, NFO_OUT, FTA_OUT, \Hnn[0] , PD_SR, ORES_LATCH, 
            ORES, n9864, \OAM1ADR[0] , \CNT1[0] , n5079, F_AT_LATCH, 
            PD_SEL, W3, PAR_O, CNT_7__N_1140, SPR0_EV1, n2282, S_EV, 
            SPR0_EV1_N_984, \Hnn[5] , n5118, Clk_enable_84, I_OAM2, 
            n5086) /* synthesis syn_module_defined=1 */ ;
    input MCLK_c;
    input SUB_1__N_16;
    output SUBCLK_c;
    input Clk2_N_24;
    input DIV_2__N_10;
    input n9980;
    output \DIV[1] ;
    output Clk_enable_153;
    output Clk_enable_393;
    output Clk_enable_535;
    output Clk_enable_157;
    output Clk_enable_160;
    output Clk_enable_162;
    output Clk_enable_78;
    output n10442;
    output Clk_enable_511;
    output Clk_enable_563;
    output Clk_enable_560;
    input HC;
    output H_8__N_233;
    output Clk_enable_150;
    input SPR0_EV;
    input SPR0HIT_LATCH;
    input R2DB6_N_1437;
    output n4;
    output Clk_enable_571;
    output Clk_enable_173;
    output Clk_enable_247;
    input nRES_c;
    output Clk_enable_543;
    input RESCL_IN;
    output Vo_7__N_212;
    input nVIS;
    output n9889;
    input OAMCTR2;
    input SPR_OV;
    output n8;
    output Clk_enable_467;
    input \Hn[0] ;
    output n8933;
    input \OAM1ADR[7] ;
    input \CNT1[7] ;
    input n9983;
    output n5081;
    input \OSTEP[0] ;
    input OAM2STEP_N_1107;
    output OAM2STEP_N_1104;
    input NFO_OUT;
    input FTA_OUT;
    input \Hnn[0] ;
    output PD_SR;
    input ORES_LATCH;
    output ORES;
    output n9864;
    input \OAM1ADR[0] ;
    input \CNT1[0] ;
    output n5079;
    input F_AT_LATCH;
    output PD_SEL;
    input W3;
    input PAR_O;
    output CNT_7__N_1140;
    input SPR0_EV1;
    output n2282;
    input S_EV;
    output SPR0_EV1_N_984;
    input \Hnn[5] ;
    output n5118;
    output Clk_enable_84;
    input I_OAM2;
    output n5086;
    
    wire MCLK_c /* synthesis is_clock=1, SET_AS_NETWORK=MCLK_c */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(36[7:11])
    wire Clk2_N_24 /* synthesis is_inv_clock=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(478[5:10])
    wire [1:0]SUB;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(480[10:13])
    wire [2:0]DIV;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(479[10:13])
    
    wire DIV_2__N_12, DIV2n;
    
    FD1S3AX SUB_i0 (.D(SUB_1__N_16), .CK(MCLK_c), .Q(SUB[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=157, LSE_RLINE=164 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(485[8] 490[28])
    defparam SUB_i0.GSR = "DISABLED";
    FD1S3AX DIV_i0 (.D(DIV_2__N_12), .CK(MCLK_c), .Q(DIV[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=157, LSE_RLINE=164 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(485[8] 490[28])
    defparam DIV_i0.GSR = "DISABLED";
    FD1S3AX SUBCLK_29 (.D(SUB[1]), .CK(MCLK_c), .Q(SUBCLK_c)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=157, LSE_RLINE=164 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(485[8] 490[28])
    defparam SUBCLK_29.GSR = "DISABLED";
    FD1S3AX DIV2n_30 (.D(DIV_2__N_10), .CK(Clk2_N_24), .Q(DIV2n)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=157, LSE_RLINE=164 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(491[8] 493[28])
    defparam DIV2n_30.GSR = "DISABLED";
    LUT4 i1_4_lut_rep_383 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_153)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam i1_4_lut_rep_383.init = 16'hfefa;
    LUT4 i1_4_lut_rep_334 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_393)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam i1_4_lut_rep_334.init = 16'hfefa;
    LUT4 PCLK_I_0_1_lut_rep_308_4_lut (.A(DIV[2]), .B(n9980), .C(DIV2n), 
         .D(\DIV[1] ), .Z(Clk_enable_535)) /* synthesis lut_function=(!(A+(B (C+(D))+!B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam PCLK_I_0_1_lut_rep_308_4_lut.init = 16'h0105;
    FD1S3AX DIV_i2 (.D(DIV_2__N_10), .CK(MCLK_c), .Q(DIV[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=157, LSE_RLINE=164 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(485[8] 490[28])
    defparam DIV_i2.GSR = "DISABLED";
    FD1S3AX DIV_i1 (.D(DIV[0]), .CK(MCLK_c), .Q(\DIV[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=157, LSE_RLINE=164 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(485[8] 490[28])
    defparam DIV_i1.GSR = "DISABLED";
    FD1S3AX SUB_i1 (.D(SUB[0]), .CK(MCLK_c), .Q(SUB[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=157, LSE_RLINE=164 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(485[8] 490[28])
    defparam SUB_i1.GSR = "DISABLED";
    LUT4 i1_4_lut_rep_384 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_157)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam i1_4_lut_rep_384.init = 16'hfefa;
    LUT4 i1_4_lut_rep_385 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_160)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam i1_4_lut_rep_385.init = 16'hfefa;
    LUT4 i1_4_lut_rep_386 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_162)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam i1_4_lut_rep_386.init = 16'hfefa;
    LUT4 i1_4_lut_rep_387 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_78)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam i1_4_lut_rep_387.init = 16'hfefa;
    LUT4 i1_4_lut_rep_388 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(n10442)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam i1_4_lut_rep_388.init = 16'hfefa;
    LUT4 i1_4_lut_rep_389 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_511)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam i1_4_lut_rep_389.init = 16'hfefa;
    LUT4 i1_4_lut_rep_390 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_563)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam i1_4_lut_rep_390.init = 16'hfefa;
    LUT4 i1_4_lut_rep_391 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_560)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam i1_4_lut_rep_391.init = 16'hfefa;
    LUT4 i1_2_lut (.A(n10442), .B(HC), .Z(H_8__N_233)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam i1_2_lut.init = 16'h2222;
    LUT4 i1_4_lut_rep_382 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_150)) /* synthesis lut_function=(A+(B (C+(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam i1_4_lut_rep_382.init = 16'hfefa;
    LUT4 i1_3_lut (.A(SPR0_EV), .B(SPR0HIT_LATCH), .C(R2DB6_N_1437), .Z(n4)) /* synthesis lut_function=(A+!(B (C))) */ ;
    defparam i1_3_lut.init = 16'hbfbf;
    LUT4 PCLK_I_0_1_lut_rep_393 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_571)) /* synthesis lut_function=(!(A+(B (C+(D))+!B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam PCLK_I_0_1_lut_rep_393.init = 16'h0105;
    LUT4 PCLK_I_0_1_lut_rep_394 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_173)) /* synthesis lut_function=(!(A+(B (C+(D))+!B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam PCLK_I_0_1_lut_rep_394.init = 16'h0105;
    LUT4 PCLK_I_0_1_lut_rep_395 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_247)) /* synthesis lut_function=(!(A+(B (C+(D))+!B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam PCLK_I_0_1_lut_rep_395.init = 16'h0105;
    LUT4 i8658_3_lut (.A(nRES_c), .B(DIV[2]), .C(\DIV[1] ), .Z(DIV_2__N_12)) /* synthesis lut_function=(!((B+(C))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(487[46:74])
    defparam i8658_3_lut.init = 16'h0202;
    LUT4 PCLK_I_0_1_lut_rep_396 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_543)) /* synthesis lut_function=(!(A+(B (C+(D))+!B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam PCLK_I_0_1_lut_rep_396.init = 16'h0105;
    LUT4 i2_3_lut (.A(HC), .B(n10442), .C(RESCL_IN), .Z(Vo_7__N_212)) /* synthesis lut_function=(!(A+!(B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam i2_3_lut.init = 16'h4040;
    LUT4 i1_2_lut_rep_284 (.A(n10442), .B(nVIS), .Z(n9889)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i1_2_lut_rep_284.init = 16'heeee;
    LUT4 i3_3_lut_4_lut (.A(n10442), .B(nVIS), .C(OAMCTR2), .D(SPR_OV), 
         .Z(n8)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i3_3_lut_4_lut.init = 16'hfffe;
    LUT4 PCLK_I_0_1_lut_rep_397 (.A(DIV[2]), .B(n9980), .C(DIV2n), .D(\DIV[1] ), 
         .Z(Clk_enable_467)) /* synthesis lut_function=(!(A+(B (C+(D))+!B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(482[18:51])
    defparam PCLK_I_0_1_lut_rep_397.init = 16'h0105;
    LUT4 i1_2_lut_2_lut (.A(n10442), .B(\Hn[0] ), .Z(n8933)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(483[16:52])
    defparam i1_2_lut_2_lut.init = 16'hdddd;
    LUT4 i4572_3_lut_4_lut_4_lut (.A(n10442), .B(\OAM1ADR[7] ), .C(\CNT1[7] ), 
         .D(n9983), .Z(n5081)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(483[16:52])
    defparam i4572_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i8802_3_lut_3_lut (.A(n10442), .B(\OSTEP[0] ), .C(OAM2STEP_N_1107), 
         .Z(OAM2STEP_N_1104)) /* synthesis lut_function=(!((B+!(C))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(483[16:52])
    defparam i8802_3_lut_3_lut.init = 16'h2020;
    LUT4 i1_3_lut_4_lut_4_lut (.A(n10442), .B(NFO_OUT), .C(FTA_OUT), .D(\Hnn[0] ), 
         .Z(PD_SR)) /* synthesis lut_function=(!(A+(B+(C+!(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(483[16:52])
    defparam i1_3_lut_4_lut_4_lut.init = 16'h0100;
    LUT4 ORES_I_0_1_lut_2_lut_2_lut (.A(n10442), .B(ORES_LATCH), .Z(ORES)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(483[16:52])
    defparam ORES_I_0_1_lut_2_lut_2_lut.init = 16'h2222;
    LUT4 nPCLK_I_0_2_lut_rep_259_2_lut (.A(n10442), .B(ORES_LATCH), .Z(n9864)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(483[16:52])
    defparam nPCLK_I_0_2_lut_rep_259_2_lut.init = 16'hdddd;
    LUT4 i4570_3_lut_4_lut_4_lut (.A(n10442), .B(\OAM1ADR[0] ), .C(\CNT1[0] ), 
         .D(n9983), .Z(n5079)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(483[16:52])
    defparam i4570_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 PD_SR_N_683_I_0_129_2_lut_3_lut_3_lut (.A(n10442), .B(F_AT_LATCH), 
         .C(\Hnn[0] ), .Z(PD_SEL)) /* synthesis lut_function=(!(A+!(B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(483[16:52])
    defparam PD_SR_N_683_I_0_129_2_lut_3_lut_3_lut.init = 16'h4040;
    LUT4 CNT_7__I_311_2_lut_3_lut_4_lut_4_lut (.A(n10442), .B(W3), .C(PAR_O), 
         .D(n9983), .Z(CNT_7__N_1140)) /* synthesis lut_function=(A (B+(C+!(D)))+!A (B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(483[16:52])
    defparam CNT_7__I_311_2_lut_3_lut_4_lut_4_lut.init = 16'hfcfe;
    LUT4 i1826_4_lut_4_lut (.A(n10442), .B(PAR_O), .C(SPR0_EV1), .D(SPR0_EV), 
         .Z(n2282)) /* synthesis lut_function=(A (D)+!A !(B (C)+!B !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(483[16:52])
    defparam i1826_4_lut_4_lut.init = 16'hbf04;
    LUT4 S_EV_I_0_2_lut_2_lut (.A(n10442), .B(S_EV), .Z(SPR0_EV1_N_984)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(483[16:52])
    defparam S_EV_I_0_2_lut_2_lut.init = 16'h4444;
    LUT4 i4609_2_lut_2_lut (.A(n10442), .B(\Hnn[5] ), .Z(n5118)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(483[16:52])
    defparam i4609_2_lut_2_lut.init = 16'h4444;
    LUT4 nPCLK_I_0_130_2_lut_rep_242_2_lut (.A(n10442), .B(\Hnn[0] ), .Z(Clk_enable_84)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(483[16:52])
    defparam nPCLK_I_0_130_2_lut_rep_242_2_lut.init = 16'h4444;
    LUT4 i4583_2_lut_2_lut (.A(n10442), .B(I_OAM2), .Z(n5086)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(483[16:52])
    defparam i4583_2_lut_2_lut.init = 16'h4444;
    
endmodule
//
// Verilog Description of module PALETTE_SWITCH
//

module PALETTE_SWITCH (PALSEL, \V_DIV[0] , P_BUTTON_N_7, P_BUTTON_c, 
            Clk, n12, Clk_enable_528) /* synthesis syn_module_defined=1 */ ;
    output [2:0]PALSEL;
    output \V_DIV[0] ;
    input P_BUTTON_N_7;
    input P_BUTTON_c;
    input Clk;
    input n12;
    input Clk_enable_528;
    
    wire TICK /* synthesis SET_AS_NETWORK=\PALSEL_2__I_0/TICK, is_clock=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1705[6:10])
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire PALSEL_2__N_1552;
    wire [2:0]n17;
    wire [5:0]V_DIV;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1703[10:15])
    
    wire n9985;
    wire [5:0]V_DIV_5__N_1543;
    
    wire FDET, n10, n9943;
    
    FD1P3AX PALSEL_670__i0 (.D(n17[0]), .SP(PALSEL_2__N_1552), .CK(TICK), 
            .Q(PALSEL[0]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1713[56:69])
    defparam PALSEL_670__i0.GSR = "DISABLED";
    LUT4 i1694_2_lut_3_lut_4_lut (.A(V_DIV[2]), .B(n9985), .C(V_DIV[4]), 
         .D(V_DIV[3]), .Z(V_DIV_5__N_1543[4])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam i1694_2_lut_3_lut_4_lut.init = 16'h78f0;
    LUT4 i1673_2_lut (.A(V_DIV[1]), .B(\V_DIV[0] ), .Z(V_DIV_5__N_1543[1])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam i1673_2_lut.init = 16'h6666;
    FD1S3AX FDET_14 (.D(P_BUTTON_N_7), .CK(TICK), .Q(FDET)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=16, LSE_RCOL=2, LSE_LLINE=455, LSE_RLINE=459 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1711[8] 1714[27])
    defparam FDET_14.GSR = "DISABLED";
    LUT4 i5_3_lut (.A(V_DIV[3]), .B(n10), .C(V_DIV[4]), .Z(TICK)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1706[15:22])
    defparam i5_3_lut.init = 16'h8080;
    LUT4 i4_4_lut (.A(V_DIV[2]), .B(V_DIV[5]), .C(\V_DIV[0] ), .D(V_DIV[1]), 
         .Z(n10)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1706[15:22])
    defparam i4_4_lut.init = 16'h8000;
    LUT4 PALSEL_2__I_379_2_lut (.A(P_BUTTON_c), .B(FDET), .Z(PALSEL_2__N_1552)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1713[28:44])
    defparam PALSEL_2__I_379_2_lut.init = 16'h8888;
    LUT4 i7702_1_lut (.A(PALSEL[0]), .Z(n17[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1713[56:69])
    defparam i7702_1_lut.init = 16'h5555;
    FD1P3AX PALSEL_670__i2 (.D(n17[2]), .SP(PALSEL_2__N_1552), .CK(TICK), 
            .Q(PALSEL[2]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1713[56:69])
    defparam PALSEL_670__i2.GSR = "DISABLED";
    FD1P3AX PALSEL_670__i1 (.D(n17[1]), .SP(PALSEL_2__N_1552), .CK(TICK), 
            .Q(PALSEL[1]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1713[56:69])
    defparam PALSEL_670__i1.GSR = "DISABLED";
    LUT4 i1675_2_lut_rep_380 (.A(V_DIV[1]), .B(\V_DIV[0] ), .Z(n9985)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam i1675_2_lut_rep_380.init = 16'h8888;
    LUT4 i1680_2_lut_3_lut (.A(V_DIV[1]), .B(\V_DIV[0] ), .C(V_DIV[2]), 
         .Z(V_DIV_5__N_1543[2])) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam i1680_2_lut_3_lut.init = 16'h7878;
    FD1S3AX V_DIV_i0_i0 (.D(n12), .CK(Clk), .Q(\V_DIV[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1707[8] 1709[28])
    defparam V_DIV_i0_i0.GSR = "DISABLED";
    LUT4 i1682_2_lut_rep_338_3_lut (.A(V_DIV[1]), .B(\V_DIV[0] ), .C(V_DIV[2]), 
         .Z(n9943)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam i1682_2_lut_rep_338_3_lut.init = 16'h8080;
    LUT4 i1687_2_lut_3_lut_4_lut (.A(V_DIV[1]), .B(\V_DIV[0] ), .C(V_DIV[3]), 
         .D(V_DIV[2]), .Z(V_DIV_5__N_1543[3])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam i1687_2_lut_3_lut_4_lut.init = 16'h78f0;
    LUT4 i7711_3_lut (.A(PALSEL[2]), .B(PALSEL[1]), .C(PALSEL[0]), .Z(n17[2])) /* synthesis lut_function=(!(A (B (C))+!A !(B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1713[56:69])
    defparam i7711_3_lut.init = 16'h6a6a;
    LUT4 i7704_2_lut (.A(PALSEL[1]), .B(PALSEL[0]), .Z(n17[1])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1713[56:69])
    defparam i7704_2_lut.init = 16'h6666;
    LUT4 i1701_3_lut_4_lut (.A(V_DIV[3]), .B(n9943), .C(V_DIV[4]), .D(V_DIV[5]), 
         .Z(V_DIV_5__N_1543[5])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1708[34:46])
    defparam i1701_3_lut_4_lut.init = 16'h7f80;
    FD1P3AX V_DIV_i0_i1 (.D(V_DIV_5__N_1543[1]), .SP(Clk_enable_528), .CK(Clk), 
            .Q(V_DIV[1]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1707[8] 1709[28])
    defparam V_DIV_i0_i1.GSR = "DISABLED";
    FD1P3AX V_DIV_i0_i2 (.D(V_DIV_5__N_1543[2]), .SP(Clk_enable_528), .CK(Clk), 
            .Q(V_DIV[2]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1707[8] 1709[28])
    defparam V_DIV_i0_i2.GSR = "DISABLED";
    FD1P3AX V_DIV_i0_i3 (.D(V_DIV_5__N_1543[3]), .SP(Clk_enable_528), .CK(Clk), 
            .Q(V_DIV[3]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1707[8] 1709[28])
    defparam V_DIV_i0_i3.GSR = "DISABLED";
    FD1P3AX V_DIV_i0_i4 (.D(V_DIV_5__N_1543[4]), .SP(Clk_enable_528), .CK(Clk), 
            .Q(V_DIV[4]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1707[8] 1709[28])
    defparam V_DIV_i0_i4.GSR = "DISABLED";
    FD1P3AX V_DIV_i0_i5 (.D(V_DIV_5__N_1543[5]), .SP(Clk_enable_528), .CK(Clk), 
            .Q(V_DIV[5]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1707[8] 1709[28])
    defparam V_DIV_i0_i5.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module PLL
//

module PLL (MCLK_c, Clk, GND_net) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input MCLK_c;
    output Clk;
    input GND_net;
    
    wire MCLK_c /* synthesis is_clock=1, SET_AS_NETWORK=MCLK_c */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(36[7:11])
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    EHXPLLJ PLLInst_0 (.CLKI(MCLK_c), .CLKFB(Clk), .PHASESEL0(GND_net), 
            .PHASESEL1(GND_net), .PHASEDIR(GND_net), .PHASESTEP(GND_net), 
            .LOADREG(GND_net), .STDBY(GND_net), .PLLWAKESYNC(GND_net), 
            .RST(GND_net), .RESETC(GND_net), .RESETD(GND_net), .RESETM(GND_net), 
            .ENCLKOP(GND_net), .ENCLKOS(GND_net), .ENCLKOS2(GND_net), 
            .ENCLKOS3(GND_net), .PLLCLK(GND_net), .PLLRST(GND_net), .PLLSTB(GND_net), 
            .PLLWE(GND_net), .PLLDATI0(GND_net), .PLLDATI1(GND_net), .PLLDATI2(GND_net), 
            .PLLDATI3(GND_net), .PLLDATI4(GND_net), .PLLDATI5(GND_net), 
            .PLLDATI6(GND_net), .PLLDATI7(GND_net), .PLLADDR0(GND_net), 
            .PLLADDR1(GND_net), .PLLADDR2(GND_net), .PLLADDR3(GND_net), 
            .PLLADDR4(GND_net), .CLKOP(Clk)) /* synthesis FREQUENCY_PIN_CLKOP="42.954540", FREQUENCY_PIN_CLKI="21.477270", ICP_CURRENT="7", LPF_RESISTOR="8", syn_instantiated=1, LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=152, LSE_RLINE=155 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(152[5] 155[2])
    defparam PLLInst_0.CLKI_DIV = 1;
    defparam PLLInst_0.CLKFB_DIV = 2;
    defparam PLLInst_0.CLKOP_DIV = 11;
    defparam PLLInst_0.CLKOS_DIV = 1;
    defparam PLLInst_0.CLKOS2_DIV = 1;
    defparam PLLInst_0.CLKOS3_DIV = 1;
    defparam PLLInst_0.CLKOP_ENABLE = "ENABLED";
    defparam PLLInst_0.CLKOS_ENABLE = "DISABLED";
    defparam PLLInst_0.CLKOS2_ENABLE = "DISABLED";
    defparam PLLInst_0.CLKOS3_ENABLE = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_A0 = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_B0 = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_C0 = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_D0 = "DISABLED";
    defparam PLLInst_0.CLKOP_CPHASE = 10;
    defparam PLLInst_0.CLKOS_CPHASE = 0;
    defparam PLLInst_0.CLKOS2_CPHASE = 0;
    defparam PLLInst_0.CLKOS3_CPHASE = 0;
    defparam PLLInst_0.CLKOP_FPHASE = 0;
    defparam PLLInst_0.CLKOS_FPHASE = 0;
    defparam PLLInst_0.CLKOS2_FPHASE = 0;
    defparam PLLInst_0.CLKOS3_FPHASE = 0;
    defparam PLLInst_0.FEEDBK_PATH = "CLKOP";
    defparam PLLInst_0.FRACN_ENABLE = "DISABLED";
    defparam PLLInst_0.FRACN_DIV = 0;
    defparam PLLInst_0.CLKOP_TRIM_POL = "RISING";
    defparam PLLInst_0.CLKOP_TRIM_DELAY = 0;
    defparam PLLInst_0.CLKOS_TRIM_POL = "FALLING";
    defparam PLLInst_0.CLKOS_TRIM_DELAY = 0;
    defparam PLLInst_0.PLL_USE_WB = "DISABLED";
    defparam PLLInst_0.PREDIVIDER_MUXA1 = 0;
    defparam PLLInst_0.PREDIVIDER_MUXB1 = 0;
    defparam PLLInst_0.PREDIVIDER_MUXC1 = 0;
    defparam PLLInst_0.PREDIVIDER_MUXD1 = 0;
    defparam PLLInst_0.OUTDIVIDER_MUXA2 = "DIVA";
    defparam PLLInst_0.OUTDIVIDER_MUXB2 = "DIVB";
    defparam PLLInst_0.OUTDIVIDER_MUXC2 = "DIVC";
    defparam PLLInst_0.OUTDIVIDER_MUXD2 = "DIVD";
    defparam PLLInst_0.PLL_LOCK_MODE = 0;
    defparam PLLInst_0.STDBY_ENABLE = "DISABLED";
    defparam PLLInst_0.DPHASE_SOURCE = "DISABLED";
    defparam PLLInst_0.PLLRST_ENA = "DISABLED";
    defparam PLLInst_0.MRST_ENA = "DISABLED";
    defparam PLLInst_0.DCRST_ENA = "DISABLED";
    defparam PLLInst_0.DDRST_ENA = "DISABLED";
    defparam PLLInst_0.INTFB_WAKE = "DISABLED";
    
endmodule
//
// Verilog Description of module REG2000_2001
//

module REG2000_2001 (Clk, W0, DBIN, EMP_G, EMP_R, n9980, \ri[7] , 
            n6646, Clk_enable_571, CLIP_B_N_247, O8_16, I1_32, BGCLIP, 
            OBSEL, Clk_enable_173, nVIS, BGSEL, CLIP_OUT, \EMPH[2] , 
            n989, RC, CLIPOR, Clk_enable_543, nCLPB_N_130, n9984, 
            BLNK_FF, n9942, N_HB, SC_CNT, n9752, n9754, \H[8] , 
            n9897, \Hn[2] , n9892, \FVO[1] , NBFVO1, n10442, OB2_7__N_1043, 
            n9911, W1, B_W, VBL_EN) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input W0;
    input [7:0]DBIN;
    output EMP_G;
    output EMP_R;
    input n9980;
    input \ri[7] ;
    output n6646;
    input Clk_enable_571;
    input CLIP_B_N_247;
    output O8_16;
    output I1_32;
    output BGCLIP;
    output OBSEL;
    input Clk_enable_173;
    input nVIS;
    output BGSEL;
    input CLIP_OUT;
    output \EMPH[2] ;
    output n989;
    input RC;
    output CLIPOR;
    input Clk_enable_543;
    output nCLPB_N_130;
    output n9984;
    input BLNK_FF;
    output n9942;
    input N_HB;
    output SC_CNT;
    input n9752;
    output n9754;
    input \H[8] ;
    output n9897;
    input \Hn[2] ;
    output n9892;
    input \FVO[1] ;
    output NBFVO1;
    input n10442;
    output OB2_7__N_1043;
    output n9911;
    input W1;
    output B_W;
    output VBL_EN;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [4:0]W0R;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(585[10:13])
    
    wire n9966, CLIPBR, W0_N_121, W1_N_127;
    wire [7:0]W1R;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(586[10:13])
    
    wire OBCLIP, BGE, OBE, nVISR, CLIPOR_N_138;
    wire [4:0]n17;
    
    wire n1928;
    
    FD1P3IX W0R__i0 (.D(DBIN[2]), .SP(W0), .CD(n9966), .CK(Clk), .Q(W0R[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W0R__i0.GSR = "DISABLED";
    LUT4 i8954_2_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(n9980), .D(\ri[7] ), 
         .Z(n6646)) /* synthesis lut_function=(!(A (B (D)+!B (C (D)))+!A !((C+!(D))+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(599[15:37])
    defparam i8954_2_lut_4_lut.init = 16'h53ff;
    FD1P3AX CLIPBR_64 (.D(CLIP_B_N_247), .SP(Clk_enable_571), .CK(Clk), 
            .Q(CLIPBR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam CLIPBR_64.GSR = "DISABLED";
    FD1P3IX W0R__i1 (.D(DBIN[3]), .SP(W0), .CD(n9966), .CK(Clk), .Q(W0R[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W0R__i1.GSR = "DISABLED";
    FD1P3AX O8_16_56 (.D(W0R[3]), .SP(W0_N_121), .CK(Clk), .Q(O8_16));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam O8_16_56.GSR = "DISABLED";
    FD1P3AX I1_32_53 (.D(W0R[0]), .SP(W0_N_121), .CK(Clk), .Q(I1_32));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam I1_32_53.GSR = "DISABLED";
    FD1P3AX BGCLIP_57 (.D(W1R[1]), .SP(W1_N_127), .CK(Clk), .Q(BGCLIP));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam BGCLIP_57.GSR = "DISABLED";
    FD1P3AX OBCLIP_58 (.D(W1R[2]), .SP(W1_N_127), .CK(Clk), .Q(OBCLIP));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam OBCLIP_58.GSR = "DISABLED";
    FD1P3AX BGE_59 (.D(W1R[3]), .SP(W1_N_127), .CK(Clk), .Q(BGE));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam BGE_59.GSR = "DISABLED";
    FD1P3AX OBSEL_54 (.D(W0R[1]), .SP(W0_N_121), .CK(Clk), .Q(OBSEL));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam OBSEL_54.GSR = "DISABLED";
    FD1P3AX OBE_60 (.D(W1R[4]), .SP(W1_N_127), .CK(Clk), .Q(OBE));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam OBE_60.GSR = "DISABLED";
    FD1P3AX EMP_R_61 (.D(W1R[5]), .SP(W1_N_127), .CK(Clk), .Q(EMP_R));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam EMP_R_61.GSR = "DISABLED";
    FD1P3AX EMP_G_62 (.D(W1R[6]), .SP(W1_N_127), .CK(Clk), .Q(EMP_G));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam EMP_G_62.GSR = "DISABLED";
    FD1P3AX nVISR_63 (.D(nVIS), .SP(Clk_enable_173), .CK(Clk), .Q(nVISR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam nVISR_63.GSR = "DISABLED";
    FD1P3AX BGSEL_55 (.D(W0R[2]), .SP(W0_N_121), .CK(Clk), .Q(BGSEL));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam BGSEL_55.GSR = "DISABLED";
    LUT4 i8667_4_lut (.A(nVISR), .B(CLIP_OUT), .C(OBE), .D(OBCLIP), 
         .Z(CLIPOR_N_138)) /* synthesis lut_function=(!(A+!(B (C)+!B (C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(612[20:46])
    defparam i8667_4_lut.init = 16'h5040;
    LUT4 i506_3_lut (.A(\EMPH[2] ), .B(EMP_R), .C(EMP_G), .Z(n989)) /* synthesis lut_function=(!((B (C)+!B !(C))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam i506_3_lut.init = 16'h2828;
    LUT4 i1494_2_lut_rep_361 (.A(W0), .B(RC), .Z(n9966)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam i1494_2_lut_rep_361.init = 16'h8888;
    LUT4 i6026_2_lut_3_lut (.A(W0), .B(RC), .C(DBIN[7]), .Z(n17[4])) /* synthesis lut_function=(!(A (B+!(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam i6026_2_lut_3_lut.init = 16'h7070;
    LUT4 i6024_2_lut_3_lut (.A(W0), .B(RC), .C(DBIN[4]), .Z(n17[2])) /* synthesis lut_function=(!(A (B+!(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam i6024_2_lut_3_lut.init = 16'h7070;
    LUT4 i6025_2_lut_3_lut (.A(W0), .B(RC), .C(DBIN[5]), .Z(n17[3])) /* synthesis lut_function=(!(A (B+!(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam i6025_2_lut_3_lut.init = 16'h7070;
    FD1P3AX CLIPOR_65 (.D(CLIPOR_N_138), .SP(Clk_enable_543), .CK(Clk), 
            .Q(CLIPOR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam CLIPOR_65.GSR = "DISABLED";
    LUT4 i8665_3_lut (.A(nVISR), .B(BGE), .C(CLIPBR), .Z(nCLPB_N_130)) /* synthesis lut_function=(!(A+((C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(595[16:42])
    defparam i8665_3_lut.init = 16'h0404;
    LUT4 BGE_I_0_66_2_lut_rep_379 (.A(BGE), .B(OBE), .Z(n9984)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(592[17:30])
    defparam BGE_I_0_66_2_lut_rep_379.init = 16'heeee;
    LUT4 BLACK_I_0_2_lut_rep_337_3_lut (.A(BGE), .B(OBE), .C(BLNK_FF), 
         .Z(n9942)) /* synthesis lut_function=(A (C)+!A ((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(592[17:30])
    defparam BLACK_I_0_2_lut_rep_337_3_lut.init = 16'hf1f1;
    LUT4 i5884_2_lut_3_lut (.A(BGE), .B(OBE), .C(N_HB), .Z(SC_CNT)) /* synthesis lut_function=(A (C)+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(592[17:30])
    defparam i5884_2_lut_3_lut.init = 16'he0e0;
    LUT4 n237_bdd_2_lut_3_lut_4_lut (.A(BGE), .B(OBE), .C(n9752), .D(BLNK_FF), 
         .Z(n9754)) /* synthesis lut_function=(A (C+!(D))+!A (B (C+!(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(592[17:30])
    defparam n237_bdd_2_lut_3_lut_4_lut.init = 16'hf0fe;
    LUT4 i8746_2_lut_rep_292_3_lut_4_lut (.A(BGE), .B(OBE), .C(\H[8] ), 
         .D(BLNK_FF), .Z(n9897)) /* synthesis lut_function=(!(A (C+(D))+!A ((C+(D))+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(592[17:30])
    defparam i8746_2_lut_rep_292_3_lut_4_lut.init = 16'h000e;
    LUT4 Hn2_I_0_2_lut_rep_287_3_lut_4_lut (.A(BGE), .B(OBE), .C(\Hn[2] ), 
         .D(BLNK_FF), .Z(n9892)) /* synthesis lut_function=(!(A ((D)+!C)+!A (((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(592[17:30])
    defparam Hn2_I_0_2_lut_rep_287_3_lut_4_lut.init = 16'h00e0;
    LUT4 BLNK_N_932_I_0_2_lut_3_lut_4_lut (.A(BGE), .B(OBE), .C(\FVO[1] ), 
         .D(BLNK_FF), .Z(NBFVO1)) /* synthesis lut_function=(A (C+!(D))+!A (B (C+!(D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(592[17:30])
    defparam BLNK_N_932_I_0_2_lut_3_lut_4_lut.init = 16'hf0fe;
    LUT4 i8810_2_lut_2_lut_3_lut_4_lut (.A(BGE), .B(OBE), .C(n10442), 
         .D(BLNK_FF), .Z(OB2_7__N_1043)) /* synthesis lut_function=(!(A ((D)+!C)+!A (((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(592[17:30])
    defparam i8810_2_lut_2_lut_3_lut_4_lut.init = 16'h00e0;
    LUT4 I1_32_I_0_2_lut_rep_306_3_lut_4_lut (.A(BGE), .B(OBE), .C(I1_32), 
         .D(BLNK_FF), .Z(n9911)) /* synthesis lut_function=(A (C (D))+!A (B (C (D))+!B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(592[17:30])
    defparam I1_32_I_0_2_lut_rep_306_3_lut_4_lut.init = 16'hf010;
    LUT4 W0_I_0_1_lut (.A(W0), .Z(W0_N_121)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(607[14:17])
    defparam W0_I_0_1_lut.init = 16'h5555;
    LUT4 W1_I_0_1_lut (.A(W1), .Z(W1_N_127)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(608[14:17])
    defparam W1_I_0_1_lut.init = 16'h5555;
    LUT4 i1492_2_lut (.A(W1), .B(RC), .Z(n1928)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam i1492_2_lut.init = 16'h8888;
    FD1P3IX W1R__i7 (.D(DBIN[7]), .SP(W1), .CD(n1928), .CK(Clk), .Q(\EMPH[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i7.GSR = "DISABLED";
    FD1P3IX W1R__i6 (.D(DBIN[6]), .SP(W1), .CD(n1928), .CK(Clk), .Q(W1R[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i6.GSR = "DISABLED";
    FD1P3IX W1R__i5 (.D(DBIN[5]), .SP(W1), .CD(n1928), .CK(Clk), .Q(W1R[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i5.GSR = "DISABLED";
    FD1P3IX W1R__i4 (.D(DBIN[4]), .SP(W1), .CD(n1928), .CK(Clk), .Q(W1R[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i4.GSR = "DISABLED";
    FD1P3IX W1R__i3 (.D(DBIN[3]), .SP(W1), .CD(n1928), .CK(Clk), .Q(W1R[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i3.GSR = "DISABLED";
    FD1P3IX W1R__i2 (.D(DBIN[2]), .SP(W1), .CD(n1928), .CK(Clk), .Q(W1R[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i2.GSR = "DISABLED";
    FD1P3IX W1R__i1 (.D(DBIN[1]), .SP(W1), .CD(n1928), .CK(Clk), .Q(W1R[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i1.GSR = "DISABLED";
    FD1P3IX W1R__i0 (.D(DBIN[0]), .SP(W1), .CD(n1928), .CK(Clk), .Q(B_W)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W1R__i0.GSR = "DISABLED";
    FD1P3AX W0R__i2 (.D(n17[2]), .SP(W0), .CK(Clk), .Q(W0R[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W0R__i2.GSR = "DISABLED";
    FD1P3AX W0R__i3 (.D(n17[3]), .SP(W0), .CK(Clk), .Q(W0R[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W0R__i3.GSR = "DISABLED";
    FD1P3AX W0R__i4 (.D(n17[4]), .SP(W0), .CK(Clk), .Q(VBL_EN)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=190, LSE_RLINE=213 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(604[8] 614[26])
    defparam W0R__i4.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module BG_COLOR
//

module BG_COLOR (THO1R, Clk, Clk_enable_393, \THO[1] , Clk_enable_563, 
            Clk_enable_267, ATSEL, Clk_enable_571, PD_SR, PD_out_0, 
            \Hnn[0] , n9944, n9941, n10442, THSTEP_N_923, Clk_enable_84, 
            n9938, PD_out_7, PD_out_6, PD_out_5, PD_out_4, PD_out_3, 
            CLPB_LATCH, Clk_enable_560, nCLPB_N_130, PD_out_2, PD_out_1, 
            Clk_enable_543, Clk_enable_511, F_AT_LATCH, n9925, BGC2, 
            PDAT, PD_SEL, RC, \DBIN[0] , W5_1, \DBIN[1] , \DBIN[2] , 
            NFO_OUT, n9838) /* synthesis syn_module_defined=1 */ ;
    output THO1R;
    input Clk;
    input Clk_enable_393;
    input \THO[1] ;
    input Clk_enable_563;
    input Clk_enable_267;
    input [1:0]ATSEL;
    input Clk_enable_571;
    input PD_SR;
    input PD_out_0;
    input \Hnn[0] ;
    input n9944;
    input n9941;
    input n10442;
    output THSTEP_N_923;
    input Clk_enable_84;
    input n9938;
    input PD_out_7;
    input PD_out_6;
    input PD_out_5;
    input PD_out_4;
    input PD_out_3;
    output CLPB_LATCH;
    input Clk_enable_560;
    input nCLPB_N_130;
    input PD_out_2;
    input PD_out_1;
    input Clk_enable_543;
    input Clk_enable_511;
    output F_AT_LATCH;
    input n9925;
    output [3:0]BGC2;
    output [7:0]PDAT;
    input PD_SEL;
    input RC;
    input \DBIN[0] ;
    input W5_1;
    input \DBIN[1] ;
    input \DBIN[2] ;
    input NFO_OUT;
    input n9838;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]SR2;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(974[20:23])
    wire [2:0]FH;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(953[10:12])
    
    wire n10222, n10223;
    wire [1:0]ATR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(959[10:13])
    wire [1:0]ATRO;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(960[10:14])
    wire [7:0]SR0;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(974[10:13])
    
    wire n10402, n10403;
    wire [3:0]BGC1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(951[10:14])
    wire [3:0]BGC_POS;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(982[11:18])
    wire [7:0]PDTA;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(958[10:14])
    wire [7:0]SR3;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(974[25:28])
    
    wire n10406, n10407, n10409, n10410, n5057, n5058, n5055, 
        n5056, n5059, n5060, n10245, n10242, n10244, n10243, n10241, 
        n10240, n10227, n10224, n10226, n10225, Clk_enable_391;
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    wire [7:0]QP;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n5053, n5051, n5049, n5047;
    wire [7:0]QS_IN_adj_1609;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    wire [7:0]QP_adj_1610;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1475[17:19])
    
    wire n5045, n5043, n5041, n5039, n5037, n5035, n5033, Clk_enable_296, 
        n5048, n5054, n10400, n10399;
    wire [7:0]SR1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(974[15:18])
    
    wire n5034, n5036, n5038, n5040, n5042, n5044, n5046, n5050, 
        n5052, n10411, n10408, n10404, n10401;
    
    FD1P3AX THO1R_113 (.D(\THO[1] ), .SP(Clk_enable_393), .CK(Clk), .Q(THO1R));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam THO1R_113.GSR = "DISABLED";
    LUT4 SR2_1__bdd_3_lut_9184 (.A(SR2[0]), .B(FH[1]), .C(SR2[2]), .Z(n10222)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR2_1__bdd_3_lut_9184.init = 16'hb8b8;
    LUT4 SR2_1__bdd_3_lut_9235 (.A(SR2[1]), .B(FH[1]), .C(SR2[3]), .Z(n10223)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR2_1__bdd_3_lut_9235.init = 16'hb8b8;
    FD1P3AX ATR_i0_i0 (.D(ATRO[0]), .SP(Clk_enable_563), .CK(Clk), .Q(ATR[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam ATR_i0_i0.GSR = "DISABLED";
    LUT4 SR0_5__bdd_3_lut_9281 (.A(SR0[4]), .B(FH[1]), .C(SR0[6]), .Z(n10402)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR0_5__bdd_3_lut_9281.init = 16'hb8b8;
    LUT4 SR0_5__bdd_3_lut_9300 (.A(SR0[5]), .B(FH[1]), .C(SR0[7]), .Z(n10403)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR0_5__bdd_3_lut_9300.init = 16'hb8b8;
    FD1P3AX ATRO_i0_i0 (.D(ATSEL[0]), .SP(Clk_enable_267), .CK(Clk), .Q(ATRO[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam ATRO_i0_i0.GSR = "DISABLED";
    FD1P3AX BGC1_i0_i0 (.D(BGC_POS[0]), .SP(Clk_enable_571), .CK(Clk), 
            .Q(BGC1[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC1_i0_i0.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i0 (.D(PD_out_0), .SP(PD_SR), .CK(Clk), .Q(PDTA[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i0.GSR = "DISABLED";
    LUT4 SR3_1__bdd_3_lut_9286 (.A(SR3[0]), .B(FH[1]), .C(SR3[2]), .Z(n10406)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR3_1__bdd_3_lut_9286.init = 16'hb8b8;
    LUT4 SR3_1__bdd_3_lut (.A(SR3[1]), .B(FH[1]), .C(SR3[3]), .Z(n10407)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR3_1__bdd_3_lut.init = 16'hb8b8;
    LUT4 SR3_5__bdd_3_lut_9289 (.A(SR3[4]), .B(FH[1]), .C(SR3[6]), .Z(n10409)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR3_5__bdd_3_lut_9289.init = 16'hb8b8;
    LUT4 SR3_5__bdd_3_lut (.A(SR3[5]), .B(FH[1]), .C(SR3[7]), .Z(n10410)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR3_5__bdd_3_lut.init = 16'hb8b8;
    LUT4 THSTEP_I_260_3_lut_4_lut (.A(\Hnn[0] ), .B(n9944), .C(n9941), 
         .D(n10442), .Z(THSTEP_N_923)) /* synthesis lut_function=(A (B ((D)+!C)+!B (D))+!A ((D)+!C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(966[33:48])
    defparam THSTEP_I_260_3_lut_4_lut.init = 16'hff0d;
    LUT4 i4549_3_lut_4_lut (.A(Clk_enable_84), .B(n9944), .C(PDTA[2]), 
         .D(n5057), .Z(n5058)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(965[17:36])
    defparam i4549_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4547_3_lut_4_lut (.A(Clk_enable_84), .B(n9944), .C(PDTA[3]), 
         .D(n5055), .Z(n5056)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(965[17:36])
    defparam i4547_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4551_3_lut_4_lut (.A(Clk_enable_84), .B(n9944), .C(PDTA[1]), 
         .D(n5059), .Z(n5060)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(965[17:36])
    defparam i4551_3_lut_4_lut.init = 16'hfd20;
    L6MUX21 i9200 (.D0(n10245), .D1(n10242), .SD(FH[2]), .Z(BGC_POS[1]));
    PFUMX i9198 (.BLUT(n10244), .ALUT(n10243), .C0(FH[0]), .Z(n10245));
    PFUMX i9195 (.BLUT(n10241), .ALUT(n10240), .C0(FH[0]), .Z(n10242));
    L6MUX21 i9190 (.D0(n10227), .D1(n10224), .SD(FH[2]), .Z(BGC_POS[2]));
    PFUMX i9188 (.BLUT(n10226), .ALUT(n10225), .C0(FH[0]), .Z(n10227));
    LUT4 i4550_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN[1]), .C(QP[0]), 
         .D(n9938), .Z(n5059)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4550_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4548_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN[2]), .C(QP[1]), 
         .D(n9938), .Z(n5057)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4548_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4546_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN[3]), .C(QP[2]), 
         .D(n9938), .Z(n5055)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4546_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4544_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN[4]), .C(QP[3]), 
         .D(n9938), .Z(n5053)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4544_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4542_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN[5]), .C(QP[4]), 
         .D(n9938), .Z(n5051)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4542_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4540_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN[6]), .C(QP[5]), 
         .D(n9938), .Z(n5049)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4540_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4538_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN[7]), .C(QP[6]), 
         .D(n9938), .Z(n5047)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4538_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4536_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN_adj_1609[1]), 
         .C(QP_adj_1610[0]), .D(n9938), .Z(n5045)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4536_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4534_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN_adj_1609[2]), 
         .C(QP_adj_1610[1]), .D(n9938), .Z(n5043)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4534_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4532_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN_adj_1609[3]), 
         .C(QP_adj_1610[2]), .D(n9938), .Z(n5041)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4532_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4530_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN_adj_1609[4]), 
         .C(QP_adj_1610[3]), .D(n9938), .Z(n5039)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4530_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4528_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN_adj_1609[5]), 
         .C(QP_adj_1610[4]), .D(n9938), .Z(n5037)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4528_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4526_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN_adj_1609[6]), 
         .C(QP_adj_1610[5]), .D(n9938), .Z(n5035)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4526_3_lut_4_lut_4_lut.init = 16'hcce4;
    LUT4 i4524_3_lut_4_lut_4_lut (.A(Clk_enable_391), .B(QS_IN_adj_1609[7]), 
         .C(QP_adj_1610[6]), .D(n9938), .Z(n5033)) /* synthesis lut_function=(A (B (C+(D))+!B !((D)+!C))+!A (B)) */ ;
    defparam i4524_3_lut_4_lut_4_lut.init = 16'hcce4;
    FD1P3AX PDTA_i0_i7 (.D(PD_out_7), .SP(PD_SR), .CK(Clk), .Q(PDTA[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i7.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i6 (.D(PD_out_6), .SP(PD_SR), .CK(Clk), .Q(PDTA[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i6.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i5 (.D(PD_out_5), .SP(PD_SR), .CK(Clk), .Q(PDTA[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i5.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i4 (.D(PD_out_4), .SP(PD_SR), .CK(Clk), .Q(PDTA[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i4.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i3 (.D(PD_out_3), .SP(PD_SR), .CK(Clk), .Q(PDTA[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i3.GSR = "DISABLED";
    FD1P3AX CLPB_LATCH_111 (.D(nCLPB_N_130), .SP(Clk_enable_560), .CK(Clk), 
            .Q(CLPB_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam CLPB_LATCH_111.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i2 (.D(PD_out_2), .SP(PD_SR), .CK(Clk), .Q(PDTA[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i2.GSR = "DISABLED";
    FD1P3AX PDTA_i0_i1 (.D(PD_out_1), .SP(PD_SR), .CK(Clk), .Q(PDTA[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDTA_i0_i1.GSR = "DISABLED";
    FD1P3AX BGC1_i0_i3 (.D(BGC_POS[3]), .SP(Clk_enable_543), .CK(Clk), 
            .Q(BGC1[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC1_i0_i3.GSR = "DISABLED";
    FD1P3AX BGC1_i0_i2 (.D(BGC_POS[2]), .SP(Clk_enable_543), .CK(Clk), 
            .Q(BGC1[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC1_i0_i2.GSR = "DISABLED";
    LUT4 SR2_5__bdd_3_lut_9187 (.A(SR2[4]), .B(FH[1]), .C(SR2[6]), .Z(n10225)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR2_5__bdd_3_lut_9187.init = 16'hb8b8;
    FD1P3AX BGC1_i0_i1 (.D(BGC_POS[1]), .SP(Clk_enable_543), .CK(Clk), 
            .Q(BGC1[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC1_i0_i1.GSR = "DISABLED";
    FD1P3AX ATRO_i0_i1 (.D(ATSEL[1]), .SP(Clk_enable_267), .CK(Clk), .Q(ATRO[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam ATRO_i0_i1.GSR = "DISABLED";
    FD1P3AX ATR_i0_i1 (.D(ATRO[1]), .SP(Clk_enable_511), .CK(Clk), .Q(ATR[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam ATR_i0_i1.GSR = "DISABLED";
    FD1P3AX F_AT_LATCH_112 (.D(n9925), .SP(Clk_enable_560), .CK(Clk), 
            .Q(F_AT_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam F_AT_LATCH_112.GSR = "DISABLED";
    FD1P3AX BGC2_i0_i0 (.D(BGC1[0]), .SP(Clk_enable_393), .CK(Clk), .Q(BGC2[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC2_i0_i0.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i0 (.D(PD_out_0), .SP(PD_SEL), .CK(Clk), .Q(PDAT[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i0.GSR = "DISABLED";
    FD1P3IX FH__i0 (.D(\DBIN[0] ), .SP(Clk_enable_296), .CD(RC), .CK(Clk), 
            .Q(FH[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam FH__i0.GSR = "DISABLED";
    LUT4 i4539_3_lut_4_lut (.A(Clk_enable_84), .B(n9944), .C(PDTA[7]), 
         .D(n5047), .Z(n5048)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(965[17:36])
    defparam i4539_3_lut_4_lut.init = 16'hfd20;
    PFUMX i9185 (.BLUT(n10223), .ALUT(n10222), .C0(FH[0]), .Z(n10224));
    LUT4 i4545_3_lut_4_lut (.A(Clk_enable_84), .B(n9944), .C(PDTA[4]), 
         .D(n5053), .Z(n5054)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(965[17:36])
    defparam i4545_3_lut_4_lut.init = 16'hfd20;
    LUT4 i798_2_lut (.A(W5_1), .B(RC), .Z(Clk_enable_296)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i798_2_lut.init = 16'heeee;
    LUT4 SR2_5__bdd_3_lut_9239 (.A(SR2[5]), .B(FH[1]), .C(SR2[7]), .Z(n10226)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR2_5__bdd_3_lut_9239.init = 16'hb8b8;
    LUT4 SR0_1__bdd_3_lut_9296 (.A(SR0[1]), .B(FH[1]), .C(SR0[3]), .Z(n10400)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR0_1__bdd_3_lut_9296.init = 16'hb8b8;
    LUT4 SR0_1__bdd_3_lut_9278 (.A(SR0[0]), .B(FH[1]), .C(SR0[2]), .Z(n10399)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR0_1__bdd_3_lut_9278.init = 16'hb8b8;
    LUT4 SR1_1__bdd_3_lut_9209 (.A(SR1[1]), .B(FH[1]), .C(SR1[3]), .Z(n10241)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR1_1__bdd_3_lut_9209.init = 16'hb8b8;
    LUT4 i4525_3_lut_4_lut (.A(Clk_enable_84), .B(n9944), .C(PD_out_7), 
         .D(n5033), .Z(n5034)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(965[17:36])
    defparam i4525_3_lut_4_lut.init = 16'hfd20;
    FD1P3AX BGC2_i0_i1 (.D(BGC1[1]), .SP(Clk_enable_563), .CK(Clk), .Q(BGC2[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC2_i0_i1.GSR = "DISABLED";
    FD1P3AX BGC2_i0_i2 (.D(BGC1[2]), .SP(Clk_enable_563), .CK(Clk), .Q(BGC2[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC2_i0_i2.GSR = "DISABLED";
    FD1P3AX BGC2_i0_i3 (.D(BGC1[3]), .SP(Clk_enable_563), .CK(Clk), .Q(BGC2[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam BGC2_i0_i3.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i1 (.D(PD_out_1), .SP(PD_SEL), .CK(Clk), .Q(PDAT[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i1.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i2 (.D(PD_out_2), .SP(PD_SEL), .CK(Clk), .Q(PDAT[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i2.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i3 (.D(PD_out_3), .SP(PD_SEL), .CK(Clk), .Q(PDAT[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i3.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i4 (.D(PD_out_4), .SP(PD_SEL), .CK(Clk), .Q(PDAT[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i4.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i5 (.D(PD_out_5), .SP(PD_SEL), .CK(Clk), .Q(PDAT[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i5.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i6 (.D(PD_out_6), .SP(PD_SEL), .CK(Clk), .Q(PDAT[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i6.GSR = "DISABLED";
    FD1P3AX PDAT_i0_i7 (.D(PD_out_7), .SP(PD_SEL), .CK(Clk), .Q(PDAT[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam PDAT_i0_i7.GSR = "DISABLED";
    FD1P3IX FH__i1 (.D(\DBIN[1] ), .SP(W5_1), .CD(RC), .CK(Clk), .Q(FH[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam FH__i1.GSR = "DISABLED";
    FD1P3IX FH__i2 (.D(\DBIN[2] ), .SP(W5_1), .CD(RC), .CK(Clk), .Q(FH[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=300, LSE_RLINE=317 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(994[8] 1008[27])
    defparam FH__i2.GSR = "DISABLED";
    LUT4 SR1_5__bdd_3_lut_9197 (.A(SR1[4]), .B(FH[1]), .C(SR1[6]), .Z(n10243)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR1_5__bdd_3_lut_9197.init = 16'hb8b8;
    LUT4 SR1_1__bdd_3_lut_9194 (.A(SR1[0]), .B(FH[1]), .C(SR1[2]), .Z(n10240)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR1_1__bdd_3_lut_9194.init = 16'hb8b8;
    LUT4 SR1_5__bdd_3_lut_9213 (.A(SR1[5]), .B(FH[1]), .C(SR1[7]), .Z(n10244)) /* synthesis lut_function=(A (B+(C))+!A !(B+!(C))) */ ;
    defparam SR1_5__bdd_3_lut_9213.init = 16'hb8b8;
    LUT4 i4527_3_lut_4_lut (.A(Clk_enable_84), .B(n9944), .C(PD_out_6), 
         .D(n5035), .Z(n5036)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(965[17:36])
    defparam i4527_3_lut_4_lut.init = 16'hfd20;
    LUT4 i8779_2_lut_rep_295 (.A(n10442), .B(NFO_OUT), .Z(Clk_enable_391)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i8779_2_lut_rep_295.init = 16'h1111;
    LUT4 i4529_3_lut_4_lut (.A(Clk_enable_84), .B(n9944), .C(PD_out_5), 
         .D(n5037), .Z(n5038)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(965[17:36])
    defparam i4529_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4531_3_lut_4_lut (.A(Clk_enable_84), .B(n9944), .C(PD_out_4), 
         .D(n5039), .Z(n5040)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(965[17:36])
    defparam i4531_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4533_3_lut_4_lut (.A(Clk_enable_84), .B(n9944), .C(PD_out_3), 
         .D(n5041), .Z(n5042)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(965[17:36])
    defparam i4533_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4535_3_lut_4_lut (.A(Clk_enable_84), .B(n9944), .C(PD_out_2), 
         .D(n5043), .Z(n5044)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(965[17:36])
    defparam i4535_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4537_3_lut_4_lut (.A(Clk_enable_84), .B(n9944), .C(PD_out_1), 
         .D(n5045), .Z(n5046)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(965[17:36])
    defparam i4537_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4541_3_lut_4_lut (.A(Clk_enable_84), .B(n9944), .C(PDTA[6]), 
         .D(n5049), .Z(n5050)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(965[17:36])
    defparam i4541_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4543_3_lut_4_lut (.A(Clk_enable_84), .B(n9944), .C(PDTA[5]), 
         .D(n5051), .Z(n5052)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(965[17:36])
    defparam i4543_3_lut_4_lut.init = 16'hfd20;
    L6MUX21 i9292 (.D0(n10411), .D1(n10408), .SD(FH[2]), .Z(BGC_POS[3]));
    PFUMX i9290 (.BLUT(n10410), .ALUT(n10409), .C0(FH[0]), .Z(n10411));
    PFUMX i9287 (.BLUT(n10407), .ALUT(n10406), .C0(FH[0]), .Z(n10408));
    L6MUX21 i9284 (.D0(n10404), .D1(n10401), .SD(FH[2]), .Z(BGC_POS[0]));
    PFUMX i9282 (.BLUT(n10403), .ALUT(n10402), .C0(FH[0]), .Z(n10404));
    PFUMX i9279 (.BLUT(n10400), .ALUT(n10399), .C0(FH[0]), .Z(n10401));
    SHIFTREG_U105 SREG_TB (.QP({QP_adj_1610}), .Clk(Clk), .Clk_enable_563(Clk_enable_563), 
            .\QS_IN[1] (QS_IN_adj_1609[1]), .Clk_enable_511(Clk_enable_511), 
            .\QS_IN[2] (QS_IN_adj_1609[2]), .\QS_IN[3] (QS_IN_adj_1609[3]), 
            .\QS_IN[4] (QS_IN_adj_1609[4]), .\QS_IN[5] (QS_IN_adj_1609[5]), 
            .\QS_IN[6] (QS_IN_adj_1609[6]), .\QS_IN[7] (QS_IN_adj_1609[7]), 
            .n5046(n5046), .n5044(n5044), .n5042(n5042), .n5040(n5040), 
            .n5038(n5038), .n5036(n5036), .n5034(n5034), .PD_out_0(PD_out_0), 
            .Clk_enable_267(Clk_enable_267), .n9838(n9838)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(977[10:81])
    SHIFTREG_U106 SREG_TA (.Clk(Clk), .QP({QP}), .Clk_enable_563(Clk_enable_563), 
            .\QS_IN[1] (QS_IN[1]), .n5060(n5060), .\QS_IN[2] (QS_IN[2]), 
            .n5058(n5058), .\QS_IN[3] (QS_IN[3]), .n5056(n5056), .\QS_IN[4] (QS_IN[4]), 
            .n5054(n5054), .\QS_IN[5] (QS_IN[5]), .n5052(n5052), .\QS_IN[6] (QS_IN[6]), 
            .n5050(n5050), .\QS_IN[7] (QS_IN[7]), .n5048(n5048), .Clk_enable_511(Clk_enable_511), 
            .\PDTA[0] (PDTA[0]), .Clk_enable_267(Clk_enable_267), .n9838(n9838)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(976[10:81])
    SHIFTREG_U107 SREG_FS3 (.SR3({SR3}), .Clk(Clk), .Clk_enable_511(Clk_enable_511), 
            .Clk_enable_391(Clk_enable_391), .\ATR[1] (ATR[1])) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(981[10:81])
    SHIFTREG_U108 SREG_FS2 (.SR2({SR2}), .Clk(Clk), .Clk_enable_511(Clk_enable_511), 
            .Clk_enable_391(Clk_enable_391), .\ATR[0] (ATR[0])) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(980[10:81])
    SHIFTREG_U109 SREG_FS1 (.SR1({SR1}), .Clk(Clk), .Clk_enable_511(Clk_enable_511), 
            .Clk_enable_391(Clk_enable_391), .QTB(QP_adj_1610[7])) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(979[10:81])
    SHIFTREG_U110 SREG_FS0 (.SR0({SR0}), .Clk(Clk), .Clk_enable_563(Clk_enable_563), 
            .Clk_enable_391(Clk_enable_391), .QTA(QP[7]), .Clk_enable_511(Clk_enable_511)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(978[10:81])
    
endmodule
//
// Verilog Description of module SHIFTREG_U105
//

module SHIFTREG_U105 (QP, Clk, Clk_enable_563, \QS_IN[1] , Clk_enable_511, 
            \QS_IN[2] , \QS_IN[3] , \QS_IN[4] , \QS_IN[5] , \QS_IN[6] , 
            \QS_IN[7] , n5046, n5044, n5042, n5040, n5038, n5036, 
            n5034, PD_out_0, Clk_enable_267, n9838) /* synthesis syn_module_defined=1 */ ;
    output [7:0]QP;
    input Clk;
    input Clk_enable_563;
    output \QS_IN[1] ;
    input Clk_enable_511;
    output \QS_IN[2] ;
    output \QS_IN[3] ;
    output \QS_IN[4] ;
    output \QS_IN[5] ;
    output \QS_IN[6] ;
    output \QS_IN[7] ;
    input n5046;
    input n5044;
    input n5042;
    input n5040;
    input n5038;
    input n5036;
    input n5034;
    input PD_out_0;
    input Clk_enable_267;
    input n9838;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4924;
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_563), .CK(Clk), .Q(QP[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i0 (.D(n4924), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_563), .CK(Clk), .Q(QP[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_511), .CK(Clk), .Q(QP[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_511), .CK(Clk), .Q(QP[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_511), .CK(Clk), .Q(QP[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_511), .CK(Clk), .Q(QP[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_511), .CK(Clk), .Q(QP[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_511), .CK(Clk), .Q(QP[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5046), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5044), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5042), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5040), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5038), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5036), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5034), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=977, LSE_RLINE=977 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    LUT4 i4415_4_lut (.A(QS_IN[0]), .B(PD_out_0), .C(Clk_enable_267), 
         .D(n9838), .Z(n4924)) /* synthesis lut_function=(A (B+!(C))+!A (B (C+!(D))+!B !(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4415_4_lut.init = 16'hcacf;
    
endmodule
//
// Verilog Description of module SHIFTREG_U106
//

module SHIFTREG_U106 (Clk, QP, Clk_enable_563, \QS_IN[1] , n5060, 
            \QS_IN[2] , n5058, \QS_IN[3] , n5056, \QS_IN[4] , n5054, 
            \QS_IN[5] , n5052, \QS_IN[6] , n5050, \QS_IN[7] , n5048, 
            Clk_enable_511, \PDTA[0] , Clk_enable_267, n9838) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    output [7:0]QP;
    input Clk_enable_563;
    output \QS_IN[1] ;
    input n5060;
    output \QS_IN[2] ;
    input n5058;
    output \QS_IN[3] ;
    input n5056;
    output \QS_IN[4] ;
    input n5054;
    output \QS_IN[5] ;
    input n5052;
    output \QS_IN[6] ;
    input n5050;
    output \QS_IN[7] ;
    input n5048;
    input Clk_enable_511;
    input \PDTA[0] ;
    input Clk_enable_267;
    input n9838;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    wire n4926;
    
    FD1S3AX QS_IN_i0_i0 (.D(n4926), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_563), .CK(Clk), .Q(QP[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i1 (.D(n5060), .CK(Clk), .Q(\QS_IN[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i2 (.D(n5058), .CK(Clk), .Q(\QS_IN[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i3 (.D(n5056), .CK(Clk), .Q(\QS_IN[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i4 (.D(n5054), .CK(Clk), .Q(\QS_IN[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i5 (.D(n5052), .CK(Clk), .Q(\QS_IN[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i6 (.D(n5050), .CK(Clk), .Q(\QS_IN[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1S3AX QS_IN_i0_i7 (.D(n5048), .CK(Clk), .Q(\QS_IN[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(\QS_IN[1] ), .SP(Clk_enable_511), .CK(Clk), .Q(QP[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(\QS_IN[2] ), .SP(Clk_enable_511), .CK(Clk), .Q(QP[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(\QS_IN[3] ), .SP(Clk_enable_511), .CK(Clk), .Q(QP[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(\QS_IN[4] ), .SP(Clk_enable_511), .CK(Clk), .Q(QP[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(\QS_IN[5] ), .SP(Clk_enable_511), .CK(Clk), .Q(QP[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(\QS_IN[6] ), .SP(Clk_enable_511), .CK(Clk), .Q(QP[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(\QS_IN[7] ), .SP(Clk_enable_511), .CK(Clk), .Q(QP[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=976, LSE_RLINE=976 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    LUT4 i4417_4_lut (.A(QS_IN[0]), .B(\PDTA[0] ), .C(Clk_enable_267), 
         .D(n9838), .Z(n4926)) /* synthesis lut_function=(A (B+!(C))+!A (B (C+!(D))+!B !(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam i4417_4_lut.init = 16'hcacf;
    
endmodule
//
// Verilog Description of module SHIFTREG_U107
//

module SHIFTREG_U107 (SR3, Clk, Clk_enable_511, Clk_enable_391, \ATR[1] ) /* synthesis syn_module_defined=1 */ ;
    output [7:0]SR3;
    input Clk;
    input Clk_enable_511;
    input Clk_enable_391;
    input \ATR[1] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_511), .CK(Clk), .Q(SR3[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i0 (.D(\ATR[1] ), .SP(Clk_enable_391), .CK(Clk), 
            .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(Clk_enable_511), .CK(Clk), .Q(SR3[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(Clk_enable_511), .CK(Clk), .Q(SR3[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(Clk_enable_511), .CK(Clk), .Q(SR3[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(Clk_enable_511), .CK(Clk), .Q(SR3[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(Clk_enable_511), .CK(Clk), .Q(SR3[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(Clk_enable_511), .CK(Clk), .Q(SR3[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(Clk_enable_511), .CK(Clk), .Q(SR3[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(SR3[0]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(SR3[1]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(SR3[2]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(SR3[3]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(SR3[4]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(SR3[5]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(SR3[6]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=981, LSE_RLINE=981 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U108
//

module SHIFTREG_U108 (SR2, Clk, Clk_enable_511, Clk_enable_391, \ATR[0] ) /* synthesis syn_module_defined=1 */ ;
    output [7:0]SR2;
    input Clk;
    input Clk_enable_511;
    input Clk_enable_391;
    input \ATR[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_511), .CK(Clk), .Q(SR2[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i0 (.D(\ATR[0] ), .SP(Clk_enable_391), .CK(Clk), 
            .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(Clk_enable_511), .CK(Clk), .Q(SR2[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(Clk_enable_511), .CK(Clk), .Q(SR2[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(Clk_enable_511), .CK(Clk), .Q(SR2[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(Clk_enable_511), .CK(Clk), .Q(SR2[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(Clk_enable_511), .CK(Clk), .Q(SR2[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(Clk_enable_511), .CK(Clk), .Q(SR2[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(Clk_enable_511), .CK(Clk), .Q(SR2[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(SR2[0]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(SR2[1]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(SR2[2]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(SR2[3]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(SR2[4]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(SR2[5]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(SR2[6]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=980, LSE_RLINE=980 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U109
//

module SHIFTREG_U109 (SR1, Clk, Clk_enable_511, Clk_enable_391, QTB) /* synthesis syn_module_defined=1 */ ;
    output [7:0]SR1;
    input Clk;
    input Clk_enable_511;
    input Clk_enable_391;
    input QTB;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_511), .CK(Clk), .Q(SR1[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i0 (.D(QTB), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(Clk_enable_511), .CK(Clk), .Q(SR1[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(Clk_enable_511), .CK(Clk), .Q(SR1[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(Clk_enable_511), .CK(Clk), .Q(SR1[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(Clk_enable_511), .CK(Clk), .Q(SR1[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(Clk_enable_511), .CK(Clk), .Q(SR1[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(Clk_enable_511), .CK(Clk), .Q(SR1[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(Clk_enable_511), .CK(Clk), .Q(SR1[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(SR1[0]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(SR1[1]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(SR1[2]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(SR1[3]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(SR1[4]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(SR1[5]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(SR1[6]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=979, LSE_RLINE=979 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U110
//

module SHIFTREG_U110 (SR0, Clk, Clk_enable_563, Clk_enable_391, QTA, 
            Clk_enable_511) /* synthesis syn_module_defined=1 */ ;
    output [7:0]SR0;
    input Clk;
    input Clk_enable_563;
    input Clk_enable_391;
    input QTA;
    input Clk_enable_511;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1479[10:15])
    
    FD1P3AX QP_i0_i0 (.D(QS_IN[0]), .SP(Clk_enable_563), .CK(Clk), .Q(SR0[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i0.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i0 (.D(QTA), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i0.GSR = "DISABLED";
    FD1P3AX QP_i0_i1 (.D(QS_IN[1]), .SP(Clk_enable_511), .CK(Clk), .Q(SR0[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i1.GSR = "DISABLED";
    FD1P3AX QP_i0_i2 (.D(QS_IN[2]), .SP(Clk_enable_511), .CK(Clk), .Q(SR0[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i2.GSR = "DISABLED";
    FD1P3AX QP_i0_i3 (.D(QS_IN[3]), .SP(Clk_enable_511), .CK(Clk), .Q(SR0[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i3.GSR = "DISABLED";
    FD1P3AX QP_i0_i4 (.D(QS_IN[4]), .SP(Clk_enable_511), .CK(Clk), .Q(SR0[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i4.GSR = "DISABLED";
    FD1P3AX QP_i0_i5 (.D(QS_IN[5]), .SP(Clk_enable_511), .CK(Clk), .Q(SR0[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i5.GSR = "DISABLED";
    FD1P3AX QP_i0_i6 (.D(QS_IN[6]), .SP(Clk_enable_511), .CK(Clk), .Q(SR0[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i6.GSR = "DISABLED";
    FD1P3AX QP_i0_i7 (.D(QS_IN[7]), .SP(Clk_enable_511), .CK(Clk), .Q(SR0[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QP_i0_i7.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i1 (.D(SR0[0]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i1.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i2 (.D(SR0[1]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i2.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i3 (.D(SR0[2]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i3.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i4 (.D(SR0[3]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i4.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i5 (.D(SR0[4]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i5.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i6 (.D(SR0[5]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i6.GSR = "DISABLED";
    FD1P3AX QS_IN_i0_i7 (.D(SR0[6]), .SP(Clk_enable_391), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=81, LSE_LLINE=978, LSE_RLINE=978 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1483[8] 1486[26])
    defparam QS_IN_i0_i7.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module READBUSMUX
//

module READBUSMUX (Clk, Clk_enable_86, RC, PD_out_0, OB_R, Clk_enable_563, 
            OB, DBIN, D, R2, R7, R4, Clk_enable_47, PD_out_5, 
            PD_out_4, PD_out_3, PD_out_2, PD_out_1, PD_out_7, \PD_R[6] , 
            PD_out_6, \Do_7__N_163[6] , Clk_enable_393, Clk_enable_511, 
            Clk_enable_560, XRB_N_606, n91, n84, \R2DB[2] , n76, 
            n86, \R2DB[0] , n87, n88, n89, n90, RnWR, nDBER, 
            R_EN) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_86;
    input RC;
    input PD_out_0;
    output [7:0]OB_R;
    input Clk_enable_563;
    input [7:0]OB;
    input [7:0]DBIN;
    output [7:0]D;
    input R2;
    input R7;
    input R4;
    input Clk_enable_47;
    input PD_out_5;
    input PD_out_4;
    input PD_out_3;
    input PD_out_2;
    input PD_out_1;
    input PD_out_7;
    output \PD_R[6] ;
    input PD_out_6;
    input \Do_7__N_163[6] ;
    input Clk_enable_393;
    input Clk_enable_511;
    input Clk_enable_560;
    input XRB_N_606;
    input n91;
    input n84;
    input \R2DB[2] ;
    output n76;
    input n86;
    input \R2DB[0] ;
    input n87;
    input n88;
    input n89;
    input n90;
    input RnWR;
    input nDBER;
    output R_EN;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]PD_R;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(641[10:14])
    wire [7:0]Do;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(643[10:12])
    wire [7:0]Do_7__N_163;
    
    wire D_7__N_171, n5, n5_adj_1589, n5_adj_1590, n5_adj_1591, n5_adj_1592, 
        n5_adj_1593, n5_adj_1594;
    
    FD1P3IX PD_R__i0 (.D(PD_out_0), .SP(Clk_enable_86), .CD(RC), .CK(Clk), 
            .Q(PD_R[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i0.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i0 (.D(OB[0]), .SP(Clk_enable_563), .CK(Clk), .Q(OB_R[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i0.GSR = "DISABLED";
    FD1S3AX Do_i0 (.D(Do_7__N_163[0]), .CK(Clk), .Q(Do[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i0.GSR = "DISABLED";
    LUT4 DBIN_7__I_0_i8_3_lut (.A(DBIN[7]), .B(Do[7]), .C(D_7__N_171), 
         .Z(D[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i8_3_lut.init = 16'hcaca;
    LUT4 i3_4_lut_4_lut (.A(R2), .B(R7), .C(R4), .Z(D_7__N_171)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(646[18:42])
    defparam i3_4_lut_4_lut.init = 16'hfefe;
    FD1P3IX PD_R__i5 (.D(PD_out_5), .SP(Clk_enable_47), .CD(RC), .CK(Clk), 
            .Q(PD_R[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i5.GSR = "DISABLED";
    FD1P3IX PD_R__i4 (.D(PD_out_4), .SP(Clk_enable_47), .CD(RC), .CK(Clk), 
            .Q(PD_R[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i4.GSR = "DISABLED";
    FD1P3IX PD_R__i3 (.D(PD_out_3), .SP(Clk_enable_47), .CD(RC), .CK(Clk), 
            .Q(PD_R[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i3.GSR = "DISABLED";
    FD1P3IX PD_R__i2 (.D(PD_out_2), .SP(Clk_enable_47), .CD(RC), .CK(Clk), 
            .Q(PD_R[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i2.GSR = "DISABLED";
    FD1P3IX PD_R__i1 (.D(PD_out_1), .SP(Clk_enable_47), .CD(RC), .CK(Clk), 
            .Q(PD_R[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i1.GSR = "DISABLED";
    FD1P3IX PD_R__i7 (.D(PD_out_7), .SP(Clk_enable_86), .CD(RC), .CK(Clk), 
            .Q(PD_R[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i7.GSR = "DISABLED";
    FD1P3IX PD_R__i6 (.D(PD_out_6), .SP(Clk_enable_86), .CD(RC), .CK(Clk), 
            .Q(\PD_R[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam PD_R__i6.GSR = "DISABLED";
    FD1S3AX Do_i7 (.D(Do_7__N_163[7]), .CK(Clk), .Q(Do[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i7.GSR = "DISABLED";
    FD1S3AX Do_i6 (.D(\Do_7__N_163[6] ), .CK(Clk), .Q(Do[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i6.GSR = "DISABLED";
    FD1S3AX Do_i5 (.D(Do_7__N_163[5]), .CK(Clk), .Q(Do[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i5.GSR = "DISABLED";
    FD1S3AX Do_i4 (.D(Do_7__N_163[4]), .CK(Clk), .Q(Do[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i4.GSR = "DISABLED";
    FD1S3AX Do_i3 (.D(Do_7__N_163[3]), .CK(Clk), .Q(Do[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i3.GSR = "DISABLED";
    FD1S3AX Do_i2 (.D(Do_7__N_163[2]), .CK(Clk), .Q(Do[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i2.GSR = "DISABLED";
    FD1S3AX Do_i1 (.D(Do_7__N_163[1]), .CK(Clk), .Q(Do[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam Do_i1.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i7 (.D(OB[7]), .SP(Clk_enable_393), .CK(Clk), .Q(OB_R[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i7.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i6 (.D(OB[6]), .SP(Clk_enable_511), .CK(Clk), .Q(OB_R[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i6.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i5 (.D(OB[5]), .SP(Clk_enable_511), .CK(Clk), .Q(OB_R[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i5.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i4 (.D(OB[4]), .SP(Clk_enable_560), .CK(Clk), .Q(OB_R[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i4.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i3 (.D(OB[3]), .SP(Clk_enable_560), .CK(Clk), .Q(OB_R[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i3.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i2 (.D(OB[2]), .SP(Clk_enable_563), .CK(Clk), .Q(OB_R[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i2.GSR = "DISABLED";
    FD1P3AX OB_R_i0_i1 (.D(OB[1]), .SP(Clk_enable_563), .CK(Clk), .Q(OB_R[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=216, LSE_RLINE=232 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(649[8] 654[27])
    defparam OB_R_i0_i1.GSR = "DISABLED";
    LUT4 i3_4_lut (.A(n5), .B(XRB_N_606), .C(n91), .D(PD_R[0]), .Z(Do_7__N_163[0])) /* synthesis lut_function=(A+(B (C)+!B (C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i3_4_lut.init = 16'hfbfa;
    LUT4 i1_4_lut (.A(R4), .B(R2), .C(OB_R[0]), .D(DBIN[0]), .Z(n5)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i1_4_lut.init = 16'heca0;
    LUT4 i3_4_lut_adj_384 (.A(n5_adj_1589), .B(XRB_N_606), .C(n84), .D(PD_R[7]), 
         .Z(Do_7__N_163[7])) /* synthesis lut_function=(A+(B (C)+!B (C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i3_4_lut_adj_384.init = 16'hfbfa;
    LUT4 i1_4_lut_adj_385 (.A(R4), .B(R2), .C(OB_R[7]), .D(\R2DB[2] ), 
         .Z(n5_adj_1589)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i1_4_lut_adj_385.init = 16'heca0;
    LUT4 and_35_i7_2_lut (.A(R4), .B(OB_R[6]), .Z(n76)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(653[19:40])
    defparam and_35_i7_2_lut.init = 16'h8888;
    LUT4 i3_4_lut_adj_386 (.A(n5_adj_1590), .B(XRB_N_606), .C(n86), .D(PD_R[5]), 
         .Z(Do_7__N_163[5])) /* synthesis lut_function=(A+(B (C)+!B (C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i3_4_lut_adj_386.init = 16'hfbfa;
    LUT4 i1_4_lut_adj_387 (.A(R4), .B(R2), .C(OB_R[5]), .D(\R2DB[0] ), 
         .Z(n5_adj_1590)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i1_4_lut_adj_387.init = 16'heca0;
    LUT4 i3_4_lut_adj_388 (.A(n5_adj_1591), .B(XRB_N_606), .C(n87), .D(PD_R[4]), 
         .Z(Do_7__N_163[4])) /* synthesis lut_function=(A+(B (C)+!B (C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i3_4_lut_adj_388.init = 16'hfbfa;
    LUT4 i1_4_lut_adj_389 (.A(R4), .B(R2), .C(OB_R[4]), .D(DBIN[4]), 
         .Z(n5_adj_1591)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i1_4_lut_adj_389.init = 16'heca0;
    LUT4 i3_4_lut_adj_390 (.A(n5_adj_1592), .B(XRB_N_606), .C(n88), .D(PD_R[3]), 
         .Z(Do_7__N_163[3])) /* synthesis lut_function=(A+(B (C)+!B (C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i3_4_lut_adj_390.init = 16'hfbfa;
    LUT4 i1_4_lut_adj_391 (.A(R4), .B(R2), .C(OB_R[3]), .D(DBIN[3]), 
         .Z(n5_adj_1592)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i1_4_lut_adj_391.init = 16'heca0;
    LUT4 i3_4_lut_adj_392 (.A(n5_adj_1593), .B(XRB_N_606), .C(n89), .D(PD_R[2]), 
         .Z(Do_7__N_163[2])) /* synthesis lut_function=(A+(B (C)+!B (C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i3_4_lut_adj_392.init = 16'hfbfa;
    LUT4 i1_4_lut_adj_393 (.A(R4), .B(R2), .C(OB_R[2]), .D(DBIN[2]), 
         .Z(n5_adj_1593)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i1_4_lut_adj_393.init = 16'heca0;
    LUT4 i3_4_lut_adj_394 (.A(n5_adj_1594), .B(XRB_N_606), .C(n90), .D(PD_R[1]), 
         .Z(Do_7__N_163[1])) /* synthesis lut_function=(A+(B (C)+!B (C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i3_4_lut_adj_394.init = 16'hfbfa;
    LUT4 i1_4_lut_adj_395 (.A(R4), .B(R2), .C(OB_R[1]), .D(DBIN[1]), 
         .Z(n5_adj_1594)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(653[19:138])
    defparam i1_4_lut_adj_395.init = 16'heca0;
    LUT4 DBIN_7__I_0_i1_3_lut (.A(DBIN[0]), .B(Do[0]), .C(D_7__N_171), 
         .Z(D[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i1_3_lut.init = 16'hcaca;
    LUT4 i8761_2_lut (.A(RnWR), .B(nDBER), .Z(R_EN)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(647[8:10])
    defparam i8761_2_lut.init = 16'hdddd;
    LUT4 DBIN_7__I_0_i2_3_lut (.A(DBIN[1]), .B(Do[1]), .C(D_7__N_171), 
         .Z(D[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i2_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i3_3_lut (.A(DBIN[2]), .B(Do[2]), .C(D_7__N_171), 
         .Z(D[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i3_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i4_3_lut (.A(DBIN[3]), .B(Do[3]), .C(D_7__N_171), 
         .Z(D[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i4_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i5_3_lut (.A(DBIN[4]), .B(Do[4]), .C(D_7__N_171), 
         .Z(D[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i5_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i6_3_lut (.A(DBIN[5]), .B(Do[5]), .C(D_7__N_171), 
         .Z(D[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i6_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i7_3_lut (.A(DBIN[6]), .B(Do[6]), .C(D_7__N_171), 
         .Z(D[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(646[18:64])
    defparam DBIN_7__I_0_i7_3_lut.init = 16'hcaca;
    
endmodule
//
// Verilog Description of module PAR_GEN
//

module PAR_GEN (n10442, SH2, SEL_LATCH, ATR_IN0_2__N_1360, ATR_IN2_2__N_1363, 
            ATR_IN3_2__N_1364, \PAD[0] , Clk, Clk_enable_563, ATR_IN4_2__N_1365, 
            Clk_enable_571, OV, RC, OB, E_EV, PD_out_0, TP, n9866, 
            I1_32, n9942, TAL_LATCH_N_890, TVZ, Clk_enable_68, W6_2, 
            W5_1, DBIN, Clk_enable_173, \TP[4] , \TP[3] , \TP[2] , 
            \TP[1] , PD_out_7, PD_out_6, PD_out_5, PD_out_4, PD_out_3, 
            PD_out_2, PD_out_1, Clk_enable_560, W5_2, Clk_enable_247, 
            PA12_c_12, PA11_c_11, PA10_c_10, PA9_c_9, PA8_c_8, PAR_O, 
            \PAD[7] , \PAMUX[7] , \PAD[6] , \PAMUX[6] , W6_1, W0, 
            \PAD[5] , SC_CNT, \PAD[4] , \PAD[3] , \PAD[2] , \PAD[1] , 
            F_NT, \Hnn[0] , \TVO[2] , \TVO[4] , n8813, \TVO[0] , 
            \TVO[3] , NTVDO, NTV_IN, RESCL, n9975, n9907, \FVO[1] , 
            TH_4__N_776, TVO1, BGSEL, OBSEL, O8_16, ATR_IN5_2__N_1366, 
            ATR_IN6_2__N_1367, ATR_IN7_2__N_1368, n9892, n9925, \Hn[2] , 
            Clk_enable_518, THO, ATR_IN1_2__N_1362, \PAMUX_7__N_859[1] , 
            PAMUX_7__N_851, n8992, \PAMUX_7__N_859[2] , \PAMUX_7__N_859[3] , 
            \PAMUX_7__N_859[4] , \PAMUX_7__N_859[5] , \PAMUX_7__N_859[0] , 
            PA13_c_13, n5110, NBFVO1, Clk_enable_393, Clk_enable_542, 
            THSTEP_N_923, Clk_enable_511, n9868, CNT1_N_565, n9911, 
            TVZB, n9863) /* synthesis syn_module_defined=1 */ ;
    input n10442;
    input SH2;
    input [7:0]SEL_LATCH;
    output ATR_IN0_2__N_1360;
    output ATR_IN2_2__N_1363;
    output ATR_IN3_2__N_1364;
    output \PAD[0] ;
    input Clk;
    input Clk_enable_563;
    output ATR_IN4_2__N_1365;
    input Clk_enable_571;
    input [3:0]OV;
    input RC;
    input [7:0]OB;
    input E_EV;
    input PD_out_0;
    output [11:0]TP;
    input n9866;
    input I1_32;
    input n9942;
    output TAL_LATCH_N_890;
    input TVZ;
    output Clk_enable_68;
    input W6_2;
    input W5_1;
    input [7:0]DBIN;
    input Clk_enable_173;
    output \TP[4] ;
    output \TP[3] ;
    output \TP[2] ;
    output \TP[1] ;
    input PD_out_7;
    input PD_out_6;
    input PD_out_5;
    input PD_out_4;
    input PD_out_3;
    input PD_out_2;
    input PD_out_1;
    input Clk_enable_560;
    input W5_2;
    input Clk_enable_247;
    output PA12_c_12;
    output PA11_c_11;
    output PA10_c_10;
    output PA9_c_9;
    output PA8_c_8;
    input PAR_O;
    output \PAD[7] ;
    input \PAMUX[7] ;
    output \PAD[6] ;
    input \PAMUX[6] ;
    input W6_1;
    input W0;
    output \PAD[5] ;
    input SC_CNT;
    output \PAD[4] ;
    output \PAD[3] ;
    output \PAD[2] ;
    output \PAD[1] ;
    input F_NT;
    input \Hnn[0] ;
    output \TVO[2] ;
    output \TVO[4] ;
    output n8813;
    output \TVO[0] ;
    output \TVO[3] ;
    output NTVDO;
    output NTV_IN;
    input RESCL;
    output n9975;
    input n9907;
    output \FVO[1] ;
    input TH_4__N_776;
    output TVO1;
    input BGSEL;
    input OBSEL;
    input O8_16;
    output ATR_IN5_2__N_1366;
    output ATR_IN6_2__N_1367;
    output ATR_IN7_2__N_1368;
    input n9892;
    input n9925;
    input \Hn[2] ;
    input Clk_enable_518;
    output [4:0]THO;
    output ATR_IN1_2__N_1362;
    input \PAMUX_7__N_859[1] ;
    output [7:0]PAMUX_7__N_851;
    input n8992;
    input \PAMUX_7__N_859[2] ;
    input \PAMUX_7__N_859[3] ;
    input \PAMUX_7__N_859[4] ;
    input \PAMUX_7__N_859[5] ;
    input \PAMUX_7__N_859[0] ;
    output PA13_c_13;
    input n5110;
    input NBFVO1;
    input Clk_enable_393;
    input Clk_enable_542;
    input THSTEP_N_923;
    input Clk_enable_511;
    input n9868;
    input CNT1_N_565;
    input n9911;
    input TVZB;
    input n9863;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [13:0]PAMUX;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1110[12:17])
    wire [3:0]OVR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1056[10:13])
    wire [4:0]TV;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1063[10:12])
    
    wire TV_4__N_816, TV_4__N_824;
    wire [7:0]OBOUT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1060[10:15])
    
    wire OVOUT_3__N_868;
    wire [7:0]PDOUT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1059[10:15])
    wire [7:0]PDIN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1058[10:14])
    
    wire TV_IN, TV_IN_N_913;
    wire [1:0]EEVR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1066[10:14])
    wire [1:0]W62;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1071[10:13])
    
    wire W62_1__N_846;
    wire [2:0]TP_11__N_880;
    wire [1:0]Z_TV;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1068[10:14])
    
    wire n8829, n4, TAL_LATCH, TVZR, VINV_LATCH, TH_4__N_790, TH_4__N_785, 
        TH_4__N_780, TH_4__N_773, TVZR_N_884;
    wire [11:0]TP_c;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1061[11:13])
    
    wire TP_11__N_869;
    wire [6:0]TP_11__N_871;
    
    wire TP_11__N_878, TV_4__N_804, TV_4__N_800, TV_4__N_807, TV_4__N_812, 
        TV_4__N_819;
    wire [2:0]FV;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1065[10:12])
    
    wire TV_4__N_803, FV_2__N_837, W62_FF;
    wire [2:0]FVO;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1096[11:14])
    wire [3:0]OVOUT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1057[10:15])
    
    wire Clk_enable_549, SCCNTR, n6, Clk_enable_235, n9909, CNT1_N_565_c, 
        CNT1, n4511, CNT1_adj_1569, n4935, CNT1_adj_1570, n4769, 
        CNT1_adj_1571, n4485, THLOAD_N_916;
    wire [4:0]TH;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1062[10:12])
    
    wire TH_4__N_795, NTHDO, FV_2__N_829, FV_2__N_832, TP_11__N_870, 
        TP_11__N_879, ZTV_N_928, NTH_N_899, NTV_N_906, n6_adj_1572, 
        CNT1_N_565_adj_1573, n9837, CNT1_adj_1574, n5126, CNT1_adj_1575, 
        n5128, n4936, n4486, NTV, n4512, n4770, CNT1_adj_1576, 
        n5123, CNT1_adj_1577, n5121, CNT1_adj_1578, n5119, NTH, 
        CNT1_N_565_adj_1579, CNT1_N_565_adj_1580, CNT1_N_565_adj_1581, 
        n9930, n9961, CNT1_N_565_adj_1582, CNT1_N_565_adj_1583, CNT1_N_565_adj_1584, 
        CNT1_N_565_adj_1585, CNT1_N_565_adj_1587, CNT1_N_565_adj_1588;
    
    LUT4 ATR_IN0_2__I_365_2_lut_3_lut (.A(n10442), .B(SH2), .C(SEL_LATCH[0]), 
         .Z(ATR_IN0_2__N_1360)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1131[12:22])
    defparam ATR_IN0_2__I_365_2_lut_3_lut.init = 16'h8080;
    LUT4 ATR_IN0_2__N_1361_I_0_357_2_lut_3_lut (.A(n10442), .B(SH2), .C(SEL_LATCH[2]), 
         .Z(ATR_IN2_2__N_1363)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1131[12:22])
    defparam ATR_IN0_2__N_1361_I_0_357_2_lut_3_lut.init = 16'h8080;
    LUT4 ATR_IN0_2__N_1361_I_0_358_2_lut_3_lut (.A(n10442), .B(SH2), .C(SEL_LATCH[3]), 
         .Z(ATR_IN3_2__N_1364)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1131[12:22])
    defparam ATR_IN0_2__N_1361_I_0_358_2_lut_3_lut.init = 16'h8080;
    FD1P3AX PAD_i0_i0 (.D(PAMUX[0]), .SP(Clk_enable_563), .CK(Clk), .Q(\PAD[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i0.GSR = "DISABLED";
    LUT4 ATR_IN0_2__N_1361_I_0_359_2_lut_3_lut (.A(n10442), .B(SH2), .C(SEL_LATCH[4]), 
         .Z(ATR_IN4_2__N_1365)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1131[12:22])
    defparam ATR_IN0_2__N_1361_I_0_359_2_lut_3_lut.init = 16'h8080;
    FD1P3AX OVR_i0_i0 (.D(OV[0]), .SP(Clk_enable_571), .CK(Clk), .Q(OVR[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVR_i0_i0.GSR = "DISABLED";
    FD1P3IX TV_i0 (.D(TV_4__N_824), .SP(TV_4__N_816), .CD(RC), .CK(Clk), 
            .Q(TV[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TV_i0.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i0 (.D(OB[0]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i0.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i0 (.D(PDIN[0]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i0.GSR = "DISABLED";
    FD1S3AX TV_IN_241 (.D(TV_IN_N_913), .CK(Clk), .Q(TV_IN)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TV_IN_241.GSR = "DISABLED";
    FD1P3AX EEVR_i0 (.D(E_EV), .SP(Clk_enable_571), .CK(Clk), .Q(EEVR[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam EEVR_i0.GSR = "DISABLED";
    FD1P3AX W62_i0 (.D(W62_1__N_846), .SP(Clk_enable_571), .CK(Clk), .Q(W62[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam W62_i0.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i0 (.D(PD_out_0), .SP(Clk_enable_571), .CK(Clk), .Q(PDIN[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i0.GSR = "DISABLED";
    FD1P3AX TP_i0_i0 (.D(TP_11__N_880[0]), .SP(Clk_enable_571), .CK(Clk), 
            .Q(TP[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i0.GSR = "DISABLED";
    FD1P3AX Z_TV_i0_i0 (.D(n9866), .SP(Clk_enable_571), .CK(Clk), .Q(Z_TV[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam Z_TV_i0_i0.GSR = "DISABLED";
    LUT4 I1_32_bdd_4_lut (.A(I1_32), .B(n8829), .C(n4), .D(n9942), .Z(TV_IN_N_913)) /* synthesis lut_function=(A (C+(D))+!A (B (C+(D))+!B !((D)+!C))) */ ;
    defparam I1_32_bdd_4_lut.init = 16'heef0;
    FD1P3AX TAL_LATCH_251 (.D(TAL_LATCH_N_890), .SP(Clk_enable_571), .CK(Clk), 
            .Q(TAL_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TAL_LATCH_251.GSR = "DISABLED";
    FD1P3AX TVZR_246 (.D(TVZ), .SP(Clk_enable_563), .CK(Clk), .Q(TVZR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TVZR_246.GSR = "DISABLED";
    FD1P3AX VINV_LATCH_240 (.D(OB[7]), .SP(Clk_enable_68), .CK(Clk), .Q(VINV_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam VINV_LATCH_240.GSR = "DISABLED";
    LUT4 TH_4__I_224_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[1]), .D(DBIN[4]), 
         .Z(TH_4__N_790)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1117[50:85])
    defparam TH_4__I_224_4_lut.init = 16'heca0;
    LUT4 TH_4__I_222_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[2]), .D(DBIN[5]), 
         .Z(TH_4__N_785)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1118[50:85])
    defparam TH_4__I_222_4_lut.init = 16'heca0;
    LUT4 TH_4__I_220_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[3]), .D(DBIN[6]), 
         .Z(TH_4__N_780)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1119[50:85])
    defparam TH_4__I_220_4_lut.init = 16'heca0;
    LUT4 TH_4__I_217_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[4]), .D(DBIN[7]), 
         .Z(TH_4__N_773)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1120[50:85])
    defparam TH_4__I_217_4_lut.init = 16'heca0;
    FD1P3AX Z_TV_i0_i1 (.D(TVZR_N_884), .SP(Clk_enable_173), .CK(Clk), 
            .Q(Z_TV[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam Z_TV_i0_i1.GSR = "DISABLED";
    FD1P3AX TP_i0_i11 (.D(TP_11__N_869), .SP(Clk_enable_173), .CK(Clk), 
            .Q(TP_c[11])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i11.GSR = "DISABLED";
    FD1P3AX TP_i0_i10 (.D(TP_11__N_871[6]), .SP(Clk_enable_173), .CK(Clk), 
            .Q(TP_c[10])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i10.GSR = "DISABLED";
    FD1P3AX TP_i0_i9 (.D(TP_11__N_871[5]), .SP(Clk_enable_173), .CK(Clk), 
            .Q(TP_c[9])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i9.GSR = "DISABLED";
    FD1P3AX TP_i0_i8 (.D(TP_11__N_871[4]), .SP(Clk_enable_173), .CK(Clk), 
            .Q(TP_c[8])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i8.GSR = "DISABLED";
    FD1P3AX TP_i0_i7 (.D(TP_11__N_871[3]), .SP(Clk_enable_173), .CK(Clk), 
            .Q(TP_c[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i7.GSR = "DISABLED";
    FD1P3AX TP_i0_i6 (.D(TP_11__N_871[2]), .SP(Clk_enable_173), .CK(Clk), 
            .Q(TP_c[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i6.GSR = "DISABLED";
    FD1P3AX TP_i0_i5 (.D(TP_11__N_871[1]), .SP(Clk_enable_173), .CK(Clk), 
            .Q(TP_c[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i5.GSR = "DISABLED";
    FD1P3AX TP_i0_i4 (.D(TP_11__N_871[0]), .SP(Clk_enable_173), .CK(Clk), 
            .Q(\TP[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i4.GSR = "DISABLED";
    FD1P3AX TP_i0_i3 (.D(TP_11__N_878), .SP(Clk_enable_173), .CK(Clk), 
            .Q(\TP[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i3.GSR = "DISABLED";
    FD1P3AX TP_i0_i2 (.D(TP_11__N_880[2]), .SP(Clk_enable_173), .CK(Clk), 
            .Q(\TP[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i2.GSR = "DISABLED";
    FD1P3AX TP_i0_i1 (.D(TP_11__N_880[1]), .SP(Clk_enable_173), .CK(Clk), 
            .Q(\TP[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TP_i0_i1.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i7 (.D(PD_out_7), .SP(Clk_enable_173), .CK(Clk), .Q(PDIN[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i7.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i6 (.D(PD_out_6), .SP(Clk_enable_173), .CK(Clk), .Q(PDIN[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i6.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i5 (.D(PD_out_5), .SP(Clk_enable_173), .CK(Clk), .Q(PDIN[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i5.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i4 (.D(PD_out_4), .SP(Clk_enable_173), .CK(Clk), .Q(PDIN[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i4.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i3 (.D(PD_out_3), .SP(Clk_enable_173), .CK(Clk), .Q(PDIN[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i3.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i2 (.D(PD_out_2), .SP(Clk_enable_173), .CK(Clk), .Q(PDIN[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i2.GSR = "DISABLED";
    FD1P3AX PDIN_i0_i1 (.D(PD_out_1), .SP(Clk_enable_173), .CK(Clk), .Q(PDIN[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDIN_i0_i1.GSR = "DISABLED";
    FD1P3AX W62_i1 (.D(W62[0]), .SP(Clk_enable_560), .CK(Clk), .Q(W62[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam W62_i1.GSR = "DISABLED";
    FD1P3AX EEVR_i1 (.D(EEVR[0]), .SP(Clk_enable_560), .CK(Clk), .Q(EEVR[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam EEVR_i1.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i7 (.D(PDIN[7]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i7.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i6 (.D(PDIN[6]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i6.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i5 (.D(PDIN[5]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i5.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i4 (.D(PDIN[4]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i4.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i3 (.D(PDIN[3]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i3.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i2 (.D(PDIN[2]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i2.GSR = "DISABLED";
    FD1P3AX PDOUT_i0_i1 (.D(PDIN[1]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(PDOUT[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PDOUT_i0_i1.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i7 (.D(OB[7]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i7.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i6 (.D(OB[6]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i6.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i5 (.D(OB[5]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i5.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i4 (.D(OB[4]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i4.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i3 (.D(OB[3]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i3.GSR = "DISABLED";
    LUT4 W6_2_I_0_271_2_lut (.A(W6_2), .B(W5_2), .Z(TV_4__N_816)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1123[11:22])
    defparam W6_2_I_0_271_2_lut.init = 16'heeee;
    FD1P3AX OBOUT_i0_i2 (.D(OB[2]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i2.GSR = "DISABLED";
    FD1P3AX OBOUT_i0_i1 (.D(OB[1]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OBOUT[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OBOUT_i0_i1.GSR = "DISABLED";
    FD1P3IX TV_i4 (.D(TV_4__N_800), .SP(TV_4__N_804), .CD(RC), .CK(Clk), 
            .Q(TV[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TV_i4.GSR = "DISABLED";
    FD1P3IX TV_i3 (.D(TV_4__N_807), .SP(TV_4__N_804), .CD(RC), .CK(Clk), 
            .Q(TV[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TV_i3.GSR = "DISABLED";
    FD1P3IX TV_i2 (.D(TV_4__N_812), .SP(TV_4__N_816), .CD(RC), .CK(Clk), 
            .Q(TV[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TV_i2.GSR = "DISABLED";
    FD1P3IX TV_i1 (.D(TV_4__N_819), .SP(TV_4__N_816), .CD(RC), .CK(Clk), 
            .Q(TV[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TV_i1.GSR = "DISABLED";
    LUT4 TV_4__I_238_4_lut (.A(W6_2), .B(W5_2), .C(DBIN[5]), .D(DBIN[3]), 
         .Z(TV_4__N_824)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1121[50:85])
    defparam TV_4__I_238_4_lut.init = 16'heca0;
    LUT4 i8835_2_lut (.A(n10442), .B(TAL_LATCH), .Z(OVOUT_3__N_868)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1133[12:33])
    defparam i8835_2_lut.init = 16'h2222;
    FD1P3IX FV__i0 (.D(FV_2__N_837), .SP(TV_4__N_803), .CD(RC), .CK(Clk), 
            .Q(FV[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam FV__i0.GSR = "DISABLED";
    FD1P3AX OVR_i0_i3 (.D(OV[3]), .SP(Clk_enable_247), .CK(Clk), .Q(OVR[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVR_i0_i3.GSR = "DISABLED";
    FD1P3AX OVR_i0_i2 (.D(OV[2]), .SP(Clk_enable_247), .CK(Clk), .Q(OVR[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVR_i0_i2.GSR = "DISABLED";
    FD1P3AX OVR_i0_i1 (.D(OV[1]), .SP(Clk_enable_247), .CK(Clk), .Q(OVR[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVR_i0_i1.GSR = "DISABLED";
    FD1P3AX PAD_i0_i12 (.D(PAMUX[12]), .SP(Clk_enable_560), .CK(Clk), 
            .Q(PA12_c_12)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i12.GSR = "DISABLED";
    FD1P3AX PAD_i0_i11 (.D(PAMUX[11]), .SP(Clk_enable_560), .CK(Clk), 
            .Q(PA11_c_11)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i11.GSR = "DISABLED";
    FD1P3AX PAD_i0_i10 (.D(PAMUX[10]), .SP(Clk_enable_560), .CK(Clk), 
            .Q(PA10_c_10)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i10.GSR = "DISABLED";
    FD1P3AX PAD_i0_i9 (.D(PAMUX[9]), .SP(Clk_enable_560), .CK(Clk), .Q(PA9_c_9)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i9.GSR = "DISABLED";
    FD1P3AX PAD_i0_i8 (.D(PAMUX[8]), .SP(Clk_enable_560), .CK(Clk), .Q(PA8_c_8)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i8.GSR = "DISABLED";
    LUT4 W62_FF_I_0_287_2_lut (.A(W62_FF), .B(W6_2), .Z(W62_1__N_846)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1157[20:34])
    defparam W62_FF_I_0_287_2_lut.init = 16'h2222;
    LUT4 mux_196_i1_4_lut (.A(FVO[0]), .B(VINV_LATCH), .C(PAR_O), .D(OVOUT[0]), 
         .Z(TP_11__N_880[0])) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1151[20:53])
    defparam mux_196_i1_4_lut.init = 16'h3aca;
    FD1P3AX PAD_i0_i7 (.D(\PAMUX[7] ), .SP(Clk_enable_560), .CK(Clk), 
            .Q(\PAD[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i7.GSR = "DISABLED";
    FD1P3AX PAD_i0_i6 (.D(\PAMUX[6] ), .SP(Clk_enable_560), .CK(Clk), 
            .Q(\PAD[6] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i6.GSR = "DISABLED";
    LUT4 i1_2_lut_3_lut (.A(RC), .B(W6_1), .C(W5_2), .Z(TV_4__N_803)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1125[11:22])
    defparam i1_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_3_lut_adj_380 (.A(RC), .B(W6_1), .C(W0), .Z(Clk_enable_549)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1125[11:22])
    defparam i1_2_lut_3_lut_adj_380.init = 16'hfefe;
    FD1P3AX PAD_i0_i5 (.D(PAMUX[5]), .SP(Clk_enable_560), .CK(Clk), .Q(\PAD[5] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i5.GSR = "DISABLED";
    FD1P3AX SCCNTR_248 (.D(SC_CNT), .SP(Clk_enable_560), .CK(Clk), .Q(SCCNTR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam SCCNTR_248.GSR = "DISABLED";
    FD1P3AX PAD_i0_i4 (.D(PAMUX[4]), .SP(Clk_enable_560), .CK(Clk), .Q(\PAD[4] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i4.GSR = "DISABLED";
    FD1P3AX PAD_i0_i3 (.D(PAMUX[3]), .SP(Clk_enable_560), .CK(Clk), .Q(\PAD[3] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i3.GSR = "DISABLED";
    FD1P3AX PAD_i0_i2 (.D(PAMUX[2]), .SP(Clk_enable_560), .CK(Clk), .Q(\PAD[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i2.GSR = "DISABLED";
    FD1P3AX PAD_i0_i1 (.D(PAMUX[1]), .SP(Clk_enable_560), .CK(Clk), .Q(\PAD[1] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i1.GSR = "DISABLED";
    LUT4 i8791_2_lut (.A(F_NT), .B(\Hnn[0] ), .Z(TAL_LATCH_N_890)) /* synthesis lut_function=(!(A (B))) */ ;
    defparam i8791_2_lut.init = 16'h7777;
    LUT4 i4_4_lut (.A(\TVO[2] ), .B(TV_IN), .C(\TVO[4] ), .D(n6), .Z(n8813)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1092[15:39])
    defparam i4_4_lut.init = 16'h8000;
    LUT4 i1_2_lut (.A(\TVO[0] ), .B(\TVO[3] ), .Z(n6)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1092[15:39])
    defparam i1_2_lut.init = 16'h8888;
    FD1P3AX W62_FF_245 (.D(n9909), .SP(Clk_enable_235), .CK(Clk), .Q(W62_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam W62_FF_245.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut_4_lut (.A(n9942), .B(NTVDO), .C(NTV_IN), .D(FVO[0]), 
         .Z(CNT1_N_565_c)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1087[17:40])
    defparam CNT_I_0_2_lut_4_lut.init = 16'h2ad5;
    LUT4 TVLOAD_I_259_3_lut_rep_370 (.A(SCCNTR), .B(W62[1]), .C(RESCL), 
         .Z(n9975)) /* synthesis lut_function=(A (B+(C))+!A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1079[21:50])
    defparam TVLOAD_I_259_3_lut_rep_370.init = 16'hecec;
    LUT4 i4002_3_lut_4_lut (.A(n9907), .B(n10442), .C(CNT1), .D(NTVDO), 
         .Z(n4511)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1081[18:48])
    defparam i4002_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4426_3_lut_4_lut (.A(n9907), .B(n10442), .C(CNT1_adj_1569), 
         .D(FVO[0]), .Z(n4935)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1081[18:48])
    defparam i4426_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4260_3_lut_4_lut (.A(n9907), .B(n10442), .C(CNT1_adj_1570), 
         .D(\FVO[1] ), .Z(n4769)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1081[18:48])
    defparam i4260_3_lut_4_lut.init = 16'hfd20;
    LUT4 i3976_3_lut_4_lut (.A(n9907), .B(n10442), .C(CNT1_adj_1571), 
         .D(FVO[2]), .Z(n4485)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1081[18:48])
    defparam i3976_3_lut_4_lut.init = 16'hfd20;
    LUT4 THLOAD_I_255_3_lut (.A(EEVR[1]), .B(n10442), .C(W62[1]), .Z(THLOAD_N_916)) /* synthesis lut_function=(A (B)+!A (B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1078[18:51])
    defparam THLOAD_I_255_3_lut.init = 16'hcdcd;
    FD1P3AX OVOUT_i0_i0 (.D(OVR[0]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OVOUT[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVOUT_i0_i0.GSR = "DISABLED";
    FD1P3IX TH__i0 (.D(TH_4__N_795), .SP(TH_4__N_776), .CD(RC), .CK(Clk), 
            .Q(TH[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TH__i0.GSR = "DISABLED";
    LUT4 i1_4_lut (.A(n8813), .B(n9942), .C(NTHDO), .D(TVO1), .Z(NTV_IN)) /* synthesis lut_function=(A (B (C (D))+!B !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1086[19:40])
    defparam i1_4_lut.init = 16'h8022;
    FD1P3IX FV__i2 (.D(FV_2__N_829), .SP(TV_4__N_804), .CD(RC), .CK(Clk), 
            .Q(FV[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam FV__i2.GSR = "DISABLED";
    FD1P3IX FV__i1 (.D(FV_2__N_832), .SP(TV_4__N_804), .CD(RC), .CK(Clk), 
            .Q(FV[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam FV__i1.GSR = "DISABLED";
    LUT4 TVZR_I_0_1_lut (.A(TVZR), .Z(TVZR_N_884)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1155[21:26])
    defparam TVZR_I_0_1_lut.init = 16'h5555;
    LUT4 BGSEL_I_0_3_lut (.A(BGSEL), .B(TP_11__N_870), .C(PAR_O), .Z(TP_11__N_869)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1154[20:74])
    defparam BGSEL_I_0_3_lut.init = 16'hcaca;
    LUT4 OBSEL_I_0_3_lut (.A(OBSEL), .B(OBOUT[0]), .C(O8_16), .Z(TP_11__N_870)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1154[30:63])
    defparam OBSEL_I_0_3_lut.init = 16'hcaca;
    LUT4 mux_199_i7_3_lut (.A(PDOUT[7]), .B(OBOUT[7]), .C(PAR_O), .Z(TP_11__N_871[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1153[20:53])
    defparam mux_199_i7_3_lut.init = 16'hcaca;
    LUT4 mux_199_i6_3_lut (.A(PDOUT[6]), .B(OBOUT[6]), .C(PAR_O), .Z(TP_11__N_871[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1153[20:53])
    defparam mux_199_i6_3_lut.init = 16'hcaca;
    LUT4 mux_199_i5_3_lut (.A(PDOUT[5]), .B(OBOUT[5]), .C(PAR_O), .Z(TP_11__N_871[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1153[20:53])
    defparam mux_199_i5_3_lut.init = 16'hcaca;
    LUT4 ATR_IN0_2__N_1361_I_0_360_2_lut_3_lut (.A(n10442), .B(SH2), .C(SEL_LATCH[5]), 
         .Z(ATR_IN5_2__N_1366)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1131[12:22])
    defparam ATR_IN0_2__N_1361_I_0_360_2_lut_3_lut.init = 16'h8080;
    LUT4 mux_199_i4_3_lut (.A(PDOUT[4]), .B(OBOUT[4]), .C(PAR_O), .Z(TP_11__N_871[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1153[20:53])
    defparam mux_199_i4_3_lut.init = 16'hcaca;
    LUT4 mux_199_i3_3_lut (.A(PDOUT[3]), .B(OBOUT[3]), .C(PAR_O), .Z(TP_11__N_871[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1153[20:53])
    defparam mux_199_i3_3_lut.init = 16'hcaca;
    LUT4 mux_199_i2_3_lut (.A(PDOUT[2]), .B(OBOUT[2]), .C(PAR_O), .Z(TP_11__N_871[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1153[20:53])
    defparam mux_199_i2_3_lut.init = 16'hcaca;
    LUT4 mux_199_i1_3_lut (.A(PDOUT[1]), .B(OBOUT[1]), .C(PAR_O), .Z(TP_11__N_871[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1153[20:53])
    defparam mux_199_i1_3_lut.init = 16'hcaca;
    LUT4 PDOUT_0__I_0_3_lut (.A(PDOUT[0]), .B(TP_11__N_879), .C(PAR_O), 
         .Z(TP_11__N_878)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1152[20:77])
    defparam PDOUT_0__I_0_3_lut.init = 16'hcaca;
    LUT4 TH_4__I_226_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[0]), .D(DBIN[3]), 
         .Z(TH_4__N_795)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1116[50:85])
    defparam TH_4__I_226_4_lut.init = 16'heca0;
    LUT4 OBOUT_0__I_0_4_lut (.A(OBOUT[0]), .B(VINV_LATCH), .C(O8_16), 
         .D(OVOUT[3]), .Z(TP_11__N_879)) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1152[30:66])
    defparam OBOUT_0__I_0_4_lut.init = 16'h3aca;
    LUT4 mux_196_i3_4_lut (.A(FVO[2]), .B(VINV_LATCH), .C(PAR_O), .D(OVOUT[2]), 
         .Z(TP_11__N_880[2])) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1151[20:53])
    defparam mux_196_i3_4_lut.init = 16'h3aca;
    LUT4 mux_196_i2_4_lut (.A(\FVO[1] ), .B(VINV_LATCH), .C(PAR_O), .D(OVOUT[1]), 
         .Z(TP_11__N_880[1])) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1151[20:53])
    defparam mux_196_i2_4_lut.init = 16'h3aca;
    LUT4 ATR_IN0_2__N_1361_I_0_361_2_lut_3_lut (.A(n10442), .B(SH2), .C(SEL_LATCH[6]), 
         .Z(ATR_IN6_2__N_1367)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1131[12:22])
    defparam ATR_IN0_2__N_1361_I_0_361_2_lut_3_lut.init = 16'h8080;
    LUT4 ATR_IN0_2__N_1361_I_0_2_lut_3_lut (.A(n10442), .B(SH2), .C(SEL_LATCH[7]), 
         .Z(ATR_IN7_2__N_1368)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1131[12:22])
    defparam ATR_IN0_2__N_1361_I_0_2_lut_3_lut.init = 16'h8080;
    LUT4 i2_3_lut (.A(\FVO[1] ), .B(FVO[2]), .C(FVO[0]), .Z(n4)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1132[16:45])
    defparam i2_3_lut.init = 16'h8080;
    LUT4 i8784_2_lut (.A(Z_TV[0]), .B(Z_TV[1]), .Z(ZTV_N_928)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1082[14:36])
    defparam i8784_2_lut.init = 16'h1111;
    LUT4 NBFVO1_I_0_i2_4_lut (.A(\TVO[4] ), .B(TP_c[8]), .C(n9892), .D(n9925), 
         .Z(PAMUX[9])) /* synthesis lut_function=(A (B+!(C))+!A (B (C+(D))+!B !(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1112[22:98])
    defparam NBFVO1_I_0_i2_4_lut.init = 16'hcfca;
    LUT4 W5_2_I_0_277_2_lut (.A(W5_2), .B(DBIN[2]), .Z(FV_2__N_829)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1130[69:85])
    defparam W5_2_I_0_277_2_lut.init = 16'h8888;
    LUT4 FV_2__I_241_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[5]), .D(DBIN[1]), 
         .Z(FV_2__N_832)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1129[50:85])
    defparam FV_2__I_241_4_lut.init = 16'heca0;
    LUT4 NTH_I_250_4_lut (.A(W6_1), .B(W0), .C(DBIN[2]), .D(DBIN[0]), 
         .Z(NTH_N_899)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1126[50:85])
    defparam NTH_I_250_4_lut.init = 16'heca0;
    LUT4 NTV_I_253_4_lut (.A(W6_1), .B(W0), .C(DBIN[3]), .D(DBIN[1]), 
         .Z(NTV_N_906)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1127[50:85])
    defparam NTV_I_253_4_lut.init = 16'heca0;
    LUT4 NBFVO1_I_0_i4_3_lut_4_lut (.A(\Hn[2] ), .B(n9942), .C(TP_c[10]), 
         .D(NTVDO), .Z(PAMUX[11])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1109[16:27])
    defparam NBFVO1_I_0_i4_3_lut_4_lut.init = 16'hfd20;
    LUT4 NBFVO1_I_0_i3_3_lut_4_lut (.A(\Hn[2] ), .B(n9942), .C(TP_c[9]), 
         .D(NTHDO), .Z(PAMUX[10])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1109[16:27])
    defparam NBFVO1_I_0_i3_3_lut_4_lut.init = 16'hfd20;
    LUT4 NBFVO1_I_0_i1_4_lut (.A(\TVO[3] ), .B(TP_c[7]), .C(n9892), .D(n9925), 
         .Z(PAMUX[8])) /* synthesis lut_function=(A (B+!(C))+!A (B (C+(D))+!B !(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1112[22:98])
    defparam NBFVO1_I_0_i1_4_lut.init = 16'hcfca;
    LUT4 NBFVO1_I_0_i5_4_lut_4_lut (.A(\Hn[2] ), .B(n9942), .C(FVO[0]), 
         .D(TP_c[11]), .Z(PAMUX[12])) /* synthesis lut_function=(A (B (C)+!B (D))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1109[16:27])
    defparam NBFVO1_I_0_i5_4_lut_4_lut.init = 16'he2c0;
    LUT4 W6_1_I_0_266_2_lut (.A(W6_1), .B(W5_2), .Z(TV_4__N_804)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1125[11:22])
    defparam W6_1_I_0_266_2_lut.init = 16'heeee;
    LUT4 TV_4__I_228_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[1]), .D(DBIN[7]), 
         .Z(TV_4__N_800)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1125[50:85])
    defparam TV_4__I_228_4_lut.init = 16'heca0;
    LUT4 TV_4__I_231_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[0]), .D(DBIN[6]), 
         .Z(TV_4__N_807)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1124[50:85])
    defparam TV_4__I_231_4_lut.init = 16'heca0;
    LUT4 TV_4__I_233_4_lut (.A(W6_2), .B(W5_2), .C(DBIN[7]), .D(DBIN[5]), 
         .Z(TV_4__N_812)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1123[50:85])
    defparam TV_4__I_233_4_lut.init = 16'heca0;
    LUT4 TV_4__I_236_4_lut (.A(W6_2), .B(W5_2), .C(DBIN[6]), .D(DBIN[4]), 
         .Z(TV_4__N_819)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1122[50:85])
    defparam TV_4__I_236_4_lut.init = 16'heca0;
    LUT4 i8933_2_lut_rep_304 (.A(n10442), .B(W62[1]), .Z(n9909)) /* synthesis lut_function=(A+!(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam i8933_2_lut_rep_304.init = 16'hbbbb;
    LUT4 i1_2_lut_3_lut_adj_381 (.A(n10442), .B(W62[1]), .C(W6_2), .Z(Clk_enable_235)) /* synthesis lut_function=(A (C)+!A (B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam i1_2_lut_3_lut_adj_381.init = 16'hf4f4;
    FD1P3AX OVOUT_i0_i1 (.D(OVR[1]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OVOUT[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVOUT_i0_i1.GSR = "DISABLED";
    FD1P3AX OVOUT_i0_i2 (.D(OVR[2]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OVOUT[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVOUT_i0_i2.GSR = "DISABLED";
    FD1P3AX OVOUT_i0_i3 (.D(OVR[3]), .SP(OVOUT_3__N_868), .CK(Clk), .Q(OVOUT[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam OVOUT_i0_i3.GSR = "DISABLED";
    FD1P3IX TH__i1 (.D(TH_4__N_790), .SP(Clk_enable_518), .CD(RC), .CK(Clk), 
            .Q(TH[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TH__i1.GSR = "DISABLED";
    FD1P3IX TH__i2 (.D(TH_4__N_785), .SP(Clk_enable_518), .CD(RC), .CK(Clk), 
            .Q(TH[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TH__i2.GSR = "DISABLED";
    FD1P3IX TH__i3 (.D(TH_4__N_780), .SP(Clk_enable_518), .CD(RC), .CK(Clk), 
            .Q(TH[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TH__i3.GSR = "DISABLED";
    FD1P3IX TH__i4 (.D(TH_4__N_773), .SP(Clk_enable_518), .CD(RC), .CK(Clk), 
            .Q(TH[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam TH__i4.GSR = "DISABLED";
    LUT4 i4_4_lut_adj_382 (.A(THO[2]), .B(THO[4]), .C(THO[1]), .D(n6_adj_1572), 
         .Z(n8829)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1089[15:58])
    defparam i4_4_lut_adj_382.init = 16'h8000;
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(I1_32), .B(n9942), .C(THO[1]), 
         .D(THO[0]), .Z(CNT1_N_565_adj_1573)) /* synthesis lut_function=(A (B (C)+!B !(C (D)+!C !(D)))+!A !(C (D)+!C !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1084[17:33])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h87f0;
    LUT4 i1_2_lut_adj_383 (.A(THO[0]), .B(THO[3]), .Z(n6_adj_1572)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1089[15:58])
    defparam i1_2_lut_adj_383.init = 16'h8888;
    LUT4 CNT_I_0_19_2_lut_rep_232_3_lut_4_lut (.A(I1_32), .B(n9942), .C(THO[1]), 
         .D(THO[0]), .Z(n9837)) /* synthesis lut_function=(!(A (B+!(C (D)))+!A !(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1084[17:33])
    defparam CNT_I_0_19_2_lut_rep_232_3_lut_4_lut.init = 16'h7000;
    LUT4 FV_2__I_243_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[4]), .D(DBIN[0]), 
         .Z(FV_2__N_837)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1128[50:85])
    defparam FV_2__I_243_4_lut.init = 16'heca0;
    LUT4 i4617_3_lut_4_lut (.A(n9975), .B(n10442), .C(TV[1]), .D(CNT1_adj_1574), 
         .Z(n5126)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i4617_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4619_3_lut_4_lut (.A(n9975), .B(n10442), .C(TV[0]), .D(CNT1_adj_1575), 
         .Z(n5128)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i4619_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4427_3_lut_4_lut (.A(n9975), .B(n10442), .C(FV[0]), .D(n4935), 
         .Z(n4936)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i4427_3_lut_4_lut.init = 16'hfd20;
    LUT4 i3977_3_lut_4_lut (.A(n9975), .B(n10442), .C(FV[2]), .D(n4485), 
         .Z(n4486)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i3977_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4003_3_lut_4_lut (.A(n9975), .B(n10442), .C(NTV), .D(n4511), 
         .Z(n4512)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i4003_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4261_3_lut_4_lut (.A(n9975), .B(n10442), .C(FV[1]), .D(n4769), 
         .Z(n4770)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i4261_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4614_3_lut_4_lut (.A(n9975), .B(n10442), .C(TV[2]), .D(CNT1_adj_1576), 
         .Z(n5123)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i4614_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4612_3_lut_4_lut (.A(n9975), .B(n10442), .C(TV[3]), .D(CNT1_adj_1577), 
         .Z(n5121)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i4612_3_lut_4_lut.init = 16'hfd20;
    LUT4 i4610_3_lut_4_lut (.A(n9975), .B(n10442), .C(TV[4]), .D(CNT1_adj_1578), 
         .Z(n5119)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1079[18:59])
    defparam i4610_3_lut_4_lut.init = 16'hfd20;
    LUT4 PCLK_I_0_2_lut_rep_300 (.A(n10442), .B(SH2), .Z(Clk_enable_68)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1131[12:22])
    defparam PCLK_I_0_2_lut_rep_300.init = 16'h8888;
    LUT4 ATR_IN0_2__N_1361_I_0_356_2_lut_3_lut (.A(n10442), .B(SH2), .C(SEL_LATCH[1]), 
         .Z(ATR_IN1_2__N_1362)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1131[12:22])
    defparam ATR_IN0_2__N_1361_I_0_356_2_lut_3_lut.init = 16'h8080;
    PFUMX PAMUX_7__I_0_i2 (.BLUT(\PAMUX_7__N_859[1] ), .ALUT(PAMUX_7__N_851[1]), 
          .C0(n8992), .Z(PAMUX[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;
    PFUMX PAMUX_7__I_0_i3 (.BLUT(\PAMUX_7__N_859[2] ), .ALUT(PAMUX_7__N_851[2]), 
          .C0(n8992), .Z(PAMUX[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;
    PFUMX PAMUX_7__I_0_i4 (.BLUT(\PAMUX_7__N_859[3] ), .ALUT(PAMUX_7__N_851[3]), 
          .C0(n8992), .Z(PAMUX[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;
    PFUMX PAMUX_7__I_0_i5 (.BLUT(\PAMUX_7__N_859[4] ), .ALUT(PAMUX_7__N_851[4]), 
          .C0(n8992), .Z(PAMUX[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;
    PFUMX PAMUX_7__I_0_i6 (.BLUT(\PAMUX_7__N_859[5] ), .ALUT(PAMUX_7__N_851[5]), 
          .C0(n8992), .Z(PAMUX[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;
    LUT4 PAMUX_7__I_244_i8_4_lut (.A(\TVO[2] ), .B(TP_c[6]), .C(n9892), 
         .D(n9925), .Z(PAMUX_7__N_851[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C+(D))+!B !(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1111[43:128])
    defparam PAMUX_7__I_244_i8_4_lut.init = 16'hcfca;
    PFUMX PAMUX_7__I_0_i1 (.BLUT(\PAMUX_7__N_859[0] ), .ALUT(PAMUX_7__N_851[0]), 
          .C0(n8992), .Z(PAMUX[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;
    LUT4 PAMUX_7__I_244_i7_4_lut (.A(TVO1), .B(TP_c[5]), .C(n9892), .D(n9925), 
         .Z(PAMUX_7__N_851[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C+(D))+!B !(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1111[43:128])
    defparam PAMUX_7__I_244_i7_4_lut.init = 16'hcfca;
    FD1P3IX NTH_237 (.D(NTH_N_899), .SP(Clk_enable_549), .CD(RC), .CK(Clk), 
            .Q(NTH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam NTH_237.GSR = "DISABLED";
    FD1P3IX NTV_238 (.D(NTV_N_906), .SP(Clk_enable_549), .CD(RC), .CK(Clk), 
            .Q(NTV));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam NTV_238.GSR = "DISABLED";
    FD1P3IX PAD_i0_i13 (.D(NBFVO1), .SP(Clk_enable_560), .CD(n5110), .CK(Clk), 
            .Q(PA13_c_13)) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=320, LSE_RLINE=355 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1115[8] 1159[26])
    defparam PAD_i0_i13.GSR = "DISABLED";
    COUNTER_U63 TVCNT_4 (.CNT1(CNT1_adj_1578), .Clk(Clk), .Clk_enable_393(Clk_enable_393), 
            .CNT1_N_565(CNT1_N_565_adj_1579), .\TVO[4] (\TVO[4] ), .Clk_enable_542(Clk_enable_542), 
            .ZTV_N_928(ZTV_N_928), .n5119(n5119)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1100[9:115])
    COUNTER_U64 TVCNT_3 (.CNT1(CNT1_adj_1577), .Clk(Clk), .Clk_enable_393(Clk_enable_393), 
            .CNT1_N_565(CNT1_N_565_adj_1580), .\TVO[3] (\TVO[3] ), .Clk_enable_542(Clk_enable_542), 
            .ZTV_N_928(ZTV_N_928), .n5121(n5121)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1100[9:115])
    COUNTER_U65 TVCNT_2 (.CNT1(CNT1_adj_1576), .Clk(Clk), .Clk_enable_393(Clk_enable_393), 
            .CNT1_N_565(CNT1_N_565_adj_1581), .\TVO[2] (\TVO[2] ), .n9930(n9930), 
            .\TVO[3] (\TVO[3] ), .\TVO[4] (\TVO[4] ), .CNT1_N_565_adj_10(CNT1_N_565_adj_1579), 
            .Clk_enable_542(Clk_enable_542), .ZTV_N_928(ZTV_N_928), .n5123(n5123)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1100[9:115])
    COUNTER_U66 TVCNT_1 (.TVO1(TVO1), .n9961(n9961), .\TVO[3] (\TVO[3] ), 
            .\TVO[2] (\TVO[2] ), .CNT1_N_565(CNT1_N_565_adj_1580), .CNT1(CNT1_adj_1574), 
            .Clk(Clk), .Clk_enable_393(Clk_enable_393), .CNT1_N_565_adj_9(CNT1_N_565_adj_1582), 
            .Clk_enable_542(Clk_enable_542), .ZTV_N_928(ZTV_N_928), .n5126(n5126)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1100[9:115])
    COUNTER_U67 TVCNT_0 (.\TVO[0] (\TVO[0] ), .TV_IN(TV_IN), .n9961(n9961), 
            .TVO1(TVO1), .n9930(n9930), .CNT1_N_565(CNT1_N_565_adj_1582), 
            .\TVO[2] (\TVO[2] ), .CNT1_N_565_adj_8(CNT1_N_565_adj_1581), 
            .CNT1(CNT1_adj_1575), .Clk(Clk), .Clk_enable_393(Clk_enable_393), 
            .Clk_enable_542(Clk_enable_542), .ZTV_N_928(ZTV_N_928), .n5128(n5128)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1100[9:115])
    COUNTER_U68 THCNT_4 (.Clk(Clk), .Clk_enable_563(Clk_enable_563), .CNT1_N_565(CNT1_N_565_adj_1583), 
            .\THO[4] (THO[4]), .\TH[4] (TH[4]), .THLOAD_N_916(THLOAD_N_916), 
            .THSTEP_N_923(THSTEP_N_923)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1099[9:115])
    COUNTER_U69 THCNT_3 (.Clk(Clk), .Clk_enable_563(Clk_enable_563), .CNT1_N_565(CNT1_N_565_adj_1584), 
            .\THO[3] (THO[3]), .\TH[3] (TH[3]), .THLOAD_N_916(THLOAD_N_916), 
            .THSTEP_N_923(THSTEP_N_923)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1099[9:115])
    COUNTER_U70 THCNT_2 (.\THO[2] (THO[2]), .Clk(Clk), .\TH[2] (TH[2]), 
            .THLOAD_N_916(THLOAD_N_916), .THSTEP_N_923(THSTEP_N_923), .Clk_enable_563(Clk_enable_563), 
            .CNT1_N_565(CNT1_N_565_adj_1585), .n9837(n9837), .\THO[3] (THO[3]), 
            .\THO[4] (THO[4]), .CNT1_N_565_adj_7(CNT1_N_565_adj_1583)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1099[9:115])
    COUNTER_U71 THCNT_1 (.Clk(Clk), .Clk_enable_511(Clk_enable_511), .CNT1_N_565(CNT1_N_565_adj_1573), 
            .\TH[1] (TH[1]), .THLOAD_N_916(THLOAD_N_916), .\THO[1] (THO[1]), 
            .THSTEP_N_923(THSTEP_N_923), .n9868(n9868), .\THO[3] (THO[3]), 
            .\THO[2] (THO[2]), .CNT1_N_565_adj_6(CNT1_N_565_adj_1584)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1099[9:115])
    COUNTER_U72 THCNT_0 (.Clk(Clk), .Clk_enable_560(Clk_enable_560), .CNT1_N_565(CNT1_N_565), 
            .\THO[0] (THO[0]), .n9911(n9911), .\THO[2] (THO[2]), .\THO[1] (THO[1]), 
            .CNT1_N_565_adj_5(CNT1_N_565_adj_1585), .\TH[0] (TH[0]), .THLOAD_N_916(THLOAD_N_916), 
            .THSTEP_N_923(THSTEP_N_923)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1099[9:115])
    COUNTER_U73 NTVCNT (.CNT1(CNT1), .Clk(Clk), .Clk_enable_563(Clk_enable_563), 
            .NTVDO(NTVDO), .n4512(n4512), .NTV_IN(NTV_IN)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1102[9:107])
    COUNTER_U74 NTHCNT (.Clk(Clk), .Clk_enable_560(Clk_enable_560), .NTHDO(NTHDO), 
            .n9942(n9942), .TVZB(TVZB), .n8829(n8829), .NTH(NTH), .THLOAD_N_916(THLOAD_N_916), 
            .THSTEP_N_923(THSTEP_N_923)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1101[9:107])
    COUNTER_U75 FVCNT_2 (.\FVO[2] (FVO[2]), .Clk(Clk), .n4486(n4486), 
            .CNT1(CNT1_adj_1571), .Clk_enable_563(Clk_enable_563), .CNT1_N_565(CNT1_N_565_adj_1587)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1103[9:115])
    COUNTER_U76 FVCNT_1 (.CNT1(CNT1_adj_1570), .Clk(Clk), .Clk_enable_563(Clk_enable_563), 
            .CNT1_N_565(CNT1_N_565_adj_1588), .\FVO[1] (\FVO[1] ), .n4770(n4770)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1103[9:115])
    COUNTER_U77 FVCNT_0 (.CNT1(CNT1_adj_1569), .Clk(Clk), .Clk_enable_563(Clk_enable_563), 
            .CNT1_N_565(CNT1_N_565_c), .FVO({FVO[2], \FVO[1] , FVO[0]}), 
            .n4936(n4936), .n9863(n9863), .CNT1_N_565_adj_3(CNT1_N_565_adj_1588), 
            .CNT1_N_565_adj_4(CNT1_N_565_adj_1587)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1103[9:115])
    
endmodule
//
// Verilog Description of module COUNTER_U63
//

module COUNTER_U63 (CNT1, Clk, Clk_enable_393, CNT1_N_565, \TVO[4] , 
            Clk_enable_542, ZTV_N_928, n5119) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input Clk_enable_393;
    input CNT1_N_565;
    output \TVO[4] ;
    input Clk_enable_542;
    input ZTV_N_928;
    input n5119;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_393), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(n5119), .SP(Clk_enable_542), .CK(Clk), .CD(ZTV_N_928), 
            .Q(\TVO[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U64
//

module COUNTER_U64 (CNT1, Clk, Clk_enable_393, CNT1_N_565, \TVO[3] , 
            Clk_enable_542, ZTV_N_928, n5121) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input Clk_enable_393;
    input CNT1_N_565;
    output \TVO[3] ;
    input Clk_enable_542;
    input ZTV_N_928;
    input n5121;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_393), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(n5121), .SP(Clk_enable_542), .CK(Clk), .CD(ZTV_N_928), 
            .Q(\TVO[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U65
//

module COUNTER_U65 (CNT1, Clk, Clk_enable_393, CNT1_N_565, \TVO[2] , 
            n9930, \TVO[3] , \TVO[4] , CNT1_N_565_adj_10, Clk_enable_542, 
            ZTV_N_928, n5123) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input Clk_enable_393;
    input CNT1_N_565;
    output \TVO[2] ;
    input n9930;
    input \TVO[3] ;
    input \TVO[4] ;
    output CNT1_N_565_adj_10;
    input Clk_enable_542;
    input ZTV_N_928;
    input n5123;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_393), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_3_lut_4_lut (.A(\TVO[2] ), .B(n9930), .C(\TVO[3] ), .D(\TVO[4] ), 
         .Z(CNT1_N_565_adj_10)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_3_lut_4_lut.init = 16'h7f80;
    FD1P3DX CNT_14 (.D(n5123), .SP(Clk_enable_542), .CK(Clk), .CD(ZTV_N_928), 
            .Q(\TVO[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U66
//

module COUNTER_U66 (TVO1, n9961, \TVO[3] , \TVO[2] , CNT1_N_565, CNT1, 
            Clk, Clk_enable_393, CNT1_N_565_adj_9, Clk_enable_542, ZTV_N_928, 
            n5126) /* synthesis syn_module_defined=1 */ ;
    output TVO1;
    input n9961;
    input \TVO[3] ;
    input \TVO[2] ;
    output CNT1_N_565;
    output CNT1;
    input Clk;
    input Clk_enable_393;
    input CNT1_N_565_adj_9;
    input Clk_enable_542;
    input ZTV_N_928;
    input n5126;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(TVO1), .B(n9961), .C(\TVO[3] ), 
         .D(\TVO[2] ), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h78f0;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_9), .SP(Clk_enable_393), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(n5126), .SP(Clk_enable_542), .CK(Clk), .CD(ZTV_N_928), 
            .Q(TVO1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U67
//

module COUNTER_U67 (\TVO[0] , TV_IN, n9961, TVO1, n9930, CNT1_N_565, 
            \TVO[2] , CNT1_N_565_adj_8, CNT1, Clk, Clk_enable_393, 
            Clk_enable_542, ZTV_N_928, n5128) /* synthesis syn_module_defined=1 */ ;
    output \TVO[0] ;
    input TV_IN;
    output n9961;
    input TVO1;
    output n9930;
    output CNT1_N_565;
    input \TVO[2] ;
    output CNT1_N_565_adj_8;
    output CNT1;
    input Clk;
    input Clk_enable_393;
    input Clk_enable_542;
    input ZTV_N_928;
    input n5128;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565_adj_1566;
    
    LUT4 CNT_I_0_19_2_lut_rep_356 (.A(\TVO[0] ), .B(TV_IN), .Z(n9961)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_rep_356.init = 16'h8888;
    LUT4 CNT_I_0_19_2_lut_rep_325_3_lut (.A(\TVO[0] ), .B(TV_IN), .C(TVO1), 
         .Z(n9930)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_rep_325_3_lut.init = 16'h8080;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\TVO[0] ), .B(TV_IN), .C(TVO1), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\TVO[0] ), .B(TV_IN), .C(\TVO[2] ), 
         .D(TVO1), .Z(CNT1_N_565_adj_8)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h78f0;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1566), .SP(Clk_enable_393), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut (.A(\TVO[0] ), .B(TV_IN), .Z(CNT1_N_565_adj_1566)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    FD1P3DX CNT_14 (.D(n5128), .SP(Clk_enable_542), .CK(Clk), .CD(ZTV_N_928), 
            .Q(\TVO[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U68
//

module COUNTER_U68 (Clk, Clk_enable_563, CNT1_N_565, \THO[4] , \TH[4] , 
            THLOAD_N_916, THSTEP_N_923) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_563;
    input CNT1_N_565;
    output \THO[4] ;
    input \TH[4] ;
    input THLOAD_N_916;
    input THSTEP_N_923;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, n4519, n4518;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_563), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n4519), .CK(Clk), .Q(\THO[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i4010_3_lut (.A(n4518), .B(\TH[4] ), .C(THLOAD_N_916), .Z(n4519)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i4010_3_lut.init = 16'hacac;
    LUT4 i4009_3_lut (.A(\THO[4] ), .B(CNT1), .C(THSTEP_N_923), .Z(n4518)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i4009_3_lut.init = 16'hacac;
    
endmodule
//
// Verilog Description of module COUNTER_U69
//

module COUNTER_U69 (Clk, Clk_enable_563, CNT1_N_565, \THO[3] , \TH[3] , 
            THLOAD_N_916, THSTEP_N_923) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_563;
    input CNT1_N_565;
    output \THO[3] ;
    input \TH[3] ;
    input THLOAD_N_916;
    input THSTEP_N_923;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, n4476, n4475;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_563), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n4476), .CK(Clk), .Q(\THO[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i3967_3_lut (.A(n4475), .B(\TH[3] ), .C(THLOAD_N_916), .Z(n4476)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i3967_3_lut.init = 16'hacac;
    LUT4 i3966_3_lut (.A(\THO[3] ), .B(CNT1), .C(THSTEP_N_923), .Z(n4475)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i3966_3_lut.init = 16'hacac;
    
endmodule
//
// Verilog Description of module COUNTER_U70
//

module COUNTER_U70 (\THO[2] , Clk, \TH[2] , THLOAD_N_916, THSTEP_N_923, 
            Clk_enable_563, CNT1_N_565, n9837, \THO[3] , \THO[4] , 
            CNT1_N_565_adj_7) /* synthesis syn_module_defined=1 */ ;
    output \THO[2] ;
    input Clk;
    input \TH[2] ;
    input THLOAD_N_916;
    input THSTEP_N_923;
    input Clk_enable_563;
    input CNT1_N_565;
    input n9837;
    input \THO[3] ;
    input \THO[4] ;
    output CNT1_N_565_adj_7;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire n4488, n4487, CNT1;
    
    FD1S3AX CNT_14 (.D(n4488), .CK(Clk), .Q(\THO[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i3979_3_lut (.A(n4487), .B(\TH[2] ), .C(THLOAD_N_916), .Z(n4488)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i3979_3_lut.init = 16'hacac;
    LUT4 i3978_3_lut (.A(\THO[2] ), .B(CNT1), .C(THSTEP_N_923), .Z(n4487)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i3978_3_lut.init = 16'hacac;
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_563), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_3_lut_4_lut (.A(\THO[2] ), .B(n9837), .C(\THO[3] ), .D(\THO[4] ), 
         .Z(CNT1_N_565_adj_7)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_3_lut_4_lut.init = 16'h7f80;
    
endmodule
//
// Verilog Description of module COUNTER_U71
//

module COUNTER_U71 (Clk, Clk_enable_511, CNT1_N_565, \TH[1] , THLOAD_N_916, 
            \THO[1] , THSTEP_N_923, n9868, \THO[3] , \THO[2] , CNT1_N_565_adj_6) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_511;
    input CNT1_N_565;
    input \TH[1] ;
    input THLOAD_N_916;
    output \THO[1] ;
    input THSTEP_N_923;
    input n9868;
    input \THO[3] ;
    input \THO[2] ;
    output CNT1_N_565_adj_6;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, n4901, n4902;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_511), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i4393_3_lut (.A(n4901), .B(\TH[1] ), .C(THLOAD_N_916), .Z(n4902)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i4393_3_lut.init = 16'hacac;
    LUT4 i4392_3_lut (.A(\THO[1] ), .B(CNT1), .C(THSTEP_N_923), .Z(n4901)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i4392_3_lut.init = 16'hacac;
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\THO[1] ), .B(n9868), .C(\THO[3] ), 
         .D(\THO[2] ), .Z(CNT1_N_565_adj_6)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h78f0;
    FD1S3AX CNT_14 (.D(n4902), .CK(Clk), .Q(\THO[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U72
//

module COUNTER_U72 (Clk, Clk_enable_560, CNT1_N_565, \THO[0] , n9911, 
            \THO[2] , \THO[1] , CNT1_N_565_adj_5, \TH[0] , THLOAD_N_916, 
            THSTEP_N_923) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_560;
    input CNT1_N_565;
    output \THO[0] ;
    input n9911;
    input \THO[2] ;
    input \THO[1] ;
    output CNT1_N_565_adj_5;
    input \TH[0] ;
    input THLOAD_N_916;
    input THSTEP_N_923;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, n4630, n4629;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_560), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\THO[0] ), .B(n9911), .C(\THO[2] ), 
         .D(\THO[1] ), .Z(CNT1_N_565_adj_5)) /* synthesis lut_function=(A (B (C)+!B !(C (D)+!C !(D)))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'hd2f0;
    FD1S3AX CNT_14 (.D(n4630), .CK(Clk), .Q(\THO[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 i4121_3_lut (.A(n4629), .B(\TH[0] ), .C(THLOAD_N_916), .Z(n4630)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i4121_3_lut.init = 16'hacac;
    LUT4 i4120_3_lut (.A(\THO[0] ), .B(CNT1), .C(THSTEP_N_923), .Z(n4629)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i4120_3_lut.init = 16'hacac;
    
endmodule
//
// Verilog Description of module COUNTER_U73
//

module COUNTER_U73 (CNT1, Clk, Clk_enable_563, NTVDO, n4512, NTV_IN) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input Clk_enable_563;
    output NTVDO;
    input n4512;
    input NTV_IN;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1_N_565;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_563), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n4512), .CK(Clk), .Q(NTVDO));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut (.A(NTVDO), .B(NTV_IN), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    
endmodule
//
// Verilog Description of module COUNTER_U74
//

module COUNTER_U74 (Clk, Clk_enable_560, NTHDO, n9942, TVZB, n8829, 
            NTH, THLOAD_N_916, THSTEP_N_923) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_560;
    output NTHDO;
    input n9942;
    input TVZB;
    input n8829;
    input NTH;
    input THLOAD_N_916;
    input THSTEP_N_923;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, CNT1_N_565, n4530, n4529;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_560), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n4530), .CK(Clk), .Q(NTHDO));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_4_lut (.A(NTHDO), .B(n9942), .C(TVZB), .D(n8829), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C)+!B (C+(D)))+!A !(B (C)+!B (C+(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_4_lut.init = 16'h595a;
    LUT4 i4021_3_lut (.A(n4529), .B(NTH), .C(THLOAD_N_916), .Z(n4530)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i4021_3_lut.init = 16'hacac;
    LUT4 i4020_3_lut (.A(NTHDO), .B(CNT1), .C(THSTEP_N_923), .Z(n4529)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam i4020_3_lut.init = 16'hacac;
    
endmodule
//
// Verilog Description of module COUNTER_U75
//

module COUNTER_U75 (\FVO[2] , Clk, n4486, CNT1, Clk_enable_563, CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    output \FVO[2] ;
    input Clk;
    input n4486;
    output CNT1;
    input Clk_enable_563;
    input CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1S3AX CNT_14 (.D(n4486), .CK(Clk), .Q(\FVO[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_563), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U76
//

module COUNTER_U76 (CNT1, Clk, Clk_enable_563, CNT1_N_565, \FVO[1] , 
            n4770) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input Clk_enable_563;
    input CNT1_N_565;
    output \FVO[1] ;
    input n4770;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_563), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n4770), .CK(Clk), .Q(\FVO[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U77
//

module COUNTER_U77 (CNT1, Clk, Clk_enable_563, CNT1_N_565, FVO, n4936, 
            n9863, CNT1_N_565_adj_3, CNT1_N_565_adj_4) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input Clk_enable_563;
    input CNT1_N_565;
    input [2:0]FVO;
    input n4936;
    input n9863;
    output CNT1_N_565_adj_3;
    output CNT1_N_565_adj_4;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_563), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1S3AX CNT_14 (.D(n4936), .CK(Clk), .Q(FVO[0]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut_3_lut (.A(FVO[0]), .B(n9863), .C(FVO[1]), .Z(CNT1_N_565_adj_3)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    LUT4 CNT_I_0_3_lut_4_lut (.A(FVO[0]), .B(n9863), .C(FVO[1]), .D(FVO[2]), 
         .Z(CNT1_N_565_adj_4)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_3_lut_4_lut.init = 16'h7f80;
    
endmodule
//
// Verilog Description of module OAM
//

module OAM (ORES_LATCH, Clk, Clk_enable_571, nEVAL, OVF_LATCH, OMFG_LATCH, 
            OMFG, n9828, I_OAM2, W4Q, Clk_enable_563, \W4Q[2] , 
            OMSTEP_1__N_1053, OMV_LATCH, OB2_7__N_1043, OB, \OAM1ADR[7] , 
            \OSTEP[0] , OAMCTR2, \OAM1ADR[0] , n9826, W4, PAR_O, 
            \Hn[0] , \Hn[2] , OAM2STEP_N_1107, n10442, n9942, \R2DB[0] , 
            n3985, SPR_OV, n8599, n9864, n9983, W3, Clk_enable_562, 
            OAP_N_1091, n8, \Hnn[0] , n5086, VCC_net, GND_net, OAMQ_7__N_1041, 
            DBIN, n5081, n5079, \CNT1[7] , CNT_7__N_1140, n6437, 
            \CNT1[0] , Clk_enable_543, OAM2STEP_N_1104, ORES, Clk_enable_173) /* synthesis syn_module_defined=1 */ ;
    output ORES_LATCH;
    input Clk;
    input Clk_enable_571;
    input nEVAL;
    output OVF_LATCH;
    output OMFG_LATCH;
    input OMFG;
    input n9828;
    input I_OAM2;
    output [4:0]W4Q;
    input Clk_enable_563;
    output \W4Q[2] ;
    input OMSTEP_1__N_1053;
    output OMV_LATCH;
    input OB2_7__N_1043;
    output [7:0]OB;
    output \OAM1ADR[7] ;
    output \OSTEP[0] ;
    output OAMCTR2;
    output \OAM1ADR[0] ;
    input n9826;
    input W4;
    input PAR_O;
    input \Hn[0] ;
    input \Hn[2] ;
    output OAM2STEP_N_1107;
    input n10442;
    input n9942;
    output \R2DB[0] ;
    input n3985;
    output SPR_OV;
    input n8599;
    input n9864;
    output n9983;
    input W3;
    output Clk_enable_562;
    input OAP_N_1091;
    input n8;
    input \Hnn[0] ;
    input n5086;
    input VCC_net;
    input GND_net;
    input OAMQ_7__N_1041;
    input [7:0]DBIN;
    input n5081;
    input n5079;
    output \CNT1[7] ;
    input CNT_7__N_1140;
    input n6437;
    output \CNT1[0] ;
    input Clk_enable_543;
    input OAM2STEP_N_1104;
    input ORES;
    input Clk_enable_173;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire OAMCTR2_N_1061;
    wire [7:0]OAM1ADR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1267[11:18])
    
    wire n9948, n9850;
    wire [2:0]OSTEP;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1247[10:15])
    
    wire n9950;
    wire [4:0]W4Q_c;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1244[10:13])
    
    wire W4Q_2__N_1014;
    wire [1:0]OMSTEP;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1245[10:16])
    
    wire OMV_LATCH_N_1075, TMV_LATCH, C_OUT_N_563;
    wire [7:0]OB2;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1251[10:13])
    
    wire n9886, n3531, OFETCH_N_1090, W4Q_2__N_1019, OSTEP_2__N_1059, 
        n9922, Clk_enable_248, OAM2STEP_N_1114, n9954, OBDZ_2__N_1038, 
        n8856, Clk_enable_246, W4FF;
    wire [7:0]OAM1Cout;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1682[11:19])
    wire [7:0]CNT1_7__N_1142;
    wire [7:0]OAMQ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1275[11:15])
    wire [7:0]OAM2Q;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1275[17:22])
    wire [7:0]n115;
    
    wire WE, CNT1_N_565;
    wire [4:0]OAM2ADR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1266[11:18])
    
    wire CNT1_N_565_adj_1558, n9947, CNT1_N_565_adj_1559;
    
    FD1P3AX ORES_LATCH_123 (.D(nEVAL), .SP(Clk_enable_571), .CK(Clk), 
            .Q(ORES_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam ORES_LATCH_123.GSR = "DISABLED";
    FD1P3AX OVF_LATCH_124 (.D(OAMCTR2_N_1061), .SP(Clk_enable_571), .CK(Clk), 
            .Q(OVF_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OVF_LATCH_124.GSR = "DISABLED";
    FD1P3AX OMFG_LATCH_125 (.D(OMFG), .SP(Clk_enable_571), .CK(Clk), .Q(OMFG_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OMFG_LATCH_125.GSR = "DISABLED";
    LUT4 i1_2_lut_rep_245_3_lut_4_lut (.A(OAM1ADR[4]), .B(n9948), .C(OAM1ADR[6]), 
         .D(OAM1ADR[5]), .Z(n9850)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1298[30:43])
    defparam i1_2_lut_rep_245_3_lut_4_lut.init = 16'h8000;
    FD1P3AX OSTEP_i0_i2 (.D(n9828), .SP(Clk_enable_571), .CK(Clk), .Q(OSTEP[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OSTEP_i0_i2.GSR = "DISABLED";
    FD1P3AX OSTEP_i0_i1 (.D(I_OAM2), .SP(Clk_enable_571), .CK(Clk), .Q(OSTEP[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OSTEP_i0_i1.GSR = "DISABLED";
    FD1P3AX W4Q_i4 (.D(n9950), .SP(Clk_enable_563), .CK(Clk), .Q(W4Q[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam W4Q_i4.GSR = "DISABLED";
    FD1P3AX W4Q_i3 (.D(W4Q_2__N_1014), .SP(Clk_enable_571), .CK(Clk), 
            .Q(W4Q_c[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam W4Q_i3.GSR = "DISABLED";
    FD1P3AX W4Q_i2 (.D(W4Q_c[1]), .SP(Clk_enable_563), .CK(Clk), .Q(\W4Q[2] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam W4Q_i2.GSR = "DISABLED";
    FD1P3AX W4Q_i1 (.D(W4Q_c[0]), .SP(Clk_enable_571), .CK(Clk), .Q(W4Q_c[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam W4Q_i1.GSR = "DISABLED";
    FD1P3AX OMSTEP_i0_i1 (.D(OMSTEP_1__N_1053), .SP(Clk_enable_571), .CK(Clk), 
            .Q(OMSTEP[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OMSTEP_i0_i1.GSR = "DISABLED";
    FD1P3AX OMV_LATCH_126 (.D(OMV_LATCH_N_1075), .SP(Clk_enable_571), .CK(Clk), 
            .Q(OMV_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OMV_LATCH_126.GSR = "DISABLED";
    FD1P3AX TMV_LATCH_127 (.D(C_OUT_N_563), .SP(Clk_enable_571), .CK(Clk), 
            .Q(TMV_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam TMV_LATCH_127.GSR = "DISABLED";
    FD1P3AX OB2_i0_i0 (.D(OB[0]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i0.GSR = "DISABLED";
    LUT4 i2_3_lut_4_lut (.A(OAM1ADR[6]), .B(n9886), .C(\OAM1ADR[7] ), 
         .D(n3531), .Z(OMV_LATCH_N_1075)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1298[30:43])
    defparam i2_3_lut_4_lut.init = 16'h8000;
    FD1P3AX OMSTEP_i0_i0 (.D(OFETCH_N_1090), .SP(Clk_enable_571), .CK(Clk), 
            .Q(OMSTEP[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OMSTEP_i0_i0.GSR = "DISABLED";
    FD1P3AX W4Q_i0 (.D(W4Q_2__N_1019), .SP(Clk_enable_563), .CK(Clk), 
            .Q(W4Q_c[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam W4Q_i0.GSR = "DISABLED";
    FD1P3AX OSTEP_i0_i0 (.D(OSTEP_2__N_1059), .SP(Clk_enable_571), .CK(Clk), 
            .Q(\OSTEP[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OSTEP_i0_i0.GSR = "DISABLED";
    LUT4 OAMCTR2_I_0_1_lut (.A(OAMCTR2), .Z(OAMCTR2_N_1061)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1294[51:59])
    defparam OAMCTR2_I_0_1_lut.init = 16'h5555;
    FD1P3AX OB2_i0_i7 (.D(OB[7]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i7.GSR = "DISABLED";
    FD1P3AX OB2_i0_i6 (.D(OB[6]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i6.GSR = "DISABLED";
    FD1P3AX OB2_i0_i5 (.D(OB[5]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i5.GSR = "DISABLED";
    FD1P3AX OB2_i0_i4 (.D(OB[4]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i4.GSR = "DISABLED";
    FD1P3AX OB2_i0_i3 (.D(OB[3]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i3.GSR = "DISABLED";
    FD1P3AX OB2_i0_i2 (.D(OB[2]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i2.GSR = "DISABLED";
    FD1P3AX OB2_i0_i1 (.D(OB[1]), .SP(OB2_7__N_1043), .CK(Clk), .Q(OB2[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB2_i0_i1.GSR = "DISABLED";
    LUT4 i1_2_lut_rep_343 (.A(OAM1ADR[2]), .B(OAM1ADR[3]), .Z(n9948)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1298[30:43])
    defparam i1_2_lut_rep_343.init = 16'h8888;
    LUT4 i1_2_lut_rep_317_3_lut (.A(OAM1ADR[2]), .B(OAM1ADR[3]), .C(OAM1ADR[4]), 
         .Z(n9922)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1298[30:43])
    defparam i1_2_lut_rep_317_3_lut.init = 16'h8080;
    LUT4 i1_2_lut_rep_281_3_lut_4_lut (.A(OAM1ADR[2]), .B(OAM1ADR[3]), .C(OAM1ADR[5]), 
         .D(OAM1ADR[4]), .Z(n9886)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1298[30:43])
    defparam i1_2_lut_rep_281_3_lut_4_lut.init = 16'h8000;
    LUT4 i3027_4_lut_3_lut (.A(\OAM1ADR[0] ), .B(OAM1ADR[1]), .C(n9826), 
         .Z(n3531)) /* synthesis lut_function=(A (B (C))+!A !(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1298[74:87])
    defparam i3027_4_lut_3_lut.init = 16'h8181;
    LUT4 W4Q_3__I_0_1_lut_rep_345 (.A(W4Q_c[3]), .Z(n9950)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1289[49:56])
    defparam W4Q_3__I_0_1_lut_rep_345.init = 16'h5555;
    LUT4 i1_2_lut_2_lut (.A(W4Q_c[3]), .B(W4), .Z(Clk_enable_248)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1289[49:56])
    defparam i1_2_lut_2_lut.init = 16'hdddd;
    LUT4 OAM2STEP_I_308_4_lut (.A(PAR_O), .B(\Hn[0] ), .C(\Hn[2] ), .D(OAM2STEP_N_1114), 
         .Z(OAM2STEP_N_1107)) /* synthesis lut_function=(!(A (B (C)+!B !((D)+!C))+!A (B+!(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1263[42:97])
    defparam OAM2STEP_I_308_4_lut.init = 16'h3b0a;
    LUT4 OSTEP_1__I_0_2_lut (.A(OSTEP[1]), .B(OSTEP[2]), .Z(OAM2STEP_N_1114)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1263[72:95])
    defparam OSTEP_1__I_0_2_lut.init = 16'heeee;
    LUT4 OAM1ADR_0__I_0_1_lut_rep_349 (.A(\OAM1ADR[0] ), .Z(n9954)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1265[52:63])
    defparam OAM1ADR_0__I_0_1_lut_rep_349.init = 16'h5555;
    LUT4 OAM1ADR_1__I_0_137_2_lut_2_lut (.A(\OAM1ADR[0] ), .B(OAM1ADR[1]), 
         .Z(OBDZ_2__N_1038)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1265[52:63])
    defparam OAM1ADR_1__I_0_137_2_lut_2_lut.init = 16'h4444;
    LUT4 i1_4_lut (.A(n10442), .B(OAM2STEP_N_1107), .C(ORES_LATCH), .D(n8856), 
         .Z(Clk_enable_246)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))) */ ;
    defparam i1_4_lut.init = 16'h8a0a;
    LUT4 i1_2_lut (.A(TMV_LATCH), .B(\OSTEP[0] ), .Z(n8856)) /* synthesis lut_function=(!((B)+!A)) */ ;
    defparam i1_2_lut.init = 16'h2222;
    LUT4 i8800_2_lut (.A(\W4Q[2] ), .B(W4Q[4]), .Z(OFETCH_N_1090)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1256[17:38])
    defparam i8800_2_lut.init = 16'h2222;
    LUT4 i8804_2_lut (.A(W4), .B(W4FF), .Z(W4Q_2__N_1019)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1289[66:79])
    defparam i8804_2_lut.init = 16'h4444;
    LUT4 i8808_2_lut (.A(nEVAL), .B(OAMCTR2), .Z(OSTEP_2__N_1059)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1294[41:60])
    defparam i8808_2_lut.init = 16'hdddd;
    LUT4 mux_14_i3_3_lut_4_lut (.A(n9828), .B(n9942), .C(OAM1Cout[1]), 
         .D(OAM1ADR[2]), .Z(CNT1_7__N_1142[2])) /* synthesis lut_function=(!(A (C (D)+!C !(D))+!A (B (C (D)+!C !(D))+!B (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1261[14:30])
    defparam mux_14_i3_3_lut_4_lut.init = 16'h0ef1;
    FD1S3AX R2DB5_115 (.D(n3985), .CK(Clk), .Q(\R2DB[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam R2DB5_115.GSR = "DISABLED";
    FD1S3AX SPR_OV_116 (.D(n8599), .CK(Clk), .Q(SPR_OV));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam SPR_OV_116.GSR = "DISABLED";
    FD1P3AX OAMCTR2_117 (.D(n9864), .SP(Clk_enable_246), .CK(Clk), .Q(OAMCTR2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OAMCTR2_117.GSR = "DISABLED";
    FD1P3AX W4FF_114 (.D(W4Q_c[3]), .SP(Clk_enable_248), .CK(Clk), .Q(W4FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam W4FF_114.GSR = "DISABLED";
    LUT4 OAMSTEP_I_304_2_lut_rep_378 (.A(OMSTEP[1]), .B(OMSTEP[0]), .Z(n9983)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1260[19:67])
    defparam OAMSTEP_I_304_2_lut_rep_378.init = 16'h2222;
    LUT4 i8765_2_lut_rep_230_3_lut_3_lut_4_lut (.A(OMSTEP[1]), .B(OMSTEP[0]), 
         .C(W3), .D(n10442), .Z(Clk_enable_562)) /* synthesis lut_function=(!(A (B (C+(D))+!B (C))+!A (C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1260[19:67])
    defparam i8765_2_lut_rep_230_3_lut_3_lut_4_lut.init = 16'h020f;
    LUT4 mux_71_i2_3_lut (.A(OAMQ[1]), .B(OAM2Q[1]), .C(OAP_N_1091), .Z(n115[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i2_3_lut.init = 16'hcaca;
    LUT4 mux_71_i3_4_lut (.A(OAMQ[2]), .B(OAM2Q[2]), .C(OAP_N_1091), .D(OBDZ_2__N_1038), 
         .Z(n115[2])) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i3_4_lut.init = 16'hc0ca;
    LUT4 mux_71_i4_4_lut (.A(OAMQ[3]), .B(OAM2Q[3]), .C(OAP_N_1091), .D(OBDZ_2__N_1038), 
         .Z(n115[3])) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i4_4_lut.init = 16'hc0ca;
    LUT4 mux_71_i5_4_lut (.A(OAMQ[4]), .B(OAM2Q[4]), .C(OAP_N_1091), .D(OBDZ_2__N_1038), 
         .Z(n115[4])) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i5_4_lut.init = 16'hc0ca;
    LUT4 mux_71_i6_3_lut (.A(OAMQ[5]), .B(OAM2Q[5]), .C(OAP_N_1091), .Z(n115[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i6_3_lut.init = 16'hcaca;
    LUT4 OAM1ADR_7__I_0_136_i1_2_lut (.A(\OAM1ADR[0] ), .B(OAM1ADR[1]), 
         .Z(OAM1Cout[1])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1298[74:87])
    defparam OAM1ADR_7__I_0_136_i1_2_lut.init = 16'h8888;
    LUT4 mux_71_i7_3_lut (.A(OAMQ[6]), .B(OAM2Q[6]), .C(OAP_N_1091), .Z(n115[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i7_3_lut.init = 16'hcaca;
    LUT4 mux_71_i8_3_lut (.A(OAMQ[7]), .B(OAM2Q[7]), .C(OAP_N_1091), .Z(n115[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i8_3_lut.init = 16'hcaca;
    LUT4 i8797_4_lut (.A(n9942), .B(OFETCH_N_1090), .C(n8), .D(\Hnn[0] ), 
         .Z(WE)) /* synthesis lut_function=(A (B)+!A (B+!(C+!(D)))) */ ;
    defparam i8797_4_lut.init = 16'hcdcc;
    LUT4 mux_71_i1_3_lut (.A(OAMQ[0]), .B(OAM2Q[0]), .C(OAP_N_1091), .Z(n115[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1292[38:90])
    defparam mux_71_i1_3_lut.init = 16'hcaca;
    LUT4 W4Q_2__I_0_1_lut (.A(\W4Q[2] ), .Z(W4Q_2__N_1014)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1256[20:27])
    defparam W4Q_2__I_0_1_lut.init = 16'h5555;
    FD1P3JX OB_i0_i0 (.D(n115[0]), .SP(Clk_enable_571), .PD(n5086), .CK(Clk), 
            .Q(OB[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i0.GSR = "DISABLED";
    FD1P3JX OB_i0_i1 (.D(n115[1]), .SP(Clk_enable_571), .PD(n5086), .CK(Clk), 
            .Q(OB[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i1.GSR = "DISABLED";
    FD1P3JX OB_i0_i2 (.D(n115[2]), .SP(Clk_enable_571), .PD(n5086), .CK(Clk), 
            .Q(OB[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i2.GSR = "DISABLED";
    FD1P3JX OB_i0_i3 (.D(n115[3]), .SP(Clk_enable_571), .PD(n5086), .CK(Clk), 
            .Q(OB[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i3.GSR = "DISABLED";
    FD1P3JX OB_i0_i4 (.D(n115[4]), .SP(Clk_enable_571), .PD(n5086), .CK(Clk), 
            .Q(OB[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i4.GSR = "DISABLED";
    FD1P3JX OB_i0_i5 (.D(n115[5]), .SP(Clk_enable_571), .PD(n5086), .CK(Clk), 
            .Q(OB[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i5.GSR = "DISABLED";
    FD1P3JX OB_i0_i6 (.D(n115[6]), .SP(Clk_enable_571), .PD(n5086), .CK(Clk), 
            .Q(OB[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i6.GSR = "DISABLED";
    FD1P3JX OB_i0_i7 (.D(n115[7]), .SP(Clk_enable_571), .PD(n5086), .CK(Clk), 
            .Q(OB[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=379, LSE_RLINE=399 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1279[8] 1301[27])
    defparam OB_i0_i7.GSR = "DISABLED";
    OAM_RAM OAMQ_7__I_0 (.Clk(Clk), .VCC_net(VCC_net), .GND_net(GND_net), 
            .OAMQ_7__N_1041(OAMQ_7__N_1041), .OAM1ADR({\OAM1ADR[7] , OAM1ADR[6:1], 
            \OAM1ADR[0] }), .DBIN({DBIN}), .OAMQ({OAMQ})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1276[10:89])
    OAM_COUNTER OAMCNT (.DBIN({DBIN}), .W3(W3), .n5081(n5081), .n9826(n9826), 
            .\OAM1Cout[1] (OAM1Cout[1]), .n9948(n9948), .OAM1ADR({\OAM1ADR[7] , 
            OAM1ADR[6:1], \OAM1ADR[0] }), .n9922(n9922), .n9886(n9886), 
            .Clk(Clk), .PAR_O(PAR_O), .n9850(n9850), .n5079(n5079), 
            .Clk_enable_562(Clk_enable_562), .\CNT1_7__N_1142[2] (CNT1_7__N_1142[2]), 
            .\CNT1[7] (\CNT1[7] ), .CNT_7__N_1140(CNT_7__N_1140), .n6437(n6437), 
            .\CNT1[0] (\CNT1[0] ), .n9954(n9954)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1270[13:77])
    COUNTER_U100 OAM2CNT_4 (.Clk(Clk), .Clk_enable_543(Clk_enable_543), 
            .CNT1_N_565(CNT1_N_565), .\OAM2ADR[4] (OAM2ADR[4]), .OAM2STEP_N_1104(OAM2STEP_N_1104), 
            .ORES(ORES)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1273[9:121])
    COUNTER_U101 OAM2CNT_3 (.\OAM2ADR[3] (OAM2ADR[3]), .Clk(Clk), .OAM2STEP_N_1104(OAM2STEP_N_1104), 
            .ORES(ORES), .Clk_enable_543(Clk_enable_543), .CNT1_N_565(CNT1_N_565_adj_1558)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1273[9:121])
    COUNTER_U102 OAM2CNT_2 (.\OAM2ADR[2] (OAM2ADR[2]), .n9947(n9947), .\OAM2ADR[4] (OAM2ADR[4]), 
            .\OAM2ADR[3] (OAM2ADR[3]), .CNT1_N_565(CNT1_N_565), .C_OUT_N_563(C_OUT_N_563), 
            .Clk(Clk), .Clk_enable_173(Clk_enable_173), .CNT1_N_565_adj_2(CNT1_N_565_adj_1559), 
            .OAM2STEP_N_1104(OAM2STEP_N_1104), .ORES(ORES)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1273[9:121])
    COUNTER_U103 OAM2CNT_1 (.\OAM2ADR[1] (OAM2ADR[1]), .\OAM2ADR[0] (OAM2ADR[0]), 
            .n9947(n9947), .\OAM2ADR[2] (OAM2ADR[2]), .CNT1_N_565(CNT1_N_565_adj_1559), 
            .\OAM2ADR[3] (OAM2ADR[3]), .CNT1_N_565_adj_1(CNT1_N_565_adj_1558), 
            .Clk(Clk), .Clk_enable_173(Clk_enable_173), .OAM2STEP_N_1104(OAM2STEP_N_1104), 
            .ORES(ORES)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1273[9:121])
    COUNTER_U104 OAM2CNT_0 (.\OAM2ADR[0] (OAM2ADR[0]), .Clk(Clk), .OAM2STEP_N_1104(OAM2STEP_N_1104), 
            .ORES(ORES), .Clk_enable_173(Clk_enable_173)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1273[9:121])
    OAM2_RAM MOD_OAM2_RAM (.Clk(Clk), .VCC_net(VCC_net), .GND_net(GND_net), 
            .WE(WE), .OAM2ADR({OAM2ADR}), .OB2({OB2}), .OAM2Q({OAM2Q})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1277[10:90])
    
endmodule
//
// Verilog Description of module OAM_RAM
//

module OAM_RAM (Clk, VCC_net, GND_net, OAMQ_7__N_1041, OAM1ADR, DBIN, 
            OAMQ) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input Clk;
    input VCC_net;
    input GND_net;
    input OAMQ_7__N_1041;
    input [7:0]OAM1ADR;
    input [7:0]DBIN;
    output [7:0]OAMQ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    DP8KC OAM_RAM_0_0_0 (.DIA0(DBIN[0]), .DIA1(DBIN[1]), .DIA2(DBIN[2]), 
          .DIA3(DBIN[3]), .DIA4(DBIN[4]), .DIA5(DBIN[5]), .DIA6(DBIN[6]), 
          .DIA7(DBIN[7]), .DIA8(GND_net), .ADA0(VCC_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(OAM1ADR[0]), .ADA4(OAM1ADR[1]), .ADA5(OAM1ADR[2]), 
          .ADA6(OAM1ADR[3]), .ADA7(OAM1ADR[4]), .ADA8(OAM1ADR[5]), .ADA9(OAM1ADR[6]), 
          .ADA10(OAM1ADR[7]), .ADA11(GND_net), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(OAMQ_7__N_1041), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), 
          .ADB4(GND_net), .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), 
          .ADB8(GND_net), .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), 
          .ADB12(GND_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(GND_net), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(OAMQ[0]), .DOA1(OAMQ[1]), .DOA2(OAMQ[2]), 
          .DOA3(OAMQ[3]), .DOA4(OAMQ[4]), .DOA5(OAMQ[5]), .DOA6(OAMQ[6]), 
          .DOA7(OAMQ[7])) /* synthesis MEM_LPC_FILE="OAM_RAM.lpc", MEM_INIT_FILE="INIT_ALL_0s", syn_instantiated=1, LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=89, LSE_LLINE=1276, LSE_RLINE=1276 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1276[10:89])
    defparam OAM_RAM_0_0_0.DATA_WIDTH_A = 9;
    defparam OAM_RAM_0_0_0.DATA_WIDTH_B = 9;
    defparam OAM_RAM_0_0_0.REGMODE_A = "OUTREG";
    defparam OAM_RAM_0_0_0.REGMODE_B = "NOREG";
    defparam OAM_RAM_0_0_0.CSDECODE_A = "0b000";
    defparam OAM_RAM_0_0_0.CSDECODE_B = "0b111";
    defparam OAM_RAM_0_0_0.WRITEMODE_A = "NORMAL";
    defparam OAM_RAM_0_0_0.WRITEMODE_B = "NORMAL";
    defparam OAM_RAM_0_0_0.GSR = "ENABLED";
    defparam OAM_RAM_0_0_0.RESETMODE = "SYNC";
    defparam OAM_RAM_0_0_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam OAM_RAM_0_0_0.INIT_DATA = "STATIC";
    defparam OAM_RAM_0_0_0.INITVAL_00 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_01 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_02 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_03 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_04 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_05 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_06 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_07 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_08 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_09 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    
endmodule
//
// Verilog Description of module OAM_COUNTER
//

module OAM_COUNTER (DBIN, W3, n5081, n9826, \OAM1Cout[1] , n9948, 
            OAM1ADR, n9922, n9886, Clk, PAR_O, n9850, n5079, Clk_enable_562, 
            \CNT1_7__N_1142[2] , \CNT1[7] , CNT_7__N_1140, n6437, \CNT1[0] , 
            n9954) /* synthesis syn_module_defined=1 */ ;
    input [7:0]DBIN;
    input W3;
    input n5081;
    input n9826;
    input \OAM1Cout[1] ;
    input n9948;
    output [7:0]OAM1ADR;
    input n9922;
    input n9886;
    input Clk;
    input PAR_O;
    input n9850;
    input n5079;
    input Clk_enable_562;
    input \CNT1_7__N_1142[2] ;
    output \CNT1[7] ;
    input CNT_7__N_1140;
    input n6437;
    output \CNT1[0] ;
    input n9954;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    wire [7:0]CNT1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1681[10:14])
    wire [7:0]n27;
    
    wire n5082;
    wire [7:0]CNT1_7__N_1142;
    
    wire n5080;
    wire [7:0]n56;
    
    LUT4 mux_8_i2_3_lut (.A(CNT1[1]), .B(DBIN[1]), .C(W3), .Z(n27[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1689[64:92])
    defparam mux_8_i2_3_lut.init = 16'hcaca;
    LUT4 mux_8_i3_3_lut (.A(CNT1[2]), .B(DBIN[2]), .C(W3), .Z(n27[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1689[64:92])
    defparam mux_8_i3_3_lut.init = 16'hcaca;
    LUT4 mux_8_i4_3_lut (.A(CNT1[3]), .B(DBIN[3]), .C(W3), .Z(n27[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1689[64:92])
    defparam mux_8_i4_3_lut.init = 16'hcaca;
    LUT4 mux_8_i5_3_lut (.A(CNT1[4]), .B(DBIN[4]), .C(W3), .Z(n27[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1689[64:92])
    defparam mux_8_i5_3_lut.init = 16'hcaca;
    LUT4 mux_8_i6_3_lut (.A(CNT1[5]), .B(DBIN[5]), .C(W3), .Z(n27[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1689[64:92])
    defparam mux_8_i6_3_lut.init = 16'hcaca;
    LUT4 mux_8_i7_3_lut (.A(CNT1[6]), .B(DBIN[6]), .C(W3), .Z(n27[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1689[64:92])
    defparam mux_8_i7_3_lut.init = 16'hcaca;
    LUT4 i4573_3_lut (.A(n5081), .B(DBIN[7]), .C(W3), .Z(n5082)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam i4573_3_lut.init = 16'hcaca;
    LUT4 i2551_3_lut_4_lut (.A(n9826), .B(\OAM1Cout[1] ), .C(n9948), .D(OAM1ADR[4]), 
         .Z(CNT1_7__N_1142[4])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A (C (D)+!C !(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1690[48:112])
    defparam i2551_3_lut_4_lut.init = 16'h2fd0;
    LUT4 i2552_3_lut_4_lut (.A(n9826), .B(\OAM1Cout[1] ), .C(n9922), .D(OAM1ADR[5]), 
         .Z(CNT1_7__N_1142[5])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A (C (D)+!C !(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1690[48:112])
    defparam i2552_3_lut_4_lut.init = 16'h2fd0;
    LUT4 i2553_3_lut_4_lut (.A(n9826), .B(\OAM1Cout[1] ), .C(n9886), .D(OAM1ADR[6]), 
         .Z(CNT1_7__N_1142[6])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A (C (D)+!C !(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1690[48:112])
    defparam i2553_3_lut_4_lut.init = 16'h2fd0;
    FD1S3IX CNT__i0 (.D(n5080), .CK(Clk), .CD(PAR_O), .Q(OAM1ADR[0])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i0.GSR = "DISABLED";
    LUT4 i2554_3_lut_4_lut (.A(n9826), .B(\OAM1Cout[1] ), .C(n9850), .D(OAM1ADR[7]), 
         .Z(CNT1_7__N_1142[7])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A (C (D)+!C !(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1690[48:112])
    defparam i2554_3_lut_4_lut.init = 16'h2fd0;
    LUT4 i4571_3_lut (.A(n5079), .B(DBIN[0]), .C(W3), .Z(n5080)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam i4571_3_lut.init = 16'hcaca;
    FD1P3AX CNT1_i0_i2 (.D(\CNT1_7__N_1142[2] ), .SP(Clk_enable_562), .CK(Clk), 
            .Q(CNT1[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i2.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i3 (.D(CNT1_7__N_1142[3]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(CNT1[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i3.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i4 (.D(CNT1_7__N_1142[4]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(CNT1[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i4.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i5 (.D(CNT1_7__N_1142[5]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(CNT1[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i5.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i6 (.D(CNT1_7__N_1142[6]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(CNT1[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i6.GSR = "DISABLED";
    FD1P3AX CNT1_i0_i7 (.D(CNT1_7__N_1142[7]), .SP(Clk_enable_562), .CK(Clk), 
            .Q(\CNT1[7] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i7.GSR = "DISABLED";
    LUT4 i2550_3_lut_4_lut (.A(n9826), .B(\OAM1Cout[1] ), .C(OAM1ADR[2]), 
         .D(OAM1ADR[3]), .Z(CNT1_7__N_1142[3])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A (C (D)+!C !(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1690[48:112])
    defparam i2550_3_lut_4_lut.init = 16'h2fd0;
    LUT4 xor_13_i2_2_lut (.A(OAM1ADR[1]), .B(OAM1ADR[0]), .Z(n56[1])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1690[78:112])
    defparam xor_13_i2_2_lut.init = 16'h6666;
    FD1P3IX CNT__i1 (.D(n27[1]), .SP(CNT_7__N_1140), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i1.GSR = "DISABLED";
    FD1P3IX CNT__i2 (.D(n27[2]), .SP(CNT_7__N_1140), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[2])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i2.GSR = "DISABLED";
    FD1P3IX CNT__i3 (.D(n27[3]), .SP(CNT_7__N_1140), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[3])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i3.GSR = "DISABLED";
    FD1P3IX CNT__i4 (.D(n27[4]), .SP(CNT_7__N_1140), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[4])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i4.GSR = "DISABLED";
    FD1P3IX CNT__i5 (.D(n27[5]), .SP(CNT_7__N_1140), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[5])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i5.GSR = "DISABLED";
    FD1P3IX CNT__i6 (.D(n27[6]), .SP(CNT_7__N_1140), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[6])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i6.GSR = "DISABLED";
    FD1S3IX CNT__i7 (.D(n5082), .CK(Clk), .CD(PAR_O), .Q(OAM1ADR[7])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT__i7.GSR = "DISABLED";
    FD1P3IX CNT1_i0_i1 (.D(n56[1]), .SP(Clk_enable_562), .CD(n6437), .CK(Clk), 
            .Q(CNT1[1])) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i1.GSR = "DISABLED";
    FD1P3IX CNT1_i0_i0 (.D(n9954), .SP(Clk_enable_562), .CD(n6437), .CK(Clk), 
            .Q(\CNT1[0] )) /* synthesis LSE_LINE_FILE_ID=8, LSE_LCOL=13, LSE_RCOL=77, LSE_LLINE=1270, LSE_RLINE=1270 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1688[8] 1691[26])
    defparam CNT1_i0_i0.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U100
//

module COUNTER_U100 (Clk, Clk_enable_543, CNT1_N_565, \OAM2ADR[4] , 
            OAM2STEP_N_1104, ORES) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input Clk_enable_543;
    input CNT1_N_565;
    output \OAM2ADR[4] ;
    input OAM2STEP_N_1104;
    input ORES;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_543), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(CNT1), .SP(OAM2STEP_N_1104), .CK(Clk), .CD(ORES), 
            .Q(\OAM2ADR[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U101
//

module COUNTER_U101 (\OAM2ADR[3] , Clk, OAM2STEP_N_1104, ORES, Clk_enable_543, 
            CNT1_N_565) /* synthesis syn_module_defined=1 */ ;
    output \OAM2ADR[3] ;
    input Clk;
    input OAM2STEP_N_1104;
    input ORES;
    input Clk_enable_543;
    input CNT1_N_565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    FD1P3DX CNT_14 (.D(CNT1), .SP(OAM2STEP_N_1104), .CK(Clk), .CD(ORES), 
            .Q(\OAM2ADR[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_543), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U102
//

module COUNTER_U102 (\OAM2ADR[2] , n9947, \OAM2ADR[4] , \OAM2ADR[3] , 
            CNT1_N_565, C_OUT_N_563, Clk, Clk_enable_173, CNT1_N_565_adj_2, 
            OAM2STEP_N_1104, ORES) /* synthesis syn_module_defined=1 */ ;
    output \OAM2ADR[2] ;
    input n9947;
    input \OAM2ADR[4] ;
    input \OAM2ADR[3] ;
    output CNT1_N_565;
    output C_OUT_N_563;
    input Clk;
    input Clk_enable_173;
    input CNT1_N_565_adj_2;
    input OAM2STEP_N_1104;
    input ORES;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1;
    
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\OAM2ADR[2] ), .B(n9947), .C(\OAM2ADR[4] ), 
         .D(\OAM2ADR[3] ), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h78f0;
    LUT4 CNT_I_0_19_2_lut_3_lut_4_lut (.A(\OAM2ADR[2] ), .B(n9947), .C(\OAM2ADR[4] ), 
         .D(\OAM2ADR[3] ), .Z(C_OUT_N_563)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_3_lut_4_lut.init = 16'h8000;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_2), .SP(Clk_enable_173), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(CNT1), .SP(OAM2STEP_N_1104), .CK(Clk), .CD(ORES), 
            .Q(\OAM2ADR[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U103
//

module COUNTER_U103 (\OAM2ADR[1] , \OAM2ADR[0] , n9947, \OAM2ADR[2] , 
            CNT1_N_565, \OAM2ADR[3] , CNT1_N_565_adj_1, Clk, Clk_enable_173, 
            OAM2STEP_N_1104, ORES) /* synthesis syn_module_defined=1 */ ;
    output \OAM2ADR[1] ;
    input \OAM2ADR[0] ;
    output n9947;
    input \OAM2ADR[2] ;
    output CNT1_N_565;
    input \OAM2ADR[3] ;
    output CNT1_N_565_adj_1;
    input Clk;
    input Clk_enable_173;
    input OAM2STEP_N_1104;
    input ORES;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, CNT1_N_565_adj_1556;
    
    LUT4 CNT_I_0_19_2_lut_rep_342 (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), .Z(n9947)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_19_2_lut_rep_342.init = 16'h8888;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), .C(\OAM2ADR[2] ), 
         .Z(CNT1_N_565)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), 
         .C(\OAM2ADR[3] ), .D(\OAM2ADR[2] ), .Z(CNT1_N_565_adj_1)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1654[22:32])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h78f0;
    FD1P3AX CNT1_15 (.D(CNT1_N_565_adj_1556), .SP(Clk_enable_173), .CK(Clk), 
            .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    FD1P3DX CNT_14 (.D(CNT1), .SP(OAM2STEP_N_1104), .CK(Clk), .CD(ORES), 
            .Q(\OAM2ADR[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    LUT4 CNT_I_0_2_lut (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), .Z(CNT1_N_565_adj_1556)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    
endmodule
//
// Verilog Description of module COUNTER_U104
//

module COUNTER_U104 (\OAM2ADR[0] , Clk, OAM2STEP_N_1104, ORES, Clk_enable_173) /* synthesis syn_module_defined=1 */ ;
    output \OAM2ADR[0] ;
    input Clk;
    input OAM2STEP_N_1104;
    input ORES;
    input Clk_enable_173;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    wire CNT1, CNT1_N_565;
    
    FD1P3DX CNT_14 (.D(CNT1), .SP(OAM2STEP_N_1104), .CK(Clk), .CD(ORES), 
            .Q(\OAM2ADR[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1658[8] 1659[31])
    defparam CNT_14.GSR = "DISABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_565), .SP(Clk_enable_173), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1661[8] 1663[26])
    defparam CNT1_15.GSR = "DISABLED";
    LUT4 i46_1_lut (.A(\OAM2ADR[0] ), .Z(CNT1_N_565)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1662[26:36])
    defparam i46_1_lut.init = 16'h5555;
    
endmodule
//
// Verilog Description of module OAM2_RAM
//

module OAM2_RAM (Clk, VCC_net, GND_net, WE, OAM2ADR, OB2, OAM2Q) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input Clk;
    input VCC_net;
    input GND_net;
    input WE;
    input [4:0]OAM2ADR;
    input [7:0]OB2;
    output [7:0]OAM2Q;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(69[6:9])
    
    DP8KC OAM2_RAM_0_0_0 (.DIA0(OB2[0]), .DIA1(OB2[1]), .DIA2(OB2[2]), 
          .DIA3(OB2[3]), .DIA4(OB2[4]), .DIA5(OB2[5]), .DIA6(OB2[6]), 
          .DIA7(OB2[7]), .DIA8(GND_net), .ADA0(VCC_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(OAM2ADR[0]), .ADA4(OAM2ADR[1]), .ADA5(OAM2ADR[2]), 
          .ADA6(OAM2ADR[3]), .ADA7(OAM2ADR[4]), .ADA8(GND_net), .ADA9(GND_net), 
          .ADA10(GND_net), .ADA11(GND_net), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(WE), .CSA0(GND_net), .CSA1(GND_net), 
          .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), .DIB1(GND_net), 
          .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), .DIB5(GND_net), 
          .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), .ADB0(GND_net), 
          .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), .ADB4(GND_net), 
          .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), .ADB8(GND_net), 
          .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), .ADB12(GND_net), 
          .CEB(VCC_net), .OCEB(VCC_net), .CLKB(GND_net), .WEB(GND_net), 
          .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), .RSTB(GND_net), 
          .DOA0(OAM2Q[0]), .DOA1(OAM2Q[1]), .DOA2(OAM2Q[2]), .DOA3(OAM2Q[3]), 
          .DOA4(OAM2Q[4]), .DOA5(OAM2Q[5]), .DOA6(OAM2Q[6]), .DOA7(OAM2Q[7])) /* synthesis MEM_LPC_FILE="OAM2_RAM.lpc", MEM_INIT_FILE="INIT_ALL_0s", syn_instantiated=1, LSE_LINE_FILE_ID=8, LSE_LCOL=10, LSE_RCOL=90, LSE_LLINE=1277, LSE_RLINE=1277 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite_lava.v(1277[10:90])
    defparam OAM2_RAM_0_0_0.DATA_WIDTH_A = 9;
    defparam OAM2_RAM_0_0_0.DATA_WIDTH_B = 9;
    defparam OAM2_RAM_0_0_0.REGMODE_A = "OUTREG";
    defparam OAM2_RAM_0_0_0.REGMODE_B = "NOREG";
    defparam OAM2_RAM_0_0_0.CSDECODE_A = "0b000";
    defparam OAM2_RAM_0_0_0.CSDECODE_B = "0b111";
    defparam OAM2_RAM_0_0_0.WRITEMODE_A = "NORMAL";
    defparam OAM2_RAM_0_0_0.WRITEMODE_B = "NORMAL";
    defparam OAM2_RAM_0_0_0.GSR = "ENABLED";
    defparam OAM2_RAM_0_0_0.RESETMODE = "SYNC";
    defparam OAM2_RAM_0_0_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam OAM2_RAM_0_0_0.INIT_DATA = "STATIC";
    defparam OAM2_RAM_0_0_0.INITVAL_00 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_01 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_02 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_03 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_04 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_05 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_06 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_07 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_08 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_09 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    
endmodule
//
// Verilog Description of module TSALL
// module not written out since it is a black-box. 
//

