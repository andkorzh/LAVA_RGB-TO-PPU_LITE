
#Begin clock constraint
define_clock -name {PLL|CLKOP_inferred_clock} {n:PLL|CLKOP_inferred_clock} -period 10.292 -clockgroup Autoconstr_clkgroup_0 -rise 0.000 -fall 5.146 -route 0.000 
#End clock constraint

#Begin clock constraint
define_clock -name {RP2C02_LITE|MCLK} {p:RP2C02_LITE|MCLK} -period 1.526 -clockgroup Autoconstr_clkgroup_1 -rise 0.000 -fall 0.763 -route 0.000 
#End clock constraint
