// Verilog netlist produced by program LSE :  version Diamond Version 3.5.0.102
// Netlist written on Sat Dec 13 17:45:12 2025
//
// Verilog Description of module RP2C02_LITE
//

module RP2C02_LITE (MCLK, MODE, DENDY, nRES, PALSEL0, PALSEL1, RnW, 
            nDBE, A, PD, DB, RGB, PA, INT, ALE, nWR, nRD, 
            SYNC, PCLK, SUBCLK, DB_OE_CONTROL, DB_DIR, PD_DIR, PD_OE) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(35[8:19])
    input MCLK;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(36[11:15])
    input MODE;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(38[11:15])
    input DENDY;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(39[8:13])
    input nRES;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(40[8:12])
    input PALSEL0;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(41[8:15])
    input PALSEL1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(42[8:15])
    input RnW;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(43[11:14])
    input nDBE;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(44[11:15])
    input [2:0]A;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(45[13:14])
    inout [7:0]PD;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(46[13:15])
    inout [7:0]DB;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(48[13:15])
    output [23:0]RGB;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    output [5:0]PA;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(50[14:16])
    output INT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(51[9:12])
    output ALE;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(52[9:12])
    output nWR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(53[9:12])
    output nRD;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(54[9:12])
    output SYNC;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(55[9:13])
    output PCLK;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(56[9:13])
    output SUBCLK;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(57[9:15])
    output DB_OE_CONTROL;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(58[9:22])
    output DB_DIR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(59[9:15])
    output PD_DIR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(60[9:15])
    output PD_OE;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(61[9:14])
    
    wire MCLK_c /* synthesis is_clock=1, SET_AS_NETWORK=MCLK_c */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(36[11:15])
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire MCLK_N_9 /* synthesis is_inv_clock=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(471[10:16])
    
    wire GND_net, MODE_c, DENDY_c, nRES_c, PALSEL0_c_6, PALSEL1_c_7, 
        RnW_c, DB_OE_CONTROL_c_c, A_c_2, A_c_1, A_c_0, RGB_c_23, 
        RGB_c_22, RGB_c_21, RGB_c_20, RGB_c_19, RGB_c_18, RGB_c_17, 
        RGB_c_16, RGB_c_15, RGB_c_14, RGB_c_13, RGB_c_12, RGB_c_11, 
        RGB_c_10, RGB_c_9, RGB_c_8, RGB_c_7, RGB_c_6, RGB_c_5, RGB_c_4, 
        RGB_c_3, RGB_c_2, RGB_c_1, RGB_c_0, PA_c_5, PA_c_4, PA_c_3, 
        PA_c_2, PA_c_1, PA_c_0, INT_c, ALE_c, nWR_c, nRD_c, SYNC_c, 
        PCLK_c, SUBCLK_c, DB_DIR_c, nPCLK;
    wire [7:0]DBIN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(68[11:15])
    wire [2:0]EMPH;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(69[11:15])
    wire [7:0]OB;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(70[11:13])
    wire [3:0]OV;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(71[11:13])
    wire [7:0]Vo;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(72[11:13])
    wire [5:0]PIX;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(73[11:14])
    wire [2:0]R2DB;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(74[11:15])
    wire [4:0]THO;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(75[11:14])
    wire [13:0]PAD;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(75[27:30])
    wire [4:0]ZCOL;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(77[11:15])
    wire [4:0]CGA;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(78[11:14])
    
    wire Hn0;
    wire [5:0]Hnn;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(82[11:14])
    
    wire W0, W1, R2, W3, W4, R4, W5_1, W5_2, W6_1, W6_2, 
        W7, R7, R_EN, I1_32, OBSEL, BGSEL, O8_16, VBL_EN, B_W, 
        BGCLIP, S_EV, O_HPOS, nEVAL, E_EV, I_OAM2, PAR_O, nVIS, 
        nF_NT, F_AT, SC_CNT, nPICTURE, RC, RESCL, BLNK, TSTEP, 
        TH_MUX, TVO1, OMFG, PD_FIFO, SPR0_EV, SPR_OV, SH2, RPIX, 
        VCC_net, RnWR, nDBER, DB_out_4, DB_out_5, CLIPOR, EMP_R, 
        EMP_G, nCLPB_N_121, DB_out_6, DB_out_7, PD_out_0, PD_out_1, 
        PD_out_2;
    wire [7:0]OB_R;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(647[10:14])
    wire [7:0]D;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(650[11:12])
    
    wire PD_out_3, PD_out_4, PD_out_5, PD_out_6;
    wire [5:0]Hn;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(716[10:12])
    
    wire CLIP_OUT, NFO_OUT, N_HB, BLNK_FF, CLIP_B_N_277, Clk_enable_292, 
        W7_Q2, W7_Q4, TSTEP_LATCH, Clk_enable_297, DB_PAR_N_634, PD_DIR_c, 
        XRB_N_650, ALE_N_645;
    wire [3:0]BGC2;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(970[10:14])
    
    wire CLPB_LATCH, THO1R;
    wire [7:0]PDAT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(975[10:14])
    
    wire PD_SR, SRLOAD, PD_SR_N_805, STEP_N_807;
    wire [1:0]ATSEL_1__N_798;
    
    wire TV_IN;
    wire [4:0]TVO;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1129[11:14])
    
    wire VINV_LATCH_N_1001, Hnn0_N_999, PD_FIFO2, DO_COPY_N_1126, OMFG_N_1097, 
        OMFG_N_1096, PD_FIFO_N_1103, OMSTEP2_N_1188, SPR0HIT_LATCH;
    wire [4:0]THO_LATCH;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1584[10:19])
    wire [4:0]STEP3;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1586[10:15])
    
    wire Clk_enable_14, Clk_enable_33, Clk_enable_280, n1026, CNT1_N_1080, 
        DB_out_0, DB_out_1, DB_out_2, DB_out_3, PD_out_7, Clk_enable_290;
    
    VHI i33 (.Z(VCC_net));
    PAR_GEN MOD_PAR_GEN (.W7_Q2(W7_Q2), .W7_Q4(W7_Q4), .\Hn[2] (Hn[2]), 
            .BLNK(BLNK), .PCLK_c(PCLK_c), .Clk(Clk), .nPCLK(nPCLK), 
            .VINV_LATCH_N_1001(VINV_LATCH_N_1001), .OB({OB}), .E_EV(E_EV), 
            .F_AT(F_AT), .SC_CNT(SC_CNT), .PD_FIFO_N_1103(PD_FIFO_N_1103), 
            .\PAD[1] (PAD[1]), .GND_net(GND_net), .OV({OV}), .DB_PAR_N_634(DB_PAR_N_634), 
            .nF_NT(nF_NT), .TV_IN(TV_IN), .PD_out_0(PD_out_0), .\PAD[6] (PAD[6]), 
            .TSTEP(TSTEP), .RESCL(RESCL), .I1_32(I1_32), .THO({THO}), 
            .DBIN({DBIN}), .VCC_net(VCC_net), .TVO1(TVO1), .\TVO[0] (TVO[0]), 
            .\Hn[1] (Hn[1]), .W6_2(W6_2), .STEP_N_807(STEP_N_807), .RC(RC), 
            .PAR_O(PAR_O), .W6_1(W6_1), .W5_2(W5_2), .PA_c_0(PA_c_0), 
            .\PAD[2] (PAD[2]), .\PAD[3] (PAD[3]), .\PAD[4] (PAD[4]), .\PAD[5] (PAD[5]), 
            .PA_c_1(PA_c_1), .PA_c_2(PA_c_2), .PA_c_3(PA_c_3), .PA_c_4(PA_c_4), 
            .W0(W0), .PD_out_1(PD_out_1), .PD_out_2(PD_out_2), .PD_out_3(PD_out_3), 
            .PD_out_4(PD_out_4), .PD_out_5(PD_out_5), .PD_out_6(PD_out_6), 
            .PD_out_7(PD_out_7), .PA_c_5(PA_c_5), .Clk_enable_292(Clk_enable_292), 
            .W5_1(W5_1), .O8_16(O8_16), .BGSEL(BGSEL), .OBSEL(OBSEL), 
            .\PAD[7] (PAD[7]), .\PAD[0] (PAD[0]), .SH2(SH2), .PD_FIFO2(PD_FIFO2), 
            .Hnn0_N_999(Hnn0_N_999), .THO1R(THO1R), .\PDAT[5] (PDAT[5]), 
            .ATSEL_1__N_798({ATSEL_1__N_798}), .\PDAT[4] (PDAT[4]), .CNT1_N_1080(CNT1_N_1080)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(318[9] 353[2])
    INV i8740 (.A(MCLK_c), .Z(MCLK_N_9));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(36[11:15])
    IB DENDY_pad (.I(DENDY), .O(DENDY_c));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(39[8:13])
    IB MODE_pad (.I(MODE), .O(MODE_c));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(38[11:15])
    IB MCLK_pad (.I(MCLK), .O(MCLK_c));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(36[11:15])
    OB PD_OE_pad (.I(GND_net), .O(PD_OE));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(61[9:14])
    LUT4 i1_2_lut (.A(W5_1), .B(RC), .Z(Clk_enable_280)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i1_2_lut.init = 16'heeee;
    TSALL TSALL_INST (.TSALL(GND_net));
    OB PD_DIR_pad (.I(PD_DIR_c), .O(PD_DIR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(60[9:15])
    OB DB_DIR_pad (.I(DB_DIR_c), .O(DB_DIR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(59[9:15])
    OB DB_OE_CONTROL_pad (.I(DB_OE_CONTROL_c_c), .O(DB_OE_CONTROL));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(58[9:22])
    OB SUBCLK_pad (.I(SUBCLK_c), .O(SUBCLK));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(57[9:15])
    OB PCLK_pad (.I(PCLK_c), .O(PCLK));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(56[9:13])
    OB SYNC_pad (.I(SYNC_c), .O(SYNC));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(55[9:13])
    OB nRD_pad (.I(nRD_c), .O(nRD));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(54[9:12])
    OB nWR_pad (.I(nWR_c), .O(nWR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(53[9:12])
    OB ALE_pad (.I(ALE_c), .O(ALE));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(52[9:12])
    OB INT_pad (.I(INT_c), .O(INT));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(51[9:12])
    OB PA_pad_0 (.I(PA_c_0), .O(PA[0]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(50[14:16])
    OB PA_pad_1 (.I(PA_c_1), .O(PA[1]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(50[14:16])
    OB PA_pad_2 (.I(PA_c_2), .O(PA[2]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(50[14:16])
    OB PA_pad_3 (.I(PA_c_3), .O(PA[3]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(50[14:16])
    OB PA_pad_4 (.I(PA_c_4), .O(PA[4]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(50[14:16])
    OB PA_pad_5 (.I(PA_c_5), .O(PA[5]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(50[14:16])
    OB RGB_pad_0 (.I(RGB_c_0), .O(RGB[0]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    OB RGB_pad_1 (.I(RGB_c_1), .O(RGB[1]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    OB RGB_pad_2 (.I(RGB_c_2), .O(RGB[2]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    OB RGB_pad_3 (.I(RGB_c_3), .O(RGB[3]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    OB RGB_pad_4 (.I(RGB_c_4), .O(RGB[4]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    OB RGB_pad_5 (.I(RGB_c_5), .O(RGB[5]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    OB RGB_pad_6 (.I(RGB_c_6), .O(RGB[6]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    OB RGB_pad_7 (.I(RGB_c_7), .O(RGB[7]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    OB RGB_pad_8 (.I(RGB_c_8), .O(RGB[8]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    OB RGB_pad_9 (.I(RGB_c_9), .O(RGB[9]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    OB RGB_pad_10 (.I(RGB_c_10), .O(RGB[10]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    OB RGB_pad_11 (.I(RGB_c_11), .O(RGB[11]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    OB RGB_pad_12 (.I(RGB_c_12), .O(RGB[12]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    OB RGB_pad_13 (.I(RGB_c_13), .O(RGB[13]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    OB RGB_pad_14 (.I(RGB_c_14), .O(RGB[14]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    OB RGB_pad_15 (.I(RGB_c_15), .O(RGB[15]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    IB nRES_pad (.I(nRES), .O(nRES_c));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(40[8:12])
    BB DB_pad_4 (.I(D[4]), .T(R_EN), .B(DB[4]), .O(DB_out_4));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(652[8:10])
    OB RGB_pad_16 (.I(RGB_c_16), .O(RGB[16]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    BB DB_pad_5 (.I(D[5]), .T(R_EN), .B(DB[5]), .O(DB_out_5));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(652[8:10])
    OB RGB_pad_17 (.I(RGB_c_17), .O(RGB[17]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    BB DB_pad_6 (.I(D[6]), .T(R_EN), .B(DB[6]), .O(DB_out_6));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(652[8:10])
    OB RGB_pad_18 (.I(RGB_c_18), .O(RGB[18]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    BB DB_pad_7 (.I(D[7]), .T(R_EN), .B(DB[7]), .O(DB_out_7));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(652[8:10])
    OB RGB_pad_19 (.I(RGB_c_19), .O(RGB[19]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    BB PD_pad_0 (.I(PAD[0]), .T(PD_DIR_c), .B(PD[0]), .O(PD_out_0));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(146[36:38])
    OB RGB_pad_20 (.I(RGB_c_20), .O(RGB[20]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    BB PD_pad_1 (.I(PAD[1]), .T(PD_DIR_c), .B(PD[1]), .O(PD_out_1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(146[36:38])
    OB RGB_pad_21 (.I(RGB_c_21), .O(RGB[21]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    BB PD_pad_2 (.I(PAD[2]), .T(PD_DIR_c), .B(PD[2]), .O(PD_out_2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(146[36:38])
    OB RGB_pad_22 (.I(RGB_c_22), .O(RGB[22]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    BB PD_pad_3 (.I(PAD[3]), .T(PD_DIR_c), .B(PD[3]), .O(PD_out_3));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(146[36:38])
    OB RGB_pad_23 (.I(RGB_c_23), .O(RGB[23]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(49[15:18])
    BB PD_pad_4 (.I(PAD[4]), .T(PD_DIR_c), .B(PD[4]), .O(PD_out_4));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(146[36:38])
    BB PD_pad_5 (.I(PAD[5]), .T(PD_DIR_c), .B(PD[5]), .O(PD_out_5));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(146[36:38])
    BB DB_pad_0 (.I(D[0]), .T(R_EN), .B(DB[0]), .O(DB_out_0));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(652[8:10])
    BB PD_pad_6 (.I(PAD[6]), .T(PD_DIR_c), .B(PD[6]), .O(PD_out_6));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(146[36:38])
    BB DB_pad_1 (.I(D[1]), .T(R_EN), .B(DB[1]), .O(DB_out_1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(652[8:10])
    BB DB_pad_2 (.I(D[2]), .T(R_EN), .B(DB[2]), .O(DB_out_2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(652[8:10])
    BB DB_pad_3 (.I(D[3]), .T(R_EN), .B(DB[3]), .O(DB_out_3));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(652[8:10])
    BB PD_pad_7 (.I(PAD[7]), .T(PD_DIR_c), .B(PD[7]), .O(PD_out_7));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(146[36:38])
    OBJ_FIFO MOD_OBJ_FIFO (.PCLK_c(PCLK_c), .CLIPOR(CLIPOR), .OB({OB}), 
            .Hnn({Hnn}), .SH2(SH2), .PD_FIFO(PD_FIFO), .PD_out_1(PD_out_1), 
            .PD_out_6(PD_out_6), .PD_out_2(PD_out_2), .PD_out_5(PD_out_5), 
            .PD_out_3(PD_out_3), .PD_out_4(PD_out_4), .Clk(Clk), .nPCLK(nPCLK), 
            .O_HPOS(O_HPOS), .PD_out_7(PD_out_7), .PD_out_0(PD_out_0), 
            .VINV_LATCH_N_1001(VINV_LATCH_N_1001), .SPR0HIT_LATCH(SPR0HIT_LATCH), 
            .ZCOL({ZCOL}), .PAR_O(PAR_O), .nVIS(nVIS)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(400[10] 415[2])
    IB PALSEL0_pad (.I(PALSEL0), .O(PALSEL0_c_6));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(41[8:15])
    IB PALSEL1_pad (.I(PALSEL1), .O(PALSEL1_c_7));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(42[8:15])
    IB RnW_pad (.I(RnW), .O(RnW_c));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(43[11:14])
    IB DB_OE_CONTROL_c_pad (.I(nDBE), .O(DB_OE_CONTROL_c_c));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(44[11:15])
    IB A_pad_2 (.I(A[2]), .O(A_c_2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(45[13:14])
    IB A_pad_1 (.I(A[1]), .O(A_c_1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(45[13:14])
    IB A_pad_0 (.I(A[0]), .O(A_c_0));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(45[13:14])
    PALETTE MOD_PALETTE (.n1026(n1026), .EMPH({EMPH}), .EMP_R(EMP_R), 
            .EMP_G(EMP_G), .\STEP3[0] (STEP3[0]), .\THO_LATCH[0] (THO_LATCH[0]), 
            .TH_MUX(TH_MUX), .\CGA[1] (CGA[1]), .RGB_c_15(RGB_c_15), .RGB_c_9(RGB_c_9), 
            .RGB_c_10(RGB_c_10), .RGB_c_2(RGB_c_2), .RGB_c_11(RGB_c_11), 
            .TSTEP_LATCH(TSTEP_LATCH), .Clk(Clk), .PCLK_c(PCLK_c), .DB_PAR_N_634(DB_PAR_N_634), 
            .RGB_c_12(RGB_c_12), .RGB_c_13(RGB_c_13), .RGB_c_18(RGB_c_18), 
            .RGB_c_14(RGB_c_14), .RGB_c_3(RGB_c_3), .GND_net(GND_net), 
            .RGB_c_19(RGB_c_19), .nPICTURE(nPICTURE), .RGB_c_20(RGB_c_20), 
            .R7(R7), .RPIX(RPIX), .RGB_c_21(RGB_c_21), .RGB_c_22(RGB_c_22), 
            .PIX({PIX}), .RGB_c_23(RGB_c_23), .RGB_c_7(RGB_c_7), .MODE_c(MODE_c), 
            .RGB_c_0(RGB_c_0), .\STEP3[4] (STEP3[4]), .\THO_LATCH[4] (THO_LATCH[4]), 
            .RGB_c_1(RGB_c_1), .B_W(B_W), .RGB_c_16(RGB_c_16), .RGB_c_17(RGB_c_17), 
            .RGB_c_4(RGB_c_4), .RGB_c_5(RGB_c_5), .RGB_c_8(RGB_c_8), .RGB_c_6(RGB_c_6), 
            .PALSEL1_c_7(PALSEL1_c_7), .PALSEL0_c_6(PALSEL0_c_6), .VCC_net(VCC_net), 
            .\CGA[3] (CGA[3]), .\CGA[2] (CGA[2]), .\CGA[0] (CGA[0]), .\DBIN[5] (DBIN[5]), 
            .\DBIN[4] (DBIN[4]), .\DBIN[3] (DBIN[3]), .\DBIN[2] (DBIN[2]), 
            .\DBIN[1] (DBIN[1]), .\DBIN[0] (DBIN[0])) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(435[9] 452[2])
    OAM MOD_OAM (.OB({OB}), .Clk(Clk), .nPCLK(nPCLK), .nEVAL(nEVAL), 
        .BLNK(BLNK), .\Hnn[0] (Hnn[0]), .I_OAM2(I_OAM2), .PCLK_c(PCLK_c), 
        .OMSTEP2_N_1188(OMSTEP2_N_1188), .OMFG_N_1096(OMFG_N_1096), .OMFG(OMFG), 
        .W4(W4), .RESCL(RESCL), .\R2DB[0] (R2DB[0]), .ALE_N_645(ALE_N_645), 
        .SPR_OV(SPR_OV), .nVIS(nVIS), .Hn0(Hn0), .Hnn0_N_999(Hnn0_N_999), 
        .OMFG_N_1097(OMFG_N_1097), .DO_COPY_N_1126(DO_COPY_N_1126), .VCC_net(VCC_net), 
        .GND_net(GND_net), .DBIN({DBIN}), .W3(W3), .PAR_O(PAR_O), .\Hn[2] (Hn[2])) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(377[5] 397[2])
    BG_COLOR MOD_BG_COLOR (.Clk(Clk), .PD_out_0(PD_out_0), .PCLK_c(PCLK_c), 
            .\Hnn[0] (Hnn[0]), .PD_SR_N_805(PD_SR_N_805), .BGC2({BGC2}), 
            .nPCLK(nPCLK), .PD_SR(PD_SR), .SRLOAD(SRLOAD), .TVO1(TVO1), 
            .NFO_OUT(NFO_OUT), .STEP_N_807(STEP_N_807), .CLPB_LATCH(CLPB_LATCH), 
            .nCLPB_N_121(nCLPB_N_121), .F_AT(F_AT), .THO1R(THO1R), .\THO[1] (THO[1]), 
            .TV_IN(TV_IN), .\TVO[0] (TVO[0]), .CNT1_N_1080(CNT1_N_1080), 
            .Clk_enable_280(Clk_enable_280), .RC(RC), .\DBIN[2] (DBIN[2]), 
            .\DBIN[1] (DBIN[1]), .PD_out_1(PD_out_1), .PD_out_2(PD_out_2), 
            .PD_out_3(PD_out_3), .\PDAT[4] (PDAT[4]), .PD_out_4(PD_out_4), 
            .\PDAT[5] (PDAT[5]), .PD_out_5(PD_out_5), .PD_out_6(PD_out_6), 
            .PD_out_7(PD_out_7), .ATSEL_1__N_798({ATSEL_1__N_798}), .\DBIN[0] (DBIN[0])) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(298[10] 315[2])
    OBJ_EVAL MOD_OBJ_EVAL (.PD_FIFO(PD_FIFO), .Clk(Clk), .PD_FIFO_N_1103(PD_FIFO_N_1103), 
            .DO_COPY_N_1126(DO_COPY_N_1126), .SPR0_EV(SPR0_EV), .PAR_O(PAR_O), 
            .PCLK_c(PCLK_c), .OMFG_N_1097(OMFG_N_1097), .OMFG(OMFG), .nPCLK(nPCLK), 
            .nVIS(nVIS), .I_OAM2(I_OAM2), .SPR_OV(SPR_OV), .\Hnn[0] (Hnn[0]), 
            .OMSTEP2_N_1188(OMSTEP2_N_1188), .S_EV(S_EV), .PD_FIFO2(PD_FIFO2), 
            .PD_SR_N_805(PD_SR_N_805), .Vo({Vo}), .OB_R({OB_R}), .GND_net(GND_net), 
            .OV({OV}), .O8_16(O8_16), .OMFG_N_1096(OMFG_N_1096)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(356[10] 374[2])
    PUR PUR_INST (.PUR(VCC_net));
    defparam PUR_INST.RST_PULSE = 1;
    VLO i1 (.Z(GND_net));
    CLK_DIV MOD_CLK_DIV (.MCLK_c(MCLK_c), .SUBCLK_c(SUBCLK_c), .MCLK_N_9(MCLK_N_9), 
            .PCLK_c(PCLK_c), .nPCLK(nPCLK), .nRES_c(nRES_c), .MODE_c(MODE_c)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(156[9] 163[2])
    READBUSMUX MOD_READBUSMUX (.DBIN({DBIN}), .D({D}), .OB_R({OB_R}), 
            .Clk(Clk), .PCLK_c(PCLK_c), .OB({OB}), .R2(R2), .R7(R7), 
            .R4(R4), .XRB_N_650(XRB_N_650), .RPIX(RPIX), .R2DB({R2DB}), 
            .PIX({PIX}), .TH_MUX(TH_MUX), .Clk_enable_297(Clk_enable_297), 
            .RC(RC), .PD_out_1(PD_out_1), .PD_out_2(PD_out_2), .PD_out_3(PD_out_3), 
            .PD_out_4(PD_out_4), .PD_out_5(PD_out_5), .PD_out_6(PD_out_6), 
            .PD_out_7(PD_out_7), .RnWR(RnWR), .nDBER(nDBER), .R_EN(R_EN), 
            .PD_out_0(PD_out_0)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(215[12] 231[2])
    ADDRESS_BUS_CONTROL MOD_ADDRESS_BUS_CONTROL (.PCLK_c(PCLK_c), .Hn0(Hn0), 
            .ALE_N_645(ALE_N_645), .BLNK(BLNK), .ALE_c(ALE_c), .W7_Q2(W7_Q2), 
            .W7_Q4(W7_Q4), .TH_MUX(TH_MUX), .nWR_c(nWR_c), .R7(R7), 
            .Clk(Clk), .nPCLK(nPCLK), .PD_DIR_c(PD_DIR_c), .nRD_c(nRD_c), 
            .TSTEP_LATCH(TSTEP_LATCH), .TSTEP(TSTEP), .\Hnn[0] (Hnn[0]), 
            .RC(RC), .Clk_enable_297(Clk_enable_297), .W7(W7), .XRB_N_650(XRB_N_650), 
            .PA_c_3(PA_c_3), .PA_c_4(PA_c_4), .PA_c_0(PA_c_0), .PA_c_5(PA_c_5), 
            .PA_c_1(PA_c_1), .PA_c_2(PA_c_2), .DB_PAR_N_634(DB_PAR_N_634)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(277[21] 295[2])
    TIMING_GENERATOR MOD_TIMING_GENERATOR (.Vo({Vo}), .Clk(Clk), .nPCLK(nPCLK), 
            .S_EV(S_EV), .PCLK_c(PCLK_c), .F_AT(F_AT), .Hnn({Hnn}), 
            .NFO_OUT(NFO_OUT), .PD_SR(PD_SR), .nRES_c(nRES_c), .nF_NT(nF_NT), 
            .RESCL(RESCL), .Hn0(Hn0), .MODE_c(MODE_c), .BLNK_FF(BLNK_FF), 
            .RC(RC), .CLIP_OUT(CLIP_OUT), .BLNK(BLNK), .O_HPOS(O_HPOS), 
            .nEVAL(nEVAL), .E_EV(E_EV), .I_OAM2(I_OAM2), .PAR_O(PAR_O), 
            .SYNC_c(SYNC_c), .nVIS(nVIS), .SRLOAD(SRLOAD), .N_HB(N_HB), 
            .STEP_N_807(STEP_N_807), .DENDY_c(DENDY_c), .VBL_EN(VBL_EN), 
            .INT_c(INT_c), .BGCLIP(BGCLIP), .CLIP_B_N_277(CLIP_B_N_277), 
            .R2(R2), .\Hn[1] (Hn[1]), .\Hn[2] (Hn[2]), .nPICTURE(nPICTURE), 
            .\R2DB[2] (R2DB[2]), .Clk_enable_290(Clk_enable_290)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(234[18] 274[2])
    REGISTER_SELECT MOD_REGISTER_SELECT (.W0(W0), .Clk(Clk), .nDBER(nDBER), 
            .W1(W1), .R2(R2), .RnWR(RnWR), .VCC_net(VCC_net), .GND_net(GND_net), 
            .RnW_c(RnW_c), .DB_OE_CONTROL_c_c(DB_OE_CONTROL_c_c), .DBIN({DBIN}), 
            .DB_out_4(DB_out_4), .W6_2(W6_2), .W5_1(W5_1), .RC(RC), 
            .Clk_enable_292(Clk_enable_292), .W6_1(W6_1), .W5_2(W5_2), 
            .DB_DIR_c(DB_DIR_c), .W3(W3), .R4(R4), .W4(W4), .R7(R7), 
            .W7(W7), .A_c_0(A_c_0), .A_c_1(A_c_1), .DB_out_0(DB_out_0), 
            .DB_out_1(DB_out_1), .Clk_enable_290(Clk_enable_290), .Clk_enable_33(Clk_enable_33), 
            .DB_out_2(DB_out_2), .DB_out_3(DB_out_3), .DB_out_5(DB_out_5), 
            .DB_out_6(DB_out_6), .DB_out_7(DB_out_7), .Clk_enable_14(Clk_enable_14), 
            .A_c_2(A_c_2)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(166[17] 186[2])
    PLL MOD_PLL (.MCLK_c(MCLK_c), .Clk(Clk), .GND_net(GND_net)) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(152[5] 153[17])
    GSR GSR_INST (.GSR(VCC_net));
    REG2000_2001 MOD_REG2000_2001 (.EMP_G(EMP_G), .Clk(Clk), .Clk_enable_14(Clk_enable_14), 
            .nPCLK(nPCLK), .nVIS(nVIS), .CLIP_B_N_277(CLIP_B_N_277), .EMPH({EMPH}), 
            .EMP_R(EMP_R), .n1026(n1026), .BGSEL(BGSEL), .Clk_enable_33(Clk_enable_33), 
            .O8_16(O8_16), .BGCLIP(BGCLIP), .CLIPOR(CLIPOR), .MODE_c(MODE_c), 
            .I1_32(I1_32), .W1(W1), .DBIN({DBIN}), .VBL_EN(VBL_EN), 
            .W0(W0), .OBSEL(OBSEL), .BLNK_FF(BLNK_FF), .BLNK(BLNK), 
            .N_HB(N_HB), .SC_CNT(SC_CNT), .RC(RC), .nCLPB_N_121(nCLPB_N_121), 
            .B_W(B_W), .CLIP_OUT(CLIP_OUT)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(189[14] 212[2])
    VID_MUX MOD_VID_MUX (.\R2DB[1] (R2DB[1]), .Clk(Clk), .SPR0HIT_LATCH(SPR0HIT_LATCH), 
            .SPR0_EV(SPR0_EV), .nVIS(nVIS), .PCLK_c(PCLK_c), .RESCL(RESCL), 
            .ZCOL({ZCOL}), .THO_LATCH({Open_0, Open_1, Open_2, Open_3, 
            THO_LATCH[0]}), .THO({THO}), .nPCLK(nPCLK), .BGC2({BGC2}), 
            .CLPB_LATCH(CLPB_LATCH), .\THO_LATCH[4] (THO_LATCH[4]), .\STEP3[4] (STEP3[4]), 
            .TH_MUX(TH_MUX), .\CGA[3] (CGA[3]), .\CGA[2] (CGA[2]), .\CGA[1] (CGA[1]), 
            .\STEP3[0] (STEP3[0]), .\CGA[0] (CGA[0])) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(418[9] 432[2])
    
endmodule
//
// Verilog Description of module PAR_GEN
//

module PAR_GEN (W7_Q2, W7_Q4, \Hn[2] , BLNK, PCLK_c, Clk, nPCLK, 
            VINV_LATCH_N_1001, OB, E_EV, F_AT, SC_CNT, PD_FIFO_N_1103, 
            \PAD[1] , GND_net, OV, DB_PAR_N_634, nF_NT, TV_IN, PD_out_0, 
            \PAD[6] , TSTEP, RESCL, I1_32, THO, DBIN, VCC_net, 
            TVO1, \TVO[0] , \Hn[1] , W6_2, STEP_N_807, RC, PAR_O, 
            W6_1, W5_2, PA_c_0, \PAD[2] , \PAD[3] , \PAD[4] , \PAD[5] , 
            PA_c_1, PA_c_2, PA_c_3, PA_c_4, W0, PD_out_1, PD_out_2, 
            PD_out_3, PD_out_4, PD_out_5, PD_out_6, PD_out_7, PA_c_5, 
            Clk_enable_292, W5_1, O8_16, BGSEL, OBSEL, \PAD[7] , 
            \PAD[0] , SH2, PD_FIFO2, Hnn0_N_999, THO1R, \PDAT[5] , 
            ATSEL_1__N_798, \PDAT[4] , CNT1_N_1080) /* synthesis syn_module_defined=1 */ ;
    input W7_Q2;
    input W7_Q4;
    input \Hn[2] ;
    input BLNK;
    input PCLK_c;
    input Clk;
    input nPCLK;
    output VINV_LATCH_N_1001;
    input [7:0]OB;
    input E_EV;
    input F_AT;
    input SC_CNT;
    input PD_FIFO_N_1103;
    output \PAD[1] ;
    input GND_net;
    input [3:0]OV;
    input DB_PAR_N_634;
    input nF_NT;
    output TV_IN;
    input PD_out_0;
    output \PAD[6] ;
    input TSTEP;
    input RESCL;
    input I1_32;
    output [4:0]THO;
    input [7:0]DBIN;
    input VCC_net;
    output TVO1;
    output \TVO[0] ;
    input \Hn[1] ;
    input W6_2;
    input STEP_N_807;
    input RC;
    input PAR_O;
    input W6_1;
    input W5_2;
    output PA_c_0;
    output \PAD[2] ;
    output \PAD[3] ;
    output \PAD[4] ;
    output \PAD[5] ;
    output PA_c_1;
    output PA_c_2;
    output PA_c_3;
    output PA_c_4;
    input W0;
    input PD_out_1;
    input PD_out_2;
    input PD_out_3;
    input PD_out_4;
    input PD_out_5;
    input PD_out_6;
    input PD_out_7;
    output PA_c_5;
    input Clk_enable_292;
    input W5_1;
    input O8_16;
    input BGSEL;
    input OBSEL;
    output \PAD[7] ;
    output \PAD[0] ;
    input SH2;
    output PD_FIFO2;
    input Hnn0_N_999;
    input THO1R;
    input \PDAT[5] ;
    output [1:0]ATSEL_1__N_798;
    input \PDAT[4] ;
    input CNT1_N_1080;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire n2230, Z_TV1, Z_TV2, Z_TV_N_1050, EEVR2, W62_2, THLOAD_N_1038, 
        Z_TV1_N_1018, TVZR, TVZ, VINV_LATCH, TVZR_N_1023, EEVR1, 
        W62_1, W62_1_N_1030;
    wire [11:0]TP;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1093[11:13])
    wire [4:0]TVO;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1129[11:14])
    
    wire PARR_N_1073;
    wire [13:0]PAQ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1150[12:15])
    
    wire SCCNTR;
    wire [3:0]OVOUT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1089[10:15])
    wire [3:0]OVR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1088[10:13])
    
    wire n4599, n2232, W62_FF_N_1027, n4502;
    wire [7:0]OBOUT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1092[10:15])
    wire [7:0]PDOUT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1091[10:15])
    wire [7:0]PDIN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1090[10:14])
    
    wire n4447, FVZ_N_1070;
    wire [2:0]TP_11__N_993;
    wire [2:0]FVO;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1131[11:14])
    
    wire NTVDO, n8786, NTHDO;
    wire [4:0]THOCout;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1129[16:23])
    
    wire CNT1_N_1080_c, TVLOAD_N_1043, Clk_enable_20, W62_FF, Clk_enable_35, 
        THSTEP_N_1047;
    wire [2:0]FV;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1097[10:12])
    
    wire Clk_enable_282, FV_2__N_951, FV_2__N_954, CNT1, n2290, NTV, 
        CNT1_adj_1929, n2397, CNT1_adj_1930, n2395, TV_4__N_922, TV_4__N_929, 
        Clk_enable_289, Clk_enable_288, NTH_N_1004, FV_2__N_959, TV_4__N_934, 
        CNT1_adj_1931, n2393, NTV_N_1011, TV_4__N_946, TV_4__N_941;
    wire [4:0]TV;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1095[10:12])
    
    wire TP_11__N_992, TP_11__N_991;
    wire [6:0]TP_11__N_984;
    
    wire TP_11__N_982, NBFVO1;
    wire [4:0]TH;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1094[10:12])
    
    wire TH_4__N_895, TH_4__N_917, TH_4__N_902, TH_4__N_907, TH_4__N_912, 
        CNT1_adj_1932, n2368, CNT1_adj_1933, n2379, CNT1_adj_1934, 
        n2362, CNT1_adj_1935, n2346, TP_11__N_983, CNT1_adj_1936, 
        n2360, THZ_N_1056, n5651, NTH_IN, n6, n8749, NTH, CNT1_N_1080_adj_1937, 
        n4513, Clk_enable_296, CNT1_N_1080_adj_1938;
    wire [4:0]TVOCout;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1129[25:32])
    
    wire CNT1_N_1080_adj_1939, Clk_enable_34, CNT1_N_1080_adj_1941;
    wire [2:0]FVOCout;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1131[16:23])
    
    LUT4 i1640_2_lut_4_lut (.A(W7_Q2), .B(W7_Q4), .C(\Hn[2] ), .D(BLNK), 
         .Z(n2230)) /* synthesis lut_function=(A ((D)+!C)+!A (B ((D)+!C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1148[6:10])
    defparam i1640_2_lut_4_lut.init = 16'hee0e;
    LUT4 Z_TV1_I_0_2_lut (.A(Z_TV1), .B(Z_TV2), .Z(Z_TV_N_1050)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1117[16:33])
    defparam Z_TV1_I_0_2_lut.init = 16'heeee;
    LUT4 THLOAD_I_257_3_lut (.A(EEVR2), .B(PCLK_c), .C(W62_2), .Z(THLOAD_N_1038)) /* synthesis lut_function=(A (B)+!A (B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1111[18:48])
    defparam THLOAD_I_257_3_lut.init = 16'hcdcd;
    FD1P3AX Z_TV1_261 (.D(Z_TV1_N_1018), .SP(nPCLK), .CK(Clk), .Q(Z_TV1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam Z_TV1_261.GSR = "ENABLED";
    FD1P3AX TVZR_252 (.D(TVZ), .SP(PCLK_c), .CK(Clk), .Q(TVZR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TVZR_252.GSR = "ENABLED";
    FD1P3AX VINV_LATCH_246 (.D(OB[7]), .SP(VINV_LATCH_N_1001), .CK(Clk), 
            .Q(VINV_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam VINV_LATCH_246.GSR = "ENABLED";
    FD1P3AX Z_TV2_262 (.D(TVZR_N_1023), .SP(nPCLK), .CK(Clk), .Q(Z_TV2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam Z_TV2_262.GSR = "ENABLED";
    FD1P3AX EEVR1_263 (.D(E_EV), .SP(nPCLK), .CK(Clk), .Q(EEVR1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam EEVR1_263.GSR = "ENABLED";
    FD1P3AX W62_1_264 (.D(W62_1_N_1030), .SP(nPCLK), .CK(Clk), .Q(W62_1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam W62_1_264.GSR = "ENABLED";
    FD1P3AX EEVR2_253 (.D(EEVR1), .SP(PCLK_c), .CK(Clk), .Q(EEVR2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam EEVR2_253.GSR = "ENABLED";
    LUT4 NBFVO1_I_0_i1_4_lut (.A(TP[7]), .B(TVO[3]), .C(PARR_N_1073), 
         .D(F_AT), .Z(PAQ[8])) /* synthesis lut_function=(A (B+((D)+!C))+!A (B (C)+!B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1152[20:124])
    defparam NBFVO1_I_0_i1_4_lut.init = 16'hfaca;
    LUT4 NBFVO1_I_0_i2_4_lut (.A(TP[8]), .B(TVO[4]), .C(PARR_N_1073), 
         .D(F_AT), .Z(PAQ[9])) /* synthesis lut_function=(A (B+((D)+!C))+!A (B (C)+!B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1152[20:124])
    defparam NBFVO1_I_0_i2_4_lut.init = 16'hfaca;
    FD1P3AX SCCNTR_254 (.D(SC_CNT), .SP(PCLK_c), .CK(Clk), .Q(SCCNTR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam SCCNTR_254.GSR = "ENABLED";
    FD1P3AX W62_2_255 (.D(W62_1), .SP(PCLK_c), .CK(Clk), .Q(W62_2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam W62_2_255.GSR = "ENABLED";
    FD1P3AX OVOUT_i0_i0 (.D(OVR[0]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(OVOUT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OVOUT_i0_i0.GSR = "ENABLED";
    OFS1P3DX PAD_i0_i1 (.D(PAQ[1]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PAD_i0_i1.GSR = "ENABLED";
    LUT4 i3988_2_lut_3_lut (.A(PCLK_c), .B(\Hn[2] ), .C(BLNK), .Z(n4599)) /* synthesis lut_function=(!(((C)+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam i3988_2_lut_3_lut.init = 16'h0808;
    FD1P3AX OVR_i0_i0 (.D(OV[0]), .SP(nPCLK), .CK(Clk), .Q(OVR[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OVR_i0_i0.GSR = "ENABLED";
    LUT4 i1642_3_lut (.A(DB_PAR_N_634), .B(PARR_N_1073), .C(F_AT), .Z(n2232)) /* synthesis lut_function=(!(A+(B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(897[8:14])
    defparam i1642_3_lut.init = 16'h1515;
    LUT4 i8474_2_lut (.A(PCLK_c), .B(W62_2), .Z(W62_FF_N_1027)) /* synthesis lut_function=(A+!(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam i8474_2_lut.init = 16'hbbbb;
    LUT4 i3891_2_lut_2_lut (.A(PCLK_c), .B(nF_NT), .Z(n4502)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1243[8] 1263[25])
    defparam i3891_2_lut_2_lut.init = 16'h4444;
    LUT4 NHn2_I_0_2_lut (.A(\Hn[2] ), .B(BLNK), .Z(PARR_N_1073)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1149[16:31])
    defparam NHn2_I_0_2_lut.init = 16'hdddd;
    FD1P3AX OBOUT_i0_i0 (.D(OB[0]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(OBOUT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OBOUT_i0_i0.GSR = "ENABLED";
    FD1P3AX PDOUT_i0_i0 (.D(PDIN[0]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(PDOUT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDOUT_i0_i0.GSR = "ENABLED";
    FD1S3JX TV_IN_247 (.D(FVZ_N_1070), .CK(Clk), .PD(n4447), .Q(TV_IN)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TV_IN_247.GSR = "ENABLED";
    FD1P3AX PDIN_i0_i0 (.D(PD_out_0), .SP(nPCLK), .CK(Clk), .Q(PDIN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDIN_i0_i0.GSR = "ENABLED";
    FD1P3AX TP_i0_i0 (.D(TP_11__N_993[0]), .SP(nPCLK), .CK(Clk), .Q(TP[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TP_i0_i0.GSR = "ENABLED";
    OFS1P3DX PAD_i0_i6 (.D(PAQ[6]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PAD_i0_i6.GSR = "ENABLED";
    LUT4 NBFVO1_I_0_i5_4_lut_4_lut (.A(TP[11]), .B(BLNK), .C(\Hn[2] ), 
         .D(FVO[0]), .Z(PAQ[12])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1152[20:124])
    defparam NBFVO1_I_0_i5_4_lut_4_lut.init = 16'hec20;
    LUT4 NBFVO1_I_0_i4_3_lut_4_lut (.A(TP[10]), .B(NTVDO), .C(\Hn[2] ), 
         .D(BLNK), .Z(PAQ[11])) /* synthesis lut_function=(A (B+!((D)+!C))+!A (B ((D)+!C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1152[20:124])
    defparam NBFVO1_I_0_i4_3_lut_4_lut.init = 16'hccac;
    LUT4 i8186_2_lut_3_lut_4_lut (.A(E_EV), .B(TSTEP), .C(RESCL), .D(SCCNTR), 
         .Z(n8786)) /* synthesis lut_function=(A+(B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1115[21:39])
    defparam i8186_2_lut_3_lut_4_lut.init = 16'hfeee;
    LUT4 NBFVO1_I_0_i3_3_lut_4_lut (.A(TP[9]), .B(NTHDO), .C(\Hn[2] ), 
         .D(BLNK), .Z(PAQ[10])) /* synthesis lut_function=(A (B+!((D)+!C))+!A (B ((D)+!C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1152[20:124])
    defparam NBFVO1_I_0_i3_3_lut_4_lut.init = 16'hccac;
    LUT4 CNT_I_0_18_2_lut_3_lut (.A(I1_32), .B(BLNK), .C(THO[0]), .Z(THOCout[0])) /* synthesis lut_function=(!(A (B+!(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1119[17:33])
    defparam CNT_I_0_18_2_lut_3_lut.init = 16'h7070;
    LUT4 i1_2_lut_3_lut (.A(I1_32), .B(BLNK), .C(THO[0]), .Z(CNT1_N_1080_c)) /* synthesis lut_function=(A (B (C)+!B !(C))+!A !(C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1119[17:33])
    defparam i1_2_lut_3_lut.init = 16'h8787;
    LUT4 Z_TV1_I_253_2_lut_3_lut (.A(E_EV), .B(TSTEP), .C(PCLK_c), .Z(Z_TV1_N_1018)) /* synthesis lut_function=(A (C)+!A ((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1115[21:39])
    defparam Z_TV1_I_253_2_lut_3_lut.init = 16'hf1f1;
    LUT4 i8521_3_lut_4_lut (.A(E_EV), .B(TSTEP), .C(TVLOAD_N_1043), .D(PCLK_c), 
         .Z(Clk_enable_20)) /* synthesis lut_function=(!(A (D)+!A (B (D)+!B ((D)+!C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1115[21:39])
    defparam i8521_3_lut_4_lut.init = 16'h00fe;
    MUX41 PAQ_7__I_012 (.D0(DBIN[7]), .D1(TP[6]), .D2(VCC_net), .D3(TVO[2]), 
          .SD1(n2232), .SD2(n2230), .Z(PAQ[7]));
    MUX41 PAQ_7__I_011 (.D0(DBIN[6]), .D1(TP[5]), .D2(VCC_net), .D3(TVO1), 
          .SD1(n2232), .SD2(n2230), .Z(PAQ[6]));
    MUX41 PAQ_7__I_010 (.D0(DBIN[5]), .D1(TP[4]), .D2(TVO[4]), .D3(\TVO[0] ), 
          .SD1(n2232), .SD2(n2230), .Z(PAQ[5]));
    MUX41 PAQ_7__I_09 (.D0(DBIN[4]), .D1(TP[3]), .D2(TVO[3]), .D3(THO[4]), 
          .SD1(n2232), .SD2(n2230), .Z(PAQ[4]));
    MUX41 PAQ_7__I_08 (.D0(DBIN[3]), .D1(\Hn[1] ), .D2(TVO[2]), .D3(THO[3]), 
          .SD1(n2232), .SD2(n2230), .Z(PAQ[3]));
    FD1P3AX W62_FF_251 (.D(W62_FF_N_1027), .SP(Clk_enable_35), .CK(Clk), 
            .Q(W62_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam W62_FF_251.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut_adj_495 (.A(W6_2), .B(PCLK_c), .C(W62_2), .Z(Clk_enable_35)) /* synthesis lut_function=(A+!(B+!(C))) */ ;
    defparam i1_2_lut_3_lut_adj_495.init = 16'hbaba;
    MUX41 PAQ_7__I_07 (.D0(DBIN[2]), .D1(TP[2]), .D2(THO[4]), .D3(THO[2]), 
          .SD1(n2232), .SD2(n2230), .Z(PAQ[2]));
    LUT4 THSTEP_I_264_2_lut (.A(STEP_N_807), .B(TSTEP), .Z(THSTEP_N_1047)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1114[21:48])
    defparam THSTEP_I_264_2_lut.init = 16'heeee;
    MUX41 PAQ_7__I_06 (.D0(DBIN[1]), .D1(TP[1]), .D2(THO[3]), .D3(THO[1]), 
          .SD1(n2232), .SD2(n2230), .Z(PAQ[1]));
    MUX41 PAQ_7__I_05 (.D0(DBIN[0]), .D1(TP[0]), .D2(THO[2]), .D3(THO[0]), 
          .SD1(n2232), .SD2(n2230), .Z(PAQ[0]));
    FD1P3IX FV__i2 (.D(FV_2__N_951), .SP(Clk_enable_282), .CD(RC), .CK(Clk), 
            .Q(FV[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam FV__i2.GSR = "ENABLED";
    FD1P3IX FV__i1 (.D(FV_2__N_954), .SP(Clk_enable_282), .CD(RC), .CK(Clk), 
            .Q(FV[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam FV__i1.GSR = "ENABLED";
    LUT4 mux_197_i2_4_lut (.A(FVO[1]), .B(VINV_LATCH), .C(PAR_O), .D(OVOUT[1]), 
         .Z(TP_11__N_993[1])) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1191[16:49])
    defparam mux_197_i2_4_lut.init = 16'h3aca;
    LUT4 i1_3_lut (.A(W6_1), .B(RC), .C(W5_2), .Z(Clk_enable_282)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1165[9:25])
    defparam i1_3_lut.init = 16'hfefe;
    LUT4 W5_2_I_0_286_2_lut (.A(W5_2), .B(DBIN[2]), .Z(FV_2__N_951)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1170[67:83])
    defparam W5_2_I_0_286_2_lut.init = 16'h8888;
    LUT4 TVLOAD_I_261_2_lut_3_lut (.A(SCCNTR), .B(RESCL), .C(W62_2), .Z(TVLOAD_N_1043)) /* synthesis lut_function=(A (B+(C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1112[22:40])
    defparam TVLOAD_I_261_2_lut_3_lut.init = 16'hf8f8;
    LUT4 FV_2__I_244_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[5]), .D(DBIN[1]), 
         .Z(FV_2__N_954)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1169[48:83])
    defparam FV_2__I_244_4_lut.init = 16'heca0;
    LUT4 i1706_3_lut_4_lut (.A(TVLOAD_N_1043), .B(PCLK_c), .C(FV[0]), 
         .D(CNT1), .Z(n2290)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1112[18:58])
    defparam i1706_3_lut_4_lut.init = 16'hfd20;
    LUT4 i1809_3_lut_4_lut (.A(TVLOAD_N_1043), .B(PCLK_c), .C(NTV), .D(CNT1_adj_1929), 
         .Z(n2397)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1112[18:58])
    defparam i1809_3_lut_4_lut.init = 16'hfd20;
    LUT4 i1807_3_lut_4_lut (.A(TVLOAD_N_1043), .B(PCLK_c), .C(FV[2]), 
         .D(CNT1_adj_1930), .Z(n2395)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1112[18:58])
    defparam i1807_3_lut_4_lut.init = 16'hfd20;
    LUT4 TV_4__I_231_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[1]), .D(DBIN[7]), 
         .Z(TV_4__N_922)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1165[48:83])
    defparam TV_4__I_231_4_lut.init = 16'heca0;
    LUT4 TV_4__I_234_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[0]), .D(DBIN[6]), 
         .Z(TV_4__N_929)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1164[48:83])
    defparam TV_4__I_234_4_lut.init = 16'heca0;
    LUT4 i2_3_lut (.A(W5_2), .B(W6_2), .C(RC), .Z(Clk_enable_289)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1163[9:20])
    defparam i2_3_lut.init = 16'hfefe;
    FD1P3AX PAD_i0_i8 (.D(PAQ[8]), .SP(PCLK_c), .CK(Clk), .Q(PA_c_0)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PAD_i0_i8.GSR = "ENABLED";
    OFS1P3DX PAD_i0_i2 (.D(PAQ[2]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PAD_i0_i2.GSR = "ENABLED";
    OFS1P3DX PAD_i0_i3 (.D(PAQ[3]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PAD_i0_i3.GSR = "ENABLED";
    OFS1P3DX PAD_i0_i4 (.D(PAQ[4]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PAD_i0_i4.GSR = "ENABLED";
    OFS1P3DX PAD_i0_i5 (.D(PAQ[5]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PAD_i0_i5.GSR = "ENABLED";
    FD1P3AX PAD_i0_i9 (.D(PAQ[9]), .SP(PCLK_c), .CK(Clk), .Q(PA_c_1)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PAD_i0_i9.GSR = "ENABLED";
    FD1P3AX PAD_i0_i10 (.D(PAQ[10]), .SP(PCLK_c), .CK(Clk), .Q(PA_c_2)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PAD_i0_i10.GSR = "ENABLED";
    FD1P3AX PAD_i0_i11 (.D(PAQ[11]), .SP(PCLK_c), .CK(Clk), .Q(PA_c_3)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PAD_i0_i11.GSR = "ENABLED";
    FD1P3AX PAD_i0_i12 (.D(PAQ[12]), .SP(PCLK_c), .CK(Clk), .Q(PA_c_4)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PAD_i0_i12.GSR = "ENABLED";
    FD1P3AX OVOUT_i0_i1 (.D(OVR[1]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(OVOUT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OVOUT_i0_i1.GSR = "ENABLED";
    FD1P3AX OVOUT_i0_i2 (.D(OVR[2]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(OVOUT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OVOUT_i0_i2.GSR = "ENABLED";
    FD1P3AX OVOUT_i0_i3 (.D(OVR[3]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(OVOUT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OVOUT_i0_i3.GSR = "ENABLED";
    FD1P3AX OVR_i0_i1 (.D(OV[1]), .SP(nPCLK), .CK(Clk), .Q(OVR[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OVR_i0_i1.GSR = "ENABLED";
    FD1P3AX OVR_i0_i2 (.D(OV[2]), .SP(nPCLK), .CK(Clk), .Q(OVR[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OVR_i0_i2.GSR = "ENABLED";
    FD1P3AX OVR_i0_i3 (.D(OV[3]), .SP(nPCLK), .CK(Clk), .Q(OVR[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OVR_i0_i3.GSR = "ENABLED";
    LUT4 i2_3_lut_adj_496 (.A(W6_1), .B(W0), .C(RC), .Z(Clk_enable_288)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1166[9:25])
    defparam i2_3_lut_adj_496.init = 16'hfefe;
    LUT4 NTH_I_249_4_lut (.A(W6_1), .B(W0), .C(DBIN[2]), .D(DBIN[0]), 
         .Z(NTH_N_1004)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1166[48:83])
    defparam NTH_I_249_4_lut.init = 16'heca0;
    LUT4 FV_2__I_246_4_lut (.A(W6_1), .B(W5_2), .C(DBIN[4]), .D(DBIN[0]), 
         .Z(FV_2__N_959)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1168[48:83])
    defparam FV_2__I_246_4_lut.init = 16'heca0;
    LUT4 TV_4__I_236_4_lut (.A(W6_2), .B(W5_2), .C(DBIN[7]), .D(DBIN[5]), 
         .Z(TV_4__N_934)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1163[48:83])
    defparam TV_4__I_236_4_lut.init = 16'heca0;
    LUT4 i1805_3_lut_4_lut (.A(TVLOAD_N_1043), .B(PCLK_c), .C(FV[1]), 
         .D(CNT1_adj_1931), .Z(n2393)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1112[18:58])
    defparam i1805_3_lut_4_lut.init = 16'hfd20;
    LUT4 NTV_I_252_4_lut (.A(W6_1), .B(W0), .C(DBIN[3]), .D(DBIN[1]), 
         .Z(NTV_N_1011)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1167[48:83])
    defparam NTV_I_252_4_lut.init = 16'heca0;
    LUT4 TV_4__I_241_4_lut (.A(W6_2), .B(W5_2), .C(DBIN[5]), .D(DBIN[3]), 
         .Z(TV_4__N_946)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1161[48:83])
    defparam TV_4__I_241_4_lut.init = 16'heca0;
    LUT4 TV_4__I_239_4_lut (.A(W6_2), .B(W5_2), .C(DBIN[6]), .D(DBIN[4]), 
         .Z(TV_4__N_941)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1162[48:83])
    defparam TV_4__I_239_4_lut.init = 16'heca0;
    FD1P3AX OBOUT_i0_i1 (.D(OB[1]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(OBOUT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OBOUT_i0_i1.GSR = "ENABLED";
    FD1P3AX OBOUT_i0_i2 (.D(OB[2]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(OBOUT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OBOUT_i0_i2.GSR = "ENABLED";
    FD1P3AX OBOUT_i0_i3 (.D(OB[3]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(OBOUT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OBOUT_i0_i3.GSR = "ENABLED";
    FD1P3AX OBOUT_i0_i4 (.D(OB[4]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(OBOUT[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OBOUT_i0_i4.GSR = "ENABLED";
    FD1P3AX OBOUT_i0_i5 (.D(OB[5]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(OBOUT[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OBOUT_i0_i5.GSR = "ENABLED";
    FD1P3AX OBOUT_i0_i6 (.D(OB[6]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(OBOUT[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OBOUT_i0_i6.GSR = "ENABLED";
    FD1P3AX OBOUT_i0_i7 (.D(OB[7]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(OBOUT[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam OBOUT_i0_i7.GSR = "ENABLED";
    FD1P3AX PDOUT_i0_i1 (.D(PDIN[1]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(PDOUT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDOUT_i0_i1.GSR = "ENABLED";
    FD1P3AX PDOUT_i0_i2 (.D(PDIN[2]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(PDOUT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDOUT_i0_i2.GSR = "ENABLED";
    FD1P3AX PDOUT_i0_i3 (.D(PDIN[3]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(PDOUT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDOUT_i0_i3.GSR = "ENABLED";
    FD1P3AX PDOUT_i0_i4 (.D(PDIN[4]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(PDOUT[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDOUT_i0_i4.GSR = "ENABLED";
    FD1P3AX PDOUT_i0_i5 (.D(PDIN[5]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(PDOUT[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDOUT_i0_i5.GSR = "ENABLED";
    FD1P3AX PDOUT_i0_i6 (.D(PDIN[6]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(PDOUT[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDOUT_i0_i6.GSR = "ENABLED";
    FD1P3AX PDOUT_i0_i7 (.D(PDIN[7]), .SP(PD_FIFO_N_1103), .CK(Clk), .Q(PDOUT[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDOUT_i0_i7.GSR = "ENABLED";
    FD1P3AX PDIN_i0_i1 (.D(PD_out_1), .SP(nPCLK), .CK(Clk), .Q(PDIN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDIN_i0_i1.GSR = "ENABLED";
    FD1P3AX PDIN_i0_i2 (.D(PD_out_2), .SP(nPCLK), .CK(Clk), .Q(PDIN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDIN_i0_i2.GSR = "ENABLED";
    FD1P3AX PDIN_i0_i3 (.D(PD_out_3), .SP(nPCLK), .CK(Clk), .Q(PDIN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDIN_i0_i3.GSR = "ENABLED";
    FD1P3AX PDIN_i0_i4 (.D(PD_out_4), .SP(nPCLK), .CK(Clk), .Q(PDIN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDIN_i0_i4.GSR = "ENABLED";
    FD1P3AX PDIN_i0_i5 (.D(PD_out_5), .SP(nPCLK), .CK(Clk), .Q(PDIN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDIN_i0_i5.GSR = "ENABLED";
    FD1P3AX PDIN_i0_i6 (.D(PD_out_6), .SP(nPCLK), .CK(Clk), .Q(PDIN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDIN_i0_i6.GSR = "ENABLED";
    FD1P3AX PDIN_i0_i7 (.D(PD_out_7), .SP(nPCLK), .CK(Clk), .Q(PDIN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PDIN_i0_i7.GSR = "ENABLED";
    FD1P3AX TP_i0_i1 (.D(TP_11__N_993[1]), .SP(nPCLK), .CK(Clk), .Q(TP[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TP_i0_i1.GSR = "ENABLED";
    LUT4 mux_197_i3_4_lut (.A(FVO[2]), .B(VINV_LATCH), .C(PAR_O), .D(OVOUT[2]), 
         .Z(TP_11__N_993[2])) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1191[16:49])
    defparam mux_197_i3_4_lut.init = 16'h3aca;
    FD1P3IX TV_i4 (.D(TV_4__N_922), .SP(Clk_enable_282), .CD(RC), .CK(Clk), 
            .Q(TV[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TV_i4.GSR = "ENABLED";
    LUT4 PDOUT_0__I_0_3_lut (.A(PDOUT[0]), .B(TP_11__N_992), .C(PAR_O), 
         .Z(TP_11__N_991)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1192[16:75])
    defparam PDOUT_0__I_0_3_lut.init = 16'hcaca;
    FD1P3IX TV_i3 (.D(TV_4__N_929), .SP(Clk_enable_282), .CD(RC), .CK(Clk), 
            .Q(TV[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TV_i3.GSR = "ENABLED";
    FD1P3IX TV_i2 (.D(TV_4__N_934), .SP(Clk_enable_289), .CD(RC), .CK(Clk), 
            .Q(TV[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TV_i2.GSR = "ENABLED";
    FD1P3IX TV_i1 (.D(TV_4__N_941), .SP(Clk_enable_289), .CD(RC), .CK(Clk), 
            .Q(TV[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TV_i1.GSR = "ENABLED";
    FD1P3AX TP_i0_i2 (.D(TP_11__N_993[2]), .SP(nPCLK), .CK(Clk), .Q(TP[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TP_i0_i2.GSR = "ENABLED";
    FD1P3AX TP_i0_i3 (.D(TP_11__N_991), .SP(nPCLK), .CK(Clk), .Q(TP[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TP_i0_i3.GSR = "ENABLED";
    FD1P3AX TP_i0_i4 (.D(TP_11__N_984[0]), .SP(nPCLK), .CK(Clk), .Q(TP[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TP_i0_i4.GSR = "ENABLED";
    FD1P3AX TP_i0_i5 (.D(TP_11__N_984[1]), .SP(nPCLK), .CK(Clk), .Q(TP[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TP_i0_i5.GSR = "ENABLED";
    FD1P3AX TP_i0_i6 (.D(TP_11__N_984[2]), .SP(nPCLK), .CK(Clk), .Q(TP[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TP_i0_i6.GSR = "ENABLED";
    FD1P3AX TP_i0_i7 (.D(TP_11__N_984[3]), .SP(nPCLK), .CK(Clk), .Q(TP[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TP_i0_i7.GSR = "ENABLED";
    FD1P3AX TP_i0_i8 (.D(TP_11__N_984[4]), .SP(nPCLK), .CK(Clk), .Q(TP[8])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TP_i0_i8.GSR = "ENABLED";
    FD1P3AX TP_i0_i9 (.D(TP_11__N_984[5]), .SP(nPCLK), .CK(Clk), .Q(TP[9])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TP_i0_i9.GSR = "ENABLED";
    FD1P3AX TP_i0_i10 (.D(TP_11__N_984[6]), .SP(nPCLK), .CK(Clk), .Q(TP[10])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TP_i0_i10.GSR = "ENABLED";
    FD1P3AX TP_i0_i11 (.D(TP_11__N_982), .SP(nPCLK), .CK(Clk), .Q(TP[11])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TP_i0_i11.GSR = "ENABLED";
    FD1P3IX PAD_i0_i13 (.D(NBFVO1), .SP(PCLK_c), .CD(n4599), .CK(Clk), 
            .Q(PA_c_5)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PAD_i0_i13.GSR = "ENABLED";
    FD1P3IX TH__i4 (.D(TH_4__N_895), .SP(Clk_enable_292), .CD(RC), .CK(Clk), 
            .Q(TH[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TH__i4.GSR = "ENABLED";
    LUT4 TH_4__I_229_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[0]), .D(DBIN[3]), 
         .Z(TH_4__N_917)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1156[48:83])
    defparam TH_4__I_229_4_lut.init = 16'heca0;
    FD1P3IX TH__i3 (.D(TH_4__N_902), .SP(Clk_enable_292), .CD(RC), .CK(Clk), 
            .Q(TH[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TH__i3.GSR = "ENABLED";
    FD1P3IX TH__i2 (.D(TH_4__N_907), .SP(Clk_enable_292), .CD(RC), .CK(Clk), 
            .Q(TH[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TH__i2.GSR = "ENABLED";
    FD1P3IX TH__i1 (.D(TH_4__N_912), .SP(Clk_enable_292), .CD(RC), .CK(Clk), 
            .Q(TH[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TH__i1.GSR = "ENABLED";
    LUT4 i1781_3_lut_4_lut (.A(TVLOAD_N_1043), .B(PCLK_c), .C(TV[1]), 
         .D(CNT1_adj_1932), .Z(n2368)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1112[18:58])
    defparam i1781_3_lut_4_lut.init = 16'hfd20;
    LUT4 i1791_3_lut_4_lut (.A(TVLOAD_N_1043), .B(PCLK_c), .C(TV[0]), 
         .D(CNT1_adj_1933), .Z(n2379)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1112[18:58])
    defparam i1791_3_lut_4_lut.init = 16'hfd20;
    LUT4 OBOUT_0__I_0_4_lut (.A(OBOUT[0]), .B(VINV_LATCH), .C(O8_16), 
         .D(OVOUT[3]), .Z(TP_11__N_992)) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1192[26:64])
    defparam OBOUT_0__I_0_4_lut.init = 16'h3aca;
    LUT4 mux_200_i1_3_lut (.A(PDOUT[1]), .B(OBOUT[1]), .C(PAR_O), .Z(TP_11__N_984[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1193[16:51])
    defparam mux_200_i1_3_lut.init = 16'hcaca;
    LUT4 mux_200_i2_3_lut (.A(PDOUT[2]), .B(OBOUT[2]), .C(PAR_O), .Z(TP_11__N_984[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1193[16:51])
    defparam mux_200_i2_3_lut.init = 16'hcaca;
    LUT4 i1775_3_lut_4_lut (.A(TVLOAD_N_1043), .B(PCLK_c), .C(TV[2]), 
         .D(CNT1_adj_1934), .Z(n2362)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1112[18:58])
    defparam i1775_3_lut_4_lut.init = 16'hfd20;
    LUT4 mux_200_i3_3_lut (.A(PDOUT[3]), .B(OBOUT[3]), .C(PAR_O), .Z(TP_11__N_984[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1193[16:51])
    defparam mux_200_i3_3_lut.init = 16'hcaca;
    LUT4 i1760_3_lut_4_lut (.A(TVLOAD_N_1043), .B(PCLK_c), .C(TV[4]), 
         .D(CNT1_adj_1935), .Z(n2346)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1112[18:58])
    defparam i1760_3_lut_4_lut.init = 16'hfd20;
    LUT4 mux_200_i4_3_lut (.A(PDOUT[4]), .B(OBOUT[4]), .C(PAR_O), .Z(TP_11__N_984[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1193[16:51])
    defparam mux_200_i4_3_lut.init = 16'hcaca;
    LUT4 mux_200_i5_3_lut (.A(PDOUT[5]), .B(OBOUT[5]), .C(PAR_O), .Z(TP_11__N_984[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1193[16:51])
    defparam mux_200_i5_3_lut.init = 16'hcaca;
    LUT4 mux_200_i6_3_lut (.A(PDOUT[6]), .B(OBOUT[6]), .C(PAR_O), .Z(TP_11__N_984[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1193[16:51])
    defparam mux_200_i6_3_lut.init = 16'hcaca;
    LUT4 mux_200_i7_3_lut (.A(PDOUT[7]), .B(OBOUT[7]), .C(PAR_O), .Z(TP_11__N_984[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1193[16:51])
    defparam mux_200_i7_3_lut.init = 16'hcaca;
    LUT4 BGSEL_I_0_3_lut (.A(BGSEL), .B(TP_11__N_983), .C(PAR_O), .Z(TP_11__N_982)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1194[16:72])
    defparam BGSEL_I_0_3_lut.init = 16'hcaca;
    LUT4 OBSEL_I_0_3_lut (.A(OBSEL), .B(OBOUT[0]), .C(O8_16), .Z(TP_11__N_983)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1194[26:61])
    defparam OBSEL_I_0_3_lut.init = 16'hcaca;
    LUT4 BLNK_N_1054_I_0_2_lut (.A(BLNK), .B(FVO[1]), .Z(NBFVO1)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1147[17:31])
    defparam BLNK_N_1054_I_0_2_lut.init = 16'hdddd;
    LUT4 TH_4__I_220_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[4]), .D(DBIN[7]), 
         .Z(TH_4__N_895)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1160[48:83])
    defparam TH_4__I_220_4_lut.init = 16'heca0;
    LUT4 TH_4__I_223_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[3]), .D(DBIN[6]), 
         .Z(TH_4__N_902)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1159[48:83])
    defparam TH_4__I_223_4_lut.init = 16'heca0;
    LUT4 TH_4__I_225_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[2]), .D(DBIN[5]), 
         .Z(TH_4__N_907)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1158[48:83])
    defparam TH_4__I_225_4_lut.init = 16'heca0;
    LUT4 TH_4__I_227_4_lut (.A(W6_2), .B(W5_1), .C(DBIN[1]), .D(DBIN[4]), 
         .Z(TH_4__N_912)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1157[48:83])
    defparam TH_4__I_227_4_lut.init = 16'heca0;
    LUT4 i1773_3_lut_4_lut (.A(TVLOAD_N_1043), .B(PCLK_c), .C(TV[3]), 
         .D(CNT1_adj_1936), .Z(n2360)) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1112[18:58])
    defparam i1773_3_lut_4_lut.init = 16'hfd20;
    LUT4 THZ_I_0_4_lut (.A(THZ_N_1056), .B(TVO1), .C(BLNK), .D(n5651), 
         .Z(NTH_IN)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1120[19:29])
    defparam THZ_I_0_4_lut.init = 16'hca0a;
    LUT4 i4_4_lut (.A(THO[2]), .B(THO[0]), .C(THO[4]), .D(n6), .Z(THZ_N_1056)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1124[15:58])
    defparam i4_4_lut.init = 16'h8000;
    LUT4 i1_2_lut (.A(THO[1]), .B(THO[3]), .Z(n6)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1124[15:58])
    defparam i1_2_lut.init = 16'h8888;
    OFS1P3DX PAD_i0_i7 (.D(PAQ[7]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PAD_i0_i7.GSR = "ENABLED";
    OFS1P3DX PAD_i0_i0 (.D(PAQ[0]), .SP(PCLK_c), .SCLK(Clk), .CD(GND_net), 
            .Q(\PAD[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam PAD_i0_i0.GSR = "ENABLED";
    LUT4 i2_3_lut_adj_497 (.A(n5651), .B(TVO1), .C(BLNK), .Z(TVZ)) /* synthesis lut_function=(!((B+(C))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam i2_3_lut_adj_497.init = 16'h0202;
    LUT4 PCLK_I_0_2_lut (.A(PCLK_c), .B(SH2), .Z(VINV_LATCH_N_1001)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1171[13:23])
    defparam PCLK_I_0_2_lut.init = 16'h8888;
    LUT4 TVZR_I_0_1_lut (.A(TVZR), .Z(TVZR_N_1023)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1196[16:21])
    defparam TVZR_I_0_1_lut.init = 16'h5555;
    LUT4 i8406_2_lut (.A(W62_FF), .B(W6_2), .Z(W62_1_N_1030)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1198[22:41])
    defparam i8406_2_lut.init = 16'h2222;
    LUT4 i3839_3_lut (.A(BLNK), .B(THZ_N_1056), .C(I1_32), .Z(n4447)) /* synthesis lut_function=(A (B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1172[14:43])
    defparam i3839_3_lut.init = 16'ha8a8;
    LUT4 i3_4_lut (.A(FVO[2]), .B(FVO[0]), .C(BLNK), .D(FVO[1]), .Z(FVZ_N_1070)) /* synthesis lut_function=(!(((C+!(D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1128[15:47])
    defparam i3_4_lut.init = 16'h0800;
    LUT4 mux_197_i1_4_lut (.A(FVO[0]), .B(VINV_LATCH), .C(PAR_O), .D(OVOUT[0]), 
         .Z(TP_11__N_993[0])) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1191[16:49])
    defparam mux_197_i1_4_lut.init = 16'h3aca;
    LUT4 i1_2_lut_adj_498 (.A(NTHDO), .B(NTH_IN), .Z(n8749)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1122[17:40])
    defparam i1_2_lut_adj_498.init = 16'h8888;
    FD1P3IX NTH_243 (.D(NTH_N_1004), .SP(Clk_enable_288), .CD(RC), .CK(Clk), 
            .Q(NTH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam NTH_243.GSR = "ENABLED";
    FD1P3IX FV__i0 (.D(FV_2__N_959), .SP(Clk_enable_282), .CD(RC), .CK(Clk), 
            .Q(FV[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam FV__i0.GSR = "ENABLED";
    FD1P3IX NTV_244 (.D(NTV_N_1011), .SP(Clk_enable_288), .CD(RC), .CK(Clk), 
            .Q(NTV));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam NTV_244.GSR = "ENABLED";
    FD1P3IX TV_i0 (.D(TV_4__N_946), .SP(Clk_enable_289), .CD(RC), .CK(Clk), 
            .Q(TV[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TV_i0.GSR = "ENABLED";
    FD1P3IX TH__i0 (.D(TH_4__N_917), .SP(Clk_enable_292), .CD(RC), .CK(Clk), 
            .Q(TH[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=318, LSE_RLINE=353 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1155[8] 1200[20])
    defparam TH__i0.GSR = "ENABLED";
    FD1P3JX PD_FIFO2_57 (.D(Hnn0_N_999), .SP(nPCLK), .PD(n4502), .CK(Clk), 
            .Q(PD_FIFO2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1243[8] 1263[25])
    defparam PD_FIFO2_57.GSR = "ENABLED";
    COUNTER TVCNT_4 (.CNT1(CNT1_adj_1935), .Clk(Clk), .PCLK_c(PCLK_c), 
            .CNT1_N_1080(CNT1_N_1080_adj_1937), .Z_TV1(Z_TV1), .Z_TV2(Z_TV2), 
            .n4513(n4513), .\TVO[4] (TVO[4]), .Clk_enable_296(Clk_enable_296), 
            .n2346(n2346)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1137[9:109])
    COUNTER_U0 TVCNT_3 (.CNT1(CNT1_adj_1936), .Clk(Clk), .PCLK_c(PCLK_c), 
            .CNT1_N_1080(CNT1_N_1080_adj_1938), .Z_TV_N_1050(Z_TV_N_1050), 
            .W62_2(W62_2), .n8786(n8786), .Clk_enable_296(Clk_enable_296), 
            .\TVO[3] (TVO[3]), .n4513(n4513), .n2360(n2360)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1137[9:109])
    COUNTER_U1 TVCNT_2 (.CNT1(CNT1_adj_1934), .Clk(Clk), .PCLK_c(PCLK_c), 
            .\TVO[2] (TVO[2]), .\TVOCout[1] (TVOCout[1]), .\TVO[3] (TVO[3]), 
            .\TVO[4] (TVO[4]), .CNT1_N_1080(CNT1_N_1080_adj_1937), .CNT1_N_1080_adj_3(CNT1_N_1080_adj_1938), 
            .Clk_enable_296(Clk_enable_296), .n4513(n4513), .n2362(n2362)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1137[9:109])
    COUNTER_U2 TVCNT_1 (.CNT1(CNT1_adj_1932), .Clk(Clk), .PCLK_c(PCLK_c), 
            .CNT1_N_1080(CNT1_N_1080_adj_1939), .TVO1(TVO1), .THO1R(THO1R), 
            .\PDAT[5] (\PDAT[5] ), .ATSEL_1__N_798({ATSEL_1__N_798}), .\PDAT[4] (\PDAT[4] ), 
            .Clk_enable_296(Clk_enable_296), .n4513(n4513), .n2368(n2368)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1137[9:109])
    COUNTER_U3 TVCNT_0 (.CNT1(CNT1_adj_1933), .Clk(Clk), .PCLK_c(PCLK_c), 
            .CNT1_N_1080(CNT1_N_1080), .\TVO[0] (\TVO[0] ), .TV_IN(TV_IN), 
            .TVO1(TVO1), .\TVOCout[1] (TVOCout[1]), .CNT1_N_1080_adj_2(CNT1_N_1080_adj_1939), 
            .\TVO[2] (TVO[2]), .\TVO[4] (TVO[4]), .n5651(n5651), .\TVO[3] (TVO[3]), 
            .Clk_enable_296(Clk_enable_296), .n4513(n4513), .n2379(n2379)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1137[9:109])
    COUNTER_U4 THCNT_4 (.Clk(Clk), .PCLK_c(PCLK_c), .\THO[4] (THO[4]), 
            .Clk_enable_34(Clk_enable_34), .\THO[3] (THO[3]), .\THOCout[2] (THOCout[2]), 
            .\TH[4] (TH[4]), .THLOAD_N_1038(THLOAD_N_1038)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1135[9:109])
    COUNTER_U5 THCNT_3 (.Clk(Clk), .PCLK_c(PCLK_c), .\THO[3] (THO[3]), 
            .Clk_enable_34(Clk_enable_34), .\TH[3] (TH[3]), .THLOAD_N_1038(THLOAD_N_1038), 
            .\THO[1] (THO[1]), .\THOCout[0] (THOCout[0]), .\THO[2] (THO[2])) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1135[9:109])
    COUNTER_U6 THCNT_2 (.\THO[2] (THO[2]), .Clk(Clk), .Clk_enable_34(Clk_enable_34), 
            .PCLK_c(PCLK_c), .CNT1_N_1080(CNT1_N_1080_adj_1941), .W62_2(W62_2), 
            .EEVR2(EEVR2), .THSTEP_N_1047(THSTEP_N_1047), .\TH[2] (TH[2]), 
            .THLOAD_N_1038(THLOAD_N_1038)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1135[9:109])
    COUNTER_U7 THCNT_1 (.Clk(Clk), .PCLK_c(PCLK_c), .\THO[1] (THO[1]), 
            .Clk_enable_34(Clk_enable_34), .\THOCout[0] (THOCout[0]), .\TH[1] (TH[1]), 
            .THLOAD_N_1038(THLOAD_N_1038), .\THO[2] (THO[2]), .\THOCout[2] (THOCout[2]), 
            .CNT1_N_1080(CNT1_N_1080_adj_1941)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1135[9:109])
    COUNTER_U8 THCNT_0 (.Clk(Clk), .PCLK_c(PCLK_c), .CNT1_N_1080(CNT1_N_1080_c), 
            .\THO[0] (THO[0]), .Clk_enable_34(Clk_enable_34), .\TH[0] (TH[0]), 
            .THLOAD_N_1038(THLOAD_N_1038)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1135[9:109])
    COUNTER_U9 NTVCNT (.CNT1(CNT1_adj_1929), .Clk(Clk), .PCLK_c(PCLK_c), 
            .NTVDO(NTVDO), .Clk_enable_20(Clk_enable_20), .n2397(n2397), 
            .TVZ(TVZ), .BLNK(BLNK), .n8749(n8749)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1141[9:101])
    COUNTER_U10 NTHCNT (.Clk(Clk), .PCLK_c(PCLK_c), .NTHDO(NTHDO), .Clk_enable_34(Clk_enable_34), 
            .NTH_IN(NTH_IN), .NTH(NTH), .THLOAD_N_1038(THLOAD_N_1038)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1139[9:101])
    COUNTER_U11 FVCNT_2 (.CNT1(CNT1_adj_1930), .Clk(Clk), .PCLK_c(PCLK_c), 
            .\FVO[2] (FVO[2]), .Clk_enable_20(Clk_enable_20), .n2395(n2395), 
            .\FVO[1] (FVO[1]), .\FVOCout[0] (FVOCout[0])) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1143[9:109])
    COUNTER_U12 FVCNT_1 (.CNT1(CNT1_adj_1931), .Clk(Clk), .PCLK_c(PCLK_c), 
            .\FVO[1] (FVO[1]), .Clk_enable_20(Clk_enable_20), .n2393(n2393), 
            .\FVOCout[0] (FVOCout[0])) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1143[9:109])
    COUNTER_U13 FVCNT_0 (.\FVO[0] (FVO[0]), .Clk(Clk), .Clk_enable_20(Clk_enable_20), 
            .n2290(n2290), .CNT1(CNT1), .PCLK_c(PCLK_c), .BLNK(BLNK), 
            .NTVDO(NTVDO), .n8749(n8749), .\FVOCout[0] (FVOCout[0])) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1143[9:109])
    
endmodule
//
// Verilog Description of module COUNTER
//

module COUNTER (CNT1, Clk, PCLK_c, CNT1_N_1080, Z_TV1, Z_TV2, n4513, 
            \TVO[4] , Clk_enable_296, n2346) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input PCLK_c;
    input CNT1_N_1080;
    input Z_TV1;
    input Z_TV2;
    output n4513;
    output \TVO[4] ;
    input Clk_enable_296;
    input n2346;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    LUT4 i8458_3_lut_2_lut (.A(Z_TV1), .B(Z_TV2), .Z(n4513)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i8458_3_lut_2_lut.init = 16'h1111;
    FD1P3IX CNT_14 (.D(n2346), .SP(Clk_enable_296), .CD(n4513), .CK(Clk), 
            .Q(\TVO[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U0
//

module COUNTER_U0 (CNT1, Clk, PCLK_c, CNT1_N_1080, Z_TV_N_1050, W62_2, 
            n8786, Clk_enable_296, \TVO[3] , n4513, n2360) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input PCLK_c;
    input CNT1_N_1080;
    input Z_TV_N_1050;
    input W62_2;
    input n8786;
    output Clk_enable_296;
    output \TVO[3] ;
    input n4513;
    input n2360;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    LUT4 i8547_4_lut (.A(Z_TV_N_1050), .B(PCLK_c), .C(W62_2), .D(n8786), 
         .Z(Clk_enable_296)) /* synthesis lut_function=(!(A (B+!(C+(D))))) */ ;
    defparam i8547_4_lut.init = 16'h7775;
    FD1P3IX CNT_14 (.D(n2360), .SP(Clk_enable_296), .CD(n4513), .CK(Clk), 
            .Q(\TVO[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U1
//

module COUNTER_U1 (CNT1, Clk, PCLK_c, \TVO[2] , \TVOCout[1] , \TVO[3] , 
            \TVO[4] , CNT1_N_1080, CNT1_N_1080_adj_3, Clk_enable_296, 
            n4513, n2362) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input PCLK_c;
    output \TVO[2] ;
    input \TVOCout[1] ;
    input \TVO[3] ;
    input \TVO[4] ;
    output CNT1_N_1080;
    output CNT1_N_1080_adj_3;
    input Clk_enable_296;
    input n4513;
    input n2362;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT1_N_1080_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080_c), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    LUT4 CNT_I_0_2_lut (.A(\TVO[2] ), .B(\TVOCout[1] ), .Z(CNT1_N_1080_c)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1735[23:33])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    LUT4 CNT_I_0_3_lut_4_lut (.A(\TVO[2] ), .B(\TVOCout[1] ), .C(\TVO[3] ), 
         .D(\TVO[4] ), .Z(CNT1_N_1080)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1731[16:26])
    defparam CNT_I_0_3_lut_4_lut.init = 16'h7f80;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\TVO[2] ), .B(\TVOCout[1] ), .C(\TVO[3] ), 
         .Z(CNT1_N_1080_adj_3)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1731[16:26])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    FD1P3IX CNT_14 (.D(n2362), .SP(Clk_enable_296), .CD(n4513), .CK(Clk), 
            .Q(\TVO[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U2
//

module COUNTER_U2 (CNT1, Clk, PCLK_c, CNT1_N_1080, TVO1, THO1R, 
            \PDAT[5] , ATSEL_1__N_798, \PDAT[4] , Clk_enable_296, n4513, 
            n2368) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input PCLK_c;
    input CNT1_N_1080;
    output TVO1;
    input THO1R;
    input \PDAT[5] ;
    output [1:0]ATSEL_1__N_798;
    input \PDAT[4] ;
    input Clk_enable_296;
    input n4513;
    input n2368;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut (.A(TVO1), .B(THO1R), .C(\PDAT[5] ), .Z(ATSEL_1__N_798[1])) /* synthesis lut_function=(!((B+!(C))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam i1_2_lut_3_lut.init = 16'h2020;
    LUT4 i1_2_lut_3_lut_adj_494 (.A(TVO1), .B(THO1R), .C(\PDAT[4] ), .Z(ATSEL_1__N_798[0])) /* synthesis lut_function=(!((B+!(C))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam i1_2_lut_3_lut_adj_494.init = 16'h2020;
    FD1P3IX CNT_14 (.D(n2368), .SP(Clk_enable_296), .CD(n4513), .CK(Clk), 
            .Q(TVO1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U3
//

module COUNTER_U3 (CNT1, Clk, PCLK_c, CNT1_N_1080, \TVO[0] , TV_IN, 
            TVO1, \TVOCout[1] , CNT1_N_1080_adj_2, \TVO[2] , \TVO[4] , 
            n5651, \TVO[3] , Clk_enable_296, n4513, n2379) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input PCLK_c;
    input CNT1_N_1080;
    output \TVO[0] ;
    input TV_IN;
    input TVO1;
    output \TVOCout[1] ;
    output CNT1_N_1080_adj_2;
    input \TVO[2] ;
    input \TVO[4] ;
    output n5651;
    input \TVO[3] ;
    input Clk_enable_296;
    input n4513;
    input n2379;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire n6;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut (.A(\TVO[0] ), .B(TV_IN), .C(TVO1), .Z(\TVOCout[1] )) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam i1_2_lut_3_lut.init = 16'h8080;
    LUT4 i5_2_lut_3_lut (.A(\TVO[0] ), .B(TV_IN), .C(TVO1), .Z(CNT1_N_1080_adj_2)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam i5_2_lut_3_lut.init = 16'h7878;
    LUT4 i4_4_lut (.A(TV_IN), .B(\TVO[2] ), .C(\TVO[4] ), .D(n6), .Z(n5651)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam i4_4_lut.init = 16'h8000;
    LUT4 i1_2_lut (.A(\TVO[0] ), .B(\TVO[3] ), .Z(n6)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam i1_2_lut.init = 16'h8888;
    FD1P3IX CNT_14 (.D(n2379), .SP(Clk_enable_296), .CD(n4513), .CK(Clk), 
            .Q(\TVO[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U4
//

module COUNTER_U4 (Clk, PCLK_c, \THO[4] , Clk_enable_34, \THO[3] , 
            \THOCout[2] , \TH[4] , THLOAD_N_1038) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input PCLK_c;
    output \THO[4] ;
    input Clk_enable_34;
    input \THO[3] ;
    input \THOCout[2] ;
    input \TH[4] ;
    input THLOAD_N_1038;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT1, CNT1_N_1080, n2373;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    FD1P3AX CNT_14 (.D(n2373), .SP(Clk_enable_34), .CK(Clk), .Q(\THO[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 CNT_I_0_3_lut (.A(\THO[4] ), .B(\THO[3] ), .C(\THOCout[2] ), 
         .Z(CNT1_N_1080)) /* synthesis lut_function=(!(A (B (C))+!A !(B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1735[23:33])
    defparam CNT_I_0_3_lut.init = 16'h6a6a;
    LUT4 i1786_3_lut (.A(CNT1), .B(\TH[4] ), .C(THLOAD_N_1038), .Z(n2373)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam i1786_3_lut.init = 16'hacac;
    
endmodule
//
// Verilog Description of module COUNTER_U5
//

module COUNTER_U5 (Clk, PCLK_c, \THO[3] , Clk_enable_34, \TH[3] , 
            THLOAD_N_1038, \THO[1] , \THOCout[0] , \THO[2] ) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input PCLK_c;
    output \THO[3] ;
    input Clk_enable_34;
    input \TH[3] ;
    input THLOAD_N_1038;
    input \THO[1] ;
    input \THOCout[0] ;
    input \THO[2] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT1, CNT1_N_1080, n2371;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    FD1P3AX CNT_14 (.D(n2371), .SP(Clk_enable_34), .CK(Clk), .Q(\THO[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 i1784_3_lut (.A(CNT1), .B(\TH[3] ), .C(THLOAD_N_1038), .Z(n2371)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam i1784_3_lut.init = 16'hacac;
    LUT4 CNT_I_0_2_lut_4_lut (.A(\THO[3] ), .B(\THO[1] ), .C(\THOCout[0] ), 
         .D(\THO[2] ), .Z(CNT1_N_1080)) /* synthesis lut_function=(!(A (B (C (D)))+!A !(B (C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1735[23:33])
    defparam CNT_I_0_2_lut_4_lut.init = 16'h6aaa;
    
endmodule
//
// Verilog Description of module COUNTER_U6
//

module COUNTER_U6 (\THO[2] , Clk, Clk_enable_34, PCLK_c, CNT1_N_1080, 
            W62_2, EEVR2, THSTEP_N_1047, \TH[2] , THLOAD_N_1038) /* synthesis syn_module_defined=1 */ ;
    output \THO[2] ;
    input Clk;
    output Clk_enable_34;
    input PCLK_c;
    input CNT1_N_1080;
    input W62_2;
    input EEVR2;
    input THSTEP_N_1047;
    input \TH[2] ;
    input THLOAD_N_1038;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire n2352, CNT1;
    
    FD1P3AX CNT_14 (.D(n2352), .SP(Clk_enable_34), .CK(Clk), .Q(\THO[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    LUT4 i8610_4_lut (.A(PCLK_c), .B(W62_2), .C(EEVR2), .D(THSTEP_N_1047), 
         .Z(Clk_enable_34)) /* synthesis lut_function=(!(A+!(B+(C+(D))))) */ ;
    defparam i8610_4_lut.init = 16'h5554;
    LUT4 i1766_3_lut (.A(CNT1), .B(\TH[2] ), .C(THLOAD_N_1038), .Z(n2352)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam i1766_3_lut.init = 16'hacac;
    
endmodule
//
// Verilog Description of module COUNTER_U7
//

module COUNTER_U7 (Clk, PCLK_c, \THO[1] , Clk_enable_34, \THOCout[0] , 
            \TH[1] , THLOAD_N_1038, \THO[2] , \THOCout[2] , CNT1_N_1080) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input PCLK_c;
    output \THO[1] ;
    input Clk_enable_34;
    input \THOCout[0] ;
    input \TH[1] ;
    input THLOAD_N_1038;
    input \THO[2] ;
    output \THOCout[2] ;
    output CNT1_N_1080;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT1, CNT1_N_1080_c, n2350;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080_c), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    FD1P3AX CNT_14 (.D(n2350), .SP(Clk_enable_34), .CK(Clk), .Q(\THO[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 CNT_I_0_2_lut (.A(\THO[1] ), .B(\THOCout[0] ), .Z(CNT1_N_1080_c)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1735[23:33])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    LUT4 i1764_3_lut (.A(CNT1), .B(\TH[1] ), .C(THLOAD_N_1038), .Z(n2350)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam i1764_3_lut.init = 16'hacac;
    LUT4 CNT_I_0_18_2_lut_3_lut (.A(\THO[1] ), .B(\THOCout[0] ), .C(\THO[2] ), 
         .Z(\THOCout[2] )) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1731[16:26])
    defparam CNT_I_0_18_2_lut_3_lut.init = 16'h8080;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\THO[1] ), .B(\THOCout[0] ), .C(\THO[2] ), 
         .Z(CNT1_N_1080)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1731[16:26])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    
endmodule
//
// Verilog Description of module COUNTER_U8
//

module COUNTER_U8 (Clk, PCLK_c, CNT1_N_1080, \THO[0] , Clk_enable_34, 
            \TH[0] , THLOAD_N_1038) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input PCLK_c;
    input CNT1_N_1080;
    output \THO[0] ;
    input Clk_enable_34;
    input \TH[0] ;
    input THLOAD_N_1038;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT1, n2348;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    FD1P3AX CNT_14 (.D(n2348), .SP(Clk_enable_34), .CK(Clk), .Q(\THO[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 i1762_3_lut (.A(CNT1), .B(\TH[0] ), .C(THLOAD_N_1038), .Z(n2348)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam i1762_3_lut.init = 16'hacac;
    
endmodule
//
// Verilog Description of module COUNTER_U9
//

module COUNTER_U9 (CNT1, Clk, PCLK_c, NTVDO, Clk_enable_20, n2397, 
            TVZ, BLNK, n8749) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input PCLK_c;
    output NTVDO;
    input Clk_enable_20;
    input n2397;
    input TVZ;
    input BLNK;
    input n8749;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT1_N_1080;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    FD1P3AX CNT_14 (.D(n2397), .SP(Clk_enable_20), .CK(Clk), .Q(NTVDO));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 CNT_I_0_4_lut (.A(NTVDO), .B(TVZ), .C(BLNK), .D(n8749), .Z(CNT1_N_1080)) /* synthesis lut_function=(!(A (B+(C (D)))+!A !(B+(C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1735[23:33])
    defparam CNT_I_0_4_lut.init = 16'h5666;
    
endmodule
//
// Verilog Description of module COUNTER_U10
//

module COUNTER_U10 (Clk, PCLK_c, NTHDO, Clk_enable_34, NTH_IN, NTH, 
            THLOAD_N_1038) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input PCLK_c;
    output NTHDO;
    input Clk_enable_34;
    input NTH_IN;
    input NTH;
    input THLOAD_N_1038;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT1, CNT1_N_1080, n2343;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    FD1P3AX CNT_14 (.D(n2343), .SP(Clk_enable_34), .CK(Clk), .Q(NTHDO));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 CNT_I_0_2_lut (.A(NTHDO), .B(NTH_IN), .Z(CNT1_N_1080)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1735[23:33])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    LUT4 i1757_3_lut (.A(CNT1), .B(NTH), .C(THLOAD_N_1038), .Z(n2343)) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam i1757_3_lut.init = 16'hacac;
    
endmodule
//
// Verilog Description of module COUNTER_U11
//

module COUNTER_U11 (CNT1, Clk, PCLK_c, \FVO[2] , Clk_enable_20, n2395, 
            \FVO[1] , \FVOCout[0] ) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input PCLK_c;
    output \FVO[2] ;
    input Clk_enable_20;
    input n2395;
    input \FVO[1] ;
    input \FVOCout[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT1_N_1080;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    FD1P3AX CNT_14 (.D(n2395), .SP(Clk_enable_20), .CK(Clk), .Q(\FVO[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 CNT_I_0_3_lut (.A(\FVO[2] ), .B(\FVO[1] ), .C(\FVOCout[0] ), 
         .Z(CNT1_N_1080)) /* synthesis lut_function=(!(A (B (C))+!A !(B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1735[23:33])
    defparam CNT_I_0_3_lut.init = 16'h6a6a;
    
endmodule
//
// Verilog Description of module COUNTER_U12
//

module COUNTER_U12 (CNT1, Clk, PCLK_c, \FVO[1] , Clk_enable_20, n2393, 
            \FVOCout[0] ) /* synthesis syn_module_defined=1 */ ;
    output CNT1;
    input Clk;
    input PCLK_c;
    output \FVO[1] ;
    input Clk_enable_20;
    input n2393;
    input \FVOCout[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT1_N_1080;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    FD1P3AX CNT_14 (.D(n2393), .SP(Clk_enable_20), .CK(Clk), .Q(\FVO[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    LUT4 CNT_I_0_2_lut (.A(\FVO[1] ), .B(\FVOCout[0] ), .Z(CNT1_N_1080)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1735[23:33])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    
endmodule
//
// Verilog Description of module COUNTER_U13
//

module COUNTER_U13 (\FVO[0] , Clk, Clk_enable_20, n2290, CNT1, PCLK_c, 
            BLNK, NTVDO, n8749, \FVOCout[0] ) /* synthesis syn_module_defined=1 */ ;
    output \FVO[0] ;
    input Clk;
    input Clk_enable_20;
    input n2290;
    output CNT1;
    input PCLK_c;
    input BLNK;
    input NTVDO;
    input n8749;
    output \FVOCout[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT1_N_1080;
    
    FD1P3AX CNT_14 (.D(n2290), .SP(Clk_enable_20), .CK(Clk), .Q(\FVO[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(PCLK_c), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    LUT4 CNT_I_0_2_lut_4_lut (.A(BLNK), .B(NTVDO), .C(n8749), .D(\FVO[0] ), 
         .Z(CNT1_N_1080)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1731[16:26])
    defparam CNT_I_0_2_lut_4_lut.init = 16'h2ad5;
    LUT4 i1_2_lut_4_lut (.A(BLNK), .B(NTVDO), .C(n8749), .D(\FVO[0] ), 
         .Z(\FVOCout[0] )) /* synthesis lut_function=(A (B (C (D)))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1731[16:26])
    defparam i1_2_lut_4_lut.init = 16'hd500;
    
endmodule
//
// Verilog Description of module TSALL
// module not written out since it is a black-box. 
//

//
// Verilog Description of module OBJ_FIFO
//

module OBJ_FIFO (PCLK_c, CLIPOR, OB, Hnn, SH2, PD_FIFO, PD_out_1, 
            PD_out_6, PD_out_2, PD_out_5, PD_out_3, PD_out_4, Clk, 
            nPCLK, O_HPOS, PD_out_7, PD_out_0, VINV_LATCH_N_1001, 
            SPR0HIT_LATCH, ZCOL, PAR_O, nVIS) /* synthesis syn_module_defined=1 */ ;
    input PCLK_c;
    input CLIPOR;
    input [7:0]OB;
    input [5:0]Hnn;
    output SH2;
    input PD_FIFO;
    input PD_out_1;
    input PD_out_6;
    input PD_out_2;
    input PD_out_5;
    input PD_out_3;
    input PD_out_4;
    input Clk;
    input nPCLK;
    input O_HPOS;
    input PD_out_7;
    input PD_out_0;
    input VINV_LATCH_N_1001;
    output SPR0HIT_LATCH;
    output [4:0]ZCOL;
    input PAR_O;
    input nVIS;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire SH3;
    wire [7:0]SEL_LATCH;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1393[10:19])
    
    wire ZH_FF, CNT_7__N_1559, COL1_7__N_1389;
    wire [7:0]SDATA;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1415[11:16])
    wire [7:0]QS;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2451;
    wire [7:0]QS_adj_1903;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2503;
    wire [7:0]QS_adj_1904;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2563, n6195, n2946, n8713, n9492, n5904, n6166, n2245, 
        COL0_7__N_1373;
    wire [7:0]QS_adj_1905;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2575, n2501, n2441;
    wire [7:0]COL1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1417[16:20])
    wire [7:0]EN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1405[11:13])
    
    wire n2, n2443, n2497, SH5, Clk_enable_222, SH7, n4565, Clk_enable_229, 
        n4572, n2499, n2445, n8710, n2_adj_1732, n4, n8712, n4563, 
        Clk_enable_257, n2557, n2447, n2449, n2453;
    wire [2:0]ATR6;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1399[47:51])
    wire [2:0]ATR7;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1399[53:57])
    wire [7:0]SPR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1435[11:14])
    
    wire n5890;
    wire [4:0]n198;
    wire [7:0]QS_adj_1906;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2525;
    wire [7:0]COL0;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1417[10:14])
    
    wire n2579, EN_7__N_1361, n4574;
    wire [7:0]CNT1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1517[10:14])
    
    wire n2637, n6117, n2356, Clk_enable_250, n2533, Clk_enable_236;
    wire [7:0]CNT1_adj_1907;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1517[10:14])
    
    wire n2705, n2643, n2639, n2641, n5847, n2707, n2709, n2699, 
        n2383, n2703, n2701, ATR_IN7_2__N_1504, ATR_IN6_2__N_1503, 
        n2711, n2537, n2645;
    wire [7:0]CNT1_adj_1908;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1517[10:14])
    
    wire n2721, n2647, n2649, n2715, n2717, ATR_IN5_2__N_1502, n2713, 
        n2385, n2719;
    wire [7:0]QS_adj_1909;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2545;
    wire [7:0]QS_adj_1910;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2437, ATR_IN4_2__N_1501, n2723, ATR_IN3_2__N_1500, ATR_IN2_2__N_1499, 
        ATR_IN1_2__N_1498, n4579, n2427, n2725;
    wire [7:0]CNT1_adj_1911;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1517[10:14])
    
    wire n2729;
    wire [7:0]PD_LATCH;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1396[10:18])
    
    wire n2727, n2429, n2431, n2433, n2435, n2439, n2387, n2555, 
        n2731;
    wire [7:0]CNT1_adj_1912;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1517[10:14])
    
    wire n2651, n2364, n2549, Clk_enable_180, n4553, Clk_enable_187, 
        n4551, ZH_FF_adj_1772, CNT_7__N_1559_adj_1773, Clk_enable_278, 
        Clk_enable_166, n4549, Clk_enable_173, n2657, n2653, n2655, 
        n2543, n2659, n2553, n2661, n2663, n2541;
    wire [7:0]QS_adj_1913;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2421, n2509, n2419, n4547, n2425, MIRR_LATCH;
    wire [7:0]MIRR_MUX;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1402[11:19])
    
    wire n2423, n1650, n2539, n2417, n2733, n2739, n2415, n2737, 
        n2413, n2735, n6197, n2547, ZH_FF_adj_1797, Clk_enable_117, 
        CNT_7__N_1559_adj_1798, n4644, SEL_LATCH_7__N_1479, SEL_LATCH_7__N_1481, 
        SEL_LATCH_7__N_1485, Clk_enable_208, n4561;
    wire [2:0]ATR_IN0;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1398[11:18])
    
    wire ATR_IN0_2__N_1496, SEL_LATCH_7__N_1489, n2551;
    wire [2:0]ATR0;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1399[11:15])
    wire [2:0]ATR1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1399[17:21])
    wire [2:0]ATR_IN1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1398[20:27])
    wire [2:0]ATR2;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1399[23:27])
    wire [2:0]ATR_IN2;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1398[29:36])
    wire [2:0]ATR3;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1399[29:33])
    wire [2:0]ATR_IN3;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1398[38:45])
    wire [2:0]ATR4;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1399[35:39])
    wire [2:0]ATR_IN4;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1398[47:54])
    wire [2:0]ATR5;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1399[41:45])
    wire [2:0]ATR_IN5;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1398[56:63])
    wire [2:0]ATR_IN6;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1398[65:72])
    wire [2:0]ATR_IN7;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1398[74:81])
    wire [2:0]ZPOS;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1395[10:14])
    wire [7:0]QS_adj_1914;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2473, n9653, Clk_enable_215, ZH_FF_adj_1801, Clk_enable_124, 
        n4559;
    wire [7:0]QS_adj_1915;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2517, CNT_7__N_1559_adj_1803, ZH_FF_adj_1804, Clk_enable_131, 
        CNT_7__N_1559_adj_1805, n2521, n8828, n2515, ZH_FF_adj_1808, 
        Clk_enable_145, CNT_7__N_1559_adj_1809;
    wire [7:0]CNT1_adj_1916;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1517[10:14])
    
    wire n2671, n2561, n2375, n2513, n2511, n2677, n2673, n2471, 
        n2675, n2679;
    wire [7:0]QS_adj_1917;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2491, n4576, n2681, n2683, n2531, n4578, Clk_enable_271, 
        Clk_enable_264, n2519;
    wire [7:0]CNT1_adj_1918;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1517[10:14])
    
    wire n2697, n2535, n2695, n2493, n2489, n2691, ZH_FF_adj_1831, 
        Clk_enable_152, CNT_7__N_1559_adj_1832, n2487, n2529, n2527, 
        n2693, n2689, n2523, Clk_enable_194, n2687, n2381, n2685, 
        Clk_enable_159, n4_adj_1842, n8711;
    wire [4:0]n216;
    
    wire n2243, n2255, n2253, SH5_N_1522, SH3_N_1518;
    wire [7:0]QS_adj_1919;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2629, n2633, n2627, n2625, n2623, n2631, n2635;
    wire [7:0]QS_adj_1920;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2615, n2619, n2613, n2611, n2609, n2617, SH2_N_1509, 
        n2621;
    wire [7:0]QS_adj_1921;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2601, n2605, n2599, n2597, n2595, n2603, n2607;
    wire [7:0]CNT1_adj_1922;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1517[10:14])
    
    wire n2304, n2399, n2401, n2403, n2405, n2407, n2409, n2411;
    wire [7:0]QS_adj_1923;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2587, n2591, n2585, n2583, n2581, n2589, n2593, n2485, 
        n2573, n2483, n2505, n2495, n2559, n9491, n2479, n2507, 
        n2565, n2469, n2477, n2475, n2481, n2577;
    wire [7:0]QS_adj_1924;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2465, n2455, n8844, n2457, n2571, n2569, n2459, n2567, 
        n2461, n2463, n4557, n4570, n4568, n2467, Clk_enable_243, 
        Clk_enable_201, n4555, Clk_enable_31, n2899, Clk_enable_30, 
        n2900, Clk_enable_29, n2909, Clk_enable_28, n2910, Clk_enable_27, 
        n2911, Clk_enable_26, n2912, Clk_enable_18, n2913;
    
    LUT4 i8435_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[7]), 
         .D(ZH_FF), .Z(CNT_7__N_1559)) /* synthesis lut_function=(!(A (B (C))+!A (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1413[51:78])
    defparam i8435_2_lut_3_lut_4_lut_4_lut.init = 16'h2a7f;
    LUT4 i1863_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[6]), .C(SDATA[6]), 
         .D(QS[5]), .Z(n2451)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1431[47:74])
    defparam i1863_3_lut_4_lut.init = 16'hf780;
    LUT4 i1915_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[4]), .C(SDATA[4]), 
         .D(QS_adj_1903[3]), .Z(n2503)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1427[47:74])
    defparam i1915_3_lut_4_lut.init = 16'hf780;
    LUT4 i1975_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[2]), .C(SDATA[6]), 
         .D(QS_adj_1904[5]), .Z(n2563)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1423[47:74])
    defparam i1975_3_lut_4_lut.init = 16'hf780;
    LUT4 i8535_3_lut_then_3_lut (.A(n6195), .B(n2946), .C(n8713), .Z(n9492)) /* synthesis lut_function=(!(A (C)+!A !(B+!(C)))) */ ;
    defparam i8535_3_lut_then_3_lut.init = 16'h4f4f;
    LUT4 i1663_3_lut_4_lut (.A(CLIPOR), .B(n5904), .C(n2946), .D(n6166), 
         .Z(n2245)) /* synthesis lut_function=(!(A (B+!(C+!(D)))+!A !(C+!(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1435[11:14])
    defparam i1663_3_lut_4_lut.init = 16'h7077;
    LUT4 i1987_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[2]), .C(SDATA[5]), 
         .D(QS_adj_1905[4]), .Z(n2575)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1422[47:74])
    defparam i1987_3_lut_4_lut.init = 16'hf780;
    LUT4 i1913_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[4]), .C(SDATA[3]), 
         .D(QS_adj_1903[2]), .Z(n2501)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1427[47:74])
    defparam i1913_3_lut_4_lut.init = 16'hf780;
    LUT4 i1853_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[6]), .C(SDATA[1]), 
         .D(QS[0]), .Z(n2441)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1431[47:74])
    defparam i1853_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_2_lut (.A(COL1[6]), .B(EN[6]), .Z(n2)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1451[20] 1453[28])
    defparam i1_2_lut.init = 16'h8888;
    LUT4 i1855_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[6]), .C(SDATA[2]), 
         .D(QS[1]), .Z(n2443)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1431[47:74])
    defparam i1855_3_lut_4_lut.init = 16'hf780;
    LUT4 i1909_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[4]), .C(SDATA[1]), 
         .D(QS_adj_1903[0]), .Z(n2497)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1427[47:74])
    defparam i1909_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[4]), .C(SEL_LATCH[4]), 
         .D(SH5), .Z(Clk_enable_222)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1426[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut.init = 16'ha888;
    LUT4 i3954_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[4]), .C(SEL_LATCH[4]), 
         .D(SH7), .Z(n4565)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1426[31:45])
    defparam i3954_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_464 (.A(PCLK_c), .B(EN[4]), .C(SEL_LATCH[4]), 
         .D(SH7), .Z(Clk_enable_229)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1426[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_464.init = 16'ha888;
    LUT4 i3961_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[6]), .C(SEL_LATCH[6]), 
         .D(SH5), .Z(n4572)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1430[31:45])
    defparam i3961_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i1911_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[4]), .C(SDATA[2]), 
         .D(QS_adj_1903[1]), .Z(n2499)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1427[47:74])
    defparam i1911_3_lut_4_lut.init = 16'hf780;
    LUT4 i1857_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[6]), .C(SDATA[3]), 
         .D(QS[2]), .Z(n2445)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1431[47:74])
    defparam i1857_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_4_lut (.A(n2), .B(n8710), .C(n2_adj_1732), .D(n4), .Z(n8712)) /* synthesis lut_function=(A (B)+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1451[20] 1453[28])
    defparam i1_4_lut.init = 16'h8c88;
    LUT4 i3952_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[4]), .C(SEL_LATCH[4]), 
         .D(SH5), .Z(n4563)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1426[31:45])
    defparam i3952_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_465 (.A(PCLK_c), .B(EN[6]), .C(SEL_LATCH[6]), 
         .D(SH7), .Z(Clk_enable_257)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1430[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_465.init = 16'ha888;
    LUT4 i1969_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[2]), .C(SDATA[3]), 
         .D(QS_adj_1904[2]), .Z(n2557)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1423[47:74])
    defparam i1969_3_lut_4_lut.init = 16'hf780;
    LUT4 i1859_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[6]), .C(SDATA[4]), 
         .D(QS[3]), .Z(n2447)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1431[47:74])
    defparam i1859_3_lut_4_lut.init = 16'hf780;
    LUT4 i1861_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[6]), .C(SDATA[5]), 
         .D(QS[4]), .Z(n2449)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1431[47:74])
    defparam i1861_3_lut_4_lut.init = 16'hf780;
    LUT4 i1865_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[6]), .C(SDATA[7]), 
         .D(QS[6]), .Z(n2453)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1431[47:74])
    defparam i1865_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_2_lut_adj_466 (.A(COL1[7]), .B(EN[7]), .Z(n4)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1451[20] 1453[28])
    defparam i1_2_lut_adj_466.init = 16'h8888;
    LUT4 mux_154_i3_4_lut (.A(ATR6[0]), .B(ATR7[0]), .C(SPR[6]), .D(n5890), 
         .Z(n198[2])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1451[20] 1453[28])
    defparam mux_154_i3_4_lut.init = 16'haca0;
    LUT4 i1937_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[3]), .C(SDATA[1]), 
         .D(QS_adj_1906[0]), .Z(n2525)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1425[47:74])
    defparam i1937_3_lut_4_lut.init = 16'hf780;
    LUT4 i2_4_lut (.A(EN[6]), .B(COL0[6]), .C(n8710), .D(COL1[6]), .Z(SPR[6])) /* synthesis lut_function=(A (B (C)+!B (C (D)))) */ ;
    defparam i2_4_lut.init = 16'ha080;
    LUT4 i1991_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[2]), .C(SDATA[7]), 
         .D(QS_adj_1905[6]), .Z(n2579)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1422[47:74])
    defparam i1991_3_lut_4_lut.init = 16'hf780;
    LUT4 PCLK_I_0_308_2_lut (.A(PCLK_c), .B(SH3), .Z(EN_7__N_1361)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1406[52:62])
    defparam PCLK_I_0_308_2_lut.init = 16'h8888;
    LUT4 i3963_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[6]), .C(SEL_LATCH[6]), 
         .D(SH7), .Z(n4574)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1430[31:45])
    defparam i3963_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i2049_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[7]), .C(OB[1]), 
         .D(CNT1[1]), .Z(n2637)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1413[51:78])
    defparam i2049_3_lut_4_lut.init = 16'hf780;
    LUT4 i3_4_lut (.A(SPR[6]), .B(n6117), .C(EN[7]), .D(n8710), .Z(n5890)) /* synthesis lut_function=(!(A+!(B (C (D))))) */ ;
    defparam i3_4_lut.init = 16'h4000;
    LUT4 i1770_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[7]), .C(OB[0]), 
         .D(CNT1[0]), .Z(n2356)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1413[51:78])
    defparam i1770_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_467 (.A(PCLK_c), .B(EN[6]), .C(SEL_LATCH[6]), 
         .D(SH5), .Z(Clk_enable_250)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1430[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_467.init = 16'ha888;
    LUT4 i1945_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[3]), .C(SDATA[5]), 
         .D(QS_adj_1906[4]), .Z(n2533)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1425[47:74])
    defparam i1945_3_lut_4_lut.init = 16'hf780;
    LUT4 i5519_2_lut (.A(COL0[7]), .B(COL1[7]), .Z(n6117)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i5519_2_lut.init = 16'heeee;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_468 (.A(PCLK_c), .B(EN[5]), .C(SEL_LATCH[5]), 
         .D(SH5), .Z(Clk_enable_236)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1428[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_468.init = 16'ha888;
    LUT4 i2117_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[3]), .C(OB[4]), 
         .D(CNT1_adj_1907[4]), .Z(n2705)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1409[51:78])
    defparam i2117_3_lut_4_lut.init = 16'hf780;
    LUT4 i2055_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[7]), .C(OB[4]), 
         .D(CNT1[4]), .Z(n2643)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1413[51:78])
    defparam i2055_3_lut_4_lut.init = 16'hf780;
    LUT4 i2051_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[7]), .C(OB[2]), 
         .D(CNT1[2]), .Z(n2639)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1413[51:78])
    defparam i2051_3_lut_4_lut.init = 16'hf780;
    LUT4 i2053_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[7]), .C(OB[3]), 
         .D(CNT1[3]), .Z(n2641)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1413[51:78])
    defparam i2053_3_lut_4_lut.init = 16'hf780;
    LUT4 i8307_2_lut (.A(Hnn[2]), .B(PCLK_c), .Z(n5847)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i8307_2_lut.init = 16'h1111;
    LUT4 mux_154_i4_4_lut (.A(ATR6[1]), .B(ATR7[1]), .C(SPR[6]), .D(n5890), 
         .Z(n198[3])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1451[20] 1453[28])
    defparam mux_154_i4_4_lut.init = 16'haca0;
    LUT4 i2119_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[3]), .C(OB[5]), 
         .D(CNT1_adj_1907[5]), .Z(n2707)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1409[51:78])
    defparam i2119_3_lut_4_lut.init = 16'hf780;
    LUT4 i2121_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[3]), .C(OB[6]), 
         .D(CNT1_adj_1907[6]), .Z(n2709)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1409[51:78])
    defparam i2121_3_lut_4_lut.init = 16'hf780;
    LUT4 i2111_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[3]), .C(OB[1]), 
         .D(CNT1_adj_1907[1]), .Z(n2699)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1409[51:78])
    defparam i2111_3_lut_4_lut.init = 16'hf780;
    LUT4 i1795_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[3]), .C(OB[0]), 
         .D(CNT1_adj_1907[0]), .Z(n2383)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1409[51:78])
    defparam i1795_3_lut_4_lut.init = 16'hf780;
    LUT4 i2115_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[3]), .C(OB[3]), 
         .D(CNT1_adj_1907[3]), .Z(n2703)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1409[51:78])
    defparam i2115_3_lut_4_lut.init = 16'hf780;
    LUT4 i2113_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[3]), .C(OB[2]), 
         .D(CNT1_adj_1907[2]), .Z(n2701)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1409[51:78])
    defparam i2113_3_lut_4_lut.init = 16'hf780;
    LUT4 ATR_IN0_2__N_1497_I_0_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[7]), 
         .Z(ATR_IN7_2__N_1504)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1494[8:33])
    defparam ATR_IN0_2__N_1497_I_0_2_lut_3_lut.init = 16'h8080;
    LUT4 ATR_IN0_2__N_1497_I_0_361_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[6]), 
         .Z(ATR_IN6_2__N_1503)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1493[8:33])
    defparam ATR_IN0_2__N_1497_I_0_361_2_lut_3_lut.init = 16'h8080;
    LUT4 i2123_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[3]), .C(OB[7]), 
         .D(CNT1_adj_1907[7]), .Z(n2711)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1409[51:78])
    defparam i2123_3_lut_4_lut.init = 16'hf780;
    LUT4 i1949_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[3]), .C(SDATA[7]), 
         .D(QS_adj_1906[6]), .Z(n2537)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1425[47:74])
    defparam i1949_3_lut_4_lut.init = 16'hf780;
    LUT4 i2057_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[7]), .C(OB[5]), 
         .D(CNT1[5]), .Z(n2645)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1413[51:78])
    defparam i2057_3_lut_4_lut.init = 16'hf780;
    LUT4 mux_154_i5_4_lut (.A(ATR6[2]), .B(ATR7[2]), .C(SPR[6]), .D(n5890), 
         .Z(n198[4])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1451[20] 1453[28])
    defparam mux_154_i5_4_lut.init = 16'haca0;
    LUT4 i2133_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[2]), .C(OB[5]), 
         .D(CNT1_adj_1908[5]), .Z(n2721)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1408[51:78])
    defparam i2133_3_lut_4_lut.init = 16'hf780;
    LUT4 i2059_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[7]), .C(OB[6]), 
         .D(CNT1[6]), .Z(n2647)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1413[51:78])
    defparam i2059_3_lut_4_lut.init = 16'hf780;
    LUT4 i2061_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[7]), .C(OB[7]), 
         .D(CNT1[7]), .Z(n2649)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1413[51:78])
    defparam i2061_3_lut_4_lut.init = 16'hf780;
    LUT4 i2127_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[2]), .C(OB[2]), 
         .D(CNT1_adj_1908[2]), .Z(n2715)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1408[51:78])
    defparam i2127_3_lut_4_lut.init = 16'hf780;
    LUT4 i2129_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[2]), .C(OB[3]), 
         .D(CNT1_adj_1908[3]), .Z(n2717)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1408[51:78])
    defparam i2129_3_lut_4_lut.init = 16'hf780;
    LUT4 ATR_IN0_2__N_1497_I_0_360_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[5]), 
         .Z(ATR_IN5_2__N_1502)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1492[8:33])
    defparam ATR_IN0_2__N_1497_I_0_360_2_lut_3_lut.init = 16'h8080;
    LUT4 i2125_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[2]), .C(OB[1]), 
         .D(CNT1_adj_1908[1]), .Z(n2713)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1408[51:78])
    defparam i2125_3_lut_4_lut.init = 16'hf780;
    LUT4 i1797_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[2]), .C(OB[0]), 
         .D(CNT1_adj_1908[0]), .Z(n2385)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1408[51:78])
    defparam i1797_3_lut_4_lut.init = 16'hf780;
    LUT4 i2131_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[2]), .C(OB[4]), 
         .D(CNT1_adj_1908[4]), .Z(n2719)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1408[51:78])
    defparam i2131_3_lut_4_lut.init = 16'hf780;
    LUT4 i1957_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[3]), .C(SDATA[4]), 
         .D(QS_adj_1909[3]), .Z(n2545)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1424[47:74])
    defparam i1957_3_lut_4_lut.init = 16'hf780;
    LUT4 i1849_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[7]), .C(SDATA[6]), 
         .D(QS_adj_1910[5]), .Z(n2437)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1432[47:74])
    defparam i1849_3_lut_4_lut.init = 16'hf780;
    LUT4 ATR_IN0_2__N_1497_I_0_359_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[4]), 
         .Z(ATR_IN4_2__N_1501)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1491[17:42])
    defparam ATR_IN0_2__N_1497_I_0_359_2_lut_3_lut.init = 16'h8080;
    LUT4 i2135_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[2]), .C(OB[6]), 
         .D(CNT1_adj_1908[6]), .Z(n2723)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1408[51:78])
    defparam i2135_3_lut_4_lut.init = 16'hf780;
    LUT4 ATR_IN0_2__N_1497_I_0_358_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[3]), 
         .Z(ATR_IN3_2__N_1500)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1490[8:33])
    defparam ATR_IN0_2__N_1497_I_0_358_2_lut_3_lut.init = 16'h8080;
    LUT4 ATR_IN0_2__N_1497_I_0_357_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[2]), 
         .Z(ATR_IN2_2__N_1499)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1489[8:33])
    defparam ATR_IN0_2__N_1497_I_0_357_2_lut_3_lut.init = 16'h8080;
    LUT4 ATR_IN0_2__N_1497_I_0_356_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[1]), 
         .Z(ATR_IN1_2__N_1498)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1488[8:33])
    defparam ATR_IN0_2__N_1497_I_0_356_2_lut_3_lut.init = 16'h8080;
    LUT4 i3968_2_lut_2_lut (.A(PCLK_c), .B(Hnn[5]), .Z(n4579)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam i3968_2_lut_2_lut.init = 16'h4444;
    LUT4 i1839_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[7]), .C(SDATA[1]), 
         .D(QS_adj_1910[0]), .Z(n2427)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1432[47:74])
    defparam i1839_3_lut_4_lut.init = 16'hf780;
    LUT4 i2137_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[2]), .C(OB[7]), 
         .D(CNT1_adj_1908[7]), .Z(n2725)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1408[51:78])
    defparam i2137_3_lut_4_lut.init = 16'hf780;
    LUT4 i2141_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[1]), .C(OB[2]), 
         .D(CNT1_adj_1911[2]), .Z(n2729)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1407[51:78])
    defparam i2141_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_FIFO_I_0_i2_2_lut (.A(PD_FIFO), .B(PD_LATCH[1]), .Z(SDATA[1])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1416[21:51])
    defparam PD_FIFO_I_0_i2_2_lut.init = 16'h8888;
    LUT4 i2139_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[1]), .C(OB[1]), 
         .D(CNT1_adj_1911[1]), .Z(n2727)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1407[51:78])
    defparam i2139_3_lut_4_lut.init = 16'hf780;
    LUT4 i1841_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[7]), .C(SDATA[2]), 
         .D(QS_adj_1910[1]), .Z(n2429)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1432[47:74])
    defparam i1841_3_lut_4_lut.init = 16'hf780;
    LUT4 i1843_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[7]), .C(SDATA[3]), 
         .D(QS_adj_1910[2]), .Z(n2431)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1432[47:74])
    defparam i1843_3_lut_4_lut.init = 16'hf780;
    LUT4 i1845_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[7]), .C(SDATA[4]), 
         .D(QS_adj_1910[3]), .Z(n2433)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1432[47:74])
    defparam i1845_3_lut_4_lut.init = 16'hf780;
    LUT4 i1847_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[7]), .C(SDATA[5]), 
         .D(QS_adj_1910[4]), .Z(n2435)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1432[47:74])
    defparam i1847_3_lut_4_lut.init = 16'hf780;
    LUT4 i1851_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[7]), .C(SDATA[7]), 
         .D(QS_adj_1910[6]), .Z(n2439)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1432[47:74])
    defparam i1851_3_lut_4_lut.init = 16'hf780;
    LUT4 i1799_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[1]), .C(OB[0]), 
         .D(CNT1_adj_1911[0]), .Z(n2387)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1407[51:78])
    defparam i1799_3_lut_4_lut.init = 16'hf780;
    LUT4 i1967_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[2]), .C(SDATA[2]), 
         .D(QS_adj_1904[1]), .Z(n2555)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1423[47:74])
    defparam i1967_3_lut_4_lut.init = 16'hf780;
    LUT4 i2143_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[1]), .C(OB[3]), 
         .D(CNT1_adj_1911[3]), .Z(n2731)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1407[51:78])
    defparam i2143_3_lut_4_lut.init = 16'hf780;
    LUT4 i2063_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[6]), .C(OB[1]), 
         .D(CNT1_adj_1912[1]), .Z(n2651)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1412[51:78])
    defparam i2063_3_lut_4_lut.init = 16'hf780;
    LUT4 i1777_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[6]), .C(OB[0]), 
         .D(CNT1_adj_1912[0]), .Z(n2364)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1412[51:78])
    defparam i1777_3_lut_4_lut.init = 16'hf780;
    LUT4 i1961_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[3]), .C(SDATA[6]), 
         .D(QS_adj_1909[5]), .Z(n2549)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1424[47:74])
    defparam i1961_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_469 (.A(PCLK_c), .B(EN[1]), .C(SEL_LATCH[1]), 
         .D(SH5), .Z(Clk_enable_180)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1420[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_469.init = 16'ha888;
    LUT4 i3942_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[1]), .C(SEL_LATCH[1]), 
         .D(SH7), .Z(n4553)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1420[31:45])
    defparam i3942_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_470 (.A(PCLK_c), .B(EN[1]), .C(SEL_LATCH[1]), 
         .D(SH7), .Z(Clk_enable_187)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1420[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_470.init = 16'ha888;
    LUT4 i3940_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[1]), .C(SEL_LATCH[1]), 
         .D(SH5), .Z(n4551)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1420[31:45])
    defparam i3940_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i8471_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[0]), 
         .D(ZH_FF_adj_1772), .Z(CNT_7__N_1559_adj_1773)) /* synthesis lut_function=(!(A (B (C))+!A (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1406[51:78])
    defparam i8471_2_lut_3_lut_4_lut_4_lut.init = 16'h2a7f;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_471 (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[0]), 
         .D(ZH_FF_adj_1772), .Z(Clk_enable_278)) /* synthesis lut_function=(A (B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1406[51:78])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_471.init = 16'hd580;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_472 (.A(PCLK_c), .B(EN[0]), .C(SEL_LATCH[0]), 
         .D(SH5), .Z(Clk_enable_166)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1418[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_472.init = 16'ha888;
    LUT4 i3938_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[0]), .C(SEL_LATCH[0]), 
         .D(SH7), .Z(n4549)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1418[31:45])
    defparam i3938_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_473 (.A(PCLK_c), .B(EN[0]), .C(SEL_LATCH[0]), 
         .D(SH7), .Z(Clk_enable_173)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1418[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_473.init = 16'ha888;
    LUT4 i2069_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[6]), .C(OB[4]), 
         .D(CNT1_adj_1912[4]), .Z(n2657)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1412[51:78])
    defparam i2069_3_lut_4_lut.init = 16'hf780;
    LUT4 i2065_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[6]), .C(OB[2]), 
         .D(CNT1_adj_1912[2]), .Z(n2653)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1412[51:78])
    defparam i2065_3_lut_4_lut.init = 16'hf780;
    LUT4 i2067_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[6]), .C(OB[3]), 
         .D(CNT1_adj_1912[3]), .Z(n2655)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1412[51:78])
    defparam i2067_3_lut_4_lut.init = 16'hf780;
    LUT4 i1955_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[3]), .C(SDATA[3]), 
         .D(QS_adj_1909[2]), .Z(n2543)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1424[47:74])
    defparam i1955_3_lut_4_lut.init = 16'hf780;
    LUT4 i2071_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[6]), .C(OB[5]), 
         .D(CNT1_adj_1912[5]), .Z(n2659)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1412[51:78])
    defparam i2071_3_lut_4_lut.init = 16'hf780;
    LUT4 i1965_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[2]), .C(SDATA[1]), 
         .D(QS_adj_1904[0]), .Z(n2553)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1423[47:74])
    defparam i1965_3_lut_4_lut.init = 16'hf780;
    LUT4 i2073_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[6]), .C(OB[6]), 
         .D(CNT1_adj_1912[6]), .Z(n2661)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1412[51:78])
    defparam i2073_3_lut_4_lut.init = 16'hf780;
    LUT4 i2075_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[6]), .C(OB[7]), 
         .D(CNT1_adj_1912[7]), .Z(n2663)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1412[51:78])
    defparam i2075_3_lut_4_lut.init = 16'hf780;
    LUT4 i1953_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[3]), .C(SDATA[2]), 
         .D(QS_adj_1909[1]), .Z(n2541)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1424[47:74])
    defparam i1953_3_lut_4_lut.init = 16'hf780;
    LUT4 i1833_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[7]), .C(SDATA[5]), 
         .D(QS_adj_1913[4]), .Z(n2421)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1433[47:74])
    defparam i1833_3_lut_4_lut.init = 16'hf780;
    LUT4 i1921_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[4]), .C(SDATA[7]), 
         .D(QS_adj_1903[6]), .Z(n2509)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1427[47:74])
    defparam i1921_3_lut_4_lut.init = 16'hf780;
    LUT4 i1831_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[7]), .C(SDATA[4]), 
         .D(QS_adj_1913[3]), .Z(n2419)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1433[47:74])
    defparam i1831_3_lut_4_lut.init = 16'hf780;
    LUT4 i3936_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[0]), .C(SEL_LATCH[0]), 
         .D(SH5), .Z(n4547)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1418[31:45])
    defparam i3936_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i1837_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[7]), .C(SDATA[7]), 
         .D(QS_adj_1913[6]), .Z(n2425)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1433[47:74])
    defparam i1837_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_FIFO_I_0_i3_2_lut (.A(PD_FIFO), .B(PD_LATCH[2]), .Z(SDATA[2])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1416[21:51])
    defparam PD_FIFO_I_0_i3_2_lut.init = 16'h8888;
    LUT4 PD_7__I_0_i2_3_lut (.A(PD_out_1), .B(PD_out_6), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1403[24:96])
    defparam PD_7__I_0_i2_3_lut.init = 16'hcaca;
    LUT4 i1835_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[7]), .C(SDATA[6]), 
         .D(QS_adj_1913[5]), .Z(n2423)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1433[47:74])
    defparam i1835_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_FIFO_I_0_i4_2_lut (.A(PD_FIFO), .B(PD_LATCH[3]), .Z(SDATA[3])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1416[21:51])
    defparam PD_FIFO_I_0_i4_2_lut.init = 16'h8888;
    LUT4 i1087_2_lut_2_lut (.A(Hnn[2]), .B(PCLK_c), .Z(n1650)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam i1087_2_lut_2_lut.init = 16'h2222;
    LUT4 i1951_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[3]), .C(SDATA[1]), 
         .D(QS_adj_1909[0]), .Z(n2539)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1424[47:74])
    defparam i1951_3_lut_4_lut.init = 16'hf780;
    LUT4 i1829_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[7]), .C(SDATA[3]), 
         .D(QS_adj_1913[2]), .Z(n2417)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1433[47:74])
    defparam i1829_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_FIFO_I_0_i5_2_lut (.A(PD_FIFO), .B(PD_LATCH[4]), .Z(SDATA[4])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1416[21:51])
    defparam PD_FIFO_I_0_i5_2_lut.init = 16'h8888;
    LUT4 PD_FIFO_I_0_i6_2_lut (.A(PD_FIFO), .B(PD_LATCH[5]), .Z(SDATA[5])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1416[21:51])
    defparam PD_FIFO_I_0_i6_2_lut.init = 16'h8888;
    LUT4 PD_FIFO_I_0_i7_2_lut (.A(PD_FIFO), .B(PD_LATCH[6]), .Z(SDATA[6])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1416[21:51])
    defparam PD_FIFO_I_0_i7_2_lut.init = 16'h8888;
    LUT4 PD_FIFO_I_0_i8_2_lut (.A(PD_FIFO), .B(PD_LATCH[7]), .Z(SDATA[7])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1416[21:51])
    defparam PD_FIFO_I_0_i8_2_lut.init = 16'h8888;
    LUT4 i2145_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[1]), .C(OB[4]), 
         .D(CNT1_adj_1911[4]), .Z(n2733)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1407[51:78])
    defparam i2145_3_lut_4_lut.init = 16'hf780;
    LUT4 i2151_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[1]), .C(OB[7]), 
         .D(CNT1_adj_1911[7]), .Z(n2739)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1407[51:78])
    defparam i2151_3_lut_4_lut.init = 16'hf780;
    LUT4 i1827_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[7]), .C(SDATA[2]), 
         .D(QS_adj_1913[1]), .Z(n2415)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1433[47:74])
    defparam i1827_3_lut_4_lut.init = 16'hf780;
    LUT4 i2149_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[1]), .C(OB[6]), 
         .D(CNT1_adj_1911[6]), .Z(n2737)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1407[51:78])
    defparam i2149_3_lut_4_lut.init = 16'hf780;
    LUT4 i1825_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[7]), .C(SDATA[1]), 
         .D(QS_adj_1913[0]), .Z(n2413)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1433[47:74])
    defparam i1825_3_lut_4_lut.init = 16'hf780;
    LUT4 i2147_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[1]), .C(OB[5]), 
         .D(CNT1_adj_1911[5]), .Z(n2735)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1407[51:78])
    defparam i2147_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_7__I_0_i3_3_lut (.A(PD_out_2), .B(PD_out_5), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1403[24:96])
    defparam PD_7__I_0_i3_3_lut.init = 16'hcaca;
    LUT4 i2_4_lut_adj_474 (.A(COL0[4]), .B(EN[4]), .C(COL1[4]), .D(n8713), 
         .Z(n6197)) /* synthesis lut_function=(A (B (D))+!A (B (C (D)))) */ ;
    defparam i2_4_lut_adj_474.init = 16'hc800;
    LUT4 i5507_3_lut (.A(COL0[1]), .B(EN[1]), .C(COL1[1]), .Z(n2946)) /* synthesis lut_function=(A (B)+!A (B (C))) */ ;
    defparam i5507_3_lut.init = 16'hc8c8;
    LUT4 i1959_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[3]), .C(SDATA[5]), 
         .D(QS_adj_1909[4]), .Z(n2547)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1424[47:74])
    defparam i1959_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_475 (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[1]), 
         .D(ZH_FF_adj_1797), .Z(Clk_enable_117)) /* synthesis lut_function=(A (B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1407[51:78])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_475.init = 16'hd580;
    LUT4 PD_7__I_0_i4_3_lut (.A(PD_out_3), .B(PD_out_4), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1403[24:96])
    defparam PD_7__I_0_i4_3_lut.init = 16'hcaca;
    LUT4 i8464_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[1]), 
         .D(ZH_FF_adj_1797), .Z(CNT_7__N_1559_adj_1798)) /* synthesis lut_function=(!(A (B (C))+!A (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1407[51:78])
    defparam i8464_2_lut_3_lut_4_lut_4_lut.init = 16'h2a7f;
    FD1P3IX SEL_LATCH_i0_i7 (.D(SEL_LATCH_7__N_1479), .SP(nPCLK), .CD(n4644), 
            .CK(Clk), .Q(SEL_LATCH[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam SEL_LATCH_i0_i7.GSR = "ENABLED";
    FD1P3IX SEL_LATCH_i0_i6 (.D(SEL_LATCH_7__N_1481), .SP(nPCLK), .CD(n4644), 
            .CK(Clk), .Q(SEL_LATCH[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam SEL_LATCH_i0_i6.GSR = "ENABLED";
    FD1P3IX SEL_LATCH_i0_i5 (.D(SEL_LATCH_7__N_1485), .SP(nPCLK), .CD(n4644), 
            .CK(Clk), .Q(SEL_LATCH[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam SEL_LATCH_i0_i5.GSR = "ENABLED";
    LUT4 PD_7__I_0_i5_3_lut (.A(PD_out_4), .B(PD_out_3), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1403[24:96])
    defparam PD_7__I_0_i5_3_lut.init = 16'hcaca;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_476 (.A(PCLK_c), .B(EN[3]), .C(SEL_LATCH[3]), 
         .D(SH5), .Z(Clk_enable_208)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1424[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_476.init = 16'ha888;
    LUT4 i3950_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[3]), .C(SEL_LATCH[3]), 
         .D(SH7), .Z(n4561)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1424[31:45])
    defparam i3950_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    FD1P3AX ATR_IN0_i0_i0 (.D(OB[0]), .SP(ATR_IN0_2__N_1496), .CK(Clk), 
            .Q(ATR_IN0[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN0_i0_i0.GSR = "ENABLED";
    FD1P3AX PD_LATCH_i0_i0 (.D(MIRR_MUX[0]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam PD_LATCH_i0_i0.GSR = "ENABLED";
    FD1P3IX SEL_LATCH_i0_i4 (.D(SEL_LATCH_7__N_1489), .SP(nPCLK), .CD(n4644), 
            .CK(Clk), .Q(SEL_LATCH[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam SEL_LATCH_i0_i4.GSR = "ENABLED";
    FD1P3IX SEL_LATCH_i0_i3 (.D(SEL_LATCH_7__N_1479), .SP(nPCLK), .CD(n4579), 
            .CK(Clk), .Q(SEL_LATCH[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam SEL_LATCH_i0_i3.GSR = "ENABLED";
    LUT4 i1963_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[3]), .C(SDATA[7]), 
         .D(QS_adj_1909[6]), .Z(n2551)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1424[47:74])
    defparam i1963_3_lut_4_lut.init = 16'hf780;
    FD1P3IX SEL_LATCH_i0_i2 (.D(SEL_LATCH_7__N_1481), .SP(nPCLK), .CD(n4579), 
            .CK(Clk), .Q(SEL_LATCH[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam SEL_LATCH_i0_i2.GSR = "ENABLED";
    FD1P3AX ATR0_i0_i0 (.D(ATR_IN0[0]), .SP(nPCLK), .CK(Clk), .Q(ATR0[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR0_i0_i0.GSR = "ENABLED";
    FD1P3AX ATR1_i0_i0 (.D(ATR_IN1[0]), .SP(nPCLK), .CK(Clk), .Q(ATR1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR1_i0_i0.GSR = "ENABLED";
    FD1P3AX ATR2_i0_i0 (.D(ATR_IN2[0]), .SP(nPCLK), .CK(Clk), .Q(ATR2[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR2_i0_i0.GSR = "ENABLED";
    FD1P3AX ATR3_i0_i0 (.D(ATR_IN3[0]), .SP(nPCLK), .CK(Clk), .Q(ATR3[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR3_i0_i0.GSR = "ENABLED";
    FD1P3AX ATR4_i0_i0 (.D(ATR_IN4[0]), .SP(nPCLK), .CK(Clk), .Q(ATR4[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR4_i0_i0.GSR = "ENABLED";
    FD1P3AX ATR5_i0_i0 (.D(ATR_IN5[0]), .SP(nPCLK), .CK(Clk), .Q(ATR5[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR5_i0_i0.GSR = "ENABLED";
    FD1P3AX ATR6_i0_i0 (.D(ATR_IN6[0]), .SP(nPCLK), .CK(Clk), .Q(ATR6[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR6_i0_i0.GSR = "ENABLED";
    FD1P3AX ATR7_i0_i0 (.D(ATR_IN7[0]), .SP(nPCLK), .CK(Clk), .Q(ATR7[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR7_i0_i0.GSR = "ENABLED";
    FD1P3AX ATR_IN1_i0_i0 (.D(OB[0]), .SP(ATR_IN1_2__N_1498), .CK(Clk), 
            .Q(ATR_IN1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN1_i0_i0.GSR = "ENABLED";
    FD1P3AX ATR_IN2_i0_i0 (.D(OB[0]), .SP(ATR_IN2_2__N_1499), .CK(Clk), 
            .Q(ATR_IN2[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN2_i0_i0.GSR = "ENABLED";
    FD1P3AX ATR_IN3_i0_i0 (.D(OB[0]), .SP(ATR_IN3_2__N_1500), .CK(Clk), 
            .Q(ATR_IN3[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN3_i0_i0.GSR = "ENABLED";
    FD1P3AX ATR_IN4_i0_i0 (.D(OB[0]), .SP(ATR_IN4_2__N_1501), .CK(Clk), 
            .Q(ATR_IN4[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN4_i0_i0.GSR = "ENABLED";
    FD1P3AX ATR_IN5_i0_i0 (.D(OB[0]), .SP(ATR_IN5_2__N_1502), .CK(Clk), 
            .Q(ATR_IN5[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN5_i0_i0.GSR = "ENABLED";
    FD1P3AX ATR_IN6_i0_i0 (.D(OB[0]), .SP(ATR_IN6_2__N_1503), .CK(Clk), 
            .Q(ATR_IN6[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN6_i0_i0.GSR = "ENABLED";
    FD1P3AX ATR_IN7_i0_i0 (.D(OB[0]), .SP(ATR_IN7_2__N_1504), .CK(Clk), 
            .Q(ATR_IN7[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN7_i0_i0.GSR = "ENABLED";
    FD1P3AX ZPOS_i0 (.D(O_HPOS), .SP(nPCLK), .CK(Clk), .Q(ZPOS[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ZPOS_i0.GSR = "ENABLED";
    FD1P3IX SEL_LATCH_i0_i1 (.D(SEL_LATCH_7__N_1485), .SP(nPCLK), .CD(n4579), 
            .CK(Clk), .Q(SEL_LATCH[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam SEL_LATCH_i0_i1.GSR = "ENABLED";
    LUT4 i2_4_lut_adj_477 (.A(COL0[2]), .B(EN[2]), .C(COL1[2]), .D(CLIPOR), 
         .Z(n6166)) /* synthesis lut_function=(A (B (D))+!A (B (C (D)))) */ ;
    defparam i2_4_lut_adj_477.init = 16'hc800;
    LUT4 i1885_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[5]), .C(SDATA[3]), 
         .D(QS_adj_1914[2]), .Z(n2473)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1429[47:74])
    defparam i1885_3_lut_4_lut.init = 16'hf780;
    LUT4 n6195_bdd_2_lut (.A(n6195), .B(n9653), .Z(n8710)) /* synthesis lut_function=(!(A+!(B))) */ ;
    defparam n6195_bdd_2_lut.init = 16'h4444;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_478 (.A(PCLK_c), .B(EN[3]), .C(SEL_LATCH[3]), 
         .D(SH7), .Z(Clk_enable_215)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1424[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_478.init = 16'ha888;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_479 (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[2]), 
         .D(ZH_FF_adj_1801), .Z(Clk_enable_124)) /* synthesis lut_function=(A (B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1408[51:78])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_479.init = 16'hd580;
    LUT4 i3948_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[3]), .C(SEL_LATCH[3]), 
         .D(SH5), .Z(n4559)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1424[31:45])
    defparam i3948_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i1929_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[4]), .C(SDATA[4]), 
         .D(QS_adj_1915[3]), .Z(n2517)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1426[47:74])
    defparam i1929_3_lut_4_lut.init = 16'hf780;
    LUT4 i8455_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[2]), 
         .D(ZH_FF_adj_1801), .Z(CNT_7__N_1559_adj_1803)) /* synthesis lut_function=(!(A (B (C))+!A (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1408[51:78])
    defparam i8455_2_lut_3_lut_4_lut_4_lut.init = 16'h2a7f;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_480 (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[3]), 
         .D(ZH_FF_adj_1804), .Z(Clk_enable_131)) /* synthesis lut_function=(A (B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1409[51:78])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_480.init = 16'hd580;
    LUT4 i8444_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[3]), 
         .D(ZH_FF_adj_1804), .Z(CNT_7__N_1559_adj_1805)) /* synthesis lut_function=(!(A (B (C))+!A (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1409[51:78])
    defparam i8444_2_lut_3_lut_4_lut_4_lut.init = 16'h2a7f;
    LUT4 i1933_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[4]), .C(SDATA[6]), 
         .D(QS_adj_1915[5]), .Z(n2521)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1426[47:74])
    defparam i1933_3_lut_4_lut.init = 16'hf780;
    LUT4 n6195_bdd_4_lut (.A(n8828), .B(n8713), .C(n2946), .D(n6197), 
         .Z(n9653)) /* synthesis lut_function=(!(A+((C+(D))+!B))) */ ;
    defparam n6195_bdd_4_lut.init = 16'h0004;
    LUT4 i1927_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[4]), .C(SDATA[3]), 
         .D(QS_adj_1915[2]), .Z(n2515)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1426[47:74])
    defparam i1927_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_481 (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[5]), 
         .D(ZH_FF_adj_1808), .Z(Clk_enable_145)) /* synthesis lut_function=(A (B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1411[51:78])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_481.init = 16'hd580;
    LUT4 i8440_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[5]), 
         .D(ZH_FF_adj_1808), .Z(CNT_7__N_1559_adj_1809)) /* synthesis lut_function=(!(A (B (C))+!A (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1411[51:78])
    defparam i8440_2_lut_3_lut_4_lut_4_lut.init = 16'h2a7f;
    LUT4 i2083_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[5]), .C(OB[1]), 
         .D(CNT1_adj_1916[1]), .Z(n2671)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1411[51:78])
    defparam i2083_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_7__I_0_i6_3_lut (.A(PD_out_5), .B(PD_out_2), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1403[24:96])
    defparam PD_7__I_0_i6_3_lut.init = 16'hcaca;
    LUT4 i1973_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[2]), .C(SDATA[5]), 
         .D(QS_adj_1904[4]), .Z(n2561)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1423[47:74])
    defparam i1973_3_lut_4_lut.init = 16'hf780;
    LUT4 i1788_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[5]), .C(OB[0]), 
         .D(CNT1_adj_1916[0]), .Z(n2375)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1411[51:78])
    defparam i1788_3_lut_4_lut.init = 16'hf780;
    LUT4 i1925_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[4]), .C(SDATA[2]), 
         .D(QS_adj_1915[1]), .Z(n2513)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1426[47:74])
    defparam i1925_3_lut_4_lut.init = 16'hf780;
    LUT4 i1923_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[4]), .C(SDATA[1]), 
         .D(QS_adj_1915[0]), .Z(n2511)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1426[47:74])
    defparam i1923_3_lut_4_lut.init = 16'hf780;
    LUT4 i8593_2_lut (.A(PCLK_c), .B(Hnn[5]), .Z(n4644)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i8593_2_lut.init = 16'h1111;
    LUT4 PD_7__I_0_i7_3_lut (.A(PD_out_6), .B(PD_out_1), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1403[24:96])
    defparam PD_7__I_0_i7_3_lut.init = 16'hcaca;
    LUT4 i2089_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[5]), .C(OB[4]), 
         .D(CNT1_adj_1916[4]), .Z(n2677)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1411[51:78])
    defparam i2089_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_7__I_0_i8_3_lut (.A(PD_out_7), .B(PD_out_0), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1403[24:96])
    defparam PD_7__I_0_i8_3_lut.init = 16'hcaca;
    LUT4 i2085_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[5]), .C(OB[2]), 
         .D(CNT1_adj_1916[2]), .Z(n2673)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1411[51:78])
    defparam i2085_3_lut_4_lut.init = 16'hf780;
    LUT4 i1883_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[5]), .C(SDATA[2]), 
         .D(QS_adj_1914[1]), .Z(n2471)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1429[47:74])
    defparam i1883_3_lut_4_lut.init = 16'hf780;
    LUT4 i2087_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[5]), .C(OB[3]), 
         .D(CNT1_adj_1916[3]), .Z(n2675)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1411[51:78])
    defparam i2087_3_lut_4_lut.init = 16'hf780;
    LUT4 i2091_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[5]), .C(OB[5]), 
         .D(CNT1_adj_1916[5]), .Z(n2679)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1411[51:78])
    defparam i2091_3_lut_4_lut.init = 16'hf780;
    LUT4 i1903_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[5]), .C(SDATA[5]), 
         .D(QS_adj_1917[4]), .Z(n2491)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1428[47:74])
    defparam i1903_3_lut_4_lut.init = 16'hf780;
    LUT4 i3965_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[7]), .C(SEL_LATCH[7]), 
         .D(SH5), .Z(n4576)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1432[31:45])
    defparam i3965_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i2093_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[5]), .C(OB[6]), 
         .D(CNT1_adj_1916[6]), .Z(n2681)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1411[51:78])
    defparam i2093_3_lut_4_lut.init = 16'hf780;
    LUT4 i2095_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[5]), .C(OB[7]), 
         .D(CNT1_adj_1916[7]), .Z(n2683)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1411[51:78])
    defparam i2095_3_lut_4_lut.init = 16'hf780;
    LUT4 i1943_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[3]), .C(SDATA[4]), 
         .D(QS_adj_1906[3]), .Z(n2531)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1425[47:74])
    defparam i1943_3_lut_4_lut.init = 16'hf780;
    LUT4 i3967_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[7]), .C(SEL_LATCH[7]), 
         .D(SH7), .Z(n4578)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1432[31:45])
    defparam i3967_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_482 (.A(PCLK_c), .B(EN[7]), .C(SEL_LATCH[7]), 
         .D(SH7), .Z(Clk_enable_271)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1432[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_482.init = 16'ha888;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_483 (.A(PCLK_c), .B(EN[7]), .C(SEL_LATCH[7]), 
         .D(SH5), .Z(Clk_enable_264)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1432[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_483.init = 16'ha888;
    LUT4 i1931_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[4]), .C(SDATA[5]), 
         .D(QS_adj_1915[4]), .Z(n2519)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1426[47:74])
    defparam i1931_3_lut_4_lut.init = 16'hf780;
    LUT4 i2109_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[4]), .C(OB[7]), 
         .D(CNT1_adj_1918[7]), .Z(n2697)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1410[51:78])
    defparam i2109_3_lut_4_lut.init = 16'hf780;
    LUT4 i1947_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[3]), .C(SDATA[6]), 
         .D(QS_adj_1906[5]), .Z(n2535)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1425[47:74])
    defparam i1947_3_lut_4_lut.init = 16'hf780;
    LUT4 i2107_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[4]), .C(OB[6]), 
         .D(CNT1_adj_1918[6]), .Z(n2695)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1410[51:78])
    defparam i2107_3_lut_4_lut.init = 16'hf780;
    LUT4 i1905_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[5]), .C(SDATA[6]), 
         .D(QS_adj_1917[5]), .Z(n2493)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1428[47:74])
    defparam i1905_3_lut_4_lut.init = 16'hf780;
    FD1P3AX MIRR_LATCH_292 (.D(OB[6]), .SP(VINV_LATCH_N_1001), .CK(Clk), 
            .Q(MIRR_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam MIRR_LATCH_292.GSR = "ENABLED";
    FD1P3AX SPR0HIT_LATCH_277 (.D(SPR[0]), .SP(PCLK_c), .CK(Clk), .Q(SPR0HIT_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam SPR0HIT_LATCH_277.GSR = "ENABLED";
    LUT4 i1901_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[5]), .C(SDATA[4]), 
         .D(QS_adj_1917[3]), .Z(n2489)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1428[47:74])
    defparam i1901_3_lut_4_lut.init = 16'hf780;
    LUT4 i2103_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[4]), .C(OB[4]), 
         .D(CNT1_adj_1918[4]), .Z(n2691)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1410[51:78])
    defparam i2103_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_484 (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[6]), 
         .D(ZH_FF_adj_1831), .Z(Clk_enable_152)) /* synthesis lut_function=(A (B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1412[51:78])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_484.init = 16'hd580;
    LUT4 i8438_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[6]), 
         .D(ZH_FF_adj_1831), .Z(CNT_7__N_1559_adj_1832)) /* synthesis lut_function=(!(A (B (C))+!A (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1412[51:78])
    defparam i8438_2_lut_3_lut_4_lut_4_lut.init = 16'h2a7f;
    LUT4 i1899_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[5]), .C(SDATA[3]), 
         .D(QS_adj_1917[2]), .Z(n2487)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1428[47:74])
    defparam i1899_3_lut_4_lut.init = 16'hf780;
    LUT4 i1941_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[3]), .C(SDATA[3]), 
         .D(QS_adj_1906[2]), .Z(n2529)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1425[47:74])
    defparam i1941_3_lut_4_lut.init = 16'hf780;
    LUT4 i1939_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[3]), .C(SDATA[2]), 
         .D(QS_adj_1906[1]), .Z(n2527)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1425[47:74])
    defparam i1939_3_lut_4_lut.init = 16'hf780;
    LUT4 i2105_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[4]), .C(OB[5]), 
         .D(CNT1_adj_1918[5]), .Z(n2693)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1410[51:78])
    defparam i2105_3_lut_4_lut.init = 16'hf780;
    LUT4 i2101_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[4]), .C(OB[3]), 
         .D(CNT1_adj_1918[3]), .Z(n2689)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1410[51:78])
    defparam i2101_3_lut_4_lut.init = 16'hf780;
    LUT4 i1935_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[4]), .C(SDATA[7]), 
         .D(QS_adj_1915[6]), .Z(n2523)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1426[47:74])
    defparam i1935_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_485 (.A(PCLK_c), .B(EN[2]), .C(SEL_LATCH[2]), 
         .D(SH5), .Z(Clk_enable_194)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1422[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_485.init = 16'ha888;
    LUT4 i2099_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[4]), .C(OB[2]), 
         .D(CNT1_adj_1918[2]), .Z(n2687)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1410[51:78])
    defparam i2099_3_lut_4_lut.init = 16'hf780;
    LUT4 i1793_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[4]), .C(OB[0]), 
         .D(CNT1_adj_1918[0]), .Z(n2381)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1410[51:78])
    defparam i1793_3_lut_4_lut.init = 16'hf780;
    LUT4 i2097_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[4]), .C(OB[1]), 
         .D(CNT1_adj_1918[1]), .Z(n2685)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1410[51:78])
    defparam i2097_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_486 (.A(PCLK_c), .B(SH3), .C(SEL_LATCH[7]), 
         .D(ZH_FF), .Z(Clk_enable_159)) /* synthesis lut_function=(A (B (C))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1413[51:78])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_486.init = 16'hd580;
    LUT4 i1_4_lut_adj_487 (.A(n2_adj_1732), .B(n8710), .C(n2), .D(n4_adj_1842), 
         .Z(n8711)) /* synthesis lut_function=(A (B)+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1451[20] 1453[28])
    defparam i1_4_lut_adj_487.init = 16'h8c88;
    LUT4 Hnn_3__I_0_353_2_lut (.A(Hnn[3]), .B(Hnn[4]), .Z(SEL_LATCH_7__N_1479)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1473[21:37])
    defparam Hnn_3__I_0_353_2_lut.init = 16'h8888;
    MUX41 ZCOL_4__I_013 (.D0(COL0[0]), .D1(COL0[1]), .D2(COL0[2]), .D3(n216[0]), 
          .SD1(n2245), .SD2(n2243), .Z(ZCOL[0]));
    MUX41 ZCOL_4__I_014 (.D0(COL1[0]), .D1(COL1[1]), .D2(COL1[2]), .D3(n216[1]), 
          .SD1(n2245), .SD2(n2243), .Z(ZCOL[1]));
    MUX41 ZCOL_4__I_015 (.D0(ATR0[0]), .D1(ATR1[0]), .D2(ATR2[0]), .D3(n216[2]), 
          .SD1(n2245), .SD2(n2243), .Z(ZCOL[2]));
    MUX41 ZCOL_4__I_016 (.D0(ATR0[1]), .D1(ATR1[1]), .D2(ATR2[1]), .D3(n216[3]), 
          .SD1(n2245), .SD2(n2243), .Z(ZCOL[3]));
    MUX41 ZCOL_4__I_017 (.D0(ATR0[2]), .D1(ATR1[2]), .D2(ATR2[2]), .D3(n216[4]), 
          .SD1(n2245), .SD2(n2243), .Z(ZCOL[4]));
    MUX41 mux_15718 (.D0(COL0[3]), .D1(COL0[4]), .D2(COL0[5]), .D3(n8711), 
          .SD1(n2255), .SD2(n2253), .Z(n216[0]));
    MUX41 mux_15719 (.D0(COL1[3]), .D1(COL1[4]), .D2(COL1[5]), .D3(n8712), 
          .SD1(n2255), .SD2(n2253), .Z(n216[1]));
    MUX41 mux_15720 (.D0(ATR3[0]), .D1(ATR4[0]), .D2(ATR5[0]), .D3(n198[2]), 
          .SD1(n2255), .SD2(n2253), .Z(n216[2]));
    MUX41 mux_15721 (.D0(ATR3[1]), .D1(ATR4[1]), .D2(ATR5[1]), .D3(n198[3]), 
          .SD1(n2255), .SD2(n2253), .Z(n216[3]));
    MUX41 mux_15722 (.D0(ATR3[2]), .D1(ATR4[2]), .D2(ATR5[2]), .D3(n198[4]), 
          .SD1(n2255), .SD2(n2253), .Z(n216[4]));
    LUT4 SH3_N_1519_I_0_2_lut_3_lut (.A(PAR_O), .B(Hnn[0]), .C(Hnn[1]), 
         .Z(SH5_N_1522)) /* synthesis lut_function=(!(((C)+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1463[12:27])
    defparam SH3_N_1519_I_0_2_lut_3_lut.init = 16'h0808;
    LUT4 SH3_I_377_2_lut_3_lut (.A(PAR_O), .B(Hnn[0]), .C(Hnn[1]), .Z(SH3_N_1518)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1463[12:27])
    defparam SH3_I_377_2_lut_3_lut.init = 16'h8080;
    LUT4 i2041_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[0]), .C(SDATA[4]), 
         .D(QS_adj_1919[3]), .Z(n2629)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1418[47:74])
    defparam i2041_3_lut_4_lut.init = 16'hf780;
    LUT4 i2045_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[0]), .C(SDATA[6]), 
         .D(QS_adj_1919[5]), .Z(n2633)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1418[47:74])
    defparam i2045_3_lut_4_lut.init = 16'hf780;
    LUT4 i2039_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[0]), .C(SDATA[3]), 
         .D(QS_adj_1919[2]), .Z(n2627)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1418[47:74])
    defparam i2039_3_lut_4_lut.init = 16'hf780;
    LUT4 i2037_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[0]), .C(SDATA[2]), 
         .D(QS_adj_1919[1]), .Z(n2625)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1418[47:74])
    defparam i2037_3_lut_4_lut.init = 16'hf780;
    LUT4 i2035_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[0]), .C(SDATA[1]), 
         .D(QS_adj_1919[0]), .Z(n2623)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1418[47:74])
    defparam i2035_3_lut_4_lut.init = 16'hf780;
    LUT4 i2043_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[0]), .C(SDATA[5]), 
         .D(QS_adj_1919[4]), .Z(n2631)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1418[47:74])
    defparam i2043_3_lut_4_lut.init = 16'hf780;
    LUT4 i2047_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[0]), .C(SDATA[7]), 
         .D(QS_adj_1919[6]), .Z(n2635)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1418[47:74])
    defparam i2047_3_lut_4_lut.init = 16'hf780;
    LUT4 i2027_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[0]), .C(SDATA[4]), 
         .D(QS_adj_1920[3]), .Z(n2615)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1419[47:74])
    defparam i2027_3_lut_4_lut.init = 16'hf780;
    LUT4 i2031_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[0]), .C(SDATA[6]), 
         .D(QS_adj_1920[5]), .Z(n2619)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1419[47:74])
    defparam i2031_3_lut_4_lut.init = 16'hf780;
    LUT4 i2025_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[0]), .C(SDATA[3]), 
         .D(QS_adj_1920[2]), .Z(n2613)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1419[47:74])
    defparam i2025_3_lut_4_lut.init = 16'hf780;
    LUT4 i2023_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[0]), .C(SDATA[2]), 
         .D(QS_adj_1920[1]), .Z(n2611)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1419[47:74])
    defparam i2023_3_lut_4_lut.init = 16'hf780;
    LUT4 i2021_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[0]), .C(SDATA[1]), 
         .D(QS_adj_1920[0]), .Z(n2609)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1419[47:74])
    defparam i2021_3_lut_4_lut.init = 16'hf780;
    LUT4 i2029_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[0]), .C(SDATA[5]), 
         .D(QS_adj_1920[4]), .Z(n2617)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1419[47:74])
    defparam i2029_3_lut_4_lut.init = 16'hf780;
    LUT4 i2_3_lut (.A(Hnn[1]), .B(Hnn[0]), .C(PAR_O), .Z(SH2_N_1509)) /* synthesis lut_function=(!((B+!(C))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1462[12:37])
    defparam i2_3_lut.init = 16'h2020;
    LUT4 i2033_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[0]), .C(SDATA[7]), 
         .D(QS_adj_1920[6]), .Z(n2621)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1419[47:74])
    defparam i2033_3_lut_4_lut.init = 16'hf780;
    LUT4 i2013_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[1]), .C(SDATA[4]), 
         .D(QS_adj_1921[3]), .Z(n2601)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1420[47:74])
    defparam i2013_3_lut_4_lut.init = 16'hf780;
    LUT4 i2017_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[1]), .C(SDATA[6]), 
         .D(QS_adj_1921[5]), .Z(n2605)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1420[47:74])
    defparam i2017_3_lut_4_lut.init = 16'hf780;
    LUT4 i2011_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[1]), .C(SDATA[3]), 
         .D(QS_adj_1921[2]), .Z(n2599)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1420[47:74])
    defparam i2011_3_lut_4_lut.init = 16'hf780;
    LUT4 i2009_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[1]), .C(SDATA[2]), 
         .D(QS_adj_1921[1]), .Z(n2597)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1420[47:74])
    defparam i2009_3_lut_4_lut.init = 16'hf780;
    LUT4 i2007_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[1]), .C(SDATA[1]), 
         .D(QS_adj_1921[0]), .Z(n2595)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1420[47:74])
    defparam i2007_3_lut_4_lut.init = 16'hf780;
    LUT4 i2015_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[1]), .C(SDATA[5]), 
         .D(QS_adj_1921[4]), .Z(n2603)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1420[47:74])
    defparam i2015_3_lut_4_lut.init = 16'hf780;
    LUT4 i2019_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[1]), .C(SDATA[7]), 
         .D(QS_adj_1921[6]), .Z(n2607)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1420[47:74])
    defparam i2019_3_lut_4_lut.init = 16'hf780;
    LUT4 i1719_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[0]), .C(OB[0]), 
         .D(CNT1_adj_1922[0]), .Z(n2304)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1406[51:78])
    defparam i1719_3_lut_4_lut.init = 16'hf780;
    LUT4 i1811_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[0]), .C(OB[1]), 
         .D(CNT1_adj_1922[1]), .Z(n2399)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1406[51:78])
    defparam i1811_3_lut_4_lut.init = 16'hf780;
    LUT4 i1813_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[0]), .C(OB[2]), 
         .D(CNT1_adj_1922[2]), .Z(n2401)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1406[51:78])
    defparam i1813_3_lut_4_lut.init = 16'hf780;
    LUT4 i1815_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[0]), .C(OB[3]), 
         .D(CNT1_adj_1922[3]), .Z(n2403)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1406[51:78])
    defparam i1815_3_lut_4_lut.init = 16'hf780;
    LUT4 i1817_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[0]), .C(OB[4]), 
         .D(CNT1_adj_1922[4]), .Z(n2405)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1406[51:78])
    defparam i1817_3_lut_4_lut.init = 16'hf780;
    LUT4 i1819_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[0]), .C(OB[5]), 
         .D(CNT1_adj_1922[5]), .Z(n2407)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1406[51:78])
    defparam i1819_3_lut_4_lut.init = 16'hf780;
    LUT4 i1821_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[0]), .C(OB[6]), 
         .D(CNT1_adj_1922[6]), .Z(n2409)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1406[51:78])
    defparam i1821_3_lut_4_lut.init = 16'hf780;
    LUT4 i1823_3_lut_4_lut (.A(EN_7__N_1361), .B(SEL_LATCH[0]), .C(OB[7]), 
         .D(CNT1_adj_1922[7]), .Z(n2411)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1406[51:78])
    defparam i1823_3_lut_4_lut.init = 16'hf780;
    LUT4 i1999_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[1]), .C(SDATA[4]), 
         .D(QS_adj_1923[3]), .Z(n2587)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1421[47:74])
    defparam i1999_3_lut_4_lut.init = 16'hf780;
    LUT4 i2003_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[1]), .C(SDATA[6]), 
         .D(QS_adj_1923[5]), .Z(n2591)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1421[47:74])
    defparam i2003_3_lut_4_lut.init = 16'hf780;
    LUT4 i1997_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[1]), .C(SDATA[3]), 
         .D(QS_adj_1923[2]), .Z(n2585)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1421[47:74])
    defparam i1997_3_lut_4_lut.init = 16'hf780;
    LUT4 i1995_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[1]), .C(SDATA[2]), 
         .D(QS_adj_1923[1]), .Z(n2583)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1421[47:74])
    defparam i1995_3_lut_4_lut.init = 16'hf780;
    LUT4 i1993_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[1]), .C(SDATA[1]), 
         .D(QS_adj_1923[0]), .Z(n2581)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1421[47:74])
    defparam i1993_3_lut_4_lut.init = 16'hf780;
    LUT4 i5558_2_lut (.A(CLIPOR), .B(n5904), .Z(SPR[0])) /* synthesis lut_function=(A (B)) */ ;
    defparam i5558_2_lut.init = 16'h8888;
    LUT4 i2001_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[1]), .C(SDATA[5]), 
         .D(QS_adj_1923[4]), .Z(n2589)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1421[47:74])
    defparam i2001_3_lut_4_lut.init = 16'hf780;
    LUT4 i5308_3_lut (.A(COL0[0]), .B(EN[0]), .C(COL1[0]), .Z(n5904)) /* synthesis lut_function=(A (B)+!A (B (C))) */ ;
    defparam i5308_3_lut.init = 16'hc8c8;
    LUT4 i2005_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[1]), .C(SDATA[7]), 
         .D(QS_adj_1923[6]), .Z(n2593)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1421[47:74])
    defparam i2005_3_lut_4_lut.init = 16'hf780;
    LUT4 PD_7__I_0_i1_3_lut (.A(PD_out_0), .B(PD_out_7), .C(MIRR_LATCH), 
         .Z(MIRR_MUX[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1403[24:96])
    defparam PD_7__I_0_i1_3_lut.init = 16'hcaca;
    FD1P3IX SEL_LATCH_i0_i0 (.D(SEL_LATCH_7__N_1489), .SP(nPCLK), .CD(n4579), 
            .CK(Clk), .Q(SEL_LATCH[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam SEL_LATCH_i0_i0.GSR = "ENABLED";
    LUT4 i1897_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[5]), .C(SDATA[2]), 
         .D(QS_adj_1917[1]), .Z(n2485)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1428[47:74])
    defparam i1897_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR_IN0_i0_i1 (.D(OB[1]), .SP(ATR_IN0_2__N_1496), .CK(Clk), 
            .Q(ATR_IN0[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN0_i0_i1.GSR = "ENABLED";
    FD1P3AX ATR_IN0_i0_i2 (.D(OB[5]), .SP(ATR_IN0_2__N_1496), .CK(Clk), 
            .Q(ATR_IN0[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN0_i0_i2.GSR = "ENABLED";
    FD1P3AX PD_LATCH_i0_i1 (.D(MIRR_MUX[1]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam PD_LATCH_i0_i1.GSR = "ENABLED";
    FD1P3AX PD_LATCH_i0_i2 (.D(MIRR_MUX[2]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam PD_LATCH_i0_i2.GSR = "ENABLED";
    FD1P3AX PD_LATCH_i0_i3 (.D(MIRR_MUX[3]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam PD_LATCH_i0_i3.GSR = "ENABLED";
    FD1P3AX PD_LATCH_i0_i4 (.D(MIRR_MUX[4]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam PD_LATCH_i0_i4.GSR = "ENABLED";
    FD1P3AX PD_LATCH_i0_i5 (.D(MIRR_MUX[5]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam PD_LATCH_i0_i5.GSR = "ENABLED";
    FD1P3AX PD_LATCH_i0_i6 (.D(MIRR_MUX[6]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam PD_LATCH_i0_i6.GSR = "ENABLED";
    FD1P3AX PD_LATCH_i0_i7 (.D(MIRR_MUX[7]), .SP(nPCLK), .CK(Clk), .Q(PD_LATCH[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam PD_LATCH_i0_i7.GSR = "ENABLED";
    FD1P3AX ATR0_i0_i1 (.D(ATR_IN0[1]), .SP(nPCLK), .CK(Clk), .Q(ATR0[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR0_i0_i1.GSR = "ENABLED";
    FD1P3AX ATR0_i0_i2 (.D(ATR_IN0[2]), .SP(nPCLK), .CK(Clk), .Q(ATR0[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR0_i0_i2.GSR = "ENABLED";
    FD1P3AX ATR1_i0_i1 (.D(ATR_IN1[1]), .SP(nPCLK), .CK(Clk), .Q(ATR1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR1_i0_i1.GSR = "ENABLED";
    FD1P3AX ATR1_i0_i2 (.D(ATR_IN1[2]), .SP(nPCLK), .CK(Clk), .Q(ATR1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR1_i0_i2.GSR = "ENABLED";
    FD1P3AX ATR2_i0_i1 (.D(ATR_IN2[1]), .SP(nPCLK), .CK(Clk), .Q(ATR2[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR2_i0_i1.GSR = "ENABLED";
    FD1P3AX ATR2_i0_i2 (.D(ATR_IN2[2]), .SP(nPCLK), .CK(Clk), .Q(ATR2[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR2_i0_i2.GSR = "ENABLED";
    FD1P3AX ATR3_i0_i1 (.D(ATR_IN3[1]), .SP(nPCLK), .CK(Clk), .Q(ATR3[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR3_i0_i1.GSR = "ENABLED";
    FD1P3AX ATR3_i0_i2 (.D(ATR_IN3[2]), .SP(nPCLK), .CK(Clk), .Q(ATR3[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR3_i0_i2.GSR = "ENABLED";
    FD1P3AX ATR4_i0_i1 (.D(ATR_IN4[1]), .SP(nPCLK), .CK(Clk), .Q(ATR4[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR4_i0_i1.GSR = "ENABLED";
    FD1P3AX ATR4_i0_i2 (.D(ATR_IN4[2]), .SP(nPCLK), .CK(Clk), .Q(ATR4[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR4_i0_i2.GSR = "ENABLED";
    FD1P3AX ATR5_i0_i1 (.D(ATR_IN5[1]), .SP(nPCLK), .CK(Clk), .Q(ATR5[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR5_i0_i1.GSR = "ENABLED";
    FD1P3AX ATR5_i0_i2 (.D(ATR_IN5[2]), .SP(nPCLK), .CK(Clk), .Q(ATR5[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR5_i0_i2.GSR = "ENABLED";
    FD1P3AX ATR6_i0_i1 (.D(ATR_IN6[1]), .SP(nPCLK), .CK(Clk), .Q(ATR6[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR6_i0_i1.GSR = "ENABLED";
    FD1P3AX ATR6_i0_i2 (.D(ATR_IN6[2]), .SP(nPCLK), .CK(Clk), .Q(ATR6[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR6_i0_i2.GSR = "ENABLED";
    FD1P3AX ATR7_i0_i1 (.D(ATR_IN7[1]), .SP(nPCLK), .CK(Clk), .Q(ATR7[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR7_i0_i1.GSR = "ENABLED";
    FD1P3AX ATR7_i0_i2 (.D(ATR_IN7[2]), .SP(nPCLK), .CK(Clk), .Q(ATR7[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR7_i0_i2.GSR = "ENABLED";
    FD1P3AX ATR_IN1_i0_i1 (.D(OB[1]), .SP(ATR_IN1_2__N_1498), .CK(Clk), 
            .Q(ATR_IN1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN1_i0_i1.GSR = "ENABLED";
    FD1P3AX ATR_IN1_i0_i2 (.D(OB[5]), .SP(ATR_IN1_2__N_1498), .CK(Clk), 
            .Q(ATR_IN1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN1_i0_i2.GSR = "ENABLED";
    FD1P3AX ATR_IN2_i0_i1 (.D(OB[1]), .SP(ATR_IN2_2__N_1499), .CK(Clk), 
            .Q(ATR_IN2[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN2_i0_i1.GSR = "ENABLED";
    LUT4 i1985_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[2]), .C(SDATA[4]), 
         .D(QS_adj_1905[3]), .Z(n2573)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1422[47:74])
    defparam i1985_3_lut_4_lut.init = 16'hf780;
    FD1P3AX ATR_IN2_i0_i2 (.D(OB[5]), .SP(ATR_IN2_2__N_1499), .CK(Clk), 
            .Q(ATR_IN2[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN2_i0_i2.GSR = "ENABLED";
    FD1P3AX ATR_IN3_i0_i1 (.D(OB[1]), .SP(ATR_IN3_2__N_1500), .CK(Clk), 
            .Q(ATR_IN3[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN3_i0_i1.GSR = "ENABLED";
    FD1P3AX ATR_IN3_i0_i2 (.D(OB[5]), .SP(ATR_IN3_2__N_1500), .CK(Clk), 
            .Q(ATR_IN3[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN3_i0_i2.GSR = "ENABLED";
    FD1P3AX ATR_IN4_i0_i1 (.D(OB[1]), .SP(ATR_IN4_2__N_1501), .CK(Clk), 
            .Q(ATR_IN4[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN4_i0_i1.GSR = "ENABLED";
    FD1P3AX ATR_IN4_i0_i2 (.D(OB[5]), .SP(ATR_IN4_2__N_1501), .CK(Clk), 
            .Q(ATR_IN4[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN4_i0_i2.GSR = "ENABLED";
    FD1P3AX ATR_IN5_i0_i1 (.D(OB[1]), .SP(ATR_IN5_2__N_1502), .CK(Clk), 
            .Q(ATR_IN5[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN5_i0_i1.GSR = "ENABLED";
    FD1P3AX ATR_IN5_i0_i2 (.D(OB[5]), .SP(ATR_IN5_2__N_1502), .CK(Clk), 
            .Q(ATR_IN5[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN5_i0_i2.GSR = "ENABLED";
    FD1P3AX ATR_IN6_i0_i1 (.D(OB[1]), .SP(ATR_IN6_2__N_1503), .CK(Clk), 
            .Q(ATR_IN6[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN6_i0_i1.GSR = "ENABLED";
    FD1P3AX ATR_IN6_i0_i2 (.D(OB[5]), .SP(ATR_IN6_2__N_1503), .CK(Clk), 
            .Q(ATR_IN6[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN6_i0_i2.GSR = "ENABLED";
    FD1P3AX ATR_IN7_i0_i1 (.D(OB[1]), .SP(ATR_IN7_2__N_1504), .CK(Clk), 
            .Q(ATR_IN7[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN7_i0_i1.GSR = "ENABLED";
    FD1P3AX ATR_IN7_i0_i2 (.D(OB[5]), .SP(ATR_IN7_2__N_1504), .CK(Clk), 
            .Q(ATR_IN7[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ATR_IN7_i0_i2.GSR = "ENABLED";
    FD1P3AX ZPOS_i1 (.D(ZPOS[0]), .SP(PCLK_c), .CK(Clk), .Q(ZPOS[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ZPOS_i1.GSR = "ENABLED";
    FD1P3AX ZPOS_i2 (.D(ZPOS[1]), .SP(nPCLK), .CK(Clk), .Q(ZPOS[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=400, LSE_RLINE=415 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam ZPOS_i2.GSR = "ENABLED";
    LUT4 i8447_2_lut (.A(Hnn[3]), .B(Hnn[4]), .Z(SEL_LATCH_7__N_1489)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i8447_2_lut.init = 16'h1111;
    LUT4 PD_FIFO_I_0_i1_2_lut (.A(PD_FIFO), .B(PD_LATCH[0]), .Z(SDATA[0])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1416[21:51])
    defparam PD_FIFO_I_0_i1_2_lut.init = 16'h8888;
    LUT4 i1895_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[5]), .C(SDATA[1]), 
         .D(QS_adj_1917[0]), .Z(n2483)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1428[47:74])
    defparam i1895_3_lut_4_lut.init = 16'hf780;
    LUT4 PCLK_I_0_355_2_lut (.A(PCLK_c), .B(SH7), .Z(COL1_7__N_1389)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1419[48:58])
    defparam PCLK_I_0_355_2_lut.init = 16'h8888;
    LUT4 PCLK_I_0_310_2_lut (.A(PCLK_c), .B(SH5), .Z(COL0_7__N_1373)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1418[48:58])
    defparam PCLK_I_0_310_2_lut.init = 16'h8888;
    FD1P3IX SH5_280 (.D(SH5_N_1522), .SP(nPCLK), .CD(n5847), .CK(Clk), 
            .Q(SH5));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam SH5_280.GSR = "ENABLED";
    LUT4 i1917_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[4]), .C(SDATA[5]), 
         .D(QS_adj_1903[4]), .Z(n2505)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1427[47:74])
    defparam i1917_3_lut_4_lut.init = 16'hf780;
    LUT4 i1907_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[5]), .C(SDATA[7]), 
         .D(QS_adj_1917[6]), .Z(n2495)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1428[47:74])
    defparam i1907_3_lut_4_lut.init = 16'hf780;
    LUT4 i1971_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[2]), .C(SDATA[4]), 
         .D(QS_adj_1904[3]), .Z(n2559)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1423[47:74])
    defparam i1971_3_lut_4_lut.init = 16'hf780;
    LUT4 i8535_3_lut_else_3_lut (.A(n6195), .B(n2946), .C(n8713), .D(n6197), 
         .Z(n9491)) /* synthesis lut_function=(!(A (B (C)+!B !((D)+!C)))) */ ;
    defparam i8535_3_lut_else_3_lut.init = 16'h7f5f;
    LUT4 i1891_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[5]), .C(SDATA[6]), 
         .D(QS_adj_1914[5]), .Z(n2479)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1429[47:74])
    defparam i1891_3_lut_4_lut.init = 16'hf780;
    LUT4 i1919_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[4]), .C(SDATA[6]), 
         .D(QS_adj_1903[5]), .Z(n2507)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1427[47:74])
    defparam i1919_3_lut_4_lut.init = 16'hf780;
    LUT4 i1977_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[2]), .C(SDATA[7]), 
         .D(QS_adj_1904[6]), .Z(n2565)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1423[47:74])
    defparam i1977_3_lut_4_lut.init = 16'hf780;
    LUT4 i1881_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[5]), .C(SDATA[1]), 
         .D(QS_adj_1914[0]), .Z(n2469)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1429[47:74])
    defparam i1881_3_lut_4_lut.init = 16'hf780;
    LUT4 i1889_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[5]), .C(SDATA[5]), 
         .D(QS_adj_1914[4]), .Z(n2477)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1429[47:74])
    defparam i1889_3_lut_4_lut.init = 16'hf780;
    LUT4 i1887_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[5]), .C(SDATA[4]), 
         .D(QS_adj_1914[3]), .Z(n2475)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1429[47:74])
    defparam i1887_3_lut_4_lut.init = 16'hf780;
    LUT4 i8461_3_lut (.A(CLIPOR), .B(n5904), .C(n2946), .Z(n2243)) /* synthesis lut_function=(!(A (B+(C)))) */ ;
    defparam i8461_3_lut.init = 16'h5757;
    LUT4 i1_2_lut_adj_488 (.A(COL0[7]), .B(EN[7]), .Z(n4_adj_1842)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1451[20] 1453[28])
    defparam i1_2_lut_adj_488.init = 16'h8888;
    LUT4 SEL_LATCH_7__I_370_2_lut (.A(Hnn[3]), .B(Hnn[4]), .Z(SEL_LATCH_7__N_1481)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1472[20:37])
    defparam SEL_LATCH_7__I_370_2_lut.init = 16'h4444;
    LUT4 Hnn_3__I_0_2_lut (.A(Hnn[3]), .B(Hnn[4]), .Z(SEL_LATCH_7__N_1485)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1471[21:37])
    defparam Hnn_3__I_0_2_lut.init = 16'h2222;
    LUT4 i1893_3_lut_4_lut (.A(COL1_7__N_1389), .B(SEL_LATCH[5]), .C(SDATA[7]), 
         .D(QS_adj_1914[6]), .Z(n2481)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1429[47:74])
    defparam i1893_3_lut_4_lut.init = 16'hf780;
    LUT4 ATR_IN0_2__I_373_2_lut_3_lut (.A(PCLK_c), .B(SH2), .C(SEL_LATCH[0]), 
         .Z(ATR_IN0_2__N_1496)) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1487[8:33])
    defparam ATR_IN0_2__I_373_2_lut_3_lut.init = 16'h8080;
    LUT4 i1_4_lut_adj_489 (.A(CLIPOR), .B(n5904), .C(n6166), .D(n2946), 
         .Z(n8713)) /* synthesis lut_function=(!((B+!((D)+!C))+!A)) */ ;
    defparam i1_4_lut_adj_489.init = 16'h2202;
    LUT4 i1989_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[2]), .C(SDATA[6]), 
         .D(QS_adj_1905[5]), .Z(n2577)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1422[47:74])
    defparam i1989_3_lut_4_lut.init = 16'hf780;
    LUT4 i1877_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[6]), .C(SDATA[6]), 
         .D(QS_adj_1924[5]), .Z(n2465)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1430[47:74])
    defparam i1877_3_lut_4_lut.init = 16'hf780;
    LUT4 i1867_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[6]), .C(SDATA[1]), 
         .D(QS_adj_1924[0]), .Z(n2455)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1430[47:74])
    defparam i1867_3_lut_4_lut.init = 16'hf780;
    LUT4 i2_4_lut_adj_490 (.A(COL0[5]), .B(EN[5]), .C(COL1[5]), .D(n8844), 
         .Z(n6195)) /* synthesis lut_function=(!(A ((D)+!B)+!A (((D)+!C)+!B))) */ ;
    defparam i2_4_lut_adj_490.init = 16'h00c8;
    LUT4 i1869_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[6]), .C(SDATA[2]), 
         .D(QS_adj_1924[1]), .Z(n2457)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1430[47:74])
    defparam i1869_3_lut_4_lut.init = 16'hf780;
    LUT4 i1983_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[2]), .C(SDATA[3]), 
         .D(QS_adj_1905[2]), .Z(n2571)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1422[47:74])
    defparam i1983_3_lut_4_lut.init = 16'hf780;
    LUT4 i1981_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[2]), .C(SDATA[2]), 
         .D(QS_adj_1905[1]), .Z(n2569)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1422[47:74])
    defparam i1981_3_lut_4_lut.init = 16'hf780;
    LUT4 i1871_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[6]), .C(SDATA[3]), 
         .D(QS_adj_1924[2]), .Z(n2459)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1430[47:74])
    defparam i1871_3_lut_4_lut.init = 16'hf780;
    LUT4 i8243_2_lut (.A(n2946), .B(n8828), .Z(n8844)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i8243_2_lut.init = 16'heeee;
    LUT4 i1979_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[2]), .C(SDATA[1]), 
         .D(QS_adj_1905[0]), .Z(n2567)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1422[47:74])
    defparam i1979_3_lut_4_lut.init = 16'hf780;
    LUT4 i8227_3_lut (.A(EN[3]), .B(COL0[3]), .C(COL1[3]), .Z(n8828)) /* synthesis lut_function=(A (B+(C))) */ ;
    defparam i8227_3_lut.init = 16'ha8a8;
    LUT4 i1873_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[6]), .C(SDATA[4]), 
         .D(QS_adj_1924[3]), .Z(n2461)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1430[47:74])
    defparam i1873_3_lut_4_lut.init = 16'hf780;
    LUT4 i1875_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[6]), .C(SDATA[5]), 
         .D(QS_adj_1924[4]), .Z(n2463)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1430[47:74])
    defparam i1875_3_lut_4_lut.init = 16'hf780;
    LUT4 i3946_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[2]), .C(SEL_LATCH[2]), 
         .D(SH7), .Z(n4557)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1422[31:45])
    defparam i3946_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i1_2_lut_adj_491 (.A(COL0[6]), .B(EN[6]), .Z(n2_adj_1732)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1451[20] 1453[28])
    defparam i1_2_lut_adj_491.init = 16'h8888;
    LUT4 i3959_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[5]), .C(SEL_LATCH[5]), 
         .D(SH7), .Z(n4570)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1428[31:45])
    defparam i3959_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i3957_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[5]), .C(SEL_LATCH[5]), 
         .D(SH5), .Z(n4568)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1428[31:45])
    defparam i3957_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    LUT4 i1879_3_lut_4_lut (.A(COL0_7__N_1373), .B(SEL_LATCH[6]), .C(SDATA[7]), 
         .D(QS_adj_1924[6]), .Z(n2467)) /* synthesis lut_function=(A (B (C)+!B (D))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1430[47:74])
    defparam i1879_3_lut_4_lut.init = 16'hf780;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_492 (.A(PCLK_c), .B(EN[5]), .C(SEL_LATCH[5]), 
         .D(SH7), .Z(Clk_enable_243)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1428[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_492.init = 16'ha888;
    LUT4 i1676_3_lut_4_lut (.A(n8828), .B(n2946), .C(n8713), .D(n6197), 
         .Z(n2253)) /* synthesis lut_function=(A (B+!(C+(D)))+!A (B+!(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1435[11:14])
    defparam i1676_3_lut_4_lut.init = 16'hccdf;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut_adj_493 (.A(PCLK_c), .B(EN[2]), .C(SEL_LATCH[2]), 
         .D(SH7), .Z(Clk_enable_201)) /* synthesis lut_function=(A (B+(C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1422[31:45])
    defparam i1_2_lut_3_lut_4_lut_4_lut_adj_493.init = 16'ha888;
    LUT4 i3944_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(EN[2]), .C(SEL_LATCH[2]), 
         .D(SH5), .Z(n4555)) /* synthesis lut_function=(!(((C (D))+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1422[31:45])
    defparam i3944_2_lut_3_lut_4_lut_4_lut.init = 16'h0888;
    FD1P3IX SH7_281 (.D(SH3_N_1518), .SP(nPCLK), .CD(n5847), .CK(Clk), 
            .Q(SH7));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam SH7_281.GSR = "ENABLED";
    FD1P3IX SH2_278 (.D(SH2_N_1509), .SP(nPCLK), .CD(n1650), .CK(Clk), 
            .Q(SH2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam SH2_278.GSR = "ENABLED";
    FD1P3IX SH3_279 (.D(SH3_N_1518), .SP(nPCLK), .CD(n1650), .CK(Clk), 
            .Q(SH3));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1456[8] 1495[26])
    defparam SH3_279.GSR = "ENABLED";
    PFUMX i8679 (.BLUT(n9491), .ALUT(n9492), .C0(n8828), .Z(n2255));
    FIFO_HPOSCNT EN_7__I_0_330 (.\EN[7] (EN[7]), .Clk(Clk), .nPCLK(nPCLK), 
            .ZH_FF(ZH_FF), .Clk_enable_31(Clk_enable_31), .Clk_enable_159(Clk_enable_159), 
            .n2356(n2356), .CNT1({CNT1}), .CNT_7__N_1559(CNT_7__N_1559), 
            .PCLK_c(PCLK_c), .n2899(n2899), .nVIS(nVIS), .n2637(n2637), 
            .n2639(n2639), .n2641(n2641), .n2643(n2643), .n2645(n2645), 
            .n2647(n2647), .n2649(n2649)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1413[14:103])
    FIFO_HPOSCNT_U14 EN_6__I_0_333 (.\EN[6] (EN[6]), .Clk(Clk), .nPCLK(nPCLK), 
            .ZH_FF(ZH_FF_adj_1831), .Clk_enable_30(Clk_enable_30), .PCLK_c(PCLK_c), 
            .n2900(n2900), .Clk_enable_152(Clk_enable_152), .n2364(n2364), 
            .CNT1({CNT1_adj_1912}), .CNT_7__N_1559(CNT_7__N_1559_adj_1832), 
            .nVIS(nVIS), .n2651(n2651), .n2653(n2653), .n2655(n2655), 
            .n2657(n2657), .n2659(n2659), .n2661(n2661), .n2663(n2663)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1412[14:103])
    FIFO_HPOSCNT_U15 EN_5__I_0_336 (.\EN[5] (EN[5]), .Clk(Clk), .nPCLK(nPCLK), 
            .ZH_FF(ZH_FF_adj_1808), .Clk_enable_29(Clk_enable_29), .PCLK_c(PCLK_c), 
            .n2909(n2909), .Clk_enable_145(Clk_enable_145), .n2375(n2375), 
            .CNT1({CNT1_adj_1916}), .CNT_7__N_1559(CNT_7__N_1559_adj_1809), 
            .nVIS(nVIS), .n2671(n2671), .n2673(n2673), .n2675(n2675), 
            .n2677(n2677), .n2679(n2679), .n2681(n2681), .n2683(n2683)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1411[14:103])
    FIFO_HPOSCNT_U16 EN_4__I_0_339 (.nVIS(nVIS), .Clk(Clk), .Clk_enable_28(Clk_enable_28), 
            .\EN[4] (EN[4]), .nPCLK(nPCLK), .PCLK_c(PCLK_c), .\SEL_LATCH[4] (SEL_LATCH[4]), 
            .SH3(SH3), .n2381(n2381), .CNT1({CNT1_adj_1918}), .n2910(n2910), 
            .n2685(n2685), .n2687(n2687), .n2689(n2689), .n2691(n2691), 
            .n2693(n2693), .n2695(n2695), .n2697(n2697)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1410[14:103])
    FIFO_HPOSCNT_U17 EN_3__I_0_342 (.ZH_FF(ZH_FF_adj_1804), .Clk(Clk), .Clk_enable_27(Clk_enable_27), 
            .\EN[3] (EN[3]), .nPCLK(nPCLK), .Clk_enable_131(Clk_enable_131), 
            .n2383(n2383), .CNT1({CNT1_adj_1907}), .CNT_7__N_1559(CNT_7__N_1559_adj_1805), 
            .nVIS(nVIS), .PCLK_c(PCLK_c), .n2911(n2911), .n2699(n2699), 
            .n2701(n2701), .n2703(n2703), .n2705(n2705), .n2707(n2707), 
            .n2709(n2709), .n2711(n2711)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1409[14:103])
    FIFO_HPOSCNT_U18 EN_2__I_0_345 (.ZH_FF(ZH_FF_adj_1801), .Clk(Clk), .Clk_enable_26(Clk_enable_26), 
            .\EN[2] (EN[2]), .nPCLK(nPCLK), .Clk_enable_124(Clk_enable_124), 
            .n2385(n2385), .CNT1({CNT1_adj_1908}), .CNT_7__N_1559(CNT_7__N_1559_adj_1803), 
            .nVIS(nVIS), .PCLK_c(PCLK_c), .n2912(n2912), .n2713(n2713), 
            .n2715(n2715), .n2717(n2717), .n2719(n2719), .n2721(n2721), 
            .n2723(n2723), .n2725(n2725)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1408[14:103])
    FIFO_HPOSCNT_U19 EN_1__I_0_348 (.ZH_FF(ZH_FF_adj_1797), .Clk(Clk), .Clk_enable_18(Clk_enable_18), 
            .\EN[1] (EN[1]), .nPCLK(nPCLK), .Clk_enable_117(Clk_enable_117), 
            .n2387(n2387), .CNT1({CNT1_adj_1911}), .CNT_7__N_1559(CNT_7__N_1559_adj_1798), 
            .nVIS(nVIS), .PCLK_c(PCLK_c), .n2913(n2913), .n2727(n2727), 
            .n2729(n2729), .n2731(n2731), .n2733(n2733), .n2735(n2735), 
            .n2737(n2737), .n2739(n2739)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1407[14:103])
    FIFO_HPOSCNT_U20 EN_0__I_0_351 (.PCLK_c(PCLK_c), .\ZPOS[2] (ZPOS[2]), 
            .n2910(n2910), .Clk_enable_28(Clk_enable_28), .n2911(n2911), 
            .Clk_enable_27(Clk_enable_27), .n2912(n2912), .Clk_enable_26(Clk_enable_26), 
            .n2913(n2913), .Clk_enable_18(Clk_enable_18), .n2909(n2909), 
            .Clk_enable_29(Clk_enable_29), .n2899(n2899), .Clk_enable_31(Clk_enable_31), 
            .n2900(n2900), .Clk_enable_30(Clk_enable_30), .ZH_FF(ZH_FF_adj_1772), 
            .Clk(Clk), .\EN[0] (EN[0]), .nPCLK(nPCLK), .CNT1({CNT1_adj_1922}), 
            .CNT_7__N_1559(CNT_7__N_1559_adj_1773), .Clk_enable_278(Clk_enable_278), 
            .n2304(n2304), .nVIS(nVIS), .n2399(n2399), .n2401(n2401), 
            .n2403(n2403), .n2405(n2405), .n2407(n2407), .n2409(n2409), 
            .n2411(n2411)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1406[14:103])
    SHIFTREG COL1_7__I_0 (.\QS[0] (QS_adj_1913[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_271(Clk_enable_271), .n4578(n4578), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS_adj_1913[1]), .\QS[2] (QS_adj_1913[2]), .\QS[3] (QS_adj_1913[3]), 
            .\QS[4] (QS_adj_1913[4]), .\QS[5] (QS_adj_1913[5]), .\QS[6] (QS_adj_1913[6]), 
            .\COL1[7] (COL1[7]), .n2413(n2413), .n2415(n2415), .n2417(n2417), 
            .n2419(n2419), .n2421(n2421), .n2423(n2423), .n2425(n2425)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1433[10:97])
    SHIFTREG_U21 COL1_6__I_0 (.\QS[0] (QS[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_257(Clk_enable_257), .n4574(n4574), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS[1]), .\QS[2] (QS[2]), .\QS[3] (QS[3]), .\QS[4] (QS[4]), 
            .\QS[5] (QS[5]), .\QS[6] (QS[6]), .\COL1[6] (COL1[6]), .n2441(n2441), 
            .n2443(n2443), .n2445(n2445), .n2447(n2447), .n2449(n2449), 
            .n2451(n2451), .n2453(n2453)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1431[10:97])
    SHIFTREG_U22 COL1_5__I_0 (.\QS[0] (QS_adj_1914[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_243(Clk_enable_243), .n4570(n4570), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS_adj_1914[1]), .\QS[2] (QS_adj_1914[2]), .\QS[3] (QS_adj_1914[3]), 
            .\QS[4] (QS_adj_1914[4]), .\QS[5] (QS_adj_1914[5]), .\QS[6] (QS_adj_1914[6]), 
            .\COL1[5] (COL1[5]), .n2469(n2469), .n2471(n2471), .n2473(n2473), 
            .n2475(n2475), .n2477(n2477), .n2479(n2479), .n2481(n2481)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1429[10:97])
    SHIFTREG_U23 COL1_4__I_0 (.\QS[0] (QS_adj_1903[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_229(Clk_enable_229), .n4565(n4565), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS_adj_1903[1]), .\QS[2] (QS_adj_1903[2]), .\QS[3] (QS_adj_1903[3]), 
            .\QS[4] (QS_adj_1903[4]), .\QS[5] (QS_adj_1903[5]), .\QS[6] (QS_adj_1903[6]), 
            .\COL1[4] (COL1[4]), .n2497(n2497), .n2499(n2499), .n2501(n2501), 
            .n2503(n2503), .n2505(n2505), .n2507(n2507), .n2509(n2509)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1427[10:97])
    SHIFTREG_U24 COL1_3__I_0 (.\QS[0] (QS_adj_1906[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_215(Clk_enable_215), .n4561(n4561), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS_adj_1906[1]), .\QS[2] (QS_adj_1906[2]), .\QS[3] (QS_adj_1906[3]), 
            .\QS[4] (QS_adj_1906[4]), .\QS[5] (QS_adj_1906[5]), .\QS[6] (QS_adj_1906[6]), 
            .\COL1[3] (COL1[3]), .n2525(n2525), .n2527(n2527), .n2529(n2529), 
            .n2531(n2531), .n2533(n2533), .n2535(n2535), .n2537(n2537)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1425[10:97])
    SHIFTREG_U25 COL1_2__I_0 (.\QS[0] (QS_adj_1904[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_201(Clk_enable_201), .n4557(n4557), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS_adj_1904[1]), .\QS[2] (QS_adj_1904[2]), .\QS[3] (QS_adj_1904[3]), 
            .\QS[4] (QS_adj_1904[4]), .\QS[5] (QS_adj_1904[5]), .\QS[6] (QS_adj_1904[6]), 
            .\COL1[2] (COL1[2]), .n2553(n2553), .n2555(n2555), .n2557(n2557), 
            .n2559(n2559), .n2561(n2561), .n2563(n2563), .n2565(n2565)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1423[10:97])
    SHIFTREG_U26 COL1_1__I_0 (.\QS[0] (QS_adj_1923[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_187(Clk_enable_187), .n4553(n4553), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS_adj_1923[1]), .\QS[2] (QS_adj_1923[2]), .\QS[3] (QS_adj_1923[3]), 
            .\QS[4] (QS_adj_1923[4]), .\QS[5] (QS_adj_1923[5]), .\QS[6] (QS_adj_1923[6]), 
            .\COL1[1] (COL1[1]), .n2581(n2581), .n2583(n2583), .n2585(n2585), 
            .n2587(n2587), .n2589(n2589), .n2591(n2591), .n2593(n2593)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1421[10:97])
    SHIFTREG_U27 COL1_0__I_0 (.\QS[0] (QS_adj_1920[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_173(Clk_enable_173), .n4549(n4549), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS_adj_1920[1]), .\QS[2] (QS_adj_1920[2]), .\QS[3] (QS_adj_1920[3]), 
            .\QS[4] (QS_adj_1920[4]), .\QS[5] (QS_adj_1920[5]), .\QS[6] (QS_adj_1920[6]), 
            .\COL1[0] (COL1[0]), .n2609(n2609), .n2611(n2611), .n2613(n2613), 
            .n2615(n2615), .n2617(n2617), .n2619(n2619), .n2621(n2621)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1419[10:97])
    SHIFTREG_U28 COL0_7__I_0_331 (.\QS[0] (QS_adj_1910[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_264(Clk_enable_264), .n4576(n4576), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS_adj_1910[1]), .\QS[2] (QS_adj_1910[2]), .\QS[3] (QS_adj_1910[3]), 
            .\QS[4] (QS_adj_1910[4]), .\QS[5] (QS_adj_1910[5]), .\QS[6] (QS_adj_1910[6]), 
            .\COL0[7] (COL0[7]), .n2427(n2427), .n2429(n2429), .n2431(n2431), 
            .n2433(n2433), .n2435(n2435), .n2437(n2437), .n2439(n2439)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1432[10:97])
    SHIFTREG_U29 COL0_6__I_0_334 (.\QS[0] (QS_adj_1924[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_250(Clk_enable_250), .n4572(n4572), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS_adj_1924[1]), .\QS[2] (QS_adj_1924[2]), .\QS[3] (QS_adj_1924[3]), 
            .\QS[4] (QS_adj_1924[4]), .\QS[5] (QS_adj_1924[5]), .\QS[6] (QS_adj_1924[6]), 
            .\COL0[6] (COL0[6]), .n2455(n2455), .n2457(n2457), .n2459(n2459), 
            .n2461(n2461), .n2463(n2463), .n2465(n2465), .n2467(n2467)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1430[10:97])
    SHIFTREG_U30 COL0_5__I_0_337 (.\QS[0] (QS_adj_1917[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_236(Clk_enable_236), .n4568(n4568), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS_adj_1917[1]), .\QS[2] (QS_adj_1917[2]), .\QS[3] (QS_adj_1917[3]), 
            .\QS[4] (QS_adj_1917[4]), .\QS[5] (QS_adj_1917[5]), .\QS[6] (QS_adj_1917[6]), 
            .\COL0[5] (COL0[5]), .n2483(n2483), .n2485(n2485), .n2487(n2487), 
            .n2489(n2489), .n2491(n2491), .n2493(n2493), .n2495(n2495)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1428[10:97])
    SHIFTREG_U31 COL0_4__I_0_340 (.\QS[0] (QS_adj_1915[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_222(Clk_enable_222), .n4563(n4563), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS_adj_1915[1]), .\QS[2] (QS_adj_1915[2]), .\QS[3] (QS_adj_1915[3]), 
            .\QS[4] (QS_adj_1915[4]), .\QS[5] (QS_adj_1915[5]), .\QS[6] (QS_adj_1915[6]), 
            .\COL0[4] (COL0[4]), .n2511(n2511), .n2513(n2513), .n2515(n2515), 
            .n2517(n2517), .n2519(n2519), .n2521(n2521), .n2523(n2523)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1426[10:97])
    SHIFTREG_U32 COL0_3__I_0_343 (.\QS[0] (QS_adj_1909[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_208(Clk_enable_208), .n4559(n4559), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS_adj_1909[1]), .\QS[2] (QS_adj_1909[2]), .\QS[3] (QS_adj_1909[3]), 
            .\QS[4] (QS_adj_1909[4]), .\QS[5] (QS_adj_1909[5]), .\QS[6] (QS_adj_1909[6]), 
            .\COL0[3] (COL0[3]), .n2539(n2539), .n2541(n2541), .n2543(n2543), 
            .n2545(n2545), .n2547(n2547), .n2549(n2549), .n2551(n2551)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1424[10:97])
    SHIFTREG_U33 COL0_2__I_0_346 (.\QS[0] (QS_adj_1905[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_194(Clk_enable_194), .n4555(n4555), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS_adj_1905[1]), .\QS[2] (QS_adj_1905[2]), .\QS[3] (QS_adj_1905[3]), 
            .\QS[4] (QS_adj_1905[4]), .\QS[5] (QS_adj_1905[5]), .\QS[6] (QS_adj_1905[6]), 
            .\COL0[2] (COL0[2]), .n2567(n2567), .n2569(n2569), .n2571(n2571), 
            .n2573(n2573), .n2575(n2575), .n2577(n2577), .n2579(n2579)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1422[10:97])
    SHIFTREG_U34 COL0_1__I_0_349 (.\QS[0] (QS_adj_1921[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_180(Clk_enable_180), .n4551(n4551), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS_adj_1921[1]), .\QS[2] (QS_adj_1921[2]), .\QS[3] (QS_adj_1921[3]), 
            .\QS[4] (QS_adj_1921[4]), .\QS[5] (QS_adj_1921[5]), .\QS[6] (QS_adj_1921[6]), 
            .\COL0[1] (COL0[1]), .n2595(n2595), .n2597(n2597), .n2599(n2599), 
            .n2601(n2601), .n2603(n2603), .n2605(n2605), .n2607(n2607)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1420[10:97])
    SHIFTREG_U35 COL0_0__I_0_352 (.\QS[0] (QS_adj_1919[0]), .Clk(Clk), .nPCLK(nPCLK), 
            .Clk_enable_166(Clk_enable_166), .n4547(n4547), .\SDATA[0] (SDATA[0]), 
            .\QS[1] (QS_adj_1919[1]), .\QS[2] (QS_adj_1919[2]), .\QS[3] (QS_adj_1919[3]), 
            .\QS[4] (QS_adj_1919[4]), .\QS[5] (QS_adj_1919[5]), .\QS[6] (QS_adj_1919[6]), 
            .\COL0[0] (COL0[0]), .n2623(n2623), .n2625(n2625), .n2627(n2627), 
            .n2629(n2629), .n2631(n2631), .n2633(n2633), .n2635(n2635)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1418[10:97])
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT
//

module FIFO_HPOSCNT (\EN[7] , Clk, nPCLK, ZH_FF, Clk_enable_31, Clk_enable_159, 
            n2356, CNT1, CNT_7__N_1559, PCLK_c, n2899, nVIS, n2637, 
            n2639, n2641, n2643, n2645, n2647, n2649) /* synthesis syn_module_defined=1 */ ;
    output \EN[7] ;
    input Clk;
    input nPCLK;
    output ZH_FF;
    input Clk_enable_31;
    input Clk_enable_159;
    input n2356;
    output [7:0]CNT1;
    input CNT_7__N_1559;
    input PCLK_c;
    output n2899;
    input nVIS;
    input n2637;
    input n2639;
    input n2641;
    input n2643;
    input n2645;
    input n2647;
    input n2649;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]CNT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1516[10:13])
    wire [7:0]CNT1_7__N_1560;
    
    wire n6022, n6028, EN_N_1572, ZH_FF_N_1578, n14, n10;
    
    LUT4 i1_2_lut (.A(CNT[1]), .B(CNT[0]), .Z(CNT1_7__N_1560[1])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i5426_2_lut (.A(CNT[1]), .B(CNT[0]), .Z(n6022)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i5426_2_lut.init = 16'heeee;
    LUT4 i1_2_lut_adj_461 (.A(CNT[5]), .B(n6028), .Z(CNT1_7__N_1560[5])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut_adj_461.init = 16'h9999;
    LUT4 i1_2_lut_3_lut (.A(CNT[5]), .B(n6028), .C(CNT[6]), .Z(CNT1_7__N_1560[6])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i1_3_lut_4_lut (.A(CNT[5]), .B(n6028), .C(CNT[6]), .D(CNT[7]), 
         .Z(CNT1_7__N_1560[7])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    LUT4 i1_2_lut_3_lut_4_lut (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .D(CNT[3]), 
         .Z(CNT1_7__N_1560[3])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hfe01;
    LUT4 i1_2_lut_3_lut_4_lut_adj_462 (.A(CNT[2]), .B(n6022), .C(CNT[4]), 
         .D(CNT[3]), .Z(CNT1_7__N_1560[4])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut_adj_462.init = 16'hf0e1;
    LUT4 i5432_2_lut_3_lut_4_lut (.A(CNT[2]), .B(n6022), .C(CNT[4]), .D(CNT[3]), 
         .Z(n6028)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i5432_2_lut_3_lut_4_lut.init = 16'hfffe;
    FD1P3AX EN_34 (.D(EN_N_1572), .SP(nPCLK), .CK(Clk), .Q(\EN[7] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam EN_34.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut_adj_463 (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .Z(CNT1_7__N_1560[2])) /* synthesis lut_function=(A (B+(C))+!A !(B+(C))) */ ;
    defparam i1_2_lut_3_lut_adj_463.init = 16'ha9a9;
    FD1P3AX ZH_FF_31 (.D(ZH_FF_N_1578), .SP(Clk_enable_31), .CK(Clk), 
            .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam ZH_FF_31.GSR = "ENABLED";
    FD1P3AX CNT_i0_i0 (.D(n2356), .SP(Clk_enable_159), .CK(Clk), .Q(CNT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i0.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i0 (.D(CNT1_7__N_1560[0]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i0.GSR = "ENABLED";
    LUT4 i8428_2_lut (.A(PCLK_c), .B(n2899), .Z(ZH_FF_N_1578)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1525[13:34])
    defparam i8428_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n2899)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 i8517_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1572)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1530[11:28])
    defparam i8517_2_lut.init = 16'h1111;
    LUT4 i1624_1_lut (.A(CNT[0]), .Z(CNT1_7__N_1560[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1528[39:67])
    defparam i1624_1_lut.init = 16'h5555;
    FD1P3AX CNT_i0_i1 (.D(n2637), .SP(Clk_enable_159), .CK(Clk), .Q(CNT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT_i0_i2 (.D(n2639), .SP(Clk_enable_159), .CK(Clk), .Q(CNT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT_i0_i3 (.D(n2641), .SP(Clk_enable_159), .CK(Clk), .Q(CNT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT_i0_i4 (.D(n2643), .SP(Clk_enable_159), .CK(Clk), .Q(CNT[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT_i0_i5 (.D(n2645), .SP(Clk_enable_159), .CK(Clk), .Q(CNT[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT_i0_i6 (.D(n2647), .SP(Clk_enable_159), .CK(Clk), .Q(CNT[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT_i0_i7 (.D(n2649), .SP(Clk_enable_159), .CK(Clk), .Q(CNT[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i7.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i1 (.D(CNT1_7__N_1560[1]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i2 (.D(CNT1_7__N_1560[2]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i3 (.D(CNT1_7__N_1560[3]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i4 (.D(CNT1_7__N_1560[4]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i5 (.D(CNT1_7__N_1560[5]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i6 (.D(CNT1_7__N_1560[6]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i7 (.D(CNT1_7__N_1560[7]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1413, LSE_RLINE=1413 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U14
//

module FIFO_HPOSCNT_U14 (\EN[6] , Clk, nPCLK, ZH_FF, Clk_enable_30, 
            PCLK_c, n2900, Clk_enable_152, n2364, CNT1, CNT_7__N_1559, 
            nVIS, n2651, n2653, n2655, n2657, n2659, n2661, n2663) /* synthesis syn_module_defined=1 */ ;
    output \EN[6] ;
    input Clk;
    input nPCLK;
    output ZH_FF;
    input Clk_enable_30;
    input PCLK_c;
    output n2900;
    input Clk_enable_152;
    input n2364;
    output [7:0]CNT1;
    input CNT_7__N_1559;
    input nVIS;
    input n2651;
    input n2653;
    input n2655;
    input n2657;
    input n2659;
    input n2661;
    input n2663;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]CNT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1516[10:13])
    
    wire n6016;
    wire [7:0]CNT1_7__N_1560;
    
    wire EN_N_1572, n6010, ZH_FF_N_1578, n14, n10;
    
    LUT4 i1_2_lut (.A(CNT[5]), .B(n6016), .Z(CNT1_7__N_1560[5])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i1_2_lut_3_lut_4_lut (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .D(CNT[3]), 
         .Z(CNT1_7__N_1560[3])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hfe01;
    FD1P3AX EN_34 (.D(EN_N_1572), .SP(nPCLK), .CK(Clk), .Q(\EN[6] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam EN_34.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut (.A(CNT[5]), .B(n6016), .C(CNT[6]), .Z(CNT1_7__N_1560[6])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'he1e1;
    LUT4 i1_3_lut_4_lut (.A(CNT[5]), .B(n6016), .C(CNT[6]), .D(CNT[7]), 
         .Z(CNT1_7__N_1560[7])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    LUT4 i1_2_lut_3_lut_adj_458 (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .Z(CNT1_7__N_1560[2])) /* synthesis lut_function=(A (B+(C))+!A !(B+(C))) */ ;
    defparam i1_2_lut_3_lut_adj_458.init = 16'ha9a9;
    LUT4 i5420_2_lut_3_lut_4_lut (.A(CNT[2]), .B(n6010), .C(CNT[4]), .D(CNT[3]), 
         .Z(n6016)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i5420_2_lut_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut_adj_459 (.A(CNT[2]), .B(n6010), .C(CNT[4]), 
         .D(CNT[3]), .Z(CNT1_7__N_1560[4])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut_adj_459.init = 16'hf0e1;
    FD1P3AX ZH_FF_31 (.D(ZH_FF_N_1578), .SP(Clk_enable_30), .CK(Clk), 
            .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam ZH_FF_31.GSR = "ENABLED";
    LUT4 i8431_2_lut (.A(PCLK_c), .B(n2900), .Z(ZH_FF_N_1578)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1525[13:34])
    defparam i8431_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n2900)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i7_4_lut.init = 16'hfffe;
    FD1P3AX CNT_i0_i0 (.D(n2364), .SP(Clk_enable_152), .CK(Clk), .Q(CNT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i0.GSR = "ENABLED";
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i2_2_lut.init = 16'heeee;
    FD1P3AX CNT1_i0_i0 (.D(CNT1_7__N_1560[0]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i0.GSR = "ENABLED";
    LUT4 i1_2_lut_adj_460 (.A(CNT[1]), .B(CNT[0]), .Z(CNT1_7__N_1560[1])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut_adj_460.init = 16'h9999;
    LUT4 i5414_2_lut (.A(CNT[1]), .B(CNT[0]), .Z(n6010)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i5414_2_lut.init = 16'heeee;
    LUT4 i8513_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1572)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1530[11:28])
    defparam i8513_2_lut.init = 16'h1111;
    LUT4 i1623_1_lut (.A(CNT[0]), .Z(CNT1_7__N_1560[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1528[39:67])
    defparam i1623_1_lut.init = 16'h5555;
    FD1P3AX CNT_i0_i1 (.D(n2651), .SP(Clk_enable_152), .CK(Clk), .Q(CNT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT_i0_i2 (.D(n2653), .SP(Clk_enable_152), .CK(Clk), .Q(CNT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT_i0_i3 (.D(n2655), .SP(Clk_enable_152), .CK(Clk), .Q(CNT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT_i0_i4 (.D(n2657), .SP(Clk_enable_152), .CK(Clk), .Q(CNT[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT_i0_i5 (.D(n2659), .SP(Clk_enable_152), .CK(Clk), .Q(CNT[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT_i0_i6 (.D(n2661), .SP(Clk_enable_152), .CK(Clk), .Q(CNT[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT_i0_i7 (.D(n2663), .SP(Clk_enable_152), .CK(Clk), .Q(CNT[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i7.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i1 (.D(CNT1_7__N_1560[1]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i2 (.D(CNT1_7__N_1560[2]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i3 (.D(CNT1_7__N_1560[3]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i4 (.D(CNT1_7__N_1560[4]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i5 (.D(CNT1_7__N_1560[5]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i6 (.D(CNT1_7__N_1560[6]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i7 (.D(CNT1_7__N_1560[7]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1412, LSE_RLINE=1412 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U15
//

module FIFO_HPOSCNT_U15 (\EN[5] , Clk, nPCLK, ZH_FF, Clk_enable_29, 
            PCLK_c, n2909, Clk_enable_145, n2375, CNT1, CNT_7__N_1559, 
            nVIS, n2671, n2673, n2675, n2677, n2679, n2681, n2683) /* synthesis syn_module_defined=1 */ ;
    output \EN[5] ;
    input Clk;
    input nPCLK;
    output ZH_FF;
    input Clk_enable_29;
    input PCLK_c;
    output n2909;
    input Clk_enable_145;
    input n2375;
    output [7:0]CNT1;
    input CNT_7__N_1559;
    input nVIS;
    input n2671;
    input n2673;
    input n2675;
    input n2677;
    input n2679;
    input n2681;
    input n2683;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]CNT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1516[10:13])
    wire [7:0]CNT1_7__N_1560;
    
    wire EN_N_1572, n5998, ZH_FF_N_1578, n14, n10, n6004;
    
    LUT4 i1_2_lut_3_lut_4_lut (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .D(CNT[3]), 
         .Z(CNT1_7__N_1560[3])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hfe01;
    FD1P3AX EN_34 (.D(EN_N_1572), .SP(nPCLK), .CK(Clk), .Q(\EN[5] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam EN_34.GSR = "ENABLED";
    LUT4 i1_2_lut (.A(CNT[1]), .B(CNT[0]), .Z(CNT1_7__N_1560[1])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i5402_2_lut (.A(CNT[1]), .B(CNT[0]), .Z(n5998)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i5402_2_lut.init = 16'heeee;
    FD1P3AX ZH_FF_31 (.D(ZH_FF_N_1578), .SP(Clk_enable_29), .CK(Clk), 
            .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam ZH_FF_31.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .Z(CNT1_7__N_1560[2])) /* synthesis lut_function=(A (B+(C))+!A !(B+(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'ha9a9;
    LUT4 i8419_2_lut (.A(PCLK_c), .B(n2909), .Z(ZH_FF_N_1578)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1525[13:34])
    defparam i8419_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n2909)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 i1_2_lut_3_lut_adj_455 (.A(CNT[5]), .B(n6004), .C(CNT[6]), .Z(CNT1_7__N_1560[6])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut_adj_455.init = 16'he1e1;
    LUT4 i1_3_lut_4_lut (.A(CNT[5]), .B(n6004), .C(CNT[6]), .D(CNT[7]), 
         .Z(CNT1_7__N_1560[7])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    LUT4 i5408_2_lut_3_lut_4_lut (.A(CNT[2]), .B(n5998), .C(CNT[4]), .D(CNT[3]), 
         .Z(n6004)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i5408_2_lut_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut_adj_456 (.A(CNT[2]), .B(n5998), .C(CNT[4]), 
         .D(CNT[3]), .Z(CNT1_7__N_1560[4])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut_adj_456.init = 16'hf0e1;
    LUT4 i1_2_lut_adj_457 (.A(CNT[5]), .B(n6004), .Z(CNT1_7__N_1560[5])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut_adj_457.init = 16'h9999;
    FD1P3AX CNT_i0_i0 (.D(n2375), .SP(Clk_enable_145), .CK(Clk), .Q(CNT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i0.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i0 (.D(CNT1_7__N_1560[0]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i0.GSR = "ENABLED";
    LUT4 i1622_1_lut (.A(CNT[0]), .Z(CNT1_7__N_1560[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1528[39:67])
    defparam i1622_1_lut.init = 16'h5555;
    LUT4 i8510_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1572)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1530[11:28])
    defparam i8510_2_lut.init = 16'h1111;
    FD1P3AX CNT_i0_i1 (.D(n2671), .SP(Clk_enable_145), .CK(Clk), .Q(CNT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT_i0_i2 (.D(n2673), .SP(Clk_enable_145), .CK(Clk), .Q(CNT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT_i0_i3 (.D(n2675), .SP(Clk_enable_145), .CK(Clk), .Q(CNT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT_i0_i4 (.D(n2677), .SP(Clk_enable_145), .CK(Clk), .Q(CNT[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT_i0_i5 (.D(n2679), .SP(Clk_enable_145), .CK(Clk), .Q(CNT[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT_i0_i6 (.D(n2681), .SP(Clk_enable_145), .CK(Clk), .Q(CNT[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT_i0_i7 (.D(n2683), .SP(Clk_enable_145), .CK(Clk), .Q(CNT[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i7.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i1 (.D(CNT1_7__N_1560[1]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i2 (.D(CNT1_7__N_1560[2]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i3 (.D(CNT1_7__N_1560[3]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i4 (.D(CNT1_7__N_1560[4]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i5 (.D(CNT1_7__N_1560[5]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i6 (.D(CNT1_7__N_1560[6]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i7 (.D(CNT1_7__N_1560[7]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1411, LSE_RLINE=1411 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U16
//

module FIFO_HPOSCNT_U16 (nVIS, Clk, Clk_enable_28, \EN[4] , nPCLK, 
            PCLK_c, \SEL_LATCH[4] , SH3, n2381, CNT1, n2910, n2685, 
            n2687, n2689, n2691, n2693, n2695, n2697) /* synthesis syn_module_defined=1 */ ;
    input nVIS;
    input Clk;
    input Clk_enable_28;
    output \EN[4] ;
    input nPCLK;
    input PCLK_c;
    input \SEL_LATCH[4] ;
    input SH3;
    input n2381;
    output [7:0]CNT1;
    output n2910;
    input n2685;
    input n2687;
    input n2689;
    input n2691;
    input n2693;
    input n2695;
    input n2697;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire ZH_FF, EN_N_1572;
    wire [7:0]CNT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1516[10:13])
    wire [7:0]CNT1_7__N_1560;
    
    wire n5986, n5992, ZH_FF_N_1578, CNT_7__N_1559, Clk_enable_138, 
        n14, n10;
    
    LUT4 i8507_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1572)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1530[11:28])
    defparam i8507_2_lut.init = 16'h1111;
    LUT4 i1_2_lut_3_lut_4_lut (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .D(CNT[3]), 
         .Z(CNT1_7__N_1560[3])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hfe01;
    LUT4 i1_2_lut (.A(CNT[1]), .B(CNT[0]), .Z(CNT1_7__N_1560[1])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i5390_2_lut (.A(CNT[1]), .B(CNT[0]), .Z(n5986)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i5390_2_lut.init = 16'heeee;
    LUT4 i1_2_lut_adj_452 (.A(CNT[5]), .B(n5992), .Z(CNT1_7__N_1560[5])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut_adj_452.init = 16'h9999;
    FD1P3AX ZH_FF_31 (.D(ZH_FF_N_1578), .SP(Clk_enable_28), .CK(Clk), 
            .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam ZH_FF_31.GSR = "ENABLED";
    FD1P3AX EN_34 (.D(EN_N_1572), .SP(nPCLK), .CK(Clk), .Q(\EN[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam EN_34.GSR = "ENABLED";
    LUT4 i8442_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(ZH_FF), .C(\SEL_LATCH[4] ), 
         .D(SH3), .Z(CNT_7__N_1559)) /* synthesis lut_function=(!(A (C (D))+!A (B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1520[16:33])
    defparam i8442_2_lut_3_lut_4_lut_4_lut.init = 16'h1bbb;
    LUT4 i1_2_lut_3_lut_4_lut_4_lut (.A(PCLK_c), .B(ZH_FF), .C(\SEL_LATCH[4] ), 
         .D(SH3), .Z(Clk_enable_138)) /* synthesis lut_function=(A (C (D))+!A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1520[16:33])
    defparam i1_2_lut_3_lut_4_lut_4_lut.init = 16'he444;
    LUT4 i1_2_lut_3_lut (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .Z(CNT1_7__N_1560[2])) /* synthesis lut_function=(A (B+(C))+!A !(B+(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'ha9a9;
    LUT4 i1_2_lut_3_lut_adj_453 (.A(CNT[5]), .B(n5992), .C(CNT[6]), .Z(CNT1_7__N_1560[6])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut_adj_453.init = 16'he1e1;
    LUT4 i1_3_lut_4_lut (.A(CNT[5]), .B(n5992), .C(CNT[6]), .D(CNT[7]), 
         .Z(CNT1_7__N_1560[7])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    FD1P3AX CNT_i0_i0 (.D(n2381), .SP(Clk_enable_138), .CK(Clk), .Q(CNT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i0.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i0 (.D(CNT1_7__N_1560[0]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i0.GSR = "ENABLED";
    LUT4 i5396_2_lut_3_lut_4_lut (.A(CNT[2]), .B(n5986), .C(CNT[4]), .D(CNT[3]), 
         .Z(n5992)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i5396_2_lut_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut_adj_454 (.A(CNT[2]), .B(n5986), .C(CNT[4]), 
         .D(CNT[3]), .Z(CNT1_7__N_1560[4])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut_adj_454.init = 16'hf0e1;
    LUT4 i1621_1_lut (.A(CNT[0]), .Z(CNT1_7__N_1560[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1528[39:67])
    defparam i1621_1_lut.init = 16'h5555;
    LUT4 i8400_2_lut (.A(PCLK_c), .B(n2910), .Z(ZH_FF_N_1578)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1525[13:34])
    defparam i8400_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n2910)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i2_2_lut.init = 16'heeee;
    FD1P3AX CNT_i0_i1 (.D(n2685), .SP(Clk_enable_138), .CK(Clk), .Q(CNT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT_i0_i2 (.D(n2687), .SP(Clk_enable_138), .CK(Clk), .Q(CNT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT_i0_i3 (.D(n2689), .SP(Clk_enable_138), .CK(Clk), .Q(CNT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT_i0_i4 (.D(n2691), .SP(Clk_enable_138), .CK(Clk), .Q(CNT[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT_i0_i5 (.D(n2693), .SP(Clk_enable_138), .CK(Clk), .Q(CNT[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT_i0_i6 (.D(n2695), .SP(Clk_enable_138), .CK(Clk), .Q(CNT[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT_i0_i7 (.D(n2697), .SP(Clk_enable_138), .CK(Clk), .Q(CNT[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i7.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i1 (.D(CNT1_7__N_1560[1]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i2 (.D(CNT1_7__N_1560[2]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i3 (.D(CNT1_7__N_1560[3]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i4 (.D(CNT1_7__N_1560[4]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i5 (.D(CNT1_7__N_1560[5]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i6 (.D(CNT1_7__N_1560[6]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i7 (.D(CNT1_7__N_1560[7]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1410, LSE_RLINE=1410 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U17
//

module FIFO_HPOSCNT_U17 (ZH_FF, Clk, Clk_enable_27, \EN[3] , nPCLK, 
            Clk_enable_131, n2383, CNT1, CNT_7__N_1559, nVIS, PCLK_c, 
            n2911, n2699, n2701, n2703, n2705, n2707, n2709, n2711) /* synthesis syn_module_defined=1 */ ;
    output ZH_FF;
    input Clk;
    input Clk_enable_27;
    output \EN[3] ;
    input nPCLK;
    input Clk_enable_131;
    input n2383;
    output [7:0]CNT1;
    input CNT_7__N_1559;
    input nVIS;
    input PCLK_c;
    output n2911;
    input n2699;
    input n2701;
    input n2703;
    input n2705;
    input n2707;
    input n2709;
    input n2711;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]CNT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1516[10:13])
    wire [7:0]CNT1_7__N_1560;
    
    wire n5974, n5980, ZH_FF_N_1578, EN_N_1572, n14, n10;
    
    LUT4 i1_2_lut_3_lut_4_lut (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .D(CNT[3]), 
         .Z(CNT1_7__N_1560[3])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hfe01;
    LUT4 i1_2_lut (.A(CNT[1]), .B(CNT[0]), .Z(CNT1_7__N_1560[1])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i5378_2_lut (.A(CNT[1]), .B(CNT[0]), .Z(n5974)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i5378_2_lut.init = 16'heeee;
    LUT4 i1_2_lut_adj_449 (.A(CNT[5]), .B(n5980), .Z(CNT1_7__N_1560[5])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut_adj_449.init = 16'h9999;
    FD1P3AX ZH_FF_31 (.D(ZH_FF_N_1578), .SP(Clk_enable_27), .CK(Clk), 
            .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam ZH_FF_31.GSR = "ENABLED";
    FD1P3AX EN_34 (.D(EN_N_1572), .SP(nPCLK), .CK(Clk), .Q(\EN[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam EN_34.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .Z(CNT1_7__N_1560[2])) /* synthesis lut_function=(A (B+(C))+!A !(B+(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'ha9a9;
    FD1P3AX CNT_i0_i0 (.D(n2383), .SP(Clk_enable_131), .CK(Clk), .Q(CNT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i0.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i0 (.D(CNT1_7__N_1560[0]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i0.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut_adj_450 (.A(CNT[5]), .B(n5980), .C(CNT[6]), .Z(CNT1_7__N_1560[6])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut_adj_450.init = 16'he1e1;
    LUT4 i1_3_lut_4_lut (.A(CNT[5]), .B(n5980), .C(CNT[6]), .D(CNT[7]), 
         .Z(CNT1_7__N_1560[7])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    LUT4 i5384_2_lut_3_lut_4_lut (.A(CNT[2]), .B(n5974), .C(CNT[4]), .D(CNT[3]), 
         .Z(n5980)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i5384_2_lut_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut_adj_451 (.A(CNT[2]), .B(n5974), .C(CNT[4]), 
         .D(CNT[3]), .Z(CNT1_7__N_1560[4])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut_adj_451.init = 16'hf0e1;
    LUT4 i8501_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1572)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1530[11:28])
    defparam i8501_2_lut.init = 16'h1111;
    LUT4 i1620_1_lut (.A(CNT[0]), .Z(CNT1_7__N_1560[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1528[39:67])
    defparam i1620_1_lut.init = 16'h5555;
    LUT4 i8385_2_lut (.A(PCLK_c), .B(n2911), .Z(ZH_FF_N_1578)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1525[13:34])
    defparam i8385_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n2911)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i2_2_lut.init = 16'heeee;
    FD1P3AX CNT_i0_i1 (.D(n2699), .SP(Clk_enable_131), .CK(Clk), .Q(CNT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT_i0_i2 (.D(n2701), .SP(Clk_enable_131), .CK(Clk), .Q(CNT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT_i0_i3 (.D(n2703), .SP(Clk_enable_131), .CK(Clk), .Q(CNT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT_i0_i4 (.D(n2705), .SP(Clk_enable_131), .CK(Clk), .Q(CNT[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT_i0_i5 (.D(n2707), .SP(Clk_enable_131), .CK(Clk), .Q(CNT[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT_i0_i6 (.D(n2709), .SP(Clk_enable_131), .CK(Clk), .Q(CNT[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT_i0_i7 (.D(n2711), .SP(Clk_enable_131), .CK(Clk), .Q(CNT[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i7.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i1 (.D(CNT1_7__N_1560[1]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i2 (.D(CNT1_7__N_1560[2]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i3 (.D(CNT1_7__N_1560[3]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i4 (.D(CNT1_7__N_1560[4]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i5 (.D(CNT1_7__N_1560[5]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i6 (.D(CNT1_7__N_1560[6]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i7 (.D(CNT1_7__N_1560[7]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1409, LSE_RLINE=1409 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U18
//

module FIFO_HPOSCNT_U18 (ZH_FF, Clk, Clk_enable_26, \EN[2] , nPCLK, 
            Clk_enable_124, n2385, CNT1, CNT_7__N_1559, nVIS, PCLK_c, 
            n2912, n2713, n2715, n2717, n2719, n2721, n2723, n2725) /* synthesis syn_module_defined=1 */ ;
    output ZH_FF;
    input Clk;
    input Clk_enable_26;
    output \EN[2] ;
    input nPCLK;
    input Clk_enable_124;
    input n2385;
    output [7:0]CNT1;
    input CNT_7__N_1559;
    input nVIS;
    input PCLK_c;
    output n2912;
    input n2713;
    input n2715;
    input n2717;
    input n2719;
    input n2721;
    input n2723;
    input n2725;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]CNT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1516[10:13])
    wire [7:0]CNT1_7__N_1560;
    
    wire n5962, n5968, ZH_FF_N_1578, EN_N_1572, n14, n10;
    
    LUT4 i1_2_lut (.A(CNT[1]), .B(CNT[0]), .Z(CNT1_7__N_1560[1])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i5366_2_lut (.A(CNT[1]), .B(CNT[0]), .Z(n5962)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i5366_2_lut.init = 16'heeee;
    LUT4 i1_2_lut_adj_446 (.A(CNT[5]), .B(n5968), .Z(CNT1_7__N_1560[5])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut_adj_446.init = 16'h9999;
    LUT4 i1_2_lut_3_lut_4_lut (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .D(CNT[3]), 
         .Z(CNT1_7__N_1560[3])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hfe01;
    FD1P3AX ZH_FF_31 (.D(ZH_FF_N_1578), .SP(Clk_enable_26), .CK(Clk), 
            .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam ZH_FF_31.GSR = "ENABLED";
    FD1P3AX EN_34 (.D(EN_N_1572), .SP(nPCLK), .CK(Clk), .Q(\EN[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam EN_34.GSR = "ENABLED";
    FD1P3AX CNT_i0_i0 (.D(n2385), .SP(Clk_enable_124), .CK(Clk), .Q(CNT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i0.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i0 (.D(CNT1_7__N_1560[0]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i0.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .Z(CNT1_7__N_1560[2])) /* synthesis lut_function=(A (B+(C))+!A !(B+(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'ha9a9;
    LUT4 i1619_1_lut (.A(CNT[0]), .Z(CNT1_7__N_1560[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1528[39:67])
    defparam i1619_1_lut.init = 16'h5555;
    LUT4 i1_2_lut_3_lut_adj_447 (.A(CNT[5]), .B(n5968), .C(CNT[6]), .Z(CNT1_7__N_1560[6])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut_adj_447.init = 16'he1e1;
    LUT4 i1_3_lut_4_lut (.A(CNT[5]), .B(n5968), .C(CNT[6]), .D(CNT[7]), 
         .Z(CNT1_7__N_1560[7])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    LUT4 i5372_2_lut_3_lut_4_lut (.A(CNT[2]), .B(n5962), .C(CNT[4]), .D(CNT[3]), 
         .Z(n5968)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i5372_2_lut_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_3_lut_4_lut_adj_448 (.A(CNT[2]), .B(n5962), .C(CNT[4]), 
         .D(CNT[3]), .Z(CNT1_7__N_1560[4])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut_adj_448.init = 16'hf0e1;
    LUT4 i8498_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1572)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1530[11:28])
    defparam i8498_2_lut.init = 16'h1111;
    LUT4 i8377_2_lut (.A(PCLK_c), .B(n2912), .Z(ZH_FF_N_1578)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1525[13:34])
    defparam i8377_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n2912)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i2_2_lut.init = 16'heeee;
    FD1P3AX CNT_i0_i1 (.D(n2713), .SP(Clk_enable_124), .CK(Clk), .Q(CNT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT_i0_i2 (.D(n2715), .SP(Clk_enable_124), .CK(Clk), .Q(CNT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT_i0_i3 (.D(n2717), .SP(Clk_enable_124), .CK(Clk), .Q(CNT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT_i0_i4 (.D(n2719), .SP(Clk_enable_124), .CK(Clk), .Q(CNT[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT_i0_i5 (.D(n2721), .SP(Clk_enable_124), .CK(Clk), .Q(CNT[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT_i0_i6 (.D(n2723), .SP(Clk_enable_124), .CK(Clk), .Q(CNT[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT_i0_i7 (.D(n2725), .SP(Clk_enable_124), .CK(Clk), .Q(CNT[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i7.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i1 (.D(CNT1_7__N_1560[1]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i2 (.D(CNT1_7__N_1560[2]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i3 (.D(CNT1_7__N_1560[3]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i4 (.D(CNT1_7__N_1560[4]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i5 (.D(CNT1_7__N_1560[5]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i6 (.D(CNT1_7__N_1560[6]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i7 (.D(CNT1_7__N_1560[7]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1408, LSE_RLINE=1408 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U19
//

module FIFO_HPOSCNT_U19 (ZH_FF, Clk, Clk_enable_18, \EN[1] , nPCLK, 
            Clk_enable_117, n2387, CNT1, CNT_7__N_1559, nVIS, PCLK_c, 
            n2913, n2727, n2729, n2731, n2733, n2735, n2737, n2739) /* synthesis syn_module_defined=1 */ ;
    output ZH_FF;
    input Clk;
    input Clk_enable_18;
    output \EN[1] ;
    input nPCLK;
    input Clk_enable_117;
    input n2387;
    output [7:0]CNT1;
    input CNT_7__N_1559;
    input nVIS;
    input PCLK_c;
    output n2913;
    input n2727;
    input n2729;
    input n2731;
    input n2733;
    input n2735;
    input n2737;
    input n2739;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]CNT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1516[10:13])
    wire [7:0]CNT1_7__N_1560;
    
    wire n5950, n5956, ZH_FF_N_1578, EN_N_1572, n14, n10;
    
    LUT4 i1_2_lut (.A(CNT[1]), .B(CNT[0]), .Z(CNT1_7__N_1560[1])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i5354_2_lut (.A(CNT[1]), .B(CNT[0]), .Z(n5950)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i5354_2_lut.init = 16'heeee;
    LUT4 i1_2_lut_adj_443 (.A(CNT[5]), .B(n5956), .Z(CNT1_7__N_1560[5])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut_adj_443.init = 16'h9999;
    FD1P3AX ZH_FF_31 (.D(ZH_FF_N_1578), .SP(Clk_enable_18), .CK(Clk), 
            .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam ZH_FF_31.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .D(CNT[3]), 
         .Z(CNT1_7__N_1560[3])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hfe01;
    LUT4 i1618_1_lut (.A(CNT[0]), .Z(CNT1_7__N_1560[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1528[39:67])
    defparam i1618_1_lut.init = 16'h5555;
    FD1P3AX EN_34 (.D(EN_N_1572), .SP(nPCLK), .CK(Clk), .Q(\EN[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam EN_34.GSR = "ENABLED";
    FD1P3AX CNT_i0_i0 (.D(n2387), .SP(Clk_enable_117), .CK(Clk), .Q(CNT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i0.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i0 (.D(CNT1_7__N_1560[0]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i0.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .Z(CNT1_7__N_1560[2])) /* synthesis lut_function=(A (B+(C))+!A !(B+(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'ha9a9;
    LUT4 i1_2_lut_3_lut_adj_444 (.A(CNT[5]), .B(n5956), .C(CNT[6]), .Z(CNT1_7__N_1560[6])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut_adj_444.init = 16'he1e1;
    LUT4 i1_3_lut_4_lut (.A(CNT[5]), .B(n5956), .C(CNT[6]), .D(CNT[7]), 
         .Z(CNT1_7__N_1560[7])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    LUT4 i8494_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1572)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1530[11:28])
    defparam i8494_2_lut.init = 16'h1111;
    LUT4 i1_2_lut_3_lut_4_lut_adj_445 (.A(CNT[2]), .B(n5950), .C(CNT[4]), 
         .D(CNT[3]), .Z(CNT1_7__N_1560[4])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut_adj_445.init = 16'hf0e1;
    LUT4 i5360_2_lut_3_lut_4_lut (.A(CNT[2]), .B(n5950), .C(CNT[4]), .D(CNT[3]), 
         .Z(n5956)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i5360_2_lut_3_lut_4_lut.init = 16'hfffe;
    LUT4 i8480_2_lut (.A(PCLK_c), .B(n2913), .Z(ZH_FF_N_1578)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1525[13:34])
    defparam i8480_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n2913)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i2_2_lut.init = 16'heeee;
    FD1P3AX CNT_i0_i1 (.D(n2727), .SP(Clk_enable_117), .CK(Clk), .Q(CNT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT_i0_i2 (.D(n2729), .SP(Clk_enable_117), .CK(Clk), .Q(CNT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT_i0_i3 (.D(n2731), .SP(Clk_enable_117), .CK(Clk), .Q(CNT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT_i0_i4 (.D(n2733), .SP(Clk_enable_117), .CK(Clk), .Q(CNT[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT_i0_i5 (.D(n2735), .SP(Clk_enable_117), .CK(Clk), .Q(CNT[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT_i0_i6 (.D(n2737), .SP(Clk_enable_117), .CK(Clk), .Q(CNT[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT_i0_i7 (.D(n2739), .SP(Clk_enable_117), .CK(Clk), .Q(CNT[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i7.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i1 (.D(CNT1_7__N_1560[1]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i2 (.D(CNT1_7__N_1560[2]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i3 (.D(CNT1_7__N_1560[3]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i4 (.D(CNT1_7__N_1560[4]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i5 (.D(CNT1_7__N_1560[5]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i6 (.D(CNT1_7__N_1560[6]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i7 (.D(CNT1_7__N_1560[7]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1407, LSE_RLINE=1407 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module FIFO_HPOSCNT_U20
//

module FIFO_HPOSCNT_U20 (PCLK_c, \ZPOS[2] , n2910, Clk_enable_28, n2911, 
            Clk_enable_27, n2912, Clk_enable_26, n2913, Clk_enable_18, 
            n2909, Clk_enable_29, n2899, Clk_enable_31, n2900, Clk_enable_30, 
            ZH_FF, Clk, \EN[0] , nPCLK, CNT1, CNT_7__N_1559, Clk_enable_278, 
            n2304, nVIS, n2399, n2401, n2403, n2405, n2407, n2409, 
            n2411) /* synthesis syn_module_defined=1 */ ;
    input PCLK_c;
    input \ZPOS[2] ;
    input n2910;
    output Clk_enable_28;
    input n2911;
    output Clk_enable_27;
    input n2912;
    output Clk_enable_26;
    input n2913;
    output Clk_enable_18;
    input n2909;
    output Clk_enable_29;
    input n2899;
    output Clk_enable_31;
    input n2900;
    output Clk_enable_30;
    output ZH_FF;
    input Clk;
    output \EN[0] ;
    input nPCLK;
    output [7:0]CNT1;
    input CNT_7__N_1559;
    input Clk_enable_278;
    input n2304;
    input nVIS;
    input n2399;
    input n2401;
    input n2403;
    input n2405;
    input n2407;
    input n2409;
    input n2411;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]CNT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1516[10:13])
    wire [7:0]Cout_6__N_1543;
    wire [7:0]CNT1_7__N_1560;
    
    wire n5936, n5942, n2914, Clk_enable_17, ZH_FF_N_1578, EN_N_1572, 
        n14, n10;
    
    LUT4 CNT_7__I_0_35_i1_1_lut (.A(CNT[0]), .Z(Cout_6__N_1543[0])) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1522[20:29])
    defparam CNT_7__I_0_35_i1_1_lut.init = 16'h5555;
    LUT4 i1_3_lut_4_lut_3_lut (.A(PCLK_c), .B(\ZPOS[2] ), .C(n2910), .Z(Clk_enable_28)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut.init = 16'h8a8a;
    LUT4 i1_3_lut_4_lut_3_lut_adj_433 (.A(PCLK_c), .B(\ZPOS[2] ), .C(n2911), 
         .Z(Clk_enable_27)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut_adj_433.init = 16'h8a8a;
    LUT4 i1_2_lut (.A(CNT[1]), .B(CNT[0]), .Z(CNT1_7__N_1560[1])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut.init = 16'h9999;
    LUT4 i5340_2_lut (.A(CNT[1]), .B(CNT[0]), .Z(n5936)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i5340_2_lut.init = 16'heeee;
    LUT4 i1_2_lut_adj_434 (.A(CNT[5]), .B(n5942), .Z(CNT1_7__N_1560[5])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut_adj_434.init = 16'h9999;
    LUT4 i1_3_lut_4_lut_3_lut_adj_435 (.A(PCLK_c), .B(\ZPOS[2] ), .C(n2912), 
         .Z(Clk_enable_26)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut_adj_435.init = 16'h8a8a;
    LUT4 i1_3_lut_4_lut_3_lut_adj_436 (.A(PCLK_c), .B(\ZPOS[2] ), .C(n2913), 
         .Z(Clk_enable_18)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut_adj_436.init = 16'h8a8a;
    LUT4 i1_3_lut_4_lut_3_lut_adj_437 (.A(PCLK_c), .B(\ZPOS[2] ), .C(n2914), 
         .Z(Clk_enable_17)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut_adj_437.init = 16'h8a8a;
    LUT4 i1_3_lut_4_lut_3_lut_adj_438 (.A(PCLK_c), .B(\ZPOS[2] ), .C(n2909), 
         .Z(Clk_enable_29)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut_adj_438.init = 16'h8a8a;
    LUT4 i1_3_lut_4_lut_3_lut_adj_439 (.A(PCLK_c), .B(\ZPOS[2] ), .C(n2899), 
         .Z(Clk_enable_31)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut_adj_439.init = 16'h8a8a;
    LUT4 i1_3_lut_4_lut_3_lut_adj_440 (.A(PCLK_c), .B(\ZPOS[2] ), .C(n2900), 
         .Z(Clk_enable_30)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut_4_lut_3_lut_adj_440.init = 16'h8a8a;
    FD1P3AX ZH_FF_31 (.D(ZH_FF_N_1578), .SP(Clk_enable_17), .CK(Clk), 
            .Q(ZH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam ZH_FF_31.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut_4_lut (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .D(CNT[3]), 
         .Z(CNT1_7__N_1560[3])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hfe01;
    FD1P3AX EN_34 (.D(EN_N_1572), .SP(nPCLK), .CK(Clk), .Q(\EN[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam EN_34.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i0 (.D(Cout_6__N_1543[0]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i0.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut (.A(CNT[2]), .B(CNT[1]), .C(CNT[0]), .Z(CNT1_7__N_1560[2])) /* synthesis lut_function=(A (B+(C))+!A !(B+(C))) */ ;
    defparam i1_2_lut_3_lut.init = 16'ha9a9;
    FD1P3AX CNT_i0_i0 (.D(n2304), .SP(Clk_enable_278), .CK(Clk), .Q(CNT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i0.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut_adj_441 (.A(CNT[5]), .B(n5942), .C(CNT[6]), .Z(CNT1_7__N_1560[6])) /* synthesis lut_function=(A (C)+!A (B (C)+!B !(C))) */ ;
    defparam i1_2_lut_3_lut_adj_441.init = 16'he1e1;
    LUT4 i1_3_lut_4_lut (.A(CNT[5]), .B(n5942), .C(CNT[6]), .D(CNT[7]), 
         .Z(CNT1_7__N_1560[7])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfe01;
    LUT4 i1_2_lut_3_lut_4_lut_adj_442 (.A(CNT[2]), .B(n5936), .C(CNT[4]), 
         .D(CNT[3]), .Z(CNT1_7__N_1560[4])) /* synthesis lut_function=(A (C)+!A (B (C)+!B (C (D)+!C !(D)))) */ ;
    defparam i1_2_lut_3_lut_4_lut_adj_442.init = 16'hf0e1;
    LUT4 i5346_2_lut_3_lut_4_lut (.A(CNT[2]), .B(n5936), .C(CNT[4]), .D(CNT[3]), 
         .Z(n5942)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i5346_2_lut_3_lut_4_lut.init = 16'hfffe;
    LUT4 i8477_2_lut (.A(PCLK_c), .B(n2914), .Z(ZH_FF_N_1578)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1525[13:34])
    defparam i8477_2_lut.init = 16'hdddd;
    LUT4 i7_4_lut (.A(CNT[0]), .B(n14), .C(n10), .D(CNT[6]), .Z(n2914)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i7_4_lut.init = 16'hfffe;
    LUT4 i6_4_lut (.A(CNT[3]), .B(CNT[1]), .C(CNT[5]), .D(CNT[7]), .Z(n14)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i2_2_lut (.A(CNT[2]), .B(CNT[4]), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1526[30:44])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 i8489_2_lut (.A(nVIS), .B(ZH_FF), .Z(EN_N_1572)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1530[11:28])
    defparam i8489_2_lut.init = 16'h1111;
    FD1P3AX CNT1_i0_i1 (.D(CNT1_7__N_1560[1]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i2 (.D(CNT1_7__N_1560[2]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i3 (.D(CNT1_7__N_1560[3]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i4 (.D(CNT1_7__N_1560[4]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i5 (.D(CNT1_7__N_1560[5]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i6 (.D(CNT1_7__N_1560[6]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i7 (.D(CNT1_7__N_1560[7]), .SP(CNT_7__N_1559), .CK(Clk), 
            .Q(CNT1[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT1_i0_i7.GSR = "ENABLED";
    FD1P3AX CNT_i0_i1 (.D(n2399), .SP(Clk_enable_278), .CK(Clk), .Q(CNT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i1.GSR = "ENABLED";
    FD1P3AX CNT_i0_i2 (.D(n2401), .SP(Clk_enable_278), .CK(Clk), .Q(CNT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT_i0_i3 (.D(n2403), .SP(Clk_enable_278), .CK(Clk), .Q(CNT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT_i0_i4 (.D(n2405), .SP(Clk_enable_278), .CK(Clk), .Q(CNT[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT_i0_i5 (.D(n2407), .SP(Clk_enable_278), .CK(Clk), .Q(CNT[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT_i0_i6 (.D(n2409), .SP(Clk_enable_278), .CK(Clk), .Q(CNT[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT_i0_i7 (.D(n2411), .SP(Clk_enable_278), .CK(Clk), .Q(CNT[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=103, LSE_LLINE=1406, LSE_RLINE=1406 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1524[8] 1532[27])
    defparam CNT_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG
//

module SHIFTREG (\QS[0] , Clk, nPCLK, Clk_enable_271, n4578, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL1[7] , n2413, n2415, n2417, n2419, n2421, n2423, 
            n2425) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_271;
    input n4578;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL1[7] ;
    input n2413;
    input n2415;
    input n2417;
    input n2419;
    input n2421;
    input n2423;
    input n2425;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_271), .CD(n4578), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2413), .SP(Clk_enable_271), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2415), .SP(Clk_enable_271), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2417), .SP(Clk_enable_271), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2419), .SP(Clk_enable_271), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2421), .SP(Clk_enable_271), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2423), .SP(Clk_enable_271), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2425), .SP(Clk_enable_271), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1433, LSE_RLINE=1433 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U21
//

module SHIFTREG_U21 (\QS[0] , Clk, nPCLK, Clk_enable_257, n4574, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL1[6] , n2441, n2443, n2445, n2447, n2449, n2451, 
            n2453) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_257;
    input n4574;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL1[6] ;
    input n2441;
    input n2443;
    input n2445;
    input n2447;
    input n2449;
    input n2451;
    input n2453;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_257), .CD(n4574), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2441), .SP(Clk_enable_257), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2443), .SP(Clk_enable_257), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2445), .SP(Clk_enable_257), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2447), .SP(Clk_enable_257), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2449), .SP(Clk_enable_257), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2451), .SP(Clk_enable_257), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2453), .SP(Clk_enable_257), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1431, LSE_RLINE=1431 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U22
//

module SHIFTREG_U22 (\QS[0] , Clk, nPCLK, Clk_enable_243, n4570, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL1[5] , n2469, n2471, n2473, n2475, n2477, n2479, 
            n2481) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_243;
    input n4570;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL1[5] ;
    input n2469;
    input n2471;
    input n2473;
    input n2475;
    input n2477;
    input n2479;
    input n2481;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_243), .CD(n4570), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2469), .SP(Clk_enable_243), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2471), .SP(Clk_enable_243), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2473), .SP(Clk_enable_243), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2475), .SP(Clk_enable_243), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2477), .SP(Clk_enable_243), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2479), .SP(Clk_enable_243), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2481), .SP(Clk_enable_243), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1429, LSE_RLINE=1429 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U23
//

module SHIFTREG_U23 (\QS[0] , Clk, nPCLK, Clk_enable_229, n4565, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL1[4] , n2497, n2499, n2501, n2503, n2505, n2507, 
            n2509) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_229;
    input n4565;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL1[4] ;
    input n2497;
    input n2499;
    input n2501;
    input n2503;
    input n2505;
    input n2507;
    input n2509;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_229), .CD(n4565), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2497), .SP(Clk_enable_229), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2499), .SP(Clk_enable_229), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2501), .SP(Clk_enable_229), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2503), .SP(Clk_enable_229), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2505), .SP(Clk_enable_229), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2507), .SP(Clk_enable_229), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2509), .SP(Clk_enable_229), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1427, LSE_RLINE=1427 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U24
//

module SHIFTREG_U24 (\QS[0] , Clk, nPCLK, Clk_enable_215, n4561, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL1[3] , n2525, n2527, n2529, n2531, n2533, n2535, 
            n2537) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_215;
    input n4561;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL1[3] ;
    input n2525;
    input n2527;
    input n2529;
    input n2531;
    input n2533;
    input n2535;
    input n2537;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_215), .CD(n4561), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2525), .SP(Clk_enable_215), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2527), .SP(Clk_enable_215), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2529), .SP(Clk_enable_215), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2531), .SP(Clk_enable_215), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2533), .SP(Clk_enable_215), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2535), .SP(Clk_enable_215), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2537), .SP(Clk_enable_215), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1425, LSE_RLINE=1425 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U25
//

module SHIFTREG_U25 (\QS[0] , Clk, nPCLK, Clk_enable_201, n4557, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL1[2] , n2553, n2555, n2557, n2559, n2561, n2563, 
            n2565) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_201;
    input n4557;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL1[2] ;
    input n2553;
    input n2555;
    input n2557;
    input n2559;
    input n2561;
    input n2563;
    input n2565;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_201), .CD(n4557), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2553), .SP(Clk_enable_201), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2555), .SP(Clk_enable_201), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2557), .SP(Clk_enable_201), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2559), .SP(Clk_enable_201), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2561), .SP(Clk_enable_201), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2563), .SP(Clk_enable_201), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2565), .SP(Clk_enable_201), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1423, LSE_RLINE=1423 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U26
//

module SHIFTREG_U26 (\QS[0] , Clk, nPCLK, Clk_enable_187, n4553, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL1[1] , n2581, n2583, n2585, n2587, n2589, n2591, 
            n2593) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_187;
    input n4553;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL1[1] ;
    input n2581;
    input n2583;
    input n2585;
    input n2587;
    input n2589;
    input n2591;
    input n2593;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_187), .CD(n4553), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2581), .SP(Clk_enable_187), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2583), .SP(Clk_enable_187), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2585), .SP(Clk_enable_187), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2587), .SP(Clk_enable_187), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2589), .SP(Clk_enable_187), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2591), .SP(Clk_enable_187), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2593), .SP(Clk_enable_187), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1421, LSE_RLINE=1421 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U27
//

module SHIFTREG_U27 (\QS[0] , Clk, nPCLK, Clk_enable_173, n4549, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL1[0] , n2609, n2611, n2613, n2615, n2617, n2619, 
            n2621) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_173;
    input n4549;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL1[0] ;
    input n2609;
    input n2611;
    input n2613;
    input n2615;
    input n2617;
    input n2619;
    input n2621;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_173), .CD(n4549), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL1[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2609), .SP(Clk_enable_173), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2611), .SP(Clk_enable_173), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2613), .SP(Clk_enable_173), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2615), .SP(Clk_enable_173), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2617), .SP(Clk_enable_173), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2619), .SP(Clk_enable_173), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2621), .SP(Clk_enable_173), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1419, LSE_RLINE=1419 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U28
//

module SHIFTREG_U28 (\QS[0] , Clk, nPCLK, Clk_enable_264, n4576, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL0[7] , n2427, n2429, n2431, n2433, n2435, n2437, 
            n2439) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_264;
    input n4576;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL0[7] ;
    input n2427;
    input n2429;
    input n2431;
    input n2433;
    input n2435;
    input n2437;
    input n2439;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_264), .CD(n4576), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[7] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2427), .SP(Clk_enable_264), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2429), .SP(Clk_enable_264), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2431), .SP(Clk_enable_264), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2433), .SP(Clk_enable_264), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2435), .SP(Clk_enable_264), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2437), .SP(Clk_enable_264), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2439), .SP(Clk_enable_264), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1432, LSE_RLINE=1432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U29
//

module SHIFTREG_U29 (\QS[0] , Clk, nPCLK, Clk_enable_250, n4572, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL0[6] , n2455, n2457, n2459, n2461, n2463, n2465, 
            n2467) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_250;
    input n4572;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL0[6] ;
    input n2455;
    input n2457;
    input n2459;
    input n2461;
    input n2463;
    input n2465;
    input n2467;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_250), .CD(n4572), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2455), .SP(Clk_enable_250), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2457), .SP(Clk_enable_250), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2459), .SP(Clk_enable_250), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2461), .SP(Clk_enable_250), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2463), .SP(Clk_enable_250), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2465), .SP(Clk_enable_250), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2467), .SP(Clk_enable_250), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1430, LSE_RLINE=1430 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U30
//

module SHIFTREG_U30 (\QS[0] , Clk, nPCLK, Clk_enable_236, n4568, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL0[5] , n2483, n2485, n2487, n2489, n2491, n2493, 
            n2495) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_236;
    input n4568;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL0[5] ;
    input n2483;
    input n2485;
    input n2487;
    input n2489;
    input n2491;
    input n2493;
    input n2495;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_236), .CD(n4568), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2483), .SP(Clk_enable_236), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2485), .SP(Clk_enable_236), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2487), .SP(Clk_enable_236), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2489), .SP(Clk_enable_236), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2491), .SP(Clk_enable_236), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2493), .SP(Clk_enable_236), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2495), .SP(Clk_enable_236), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1428, LSE_RLINE=1428 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U31
//

module SHIFTREG_U31 (\QS[0] , Clk, nPCLK, Clk_enable_222, n4563, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL0[4] , n2511, n2513, n2515, n2517, n2519, n2521, 
            n2523) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_222;
    input n4563;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL0[4] ;
    input n2511;
    input n2513;
    input n2515;
    input n2517;
    input n2519;
    input n2521;
    input n2523;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_222), .CD(n4563), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2511), .SP(Clk_enable_222), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2513), .SP(Clk_enable_222), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2515), .SP(Clk_enable_222), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2517), .SP(Clk_enable_222), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2519), .SP(Clk_enable_222), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2521), .SP(Clk_enable_222), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2523), .SP(Clk_enable_222), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1426, LSE_RLINE=1426 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U32
//

module SHIFTREG_U32 (\QS[0] , Clk, nPCLK, Clk_enable_208, n4559, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL0[3] , n2539, n2541, n2543, n2545, n2547, n2549, 
            n2551) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_208;
    input n4559;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL0[3] ;
    input n2539;
    input n2541;
    input n2543;
    input n2545;
    input n2547;
    input n2549;
    input n2551;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_208), .CD(n4559), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2539), .SP(Clk_enable_208), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2541), .SP(Clk_enable_208), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2543), .SP(Clk_enable_208), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2545), .SP(Clk_enable_208), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2547), .SP(Clk_enable_208), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2549), .SP(Clk_enable_208), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2551), .SP(Clk_enable_208), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1424, LSE_RLINE=1424 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U33
//

module SHIFTREG_U33 (\QS[0] , Clk, nPCLK, Clk_enable_194, n4555, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL0[2] , n2567, n2569, n2571, n2573, n2575, n2577, 
            n2579) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_194;
    input n4555;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL0[2] ;
    input n2567;
    input n2569;
    input n2571;
    input n2573;
    input n2575;
    input n2577;
    input n2579;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_194), .CD(n4555), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2567), .SP(Clk_enable_194), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2569), .SP(Clk_enable_194), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2571), .SP(Clk_enable_194), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2573), .SP(Clk_enable_194), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2575), .SP(Clk_enable_194), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2577), .SP(Clk_enable_194), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2579), .SP(Clk_enable_194), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1422, LSE_RLINE=1422 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U34
//

module SHIFTREG_U34 (\QS[0] , Clk, nPCLK, Clk_enable_180, n4551, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL0[1] , n2595, n2597, n2599, n2601, n2603, n2605, 
            n2607) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_180;
    input n4551;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL0[1] ;
    input n2595;
    input n2597;
    input n2599;
    input n2601;
    input n2603;
    input n2605;
    input n2607;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_180), .CD(n4551), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2595), .SP(Clk_enable_180), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2597), .SP(Clk_enable_180), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2599), .SP(Clk_enable_180), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2601), .SP(Clk_enable_180), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2603), .SP(Clk_enable_180), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2605), .SP(Clk_enable_180), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2607), .SP(Clk_enable_180), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1420, LSE_RLINE=1420 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U35
//

module SHIFTREG_U35 (\QS[0] , Clk, nPCLK, Clk_enable_166, n4547, \SDATA[0] , 
            \QS[1] , \QS[2] , \QS[3] , \QS[4] , \QS[5] , \QS[6] , 
            \COL0[0] , n2623, n2625, n2627, n2629, n2631, n2633, 
            n2635) /* synthesis syn_module_defined=1 */ ;
    output \QS[0] ;
    input Clk;
    input nPCLK;
    input Clk_enable_166;
    input n4547;
    input \SDATA[0] ;
    output \QS[1] ;
    output \QS[2] ;
    output \QS[3] ;
    output \QS[4] ;
    output \QS[5] ;
    output \QS[6] ;
    output \COL0[0] ;
    input n2623;
    input n2625;
    input n2627;
    input n2629;
    input n2631;
    input n2633;
    input n2635;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(nPCLK), .CK(Clk), .Q(\QS[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(\SDATA[0] ), .SP(Clk_enable_166), .CD(n4547), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(nPCLK), .CK(Clk), .Q(\QS[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(nPCLK), .CK(Clk), .Q(\QS[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(nPCLK), .CK(Clk), .Q(\QS[3] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(nPCLK), .CK(Clk), .Q(\QS[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(nPCLK), .CK(Clk), .Q(\QS[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(nPCLK), .CK(Clk), .Q(\QS[6] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(nPCLK), .CK(Clk), .Q(\COL0[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2623), .SP(Clk_enable_166), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2625), .SP(Clk_enable_166), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2627), .SP(Clk_enable_166), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2629), .SP(Clk_enable_166), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2631), .SP(Clk_enable_166), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2633), .SP(Clk_enable_166), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2635), .SP(Clk_enable_166), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=97, LSE_LLINE=1418, LSE_RLINE=1418 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module PALETTE
//

module PALETTE (n1026, EMPH, EMP_R, EMP_G, \STEP3[0] , \THO_LATCH[0] , 
            TH_MUX, \CGA[1] , RGB_c_15, RGB_c_9, RGB_c_10, RGB_c_2, 
            RGB_c_11, TSTEP_LATCH, Clk, PCLK_c, DB_PAR_N_634, RGB_c_12, 
            RGB_c_13, RGB_c_18, RGB_c_14, RGB_c_3, GND_net, RGB_c_19, 
            nPICTURE, RGB_c_20, R7, RPIX, RGB_c_21, RGB_c_22, PIX, 
            RGB_c_23, RGB_c_7, MODE_c, RGB_c_0, \STEP3[4] , \THO_LATCH[4] , 
            RGB_c_1, B_W, RGB_c_16, RGB_c_17, RGB_c_4, RGB_c_5, 
            RGB_c_8, RGB_c_6, PALSEL1_c_7, PALSEL0_c_6, VCC_net, \CGA[3] , 
            \CGA[2] , \CGA[0] , \DBIN[5] , \DBIN[4] , \DBIN[3] , \DBIN[2] , 
            \DBIN[1] , \DBIN[0] ) /* synthesis syn_module_defined=1 */ ;
    input n1026;
    input [2:0]EMPH;
    input EMP_R;
    input EMP_G;
    input \STEP3[0] ;
    input \THO_LATCH[0] ;
    input TH_MUX;
    input \CGA[1] ;
    output RGB_c_15;
    output RGB_c_9;
    output RGB_c_10;
    output RGB_c_2;
    output RGB_c_11;
    output TSTEP_LATCH;
    input Clk;
    input PCLK_c;
    input DB_PAR_N_634;
    output RGB_c_12;
    output RGB_c_13;
    output RGB_c_18;
    output RGB_c_14;
    output RGB_c_3;
    input GND_net;
    output RGB_c_19;
    input nPICTURE;
    output RGB_c_20;
    input R7;
    output RPIX;
    output RGB_c_21;
    output RGB_c_22;
    output [5:0]PIX;
    output RGB_c_23;
    output RGB_c_7;
    input MODE_c;
    output RGB_c_0;
    input \STEP3[4] ;
    input \THO_LATCH[4] ;
    output RGB_c_1;
    input B_W;
    output RGB_c_16;
    output RGB_c_17;
    output RGB_c_4;
    output RGB_c_5;
    output RGB_c_8;
    output RGB_c_6;
    input PALSEL1_c_7;
    input PALSEL0_c_6;
    input VCC_net;
    input \CGA[3] ;
    input \CGA[2] ;
    input \CGA[0] ;
    input \DBIN[5] ;
    input \DBIN[4] ;
    input \DBIN[3] ;
    input \DBIN[2] ;
    input \DBIN[1] ;
    input \DBIN[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire n5876, CGAH_N_1712, n541;
    wire [7:0]go;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1639[14:16])
    
    wire PICTURER2;
    wire [7:0]n1017;
    wire [7:0]bo_7__N_1686;
    wire [7:0]n1027;
    wire [7:0]bo;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1639[18:20])
    wire [7:0]ro;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1639[10:12])
    
    wire n5932;
    wire [7:0]gi;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1653[15:17])
    
    wire n2276, n6164;
    wire [7:0]ro_7__N_1629;
    
    wire PICTURER;
    wire [7:0]go_7__N_1637;
    wire [7:0]bo_7__N_1645;
    
    wire n2272, n8227;
    wire [7:0]bi;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1653[19:21])
    
    wire n8228, n2274, n2266, n2270, n8239, n8252, n8251, n4524;
    wire [5:0]C;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1644[11:12])
    
    wire n8225, n8226;
    wire [7:0]ri;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1653[11:13])
    
    wire n2284, n8238, n6160, n2280, n2282, n2268, n2278, n8250, 
        n8237, n8236, n8249, n8247, C_5__N_1653;
    wire [4:0]Address;   // d:/ppu_reverse/fpga/lava_ppu_lite/palette_ram.v(13[22:29])
    
    wire n8246, n8245, n8244;
    
    LUT4 i5280_4_lut (.A(n1026), .B(EMPH[2]), .C(EMP_R), .D(EMP_G), 
         .Z(n5876)) /* synthesis lut_function=(A+!((C (D)+!C !(D))+!B)) */ ;
    defparam i5280_4_lut.init = 16'haeea;
    LUT4 CGA_0__I_0_2_lut_4_lut (.A(\STEP3[0] ), .B(\THO_LATCH[0] ), .C(TH_MUX), 
         .D(\CGA[1] ), .Z(CGAH_N_1712)) /* synthesis lut_function=(A (B+((D)+!C))+!A (B (C+(D))+!B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1642[15:34])
    defparam CGA_0__I_0_2_lut_4_lut.init = 16'hffca;
    LUT4 i189_2_lut (.A(EMP_G), .B(EMP_R), .Z(n541)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam i189_2_lut.init = 16'h8888;
    LUT4 i5471_2_lut (.A(go[7]), .B(PICTURER2), .Z(RGB_c_15)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5471_2_lut.init = 16'h2222;
    LUT4 i5465_2_lut (.A(go[1]), .B(PICTURER2), .Z(RGB_c_9)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5465_2_lut.init = 16'h2222;
    LUT4 mux_531_i7_3_lut (.A(n1017[6]), .B(bo_7__N_1686[6]), .C(n5876), 
         .Z(n1027[6])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_531_i7_3_lut.init = 16'hacac;
    LUT4 i5466_2_lut (.A(go[2]), .B(PICTURER2), .Z(RGB_c_10)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5466_2_lut.init = 16'h2222;
    LUT4 i5458_2_lut (.A(bo[2]), .B(PICTURER2), .Z(RGB_c_2)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5458_2_lut.init = 16'h2222;
    LUT4 i5467_2_lut (.A(go[3]), .B(PICTURER2), .Z(RGB_c_11)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5467_2_lut.init = 16'h2222;
    FD1P3AX TSTEP_LATCH_79 (.D(DB_PAR_N_634), .SP(PCLK_c), .CK(Clk), .Q(TSTEP_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam TSTEP_LATCH_79.GSR = "ENABLED";
    LUT4 i5468_2_lut (.A(go[4]), .B(PICTURER2), .Z(RGB_c_12)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5468_2_lut.init = 16'h2222;
    LUT4 i5469_2_lut (.A(go[5]), .B(PICTURER2), .Z(RGB_c_13)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5469_2_lut.init = 16'h2222;
    LUT4 i5474_2_lut (.A(ro[2]), .B(PICTURER2), .Z(RGB_c_18)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5474_2_lut.init = 16'h2222;
    LUT4 i5613_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(EMPH[0]), .D(EMPH[2]), 
         .Z(n5932)) /* synthesis lut_function=(A (B (C (D)+!C !(D))+!B (C+!(D)))+!A (C+!(D))) */ ;
    defparam i5613_3_lut_4_lut.init = 16'hf07f;
    LUT4 i5470_2_lut (.A(go[6]), .B(PICTURER2), .Z(RGB_c_14)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5470_2_lut.init = 16'h2222;
    LUT4 i5459_2_lut (.A(bo[3]), .B(PICTURER2), .Z(RGB_c_3)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5459_2_lut.init = 16'h2222;
    LUT4 mux_556_i5_3_lut (.A(gi[6]), .B(gi[7]), .C(n5932), .Z(n2276)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_556_i5_3_lut.init = 16'h5353;
    LUT4 i8544_2_lut (.A(gi[7]), .B(n5932), .Z(n6164)) /* synthesis lut_function=(!(A (B))) */ ;
    defparam i8544_2_lut.init = 16'h7777;
    FD1S3AX ro_i0 (.D(ro_7__N_1629[0]), .CK(Clk), .Q(ro[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam ro_i0.GSR = "ENABLED";
    FD1S3AX PICTURER2_49 (.D(PICTURER), .CK(Clk), .Q(PICTURER2)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam PICTURER2_49.GSR = "ENABLED";
    FD1S3AX go_i0 (.D(go_7__N_1637[0]), .CK(Clk), .Q(go[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam go_i0.GSR = "ENABLED";
    FD1S3AX bo_i0 (.D(bo_7__N_1645[0]), .CK(Clk), .Q(bo[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam bo_i0.GSR = "ENABLED";
    LUT4 mux_556_i3_3_lut (.A(gi[4]), .B(gi[5]), .C(n5932), .Z(n2272)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_556_i3_3_lut.init = 16'h5353;
    CCU2D sub_34_add_2_7 (.A0(bi[5]), .B0(bi[7]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[6]), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n8227), 
          .COUT(n8228), .S0(bo_7__N_1686[5]), .S1(bo_7__N_1686[6]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1706[12:24])
    defparam sub_34_add_2_7.INIT0 = 16'h5999;
    defparam sub_34_add_2_7.INIT1 = 16'h5555;
    defparam sub_34_add_2_7.INJECT1_0 = "NO";
    defparam sub_34_add_2_7.INJECT1_1 = "NO";
    LUT4 mux_556_i4_3_lut (.A(gi[5]), .B(gi[6]), .C(n5932), .Z(n2274)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_556_i4_3_lut.init = 16'h5353;
    LUT4 mux_556_i1_3_lut (.A(gi[2]), .B(gi[3]), .C(n5932), .Z(n2266)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_556_i1_3_lut.init = 16'h5353;
    LUT4 i5475_2_lut (.A(ro[3]), .B(PICTURER2), .Z(RGB_c_19)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5475_2_lut.init = 16'h2222;
    LUT4 mux_556_i2_3_lut (.A(gi[3]), .B(gi[4]), .C(n5932), .Z(n2270)) /* synthesis lut_function=(!(A (B+(C))+!A !((C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_556_i2_3_lut.init = 16'h5353;
    FD1P3AX PICTURER_48 (.D(nPICTURE), .SP(PCLK_c), .CK(Clk), .Q(PICTURER));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam PICTURER_48.GSR = "ENABLED";
    LUT4 i5476_2_lut (.A(ro[4]), .B(PICTURER2), .Z(RGB_c_20)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5476_2_lut.init = 16'h2222;
    CCU2D add_720_9 (.A0(EMPH[0]), .B0(EMPH[2]), .C0(gi[6]), .D0(GND_net), 
          .A1(EMPH[0]), .B1(EMPH[2]), .C1(gi[7]), .D1(GND_net), .CIN(n8239), 
          .S0(go_7__N_1637[6]), .S1(go_7__N_1637[7]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam add_720_9.INIT0 = 16'h1e1e;
    defparam add_720_9.INIT1 = 16'h1e1e;
    defparam add_720_9.INJECT1_0 = "NO";
    defparam add_720_9.INJECT1_1 = "NO";
    CCU2D add_549_9 (.A0(EMPH[2]), .B0(n541), .C0(bo_7__N_1686[7]), .D0(bi[7]), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n8252), 
          .S0(n1017[7]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam add_549_9.INIT0 = 16'h04bf;
    defparam add_549_9.INIT1 = 16'h0000;
    defparam add_549_9.INJECT1_0 = "NO";
    defparam add_549_9.INJECT1_1 = "NO";
    CCU2D add_549_7 (.A0(EMPH[2]), .B0(n541), .C0(bo_7__N_1686[5]), .D0(bi[5]), 
          .A1(EMPH[2]), .B1(n541), .C1(bo_7__N_1686[6]), .D1(bi[6]), 
          .CIN(n8251), .COUT(n8252), .S0(n1017[5]), .S1(n1017[6]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam add_549_7.INIT0 = 16'h04bf;
    defparam add_549_7.INIT1 = 16'h04bf;
    defparam add_549_7.INJECT1_0 = "NO";
    defparam add_549_7.INJECT1_1 = "NO";
    LUT4 R7_I_0_2_lut (.A(R7), .B(TH_MUX), .Z(RPIX)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1648[15:26])
    defparam R7_I_0_2_lut.init = 16'h8888;
    LUT4 i5477_2_lut (.A(ro[5]), .B(PICTURER2), .Z(RGB_c_21)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5477_2_lut.init = 16'h2222;
    LUT4 i5478_2_lut (.A(ro[6]), .B(PICTURER2), .Z(RGB_c_22)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5478_2_lut.init = 16'h2222;
    FD1P3IX PIX_i0_i3 (.D(C[3]), .SP(PCLK_c), .CD(n4524), .CK(Clk), 
            .Q(PIX[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam PIX_i0_i3.GSR = "ENABLED";
    LUT4 i5479_2_lut (.A(ro[7]), .B(PICTURER2), .Z(RGB_c_23)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5479_2_lut.init = 16'h2222;
    FD1P3IX PIX_i0_i2 (.D(C[2]), .SP(PCLK_c), .CD(n4524), .CK(Clk), 
            .Q(PIX[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam PIX_i0_i2.GSR = "ENABLED";
    CCU2D sub_34_add_2_3 (.A0(bi[1]), .B0(bi[3]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[2]), .B1(bi[4]), .C1(GND_net), .D1(GND_net), .CIN(n8225), 
          .COUT(n8226), .S0(bo_7__N_1686[1]), .S1(bo_7__N_1686[2]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1706[12:24])
    defparam sub_34_add_2_3.INIT0 = 16'h5999;
    defparam sub_34_add_2_3.INIT1 = 16'h5999;
    defparam sub_34_add_2_3.INJECT1_0 = "NO";
    defparam sub_34_add_2_3.INJECT1_1 = "NO";
    LUT4 mux_531_i5_3_lut (.A(n1017[4]), .B(bo_7__N_1686[4]), .C(n5876), 
         .Z(n1027[4])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_531_i5_3_lut.init = 16'hacac;
    LUT4 mux_555_i5_3_lut (.A(ri[7]), .B(ri[6]), .C(EMPH[1]), .Z(n2284)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_555_i5_3_lut.init = 16'h3535;
    CCU2D add_720_7 (.A0(gi[4]), .B0(EMPH[2]), .C0(EMPH[0]), .D0(n2276), 
          .A1(gi[5]), .B1(EMPH[2]), .C1(EMPH[0]), .D1(n6164), .CIN(n8238), 
          .COUT(n8239), .S0(go_7__N_1637[4]), .S1(go_7__N_1637[5]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam add_720_7.INIT0 = 16'h56aa;
    defparam add_720_7.INIT1 = 16'h56aa;
    defparam add_720_7.INJECT1_0 = "NO";
    defparam add_720_7.INJECT1_1 = "NO";
    LUT4 i8538_2_lut (.A(ri[7]), .B(EMPH[1]), .Z(n6160)) /* synthesis lut_function=(!(A (B))) */ ;
    defparam i8538_2_lut.init = 16'h7777;
    LUT4 mux_555_i3_3_lut (.A(ri[5]), .B(ri[4]), .C(EMPH[1]), .Z(n2280)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_555_i3_3_lut.init = 16'h3535;
    LUT4 mux_555_i4_3_lut (.A(ri[6]), .B(ri[5]), .C(EMPH[1]), .Z(n2282)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_555_i4_3_lut.init = 16'h3535;
    LUT4 mux_555_i1_3_lut (.A(ri[3]), .B(ri[2]), .C(EMPH[1]), .Z(n2268)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_555_i1_3_lut.init = 16'h3535;
    LUT4 mux_555_i2_3_lut (.A(ri[4]), .B(ri[3]), .C(EMPH[1]), .Z(n2278)) /* synthesis lut_function=(!(A (B+!(C))+!A (B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_555_i2_3_lut.init = 16'h3535;
    CCU2D add_549_5 (.A0(bi[6]), .B0(bi[3]), .C0(bo_7__N_1686[3]), .D0(n1026), 
          .A1(bi[7]), .B1(bi[4]), .C1(bo_7__N_1686[4]), .D1(n1026), 
          .CIN(n8250), .COUT(n8251), .S0(n1017[3]), .S1(n1017[4]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam add_549_5.INIT0 = 16'ha599;
    defparam add_549_5.INIT1 = 16'ha599;
    defparam add_549_5.INJECT1_0 = "NO";
    defparam add_549_5.INJECT1_1 = "NO";
    CCU2D sub_34_add_2_9 (.A0(bi[7]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n8228), 
          .S0(bo_7__N_1686[7]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1706[12:24])
    defparam sub_34_add_2_9.INIT0 = 16'h5555;
    defparam sub_34_add_2_9.INIT1 = 16'h0000;
    defparam sub_34_add_2_9.INJECT1_0 = "NO";
    defparam sub_34_add_2_9.INJECT1_1 = "NO";
    CCU2D add_720_5 (.A0(gi[2]), .B0(EMPH[2]), .C0(EMPH[0]), .D0(n2272), 
          .A1(gi[3]), .B1(EMPH[2]), .C1(EMPH[0]), .D1(n2274), .CIN(n8237), 
          .COUT(n8238), .S0(go_7__N_1637[2]), .S1(go_7__N_1637[3]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam add_720_5.INIT0 = 16'h56aa;
    defparam add_720_5.INIT1 = 16'h56aa;
    defparam add_720_5.INJECT1_0 = "NO";
    defparam add_720_5.INJECT1_1 = "NO";
    LUT4 i5463_2_lut (.A(bo[7]), .B(PICTURER2), .Z(RGB_c_7)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5463_2_lut.init = 16'h2222;
    CCU2D add_720_3 (.A0(gi[0]), .B0(EMPH[2]), .C0(EMPH[0]), .D0(n2266), 
          .A1(gi[1]), .B1(EMPH[2]), .C1(EMPH[0]), .D1(n2270), .CIN(n8236), 
          .COUT(n8237), .S0(go_7__N_1637[0]), .S1(go_7__N_1637[1]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam add_720_3.INIT0 = 16'h56aa;
    defparam add_720_3.INIT1 = 16'h56aa;
    defparam add_720_3.INJECT1_0 = "NO";
    defparam add_720_3.INJECT1_1 = "NO";
    CCU2D add_549_3 (.A0(bi[4]), .B0(bi[1]), .C0(bo_7__N_1686[1]), .D0(n1026), 
          .A1(bi[5]), .B1(bi[2]), .C1(bo_7__N_1686[2]), .D1(n1026), 
          .CIN(n8249), .COUT(n8250), .S0(n1017[1]), .S1(n1017[2]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam add_549_3.INIT0 = 16'ha599;
    defparam add_549_3.INIT1 = 16'ha599;
    defparam add_549_3.INJECT1_0 = "NO";
    defparam add_549_3.INJECT1_1 = "NO";
    FD1P3IX PIX_i0_i1 (.D(C[1]), .SP(PCLK_c), .CD(n4524), .CK(Clk), 
            .Q(PIX[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam PIX_i0_i1.GSR = "ENABLED";
    CCU2D sub_34_add_2_5 (.A0(bi[3]), .B0(bi[5]), .C0(GND_net), .D0(GND_net), 
          .A1(bi[4]), .B1(bi[6]), .C1(GND_net), .D1(GND_net), .CIN(n8226), 
          .COUT(n8227), .S0(bo_7__N_1686[3]), .S1(bo_7__N_1686[4]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1706[12:24])
    defparam sub_34_add_2_5.INIT0 = 16'h5999;
    defparam sub_34_add_2_5.INIT1 = 16'h5999;
    defparam sub_34_add_2_5.INJECT1_0 = "NO";
    defparam sub_34_add_2_5.INJECT1_1 = "NO";
    CCU2D add_549_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(bi[3]), .B1(bi[0]), .C1(bo_7__N_1686[0]), .D1(n1026), 
          .COUT(n8249), .S1(n1017[0]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam add_549_1.INIT0 = 16'h0000;
    defparam add_549_1.INIT1 = 16'ha599;
    defparam add_549_1.INJECT1_0 = "NO";
    defparam add_549_1.INJECT1_1 = "NO";
    LUT4 mux_516_i1_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[0]), .D(n1027[0]), 
         .Z(bo_7__N_1645[0])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_516_i1_3_lut_4_lut.init = 16'hfe10;
    CCU2D sub_34_add_2_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(bi[0]), .B1(bi[2]), .C1(GND_net), .D1(GND_net), .COUT(n8225), 
          .S1(bo_7__N_1686[0]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1706[12:24])
    defparam sub_34_add_2_1.INIT0 = 16'h0000;
    defparam sub_34_add_2_1.INIT1 = 16'h5999;
    defparam sub_34_add_2_1.INJECT1_0 = "NO";
    defparam sub_34_add_2_1.INJECT1_1 = "NO";
    LUT4 mux_516_i2_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[1]), .D(n1027[1]), 
         .Z(bo_7__N_1645[1])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_516_i2_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_516_i3_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[2]), .D(n1027[2]), 
         .Z(bo_7__N_1645[2])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_516_i3_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_516_i4_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[3]), .D(n1027[3]), 
         .Z(bo_7__N_1645[3])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_516_i4_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_516_i5_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[4]), .D(n1027[4]), 
         .Z(bo_7__N_1645[4])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_516_i5_3_lut_4_lut.init = 16'hfe10;
    CCU2D add_717_9 (.A0(EMPH[2]), .B0(EMPH[1]), .C0(ri[6]), .D0(GND_net), 
          .A1(EMPH[2]), .B1(EMPH[1]), .C1(ri[7]), .D1(GND_net), .CIN(n8247), 
          .S0(ro_7__N_1629[6]), .S1(ro_7__N_1629[7]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam add_717_9.INIT0 = 16'h1e1e;
    defparam add_717_9.INIT1 = 16'h1e1e;
    defparam add_717_9.INJECT1_0 = "NO";
    defparam add_717_9.INJECT1_1 = "NO";
    CCU2D add_720_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(EMP_G), .B1(EMP_R), .C1(MODE_c), .D1(EMPH[2]), .COUT(n8236));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam add_720_1.INIT0 = 16'hF000;
    defparam add_720_1.INIT1 = 16'h0053;
    defparam add_720_1.INJECT1_0 = "NO";
    defparam add_720_1.INJECT1_1 = "NO";
    LUT4 mux_516_i6_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[5]), .D(n1027[5]), 
         .Z(bo_7__N_1645[5])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_516_i6_3_lut_4_lut.init = 16'hfe10;
    FD1P3AX PIX_i0_i4 (.D(C[4]), .SP(PCLK_c), .CK(Clk), .Q(PIX[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam PIX_i0_i4.GSR = "ENABLED";
    FD1P3AX PIX_i0_i5 (.D(C[5]), .SP(PCLK_c), .CK(Clk), .Q(PIX[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam PIX_i0_i5.GSR = "ENABLED";
    FD1S3AX ro_i1 (.D(ro_7__N_1629[1]), .CK(Clk), .Q(ro[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam ro_i1.GSR = "ENABLED";
    LUT4 mux_516_i7_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[6]), .D(n1027[6]), 
         .Z(bo_7__N_1645[6])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_516_i7_3_lut_4_lut.init = 16'hfe10;
    LUT4 mux_516_i8_3_lut_4_lut (.A(EMP_G), .B(EMP_R), .C(bi[7]), .D(n1027[7]), 
         .Z(bo_7__N_1645[7])) /* synthesis lut_function=(A (D)+!A (B (D)+!B (C))) */ ;
    defparam mux_516_i8_3_lut_4_lut.init = 16'hfe10;
    FD1S3AX ro_i2 (.D(ro_7__N_1629[2]), .CK(Clk), .Q(ro[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam ro_i2.GSR = "ENABLED";
    FD1S3AX ro_i3 (.D(ro_7__N_1629[3]), .CK(Clk), .Q(ro[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam ro_i3.GSR = "ENABLED";
    FD1S3AX ro_i4 (.D(ro_7__N_1629[4]), .CK(Clk), .Q(ro[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam ro_i4.GSR = "ENABLED";
    FD1S3AX ro_i5 (.D(ro_7__N_1629[5]), .CK(Clk), .Q(ro[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam ro_i5.GSR = "ENABLED";
    FD1S3AX ro_i6 (.D(ro_7__N_1629[6]), .CK(Clk), .Q(ro[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam ro_i6.GSR = "ENABLED";
    FD1S3AX ro_i7 (.D(ro_7__N_1629[7]), .CK(Clk), .Q(ro[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam ro_i7.GSR = "ENABLED";
    FD1S3AX go_i1 (.D(go_7__N_1637[1]), .CK(Clk), .Q(go[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam go_i1.GSR = "ENABLED";
    FD1S3AX go_i2 (.D(go_7__N_1637[2]), .CK(Clk), .Q(go[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam go_i2.GSR = "ENABLED";
    FD1S3AX go_i3 (.D(go_7__N_1637[3]), .CK(Clk), .Q(go[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam go_i3.GSR = "ENABLED";
    FD1S3AX go_i4 (.D(go_7__N_1637[4]), .CK(Clk), .Q(go[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam go_i4.GSR = "ENABLED";
    FD1S3AX go_i5 (.D(go_7__N_1637[5]), .CK(Clk), .Q(go[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam go_i5.GSR = "ENABLED";
    FD1S3AX go_i6 (.D(go_7__N_1637[6]), .CK(Clk), .Q(go[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam go_i6.GSR = "ENABLED";
    FD1S3AX go_i7 (.D(go_7__N_1637[7]), .CK(Clk), .Q(go[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam go_i7.GSR = "ENABLED";
    FD1S3AX bo_i1 (.D(bo_7__N_1645[1]), .CK(Clk), .Q(bo[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam bo_i1.GSR = "ENABLED";
    FD1S3AX bo_i2 (.D(bo_7__N_1645[2]), .CK(Clk), .Q(bo[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam bo_i2.GSR = "ENABLED";
    FD1S3AX bo_i3 (.D(bo_7__N_1645[3]), .CK(Clk), .Q(bo[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam bo_i3.GSR = "ENABLED";
    FD1S3AX bo_i4 (.D(bo_7__N_1645[4]), .CK(Clk), .Q(bo[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam bo_i4.GSR = "ENABLED";
    FD1S3AX bo_i5 (.D(bo_7__N_1645[5]), .CK(Clk), .Q(bo[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam bo_i5.GSR = "ENABLED";
    FD1S3AX bo_i6 (.D(bo_7__N_1645[6]), .CK(Clk), .Q(bo[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam bo_i6.GSR = "ENABLED";
    FD1S3AX bo_i7 (.D(bo_7__N_1645[7]), .CK(Clk), .Q(bo[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam bo_i7.GSR = "ENABLED";
    LUT4 i5301_2_lut (.A(bo[0]), .B(PICTURER2), .Z(RGB_c_0)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5301_2_lut.init = 16'h2222;
    LUT4 TH_MUX_I_0_2_lut (.A(TH_MUX), .B(TSTEP_LATCH), .Z(C_5__N_1653)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1650[47:63])
    defparam TH_MUX_I_0_2_lut.init = 16'h8888;
    LUT4 CGAH_I_0_4_lut (.A(CGAH_N_1712), .B(\STEP3[4] ), .C(\THO_LATCH[4] ), 
         .D(TH_MUX), .Z(Address[4])) /* synthesis lut_function=(A (B (C+!(D))+!B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1642[15:43])
    defparam CGAH_I_0_4_lut.init = 16'ha088;
    LUT4 i5457_2_lut (.A(bo[1]), .B(PICTURER2), .Z(RGB_c_1)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5457_2_lut.init = 16'h2222;
    LUT4 mux_531_i2_3_lut (.A(n1017[1]), .B(bo_7__N_1686[1]), .C(n5876), 
         .Z(n1027[1])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_531_i2_3_lut.init = 16'hacac;
    LUT4 i3913_4_lut (.A(PCLK_c), .B(B_W), .C(nPICTURE), .D(RPIX), .Z(n4524)) /* synthesis lut_function=(A (B+!((D)+!C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam i3913_4_lut.init = 16'h88a8;
    LUT4 mux_531_i3_3_lut (.A(n1017[2]), .B(bo_7__N_1686[2]), .C(n5876), 
         .Z(n1027[2])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_531_i3_3_lut.init = 16'hacac;
    LUT4 i5472_2_lut (.A(ro[0]), .B(PICTURER2), .Z(RGB_c_16)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5472_2_lut.init = 16'h2222;
    LUT4 mux_531_i1_3_lut (.A(n1017[0]), .B(bo_7__N_1686[0]), .C(n5876), 
         .Z(n1027[0])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_531_i1_3_lut.init = 16'hacac;
    LUT4 i5473_2_lut (.A(ro[1]), .B(PICTURER2), .Z(RGB_c_17)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5473_2_lut.init = 16'h2222;
    LUT4 mux_531_i8_3_lut (.A(n1017[7]), .B(bo_7__N_1686[7]), .C(n5876), 
         .Z(n1027[7])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_531_i8_3_lut.init = 16'hacac;
    LUT4 mux_531_i4_3_lut (.A(n1017[3]), .B(bo_7__N_1686[3]), .C(n5876), 
         .Z(n1027[3])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_531_i4_3_lut.init = 16'hacac;
    LUT4 i5460_2_lut (.A(bo[4]), .B(PICTURER2), .Z(RGB_c_4)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5460_2_lut.init = 16'h2222;
    CCU2D add_717_7 (.A0(ri[4]), .B0(EMPH[1]), .C0(EMPH[2]), .D0(n2284), 
          .A1(ri[5]), .B1(EMPH[1]), .C1(EMPH[2]), .D1(n6160), .CIN(n8246), 
          .COUT(n8247), .S0(ro_7__N_1629[4]), .S1(ro_7__N_1629[5]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam add_717_7.INIT0 = 16'h56aa;
    defparam add_717_7.INIT1 = 16'h56aa;
    defparam add_717_7.INJECT1_0 = "NO";
    defparam add_717_7.INJECT1_1 = "NO";
    LUT4 i5461_2_lut (.A(bo[5]), .B(PICTURER2), .Z(RGB_c_5)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5461_2_lut.init = 16'h2222;
    LUT4 mux_531_i6_3_lut (.A(n1017[5]), .B(bo_7__N_1686[5]), .C(n5876), 
         .Z(n1027[5])) /* synthesis lut_function=(A (B+(C))+!A !((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam mux_531_i6_3_lut.init = 16'hacac;
    CCU2D add_717_5 (.A0(ri[2]), .B0(EMPH[1]), .C0(EMPH[2]), .D0(n2280), 
          .A1(ri[3]), .B1(EMPH[1]), .C1(EMPH[2]), .D1(n2282), .CIN(n8245), 
          .COUT(n8246), .S0(ro_7__N_1629[2]), .S1(ro_7__N_1629[3]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam add_717_5.INIT0 = 16'h56aa;
    defparam add_717_5.INIT1 = 16'h56aa;
    defparam add_717_5.INJECT1_0 = "NO";
    defparam add_717_5.INJECT1_1 = "NO";
    CCU2D add_717_3 (.A0(ri[0]), .B0(EMPH[1]), .C0(EMPH[2]), .D0(n2268), 
          .A1(ri[1]), .B1(EMPH[1]), .C1(EMPH[2]), .D1(n2278), .CIN(n8244), 
          .COUT(n8245), .S0(ro_7__N_1629[0]), .S1(ro_7__N_1629[1]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam add_717_3.INIT0 = 16'h56aa;
    defparam add_717_3.INIT1 = 16'h56aa;
    defparam add_717_3.INJECT1_0 = "NO";
    defparam add_717_3.INJECT1_1 = "NO";
    CCU2D add_717_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(EMP_G), .B1(EMP_R), .C1(MODE_c), .D1(EMPH[2]), .COUT(n8244));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1667[3] 1708[14])
    defparam add_717_1.INIT0 = 16'hF000;
    defparam add_717_1.INIT1 = 16'h0035;
    defparam add_717_1.INJECT1_0 = "NO";
    defparam add_717_1.INJECT1_1 = "NO";
    LUT4 i5464_2_lut (.A(go[0]), .B(PICTURER2), .Z(RGB_c_8)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5464_2_lut.init = 16'h2222;
    LUT4 i5462_2_lut (.A(bo[6]), .B(PICTURER2), .Z(RGB_c_6)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1655[20:75])
    defparam i5462_2_lut.init = 16'h2222;
    FD1P3IX PIX_i0_i0 (.D(C[0]), .SP(PCLK_c), .CD(n4524), .CK(Clk), 
            .Q(PIX[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=435, LSE_RLINE=452 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1657[8] 1709[7])
    defparam PIX_i0_i0.GSR = "ENABLED";
    PALETTE_RGB_TABLE MOD_PALETTE_RGB_TABLE (.PALSEL1_c_7(PALSEL1_c_7), .PALSEL0_c_6(PALSEL0_c_6), 
            .PIX({PIX}), .Clk(Clk), .VCC_net(VCC_net), .GND_net(GND_net), 
            .ri({ri}), .gi({gi}), .bi({bi})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1651[19:116])
    PALETTE_RAM C_5__I_0 (.Clk(Clk), .VCC_net(VCC_net), .GND_net(GND_net), 
            .C_5__N_1653(C_5__N_1653), .CGAH(Address[4]), .\CGA[3] (\CGA[3] ), 
            .\CGA[2] (\CGA[2] ), .\CGA[1] (\CGA[1] ), .\CGA[0] (\CGA[0] ), 
            .\DBIN[5] (\DBIN[5] ), .\DBIN[4] (\DBIN[4] ), .\DBIN[3] (\DBIN[3] ), 
            .\DBIN[2] (\DBIN[2] ), .\DBIN[1] (\DBIN[1] ), .\DBIN[0] (\DBIN[0] ), 
            .C({C})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1650[13:100])
    
endmodule
//
// Verilog Description of module PALETTE_RGB_TABLE
//

module PALETTE_RGB_TABLE (PALSEL1_c_7, PALSEL0_c_6, PIX, Clk, VCC_net, 
            GND_net, ri, gi, bi) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input PALSEL1_c_7;
    input PALSEL0_c_6;
    input [5:0]PIX;
    input Clk;
    input VCC_net;
    input GND_net;
    output [7:0]ri;
    output [7:0]gi;
    output [7:0]bi;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    DP8KC PALETTE_RGB_TABLE_0_1_0 (.DIA0(GND_net), .DIA1(GND_net), .DIA2(GND_net), 
          .DIA3(GND_net), .DIA4(GND_net), .DIA5(GND_net), .DIA6(GND_net), 
          .DIA7(GND_net), .DIA8(GND_net), .ADA0(GND_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(PIX[0]), .ADA4(PIX[1]), .ADA5(PIX[2]), 
          .ADA6(PIX[3]), .ADA7(PIX[4]), .ADA8(PIX[5]), .ADA9(PALSEL0_c_6), 
          .ADA10(PALSEL1_c_7), .ADA11(GND_net), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(GND_net), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), 
          .ADB4(GND_net), .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), 
          .ADB8(GND_net), .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), 
          .ADB12(VCC_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(Clk), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(ri[2]), .DOA1(ri[3]), .DOA2(ri[4]), 
          .DOA3(ri[5]), .DOA4(ri[6]), .DOA5(ri[7])) /* synthesis MEM_LPC_FILE="PALETTE_RGB_TABLE.lpc", MEM_INIT_FILE="pal_table1.mem", syn_instantiated=1, LSE_LINE_FILE_ID=3, LSE_LCOL=19, LSE_RCOL=116, LSE_LLINE=1651, LSE_RLINE=1651 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1651[19:116])
    defparam PALETTE_RGB_TABLE_0_1_0.DATA_WIDTH_A = 9;
    defparam PALETTE_RGB_TABLE_0_1_0.DATA_WIDTH_B = 9;
    defparam PALETTE_RGB_TABLE_0_1_0.REGMODE_A = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_1_0.REGMODE_B = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_1_0.CSDECODE_A = "0b000";
    defparam PALETTE_RGB_TABLE_0_1_0.CSDECODE_B = "0b000";
    defparam PALETTE_RGB_TABLE_0_1_0.WRITEMODE_A = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_1_0.WRITEMODE_B = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_1_0.GSR = "ENABLED";
    defparam PALETTE_RGB_TABLE_0_1_0.RESETMODE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_1_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_1_0.INIT_DATA = "STATIC";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_00 = "0x0000000000000000121603C2604E240341100C2B0000000000000000000701C1302C1501A0600019";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_01 = "0x0000005C2F05E3106A3B07C3F07E3E074360623F0000002613024160402E06C3C0763805A230323F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_02 = "0x0040200400000000181B052320642B03E0E0002B0040200400000000040D0301E03C1901E0400019";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_03 = "0x0040205A2B0542D0663907E3F07E3F0743405C3F004020260D018130403007C3F07E3F0662302A3F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_04 = "0x00000000000000000C1503E260522703610006290000000000000000000601E150321801E0700018";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_05 = "0x000000582A0542D062380783D07A390642F0563F000000240D01A1003C2C06A3C0783604C1C0263F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_06 = "0x0000000000000000161B0543406A2A03005000280000000000000000040D02E1E03C170160000016";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_07 = "0x000000562404A2A0623A07E3F07E3F0702F0503F00000020010080E03C3107E3F07E3F05A1700E3F";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_08 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_09 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_0F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_1_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    DP8KC PALETTE_RGB_TABLE_0_0_1 (.DIA0(GND_net), .DIA1(GND_net), .DIA2(GND_net), 
          .DIA3(GND_net), .DIA4(GND_net), .DIA5(GND_net), .DIA6(GND_net), 
          .DIA7(GND_net), .DIA8(GND_net), .ADA0(GND_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(PIX[0]), .ADA4(PIX[1]), .ADA5(PIX[2]), 
          .ADA6(PIX[3]), .ADA7(PIX[4]), .ADA8(PIX[5]), .ADA9(PALSEL0_c_6), 
          .ADA10(PALSEL1_c_7), .ADA11(GND_net), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(GND_net), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(PIX[0]), 
          .ADB4(PIX[1]), .ADB5(PIX[2]), .ADB6(PIX[3]), .ADB7(PIX[4]), 
          .ADB8(PIX[5]), .ADB9(PALSEL0_c_6), .ADB10(PALSEL1_c_7), .ADB11(GND_net), 
          .ADB12(VCC_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(Clk), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(bi[0]), .DOA1(bi[1]), .DOA2(bi[2]), 
          .DOA3(bi[3]), .DOA4(bi[4]), .DOA5(bi[5]), .DOA6(bi[6]), .DOA7(bi[7]), 
          .DOA8(gi[0]), .DOB0(gi[1]), .DOB1(gi[2]), .DOB2(gi[3]), .DOB3(gi[4]), 
          .DOB4(gi[5]), .DOB5(gi[6]), .DOB6(gi[7]), .DOB7(ri[0]), .DOB8(ri[1])) /* synthesis MEM_LPC_FILE="PALETTE_RGB_TABLE.lpc", MEM_INIT_FILE="pal_table1.mem", syn_instantiated=1, LSE_LINE_FILE_ID=3, LSE_LCOL=19, LSE_RCOL=116, LSE_LLINE=1651, LSE_RLINE=1651 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1651[19:116])
    defparam PALETTE_RGB_TABLE_0_0_1.DATA_WIDTH_A = 9;
    defparam PALETTE_RGB_TABLE_0_0_1.DATA_WIDTH_B = 9;
    defparam PALETTE_RGB_TABLE_0_0_1.REGMODE_A = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_0_1.REGMODE_B = "OUTREG";
    defparam PALETTE_RGB_TABLE_0_0_1.CSDECODE_A = "0b000";
    defparam PALETTE_RGB_TABLE_0_0_1.CSDECODE_B = "0b000";
    defparam PALETTE_RGB_TABLE_0_0_1.WRITEMODE_A = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_0_1.WRITEMODE_B = "NORMAL";
    defparam PALETTE_RGB_TABLE_0_0_1.GSR = "ENABLED";
    defparam PALETTE_RGB_TABLE_0_0_1.RESETMODE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_0_1.ASYNC_RESET_RELEASE = "SYNC";
    defparam PALETTE_RGB_TABLE_0_0_1.INIT_DATA = "STATIC";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_00 = "0x000000008A07C0000100200000BDAE3AFE3191AF000000005522F0020100201000305D1048E0FB65";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_01 = "0x00000373F11A6B8148A4362CB1E2FF3FFFF3FFFF00000099CB2FC3F2180A0586A189FF1FFFF3FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_02 = "0x2130921298255002000020015306E53FEFF3EAAE213092135520400200000010008A8F178C033765";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_03 = "0x2130936EF7193A030F84332C03FFFF3FEFF3FFFF2130909DEA0F5160010020D641A9FF1FFFF3FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_04 = "0x000002038F07D00000000000009BAB3B3EB3A8A6000000015C03F00001002010002E601149B11E60";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_05 = "0x00000363E7187A812A95340B91C2FD3FEFF1FFFF00000094C60EC320070C21F5016CFF1FEFF1FFFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_06 = "0x00000001A90A5062000000000083981C8FE3DDA1000000005D04500200000000002E7230B9B31858";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_07 = "0x00000158FE1B2B03248631DA93A0FB1FCFE3FDFF00000085FE3494A020002113C321F61FDFE3FDFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_08 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_09 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_0F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_10 = "0x000000003707A4127BB334A9921B8D31F9714FD7000000001703A2003C98019822010020000012B2";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_11 = "0x000001B9F82F6FC2F4F50DFEA3CCE71D0EC3E5FF0000004CE32D1EB3CADA0984036C37277440A9FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_12 = "0x108841084209A4F291B934C153138701D9F1615710884108220562D04F1C01C80301003008702AB2";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_13 = "0x108843B6772F97C0F2F30D7E43BFDE3C2E82DFFF1088424E6A0ECF81E26109DBC363AE06D452B1FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_14 = "0x00000100330763F2783204A9931A0B01C9634B53000000001803C220439901F86200003010101430";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_15 = "0x000001B1F22E6F52EDF00D6E41BF5F2B9E02D7FF0000024BDE0CAE90C5D7193BD064B23653C09DFF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_16 = "0x00000000340783E1722F2451601E8E0289E052D0000000001903C1F138953190420080104090222C";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_17 = "0x000000ACF21EC773E8EF2D1622BD5E1C2E60D9FF000002435F1D16A1CA592933B26732173443A5FF";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RGB_TABLE_0_0_1.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    
endmodule
//
// Verilog Description of module PALETTE_RAM
//

module PALETTE_RAM (Clk, VCC_net, GND_net, C_5__N_1653, CGAH, \CGA[3] , 
            \CGA[2] , \CGA[1] , \CGA[0] , \DBIN[5] , \DBIN[4] , \DBIN[3] , 
            \DBIN[2] , \DBIN[1] , \DBIN[0] , C) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input Clk;
    input VCC_net;
    input GND_net;
    input C_5__N_1653;
    input CGAH;
    input \CGA[3] ;
    input \CGA[2] ;
    input \CGA[1] ;
    input \CGA[0] ;
    input \DBIN[5] ;
    input \DBIN[4] ;
    input \DBIN[3] ;
    input \DBIN[2] ;
    input \DBIN[1] ;
    input \DBIN[0] ;
    output [5:0]C;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    DP8KC PALETTE_RAM_0_0_0 (.DIA0(\DBIN[0] ), .DIA1(\DBIN[1] ), .DIA2(\DBIN[2] ), 
          .DIA3(\DBIN[3] ), .DIA4(\DBIN[4] ), .DIA5(\DBIN[5] ), .DIA6(GND_net), 
          .DIA7(GND_net), .DIA8(GND_net), .ADA0(VCC_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(\CGA[0] ), .ADA4(\CGA[1] ), .ADA5(\CGA[2] ), 
          .ADA6(\CGA[3] ), .ADA7(CGAH), .ADA8(GND_net), .ADA9(GND_net), 
          .ADA10(GND_net), .ADA11(GND_net), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(C_5__N_1653), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), 
          .ADB4(GND_net), .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), 
          .ADB8(GND_net), .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), 
          .ADB12(GND_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(GND_net), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(C[0]), .DOA1(C[1]), .DOA2(C[2]), .DOA3(C[3]), 
          .DOA4(C[4]), .DOA5(C[5])) /* synthesis MEM_LPC_FILE="PALETTE_RAM.lpc", MEM_INIT_FILE="INIT_ALL_0s", syn_instantiated=1, LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=100, LSE_LLINE=1650, LSE_RLINE=1650 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1650[13:100])
    defparam PALETTE_RAM_0_0_0.DATA_WIDTH_A = 9;
    defparam PALETTE_RAM_0_0_0.DATA_WIDTH_B = 9;
    defparam PALETTE_RAM_0_0_0.REGMODE_A = "NOREG";
    defparam PALETTE_RAM_0_0_0.REGMODE_B = "NOREG";
    defparam PALETTE_RAM_0_0_0.CSDECODE_A = "0b000";
    defparam PALETTE_RAM_0_0_0.CSDECODE_B = "0b111";
    defparam PALETTE_RAM_0_0_0.WRITEMODE_A = "NORMAL";
    defparam PALETTE_RAM_0_0_0.WRITEMODE_B = "NORMAL";
    defparam PALETTE_RAM_0_0_0.GSR = "ENABLED";
    defparam PALETTE_RAM_0_0_0.RESETMODE = "ASYNC";
    defparam PALETTE_RAM_0_0_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam PALETTE_RAM_0_0_0.INIT_DATA = "STATIC";
    defparam PALETTE_RAM_0_0_0.INITVAL_00 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_01 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_02 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_03 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_04 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_05 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_06 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_07 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_08 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_09 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_0F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam PALETTE_RAM_0_0_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    
endmodule
//
// Verilog Description of module OAM
//

module OAM (OB, Clk, nPCLK, nEVAL, BLNK, \Hnn[0] , I_OAM2, PCLK_c, 
            OMSTEP2_N_1188, OMFG_N_1096, OMFG, W4, RESCL, \R2DB[0] , 
            ALE_N_645, SPR_OV, nVIS, Hn0, Hnn0_N_999, OMFG_N_1097, 
            DO_COPY_N_1126, VCC_net, GND_net, DBIN, W3, PAR_O, \Hn[2] ) /* synthesis syn_module_defined=1 */ ;
    output [7:0]OB;
    input Clk;
    input nPCLK;
    input nEVAL;
    input BLNK;
    input \Hnn[0] ;
    input I_OAM2;
    input PCLK_c;
    input OMSTEP2_N_1188;
    input OMFG_N_1096;
    input OMFG;
    input W4;
    input RESCL;
    output \R2DB[0] ;
    input ALE_N_645;
    output SPR_OV;
    input nVIS;
    input Hn0;
    output Hnn0_N_999;
    input OMFG_N_1097;
    input DO_COPY_N_1126;
    input VCC_net;
    input GND_net;
    input [7:0]DBIN;
    input W3;
    input PAR_O;
    input \Hn[2] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]OB_7__N_1156;
    
    wire W4Q4, W4Q4_N_1184, OSTEP1, OSTEP1_N_1194, OAMCTR2;
    wire [7:0]OAMQ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1333[11:15])
    wire [7:0]OAM2Q;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1333[17:22])
    
    wire OAP_N_1216, OAMCTR2_N_1196, OFETCH_N_1215, n8, WE;
    wire [7:0]OB2;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1302[10:13])
    wire [7:0]OAM2Q_7__N_1146;
    
    wire OMSTEP1, W4Q1, W4Q1_N_1174, OMSTEP2, W4Q3, W4Q2, OSTEP2, 
        OSTEP3, OVF_LATCH, OMFG_LATCH, Clk_enable_43, OB2_7__N_1155, 
        ORES_LATCH, ORES_N_1229, W4Q5, n8776, n8626, W4Q3_N_1181, 
        OAMQ_7__N_1145, n2322, n16, n8624, OMV_LATCH, Clk_enable_40, 
        W4FF, ORES, TMV_LATCH, n8755;
    wire [7:0]OAM1ADR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1325[11:18])
    
    wire MODE4_N_1228, n6144, OSTEP_N_1236;
    wire [4:0]OAM2ADR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1324[11:18])
    
    wire n5921, C_OUT_N_1277;
    wire [4:0]OAM2Cout;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1324[20:28])
    
    wire Clk_enable_287, CNT1_N_1080, CNT1_N_1080_adj_1727;
    
    FD1P3AX OB_i0_i0 (.D(OB_7__N_1156[0]), .SP(nPCLK), .CK(Clk), .Q(OB[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB_i0_i0.GSR = "ENABLED";
    LUT4 W4Q4_I_0_1_lut (.A(W4Q4), .Z(W4Q4_N_1184)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1350[12:17])
    defparam W4Q4_I_0_1_lut.init = 16'h5555;
    FD1P3AX OSTEP1_126 (.D(OSTEP1_N_1194), .SP(nPCLK), .CK(Clk), .Q(OSTEP1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OSTEP1_126.GSR = "ENABLED";
    LUT4 i8425_2_lut (.A(nEVAL), .B(OAMCTR2), .Z(OSTEP1_N_1194)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1359[14:35])
    defparam i8425_2_lut.init = 16'hdddd;
    LUT4 mux_67_i8_3_lut (.A(OAMQ[7]), .B(OAM2Q[7]), .C(OAP_N_1216), .Z(OB_7__N_1156[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1355[24:52])
    defparam mux_67_i8_3_lut.init = 16'hcaca;
    LUT4 OAMCTR2_I_0_1_lut (.A(OAMCTR2), .Z(OAMCTR2_N_1196)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1359[25:33])
    defparam OAMCTR2_I_0_1_lut.init = 16'h5555;
    LUT4 i8415_4_lut (.A(BLNK), .B(OFETCH_N_1215), .C(n8), .D(\Hnn[0] ), 
         .Z(WE)) /* synthesis lut_function=(A (B)+!A (B+!(C+!(D)))) */ ;
    defparam i8415_4_lut.init = 16'hcdcc;
    LUT4 i5452_2_lut (.A(OB2[7]), .B(I_OAM2), .Z(OAM2Q_7__N_1146[7])) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1335[68:93])
    defparam i5452_2_lut.init = 16'heeee;
    FD1P3AX OMSTEP1_123 (.D(OFETCH_N_1215), .SP(nPCLK), .CK(Clk), .Q(OMSTEP1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OMSTEP1_123.GSR = "ENABLED";
    FD1P3AX W4Q1_117 (.D(W4Q1_N_1174), .SP(PCLK_c), .CK(Clk), .Q(W4Q1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam W4Q1_117.GSR = "ENABLED";
    FD1P3AX OMSTEP2_124 (.D(OMSTEP2_N_1188), .SP(nPCLK), .CK(Clk), .Q(OMSTEP2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OMSTEP2_124.GSR = "ENABLED";
    FD1P3AX W4Q3_118 (.D(W4Q2), .SP(PCLK_c), .CK(Clk), .Q(W4Q3));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam W4Q3_118.GSR = "ENABLED";
    LUT4 i5451_2_lut (.A(OB2[6]), .B(I_OAM2), .Z(OAM2Q_7__N_1146[6])) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1335[68:93])
    defparam i5451_2_lut.init = 16'heeee;
    LUT4 i5450_2_lut (.A(OB2[5]), .B(I_OAM2), .Z(OAM2Q_7__N_1146[5])) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1335[68:93])
    defparam i5450_2_lut.init = 16'heeee;
    LUT4 i5449_2_lut (.A(OB2[4]), .B(I_OAM2), .Z(OAM2Q_7__N_1146[4])) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1335[68:93])
    defparam i5449_2_lut.init = 16'heeee;
    FD1P3AX OSTEP2_127 (.D(I_OAM2), .SP(nPCLK), .CK(Clk), .Q(OSTEP2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OSTEP2_127.GSR = "ENABLED";
    LUT4 i5448_2_lut (.A(OB2[3]), .B(I_OAM2), .Z(OAM2Q_7__N_1146[3])) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1335[68:93])
    defparam i5448_2_lut.init = 16'heeee;
    FD1P3AX OSTEP3_128 (.D(OMFG_N_1096), .SP(nPCLK), .CK(Clk), .Q(OSTEP3));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OSTEP3_128.GSR = "ENABLED";
    FD1P3AX OB_i0_i2 (.D(OB_7__N_1156[2]), .SP(nPCLK), .CK(Clk), .Q(OB[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB_i0_i2.GSR = "ENABLED";
    FD1P3AX OB_i0_i6 (.D(OB_7__N_1156[6]), .SP(nPCLK), .CK(Clk), .Q(OB[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB_i0_i6.GSR = "ENABLED";
    LUT4 i5447_2_lut (.A(OB2[2]), .B(I_OAM2), .Z(OAM2Q_7__N_1146[2])) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1335[68:93])
    defparam i5447_2_lut.init = 16'heeee;
    FD1P3AX OVF_LATCH_129 (.D(OAMCTR2_N_1196), .SP(nPCLK), .CK(Clk), .Q(OVF_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OVF_LATCH_129.GSR = "ENABLED";
    LUT4 i5446_2_lut (.A(OB2[1]), .B(I_OAM2), .Z(OAM2Q_7__N_1146[1])) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1335[68:93])
    defparam i5446_2_lut.init = 16'heeee;
    LUT4 i5291_2_lut (.A(OB2[0]), .B(I_OAM2), .Z(OAM2Q_7__N_1146[0])) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1335[68:93])
    defparam i5291_2_lut.init = 16'heeee;
    FD1P3AX OMFG_LATCH_130 (.D(OMFG), .SP(nPCLK), .CK(Clk), .Q(OMFG_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OMFG_LATCH_130.GSR = "ENABLED";
    FD1P3AX OB_i0_i1 (.D(OB_7__N_1156[1]), .SP(nPCLK), .CK(Clk), .Q(OB[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB_i0_i1.GSR = "ENABLED";
    FD1P3AX OB_i0_i5 (.D(OB_7__N_1156[5]), .SP(nPCLK), .CK(Clk), .Q(OB[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB_i0_i5.GSR = "ENABLED";
    LUT4 i1_2_lut_2_lut (.A(W4), .B(W4Q4), .Z(Clk_enable_43)) /* synthesis lut_function=(A+!(B)) */ ;
    defparam i1_2_lut_2_lut.init = 16'hbbbb;
    FD1P3AX OB2_i0_i0 (.D(OB[0]), .SP(OB2_7__N_1155), .CK(Clk), .Q(OB2[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB2_i0_i0.GSR = "ENABLED";
    LUT4 nPCLK_I_0_150_2_lut_2_lut (.A(PCLK_c), .B(ORES_LATCH), .Z(ORES_N_1229)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1320[18:40])
    defparam nPCLK_I_0_150_2_lut_2_lut.init = 16'hdddd;
    FD1P3AX W4Q5_119 (.D(W4Q4_N_1184), .SP(PCLK_c), .CK(Clk), .Q(W4Q5));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam W4Q5_119.GSR = "ENABLED";
    LUT4 i1_4_lut (.A(RESCL), .B(\R2DB[0] ), .C(ALE_N_645), .D(n8776), 
         .Z(n8626)) /* synthesis lut_function=(!(A+!(B+!(C+(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam i1_4_lut.init = 16'h4445;
    LUT4 i8176_2_lut (.A(OMFG_LATCH), .B(OVF_LATCH), .Z(n8776)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i8176_2_lut.init = 16'heeee;
    LUT4 mux_67_i2_3_lut (.A(OAMQ[1]), .B(OAM2Q[1]), .C(OAP_N_1216), .Z(OB_7__N_1156[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1355[24:52])
    defparam mux_67_i2_3_lut.init = 16'hcaca;
    FD1P3AX OB_i0_i4 (.D(OB_7__N_1156[4]), .SP(nPCLK), .CK(Clk), .Q(OB[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB_i0_i4.GSR = "ENABLED";
    FD1P3AX OB_i0_i3 (.D(OB_7__N_1156[3]), .SP(nPCLK), .CK(Clk), .Q(OB[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB_i0_i3.GSR = "ENABLED";
    LUT4 mux_67_i6_3_lut (.A(OAMQ[5]), .B(OAM2Q[5]), .C(OAP_N_1216), .Z(OB_7__N_1156[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1355[24:52])
    defparam mux_67_i6_3_lut.init = 16'hcaca;
    FD1P3AX W4Q2_120 (.D(W4Q1), .SP(nPCLK), .CK(Clk), .Q(W4Q2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam W4Q2_120.GSR = "ENABLED";
    LUT4 W4Q3_I_0_1_lut (.A(W4Q3), .Z(W4Q3_N_1181)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1307[20:25])
    defparam W4Q3_I_0_1_lut.init = 16'h5555;
    LUT4 i3_3_lut_4_lut (.A(SPR_OV), .B(OAMCTR2), .C(PCLK_c), .D(nVIS), 
         .Z(n8)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1305[17:66])
    defparam i3_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_3_lut_3_lut (.A(BLNK), .B(W4Q5), .C(W4Q3), .Z(OAMQ_7__N_1145)) /* synthesis lut_function=(!((B+!(C))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1334[41:52])
    defparam i1_3_lut_3_lut.init = 16'h2020;
    FD1P3AX W4Q4_121 (.D(W4Q3_N_1181), .SP(nPCLK), .CK(Clk), .Q(W4Q4));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam W4Q4_121.GSR = "ENABLED";
    LUT4 OMSTEP_I_305_2_lut (.A(OMSTEP1), .B(OMSTEP2), .Z(n2322)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1316[18:62])
    defparam OMSTEP_I_305_2_lut.init = 16'h4444;
    LUT4 i1_4_lut_adj_430 (.A(I_OAM2), .B(SPR_OV), .C(PCLK_c), .D(n16), 
         .Z(n8624)) /* synthesis lut_function=(!(A+!(B+(C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam i1_4_lut_adj_430.init = 16'h5444;
    LUT4 i1_4_lut_adj_431 (.A(Hn0), .B(OMV_LATCH), .C(n8776), .D(n2322), 
         .Z(n16)) /* synthesis lut_function=(!(A ((D)+!B)+!A (B (C (D))+!B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam i1_4_lut_adj_431.init = 16'h05cd;
    FD1S3AX R2DB5_113 (.D(n8626), .CK(Clk), .Q(\R2DB[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam R2DB5_113.GSR = "ENABLED";
    FD1S3AX SPR_OV_114 (.D(n8624), .CK(Clk), .Q(SPR_OV));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam SPR_OV_114.GSR = "ENABLED";
    FD1P3AX OAMCTR2_115 (.D(ORES_N_1229), .SP(Clk_enable_40), .CK(Clk), 
            .Q(OAMCTR2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OAMCTR2_115.GSR = "ENABLED";
    FD1P3AX W4FF_112 (.D(W4Q4), .SP(Clk_enable_43), .CK(Clk), .Q(W4FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam W4FF_112.GSR = "ENABLED";
    LUT4 ORES_I_0_1_lut_2_lut (.A(PCLK_c), .B(ORES_LATCH), .Z(ORES)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1320[17:40])
    defparam ORES_I_0_1_lut_2_lut.init = 16'h2222;
    FD1P3AX ORES_LATCH_125 (.D(nEVAL), .SP(nPCLK), .CK(Clk), .Q(ORES_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam ORES_LATCH_125.GSR = "ENABLED";
    FD1P3AX OB_i0_i7 (.D(OB_7__N_1156[7]), .SP(nPCLK), .CK(Clk), .Q(OB[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB_i0_i7.GSR = "ENABLED";
    LUT4 i1_4_lut_adj_432 (.A(PCLK_c), .B(TMV_LATCH), .C(ORES_LATCH), 
         .D(n8755), .Z(Clk_enable_40)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))) */ ;
    defparam i1_4_lut_adj_432.init = 16'h8a0a;
    LUT4 i8608_4_lut (.A(PCLK_c), .B(OAM1ADR[0]), .C(MODE4_N_1228), .D(OAM1ADR[1]), 
         .Z(n6144)) /* synthesis lut_function=(!(A+(B (C (D))+!B !(C+(D))))) */ ;
    defparam i8608_4_lut.init = 16'h1554;
    LUT4 Hn0_I_0_3_lut (.A(Hn0), .B(OSTEP2), .C(OSTEP3), .Z(OSTEP_N_1236)) /* synthesis lut_function=(A+!(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1322[59:88])
    defparam Hn0_I_0_3_lut.init = 16'habab;
    FD1P3AX OB2_i0_i1 (.D(OB[1]), .SP(OB2_7__N_1155), .CK(Clk), .Q(OB2[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB2_i0_i1.GSR = "ENABLED";
    LUT4 i8504_2_lut (.A(OAM2ADR[4]), .B(PCLK_c), .Z(n5921)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i8504_2_lut.init = 16'h1111;
    FD1P3AX OB2_i0_i2 (.D(OB[2]), .SP(OB2_7__N_1155), .CK(Clk), .Q(OB2[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB2_i0_i2.GSR = "ENABLED";
    FD1P3AX OB2_i0_i3 (.D(OB[3]), .SP(OB2_7__N_1155), .CK(Clk), .Q(OB2[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB2_i0_i3.GSR = "ENABLED";
    FD1P3AX OB2_i0_i4 (.D(OB[4]), .SP(OB2_7__N_1155), .CK(Clk), .Q(OB2[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB2_i0_i4.GSR = "ENABLED";
    FD1P3AX OB2_i0_i5 (.D(OB[5]), .SP(OB2_7__N_1155), .CK(Clk), .Q(OB2[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB2_i0_i5.GSR = "ENABLED";
    FD1P3AX OB2_i0_i6 (.D(OB[6]), .SP(OB2_7__N_1155), .CK(Clk), .Q(OB2[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB2_i0_i6.GSR = "ENABLED";
    FD1P3AX OB2_i0_i7 (.D(OB[7]), .SP(OB2_7__N_1155), .CK(Clk), .Q(OB2[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=2, LSE_LLINE=377, LSE_RLINE=397 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OB2_i0_i7.GSR = "ENABLED";
    LUT4 Hnn0_I_0_1_lut (.A(\Hnn[0] ), .Z(Hnn0_N_999)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1188[30:35])
    defparam Hnn0_I_0_1_lut.init = 16'h5555;
    LUT4 mux_67_i1_3_lut (.A(OAMQ[0]), .B(OAM2Q[0]), .C(OAP_N_1216), .Z(OB_7__N_1156[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1355[24:52])
    defparam mux_67_i1_3_lut.init = 16'hcaca;
    LUT4 i8413_2_lut (.A(W4Q3), .B(W4Q5), .Z(OFETCH_N_1215)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1307[17:34])
    defparam i8413_2_lut.init = 16'h2222;
    LUT4 i8421_2_lut (.A(W4), .B(W4FF), .Z(W4Q1_N_1174)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1348[12:27])
    defparam i8421_2_lut.init = 16'h4444;
    LUT4 i8519_2_lut (.A(BLNK), .B(PCLK_c), .Z(OB2_7__N_1155)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1346[10:26])
    defparam i8519_2_lut.init = 16'h4444;
    LUT4 mux_67_i3_3_lut (.A(OAMQ[2]), .B(OAM2Q[2]), .C(OAP_N_1216), .Z(OB_7__N_1156[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1355[24:52])
    defparam mux_67_i3_3_lut.init = 16'hcaca;
    LUT4 OAP_I_300_3_lut (.A(\Hnn[0] ), .B(BLNK), .C(nVIS), .Z(OAP_N_1216)) /* synthesis lut_function=(!(A (B)+!A (B+!(C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1311[15:41])
    defparam OAP_I_300_3_lut.init = 16'h3232;
    LUT4 mux_67_i7_3_lut (.A(OAMQ[6]), .B(OAM2Q[6]), .C(OAP_N_1216), .Z(OB_7__N_1156[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1355[24:52])
    defparam mux_67_i7_3_lut.init = 16'hcaca;
    LUT4 mux_67_i5_3_lut (.A(OAMQ[4]), .B(OAM2Q[4]), .C(OAP_N_1216), .Z(OB_7__N_1156[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1355[24:52])
    defparam mux_67_i5_3_lut.init = 16'hcaca;
    LUT4 mux_67_i4_3_lut (.A(OAMQ[3]), .B(OAM2Q[3]), .C(OAP_N_1216), .Z(OB_7__N_1156[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1355[24:52])
    defparam mux_67_i4_3_lut.init = 16'hcaca;
    FD1P3IX OMV_LATCH_131 (.D(C_OUT_N_1277), .SP(nPCLK), .CD(n6144), .CK(Clk), 
            .Q(OMV_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam OMV_LATCH_131.GSR = "ENABLED";
    LUT4 OMFG_N_1203_I_0_2_lut_3_lut (.A(OMFG_N_1097), .B(DO_COPY_N_1126), 
         .C(BLNK), .Z(MODE4_N_1228)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1318[18:34])
    defparam OMFG_N_1203_I_0_2_lut_3_lut.init = 16'hfefe;
    FD1P3IX TMV_LATCH_132 (.D(OAM2Cout[3]), .SP(nPCLK), .CD(n5921), .CK(Clk), 
            .Q(TMV_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1337[8] 1367[26])
    defparam TMV_LATCH_132.GSR = "ENABLED";
    OAM_RAM OAMQ_7__I_0 (.Clk(Clk), .VCC_net(VCC_net), .GND_net(GND_net), 
            .OAMQ_7__N_1145(OAMQ_7__N_1145), .OAM1ADR({OAM1ADR}), .DBIN({DBIN}), 
            .OAMQ({OAMQ})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1334[10:106])
    OAM_COUNTER OAMCNT (.W3(W3), .PCLK_c(PCLK_c), .OMSTEP1(OMSTEP1), .OMSTEP2(OMSTEP2), 
            .OAM1ADR({OAM1ADR}), .MODE4_N_1228(MODE4_N_1228), .Clk(Clk), 
            .PAR_O(PAR_O), .DBIN({DBIN}), .C_OUT_N_1277(C_OUT_N_1277)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1328[13:81])
    OAM2_RAM OAM2Q_7__I_0 (.Clk(Clk), .VCC_net(VCC_net), .GND_net(GND_net), 
            .WE(WE), .OAM2ADR({OAM2ADR}), .OAM2Q_7__N_1146({OAM2Q_7__N_1146}), 
            .OAM2Q({OAM2Q})) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1335[10:106])
    COUNTER_U36 OAM2CNT_4 (.PCLK_c(PCLK_c), .n8755(n8755), .ORES_LATCH(ORES_LATCH), 
            .Clk_enable_287(Clk_enable_287), .Clk(Clk), .nPCLK(nPCLK), 
            .OSTEP1(OSTEP1), .PAR_O(PAR_O), .OSTEP_N_1236(OSTEP_N_1236), 
            .\Hn[2] (\Hn[2] ), .\OAM2ADR[4] (OAM2ADR[4]), .\OAM2Cout[3] (OAM2Cout[3]), 
            .ORES(ORES)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1331[9:112])
    COUNTER_U37 OAM2CNT_3 (.Clk(Clk), .nPCLK(nPCLK), .CNT1_N_1080(CNT1_N_1080), 
            .\OAM2ADR[3] (OAM2ADR[3]), .Clk_enable_287(Clk_enable_287), 
            .ORES(ORES)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1331[9:112])
    COUNTER_U38 OAM2CNT_2 (.Clk(Clk), .nPCLK(nPCLK), .CNT1_N_1080(CNT1_N_1080_adj_1727), 
            .\OAM2ADR[2] (OAM2ADR[2]), .Clk_enable_287(Clk_enable_287), 
            .ORES(ORES)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1331[9:112])
    COUNTER_U39 OAM2CNT_1 (.Clk(Clk), .nPCLK(nPCLK), .\OAM2ADR[1] (OAM2ADR[1]), 
            .\OAM2ADR[0] (OAM2ADR[0]), .\OAM2ADR[3] (OAM2ADR[3]), .\OAM2ADR[2] (OAM2ADR[2]), 
            .CNT1_N_1080(CNT1_N_1080), .\OAM2Cout[3] (OAM2Cout[3]), .CNT1_N_1080_adj_1(CNT1_N_1080_adj_1727), 
            .Clk_enable_287(Clk_enable_287), .ORES(ORES)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1331[9:112])
    COUNTER_U40 OAM2CNT_0 (.Clk(Clk), .nPCLK(nPCLK), .\OAM2ADR[0] (OAM2ADR[0]), 
            .Clk_enable_287(Clk_enable_287), .ORES(ORES)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1331[9:112])
    
endmodule
//
// Verilog Description of module OAM_RAM
//

module OAM_RAM (Clk, VCC_net, GND_net, OAMQ_7__N_1145, OAM1ADR, DBIN, 
            OAMQ) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input Clk;
    input VCC_net;
    input GND_net;
    input OAMQ_7__N_1145;
    input [7:0]OAM1ADR;
    input [7:0]DBIN;
    output [7:0]OAMQ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    DP8KC OAM_RAM_0_0_0 (.DIA0(DBIN[0]), .DIA1(DBIN[1]), .DIA2(DBIN[2]), 
          .DIA3(DBIN[3]), .DIA4(DBIN[4]), .DIA5(DBIN[5]), .DIA6(DBIN[6]), 
          .DIA7(DBIN[7]), .DIA8(GND_net), .ADA0(VCC_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(OAM1ADR[0]), .ADA4(OAM1ADR[1]), .ADA5(OAM1ADR[2]), 
          .ADA6(OAM1ADR[3]), .ADA7(OAM1ADR[4]), .ADA8(OAM1ADR[5]), .ADA9(OAM1ADR[6]), 
          .ADA10(OAM1ADR[7]), .ADA11(GND_net), .ADA12(GND_net), .CEA(VCC_net), 
          .OCEA(VCC_net), .CLKA(Clk), .WEA(OAMQ_7__N_1145), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(GND_net), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), 
          .ADB4(GND_net), .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), 
          .ADB8(GND_net), .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), 
          .ADB12(GND_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(GND_net), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(OAMQ[0]), .DOA1(OAMQ[1]), .DOA2(OAMQ[2]), 
          .DOA3(OAMQ[3]), .DOA4(OAMQ[4]), .DOA5(OAMQ[5]), .DOA6(OAMQ[6]), 
          .DOA7(OAMQ[7])) /* synthesis MEM_LPC_FILE="OAM_RAM.lpc", MEM_INIT_FILE="INIT_ALL_0s", syn_instantiated=1, LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=106, LSE_LLINE=1334, LSE_RLINE=1334 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1334[10:106])
    defparam OAM_RAM_0_0_0.DATA_WIDTH_A = 9;
    defparam OAM_RAM_0_0_0.DATA_WIDTH_B = 9;
    defparam OAM_RAM_0_0_0.REGMODE_A = "OUTREG";
    defparam OAM_RAM_0_0_0.REGMODE_B = "NOREG";
    defparam OAM_RAM_0_0_0.CSDECODE_A = "0b000";
    defparam OAM_RAM_0_0_0.CSDECODE_B = "0b111";
    defparam OAM_RAM_0_0_0.WRITEMODE_A = "NORMAL";
    defparam OAM_RAM_0_0_0.WRITEMODE_B = "NORMAL";
    defparam OAM_RAM_0_0_0.GSR = "ENABLED";
    defparam OAM_RAM_0_0_0.RESETMODE = "SYNC";
    defparam OAM_RAM_0_0_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam OAM_RAM_0_0_0.INIT_DATA = "STATIC";
    defparam OAM_RAM_0_0_0.INITVAL_00 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_01 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_02 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_03 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_04 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_05 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_06 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_07 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_08 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_09 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_0F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM_RAM_0_0_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    
endmodule
//
// Verilog Description of module OAM_COUNTER
//

module OAM_COUNTER (W3, PCLK_c, OMSTEP1, OMSTEP2, OAM1ADR, MODE4_N_1228, 
            Clk, PAR_O, DBIN, C_OUT_N_1277) /* synthesis syn_module_defined=1 */ ;
    input W3;
    input PCLK_c;
    input OMSTEP1;
    input OMSTEP2;
    output [7:0]OAM1ADR;
    input MODE4_N_1228;
    input Clk;
    input PAR_O;
    input [7:0]DBIN;
    output C_OUT_N_1277;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT_7__N_1264, n3599;
    wire [7:0]CNT1_7__N_1265;
    wire [7:0]OAM1Cout;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1756[11:19])
    
    wire n3560, n5948;
    wire [7:0]CNT1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1755[10:14])
    wire [7:0]n73;
    
    wire n3602, Clk_enable_286;
    wire [7:0]n44;
    
    wire CNT_0__N_1287;
    
    LUT4 i8404_3_lut_4_lut (.A(W3), .B(PCLK_c), .C(OMSTEP1), .D(OMSTEP2), 
         .Z(CNT_7__N_1264)) /* synthesis lut_function=(!(A+(B (C+!(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1765[13:24])
    defparam i8404_3_lut_4_lut.init = 16'h1511;
    LUT4 i2182_2_lut_3_lut (.A(OAM1ADR[4]), .B(n3599), .C(OAM1ADR[5]), 
         .Z(CNT1_7__N_1265[5])) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1766[48:112])
    defparam i2182_2_lut_3_lut.init = 16'h7878;
    LUT4 i2183_3_lut_4_lut (.A(OAM1ADR[4]), .B(n3599), .C(OAM1ADR[5]), 
         .D(OAM1ADR[6]), .Z(CNT1_7__N_1265[6])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1766[48:112])
    defparam i2183_3_lut_4_lut.init = 16'h7f80;
    LUT4 i2184_3_lut_4_lut (.A(MODE4_N_1228), .B(OAM1Cout[1]), .C(n3560), 
         .D(OAM1ADR[7]), .Z(CNT1_7__N_1265[7])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A (C (D)+!C !(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1766[48:112])
    defparam i2184_3_lut_4_lut.init = 16'h2fd0;
    LUT4 i2180_3_lut_4_lut (.A(MODE4_N_1228), .B(OAM1Cout[1]), .C(OAM1ADR[2]), 
         .D(OAM1ADR[3]), .Z(CNT1_7__N_1265[3])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A (C (D)+!C !(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1766[48:112])
    defparam i2180_3_lut_4_lut.init = 16'h2fd0;
    LUT4 i8532_2_lut (.A(CNT_7__N_1264), .B(MODE4_N_1228), .Z(n5948)) /* synthesis lut_function=(!((B)+!A)) */ ;
    defparam i8532_2_lut.init = 16'h2222;
    LUT4 mux_31_i3_3_lut_4_lut (.A(OAM1ADR[2]), .B(OAM1ADR[1]), .C(OAM1ADR[0]), 
         .D(MODE4_N_1228), .Z(CNT1_7__N_1265[2])) /* synthesis lut_function=(!(A (B (C+!(D))+!B !(D))+!A !(B (C+!(D))+!B !(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1766[48:112])
    defparam mux_31_i3_3_lut_4_lut.init = 16'h6a55;
    FD1P3IX CNT1_i0_i1 (.D(n73[1]), .SP(CNT_7__N_1264), .CD(n5948), .CK(Clk), 
            .Q(CNT1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT1_i0_i1.GSR = "ENABLED";
    LUT4 xor_30_i2_2_lut (.A(OAM1ADR[1]), .B(OAM1ADR[0]), .Z(n73[1])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1766[78:112])
    defparam xor_30_i2_2_lut.init = 16'h6666;
    LUT4 i1_2_lut_3_lut_4_lut (.A(MODE4_N_1228), .B(OAM1ADR[1]), .C(OAM1ADR[0]), 
         .D(n3602), .Z(n3599)) /* synthesis lut_function=(A (B (C (D)))+!A (D)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1766[48:112])
    defparam i1_2_lut_3_lut_4_lut.init = 16'hd500;
    LUT4 i1_2_lut (.A(CNT_7__N_1264), .B(PAR_O), .Z(Clk_enable_286)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1765[13:32])
    defparam i1_2_lut.init = 16'hdddd;
    LUT4 mux_25_i8_3_lut (.A(CNT1[7]), .B(DBIN[7]), .C(W3), .Z(n44[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1765[64:92])
    defparam mux_25_i8_3_lut.init = 16'hcaca;
    LUT4 mux_25_i7_3_lut (.A(CNT1[6]), .B(DBIN[6]), .C(W3), .Z(n44[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1765[64:92])
    defparam mux_25_i7_3_lut.init = 16'hcaca;
    LUT4 mux_25_i6_3_lut (.A(CNT1[5]), .B(DBIN[5]), .C(W3), .Z(n44[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1765[64:92])
    defparam mux_25_i6_3_lut.init = 16'hcaca;
    LUT4 mux_25_i5_3_lut (.A(CNT1[4]), .B(DBIN[4]), .C(W3), .Z(n44[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1765[64:92])
    defparam mux_25_i5_3_lut.init = 16'hcaca;
    LUT4 mux_25_i4_3_lut (.A(CNT1[3]), .B(DBIN[3]), .C(W3), .Z(n44[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1765[64:92])
    defparam mux_25_i4_3_lut.init = 16'hcaca;
    LUT4 mux_25_i3_3_lut (.A(CNT1[2]), .B(DBIN[2]), .C(W3), .Z(n44[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1765[64:92])
    defparam mux_25_i3_3_lut.init = 16'hcaca;
    LUT4 mux_25_i2_3_lut (.A(CNT1[1]), .B(DBIN[1]), .C(W3), .Z(n44[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1765[64:92])
    defparam mux_25_i2_3_lut.init = 16'hcaca;
    LUT4 CNT_7__I_0_38_i2_2_lut (.A(OAM1ADR[1]), .B(OAM1ADR[0]), .Z(OAM1Cout[1])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1757[24:55])
    defparam CNT_7__I_0_38_i2_2_lut.init = 16'h8888;
    LUT4 i2181_2_lut (.A(OAM1ADR[4]), .B(n3599), .Z(CNT1_7__N_1265[4])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1766[48:112])
    defparam i2181_2_lut.init = 16'h6666;
    LUT4 i1_2_lut_adj_428 (.A(OAM1ADR[2]), .B(OAM1ADR[3]), .Z(n3602)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1763[26:77])
    defparam i1_2_lut_adj_428.init = 16'h8888;
    LUT4 i3_4_lut (.A(OAM1ADR[4]), .B(OAM1ADR[5]), .C(OAM1ADR[6]), .D(n3602), 
         .Z(n3560)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1763[26:77])
    defparam i3_4_lut.init = 16'h8000;
    LUT4 mux_25_i1_3_lut (.A(CNT1[0]), .B(DBIN[0]), .C(W3), .Z(n44[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1765[64:92])
    defparam mux_25_i1_3_lut.init = 16'hcaca;
    LUT4 i1_2_lut_adj_429 (.A(OAM1ADR[7]), .B(n3560), .Z(C_OUT_N_1277)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1763[26:77])
    defparam i1_2_lut_adj_429.init = 16'h8888;
    FD1P3IX CNT__i7 (.D(n44[7]), .SP(Clk_enable_286), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT__i7.GSR = "ENABLED";
    FD1P3IX CNT__i6 (.D(n44[6]), .SP(Clk_enable_286), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT__i6.GSR = "ENABLED";
    FD1P3IX CNT__i5 (.D(n44[5]), .SP(Clk_enable_286), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT__i5.GSR = "ENABLED";
    FD1P3IX CNT__i4 (.D(n44[4]), .SP(Clk_enable_286), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT__i4.GSR = "ENABLED";
    FD1P3IX CNT__i3 (.D(n44[3]), .SP(Clk_enable_286), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT__i3.GSR = "ENABLED";
    FD1P3IX CNT__i2 (.D(n44[2]), .SP(Clk_enable_286), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT__i2.GSR = "ENABLED";
    FD1P3IX CNT__i1 (.D(n44[1]), .SP(Clk_enable_286), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT__i1.GSR = "ENABLED";
    FD1P3IX CNT1_i0_i0 (.D(CNT_0__N_1287), .SP(CNT_7__N_1264), .CD(n5948), 
            .CK(Clk), .Q(CNT1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT1_i0_i0.GSR = "ENABLED";
    LUT4 i1616_1_lut (.A(OAM1ADR[0]), .Z(CNT_0__N_1287)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1766[78:112])
    defparam i1616_1_lut.init = 16'h5555;
    FD1P3AX CNT1_i0_i2 (.D(CNT1_7__N_1265[2]), .SP(CNT_7__N_1264), .CK(Clk), 
            .Q(CNT1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT1_i0_i2.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i3 (.D(CNT1_7__N_1265[3]), .SP(CNT_7__N_1264), .CK(Clk), 
            .Q(CNT1[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT1_i0_i3.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i4 (.D(CNT1_7__N_1265[4]), .SP(CNT_7__N_1264), .CK(Clk), 
            .Q(CNT1[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT1_i0_i4.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i5 (.D(CNT1_7__N_1265[5]), .SP(CNT_7__N_1264), .CK(Clk), 
            .Q(CNT1[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT1_i0_i5.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i6 (.D(CNT1_7__N_1265[6]), .SP(CNT_7__N_1264), .CK(Clk), 
            .Q(CNT1[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT1_i0_i6.GSR = "ENABLED";
    FD1P3AX CNT1_i0_i7 (.D(CNT1_7__N_1265[7]), .SP(CNT_7__N_1264), .CK(Clk), 
            .Q(CNT1[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT1_i0_i7.GSR = "ENABLED";
    FD1P3IX CNT__i0 (.D(n44[0]), .SP(Clk_enable_286), .CD(PAR_O), .CK(Clk), 
            .Q(OAM1ADR[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=13, LSE_RCOL=81, LSE_LLINE=1328, LSE_RLINE=1328 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1764[8] 1767[26])
    defparam CNT__i0.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module OAM2_RAM
//

module OAM2_RAM (Clk, VCC_net, GND_net, WE, OAM2ADR, OAM2Q_7__N_1146, 
            OAM2Q) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input Clk;
    input VCC_net;
    input GND_net;
    input WE;
    input [4:0]OAM2ADR;
    input [7:0]OAM2Q_7__N_1146;
    output [7:0]OAM2Q;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    DP8KC OAM2_RAM_0_0_0 (.DIA0(OAM2Q_7__N_1146[0]), .DIA1(OAM2Q_7__N_1146[1]), 
          .DIA2(OAM2Q_7__N_1146[2]), .DIA3(OAM2Q_7__N_1146[3]), .DIA4(OAM2Q_7__N_1146[4]), 
          .DIA5(OAM2Q_7__N_1146[5]), .DIA6(OAM2Q_7__N_1146[6]), .DIA7(OAM2Q_7__N_1146[7]), 
          .DIA8(GND_net), .ADA0(VCC_net), .ADA1(GND_net), .ADA2(GND_net), 
          .ADA3(OAM2ADR[0]), .ADA4(OAM2ADR[1]), .ADA5(OAM2ADR[2]), .ADA6(OAM2ADR[3]), 
          .ADA7(OAM2ADR[4]), .ADA8(GND_net), .ADA9(GND_net), .ADA10(GND_net), 
          .ADA11(GND_net), .ADA12(GND_net), .CEA(VCC_net), .OCEA(VCC_net), 
          .CLKA(Clk), .WEA(WE), .CSA0(GND_net), .CSA1(GND_net), .CSA2(GND_net), 
          .RSTA(GND_net), .DIB0(GND_net), .DIB1(GND_net), .DIB2(GND_net), 
          .DIB3(GND_net), .DIB4(GND_net), .DIB5(GND_net), .DIB6(GND_net), 
          .DIB7(GND_net), .DIB8(GND_net), .ADB0(GND_net), .ADB1(GND_net), 
          .ADB2(GND_net), .ADB3(GND_net), .ADB4(GND_net), .ADB5(GND_net), 
          .ADB6(GND_net), .ADB7(GND_net), .ADB8(GND_net), .ADB9(GND_net), 
          .ADB10(GND_net), .ADB11(GND_net), .ADB12(GND_net), .CEB(VCC_net), 
          .OCEB(VCC_net), .CLKB(GND_net), .WEB(GND_net), .CSB0(GND_net), 
          .CSB1(GND_net), .CSB2(GND_net), .RSTB(GND_net), .DOA0(OAM2Q[0]), 
          .DOA1(OAM2Q[1]), .DOA2(OAM2Q[2]), .DOA3(OAM2Q[3]), .DOA4(OAM2Q[4]), 
          .DOA5(OAM2Q[5]), .DOA6(OAM2Q[6]), .DOA7(OAM2Q[7])) /* synthesis MEM_LPC_FILE="OAM2_RAM.lpc", MEM_INIT_FILE="INIT_ALL_0s", syn_instantiated=1, LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=106, LSE_LLINE=1335, LSE_RLINE=1335 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1335[10:106])
    defparam OAM2_RAM_0_0_0.DATA_WIDTH_A = 9;
    defparam OAM2_RAM_0_0_0.DATA_WIDTH_B = 9;
    defparam OAM2_RAM_0_0_0.REGMODE_A = "OUTREG";
    defparam OAM2_RAM_0_0_0.REGMODE_B = "NOREG";
    defparam OAM2_RAM_0_0_0.CSDECODE_A = "0b000";
    defparam OAM2_RAM_0_0_0.CSDECODE_B = "0b111";
    defparam OAM2_RAM_0_0_0.WRITEMODE_A = "NORMAL";
    defparam OAM2_RAM_0_0_0.WRITEMODE_B = "NORMAL";
    defparam OAM2_RAM_0_0_0.GSR = "ENABLED";
    defparam OAM2_RAM_0_0_0.RESETMODE = "SYNC";
    defparam OAM2_RAM_0_0_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam OAM2_RAM_0_0_0.INIT_DATA = "STATIC";
    defparam OAM2_RAM_0_0_0.INITVAL_00 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_01 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_02 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_03 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_04 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_05 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_06 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_07 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_08 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_09 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_0F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam OAM2_RAM_0_0_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    
endmodule
//
// Verilog Description of module COUNTER_U36
//

module COUNTER_U36 (PCLK_c, n8755, ORES_LATCH, Clk_enable_287, Clk, 
            nPCLK, OSTEP1, PAR_O, OSTEP_N_1236, \Hn[2] , \OAM2ADR[4] , 
            \OAM2Cout[3] , ORES) /* synthesis syn_module_defined=1 */ ;
    input PCLK_c;
    output n8755;
    input ORES_LATCH;
    output Clk_enable_287;
    input Clk;
    input nPCLK;
    input OSTEP1;
    input PAR_O;
    input OSTEP_N_1236;
    input \Hn[2] ;
    output \OAM2ADR[4] ;
    input \OAM2Cout[3] ;
    input ORES;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT1, CNT1_N_1080;
    
    LUT4 i1_3_lut (.A(PCLK_c), .B(n8755), .C(ORES_LATCH), .Z(Clk_enable_287)) /* synthesis lut_function=(A (B+!(C))) */ ;
    defparam i1_3_lut.init = 16'h8a8a;
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    LUT4 i1_4_lut (.A(OSTEP1), .B(PAR_O), .C(OSTEP_N_1236), .D(\Hn[2] ), 
         .Z(n8755)) /* synthesis lut_function=(!(A+(B (C (D))+!B (C)))) */ ;
    defparam i1_4_lut.init = 16'h0545;
    LUT4 CNT_I_0_2_lut (.A(\OAM2ADR[4] ), .B(\OAM2Cout[3] ), .Z(CNT1_N_1080)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1735[23:33])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_287), .CD(ORES), .CK(Clk), 
            .Q(\OAM2ADR[4] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U37
//

module COUNTER_U37 (Clk, nPCLK, CNT1_N_1080, \OAM2ADR[3] , Clk_enable_287, 
            ORES) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    input CNT1_N_1080;
    output \OAM2ADR[3] ;
    input Clk_enable_287;
    input ORES;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_287), .CD(ORES), .CK(Clk), 
            .Q(\OAM2ADR[3] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U38
//

module COUNTER_U38 (Clk, nPCLK, CNT1_N_1080, \OAM2ADR[2] , Clk_enable_287, 
            ORES) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    input CNT1_N_1080;
    output \OAM2ADR[2] ;
    input Clk_enable_287;
    input ORES;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT1;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_287), .CD(ORES), .CK(Clk), 
            .Q(\OAM2ADR[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U39
//

module COUNTER_U39 (Clk, nPCLK, \OAM2ADR[1] , \OAM2ADR[0] , \OAM2ADR[3] , 
            \OAM2ADR[2] , CNT1_N_1080, \OAM2Cout[3] , CNT1_N_1080_adj_1, 
            Clk_enable_287, ORES) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    output \OAM2ADR[1] ;
    input \OAM2ADR[0] ;
    input \OAM2ADR[3] ;
    input \OAM2ADR[2] ;
    output CNT1_N_1080;
    output \OAM2Cout[3] ;
    output CNT1_N_1080_adj_1;
    input Clk_enable_287;
    input ORES;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT1, CNT1_N_1080_c;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080_c), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    LUT4 CNT_I_0_2_lut_3_lut_4_lut (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), 
         .C(\OAM2ADR[3] ), .D(\OAM2ADR[2] ), .Z(CNT1_N_1080)) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1731[16:26])
    defparam CNT_I_0_2_lut_3_lut_4_lut.init = 16'h78f0;
    LUT4 CNT_I_0_18_2_lut_3_lut_4_lut (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), 
         .C(\OAM2ADR[3] ), .D(\OAM2ADR[2] ), .Z(\OAM2Cout[3] )) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1731[16:26])
    defparam CNT_I_0_18_2_lut_3_lut_4_lut.init = 16'h8000;
    LUT4 CNT_I_0_2_lut_3_lut (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), .C(\OAM2ADR[2] ), 
         .Z(CNT1_N_1080_adj_1)) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1731[16:26])
    defparam CNT_I_0_2_lut_3_lut.init = 16'h7878;
    LUT4 CNT_I_0_2_lut (.A(\OAM2ADR[1] ), .B(\OAM2ADR[0] ), .Z(CNT1_N_1080_c)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1735[23:33])
    defparam CNT_I_0_2_lut.init = 16'h6666;
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_287), .CD(ORES), .CK(Clk), 
            .Q(\OAM2ADR[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module COUNTER_U40
//

module COUNTER_U40 (Clk, nPCLK, \OAM2ADR[0] , Clk_enable_287, ORES) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input nPCLK;
    output \OAM2ADR[0] ;
    input Clk_enable_287;
    input ORES;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire CNT1, CNT1_N_1080;
    
    FD1P3AX CNT1_15 (.D(CNT1_N_1080), .SP(nPCLK), .CK(Clk), .Q(CNT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT1_15.GSR = "ENABLED";
    LUT4 i34_1_lut (.A(\OAM2ADR[0] ), .Z(CNT1_N_1080)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1735[23:33])
    defparam i34_1_lut.init = 16'h5555;
    FD1P3IX CNT_14 (.D(CNT1), .SP(Clk_enable_287), .CD(ORES), .CK(Clk), 
            .Q(\OAM2ADR[0] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1733[8] 1736[26])
    defparam CNT_14.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module BG_COLOR
//

module BG_COLOR (Clk, PD_out_0, PCLK_c, \Hnn[0] , PD_SR_N_805, BGC2, 
            nPCLK, PD_SR, SRLOAD, TVO1, NFO_OUT, STEP_N_807, CLPB_LATCH, 
            nCLPB_N_121, F_AT, THO1R, \THO[1] , TV_IN, \TVO[0] , 
            CNT1_N_1080, Clk_enable_280, RC, \DBIN[2] , \DBIN[1] , 
            PD_out_1, PD_out_2, PD_out_3, \PDAT[4] , PD_out_4, \PDAT[5] , 
            PD_out_5, PD_out_6, PD_out_7, ATSEL_1__N_798, \DBIN[0] ) /* synthesis syn_module_defined=1 */ ;
    input Clk;
    input PD_out_0;
    input PCLK_c;
    input \Hnn[0] ;
    output PD_SR_N_805;
    output [3:0]BGC2;
    input nPCLK;
    input PD_SR;
    input SRLOAD;
    input TVO1;
    input NFO_OUT;
    input STEP_N_807;
    output CLPB_LATCH;
    input nCLPB_N_121;
    input F_AT;
    output THO1R;
    input \THO[1] ;
    input TV_IN;
    input \TVO[0] ;
    output CNT1_N_1080;
    input Clk_enable_280;
    input RC;
    input \DBIN[2] ;
    input \DBIN[1] ;
    input PD_out_1;
    input PD_out_2;
    input PD_out_3;
    output \PDAT[4] ;
    input PD_out_4;
    output \PDAT[5] ;
    input PD_out_5;
    input PD_out_6;
    input PD_out_7;
    input [1:0]ATSEL_1__N_798;
    input \DBIN[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]SR3;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(980[10:13])
    wire [2:0]FH;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(971[10:12])
    wire [3:0]n74;
    wire [7:0]SR1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(978[10:13])
    
    wire n9494, n9498, n9497;
    wire [7:0]SR2;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(979[10:13])
    
    wire n9501, n9500;
    wire [7:0]SR0;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(977[10:13])
    
    wire n9504, n9503;
    wire [7:0]PDAT;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(975[10:14])
    
    wire PD_SEL, F_AT_LATCH;
    wire [1:0]ATR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(985[10:13])
    wire [1:0]ATRO;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(986[10:14])
    wire [3:0]BGC1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(969[10:14])
    wire [7:0]FSR0;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(981[10:14])
    wire [7:0]FSR1;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(982[10:14])
    wire [7:0]FSR2;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(983[10:14])
    wire [7:0]FSR3;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(984[10:14])
    
    wire STEP2;
    wire [7:0]n17;
    wire [7:0]n17_adj_1724;
    wire [3:0]BGC_POS;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(998[11:18])
    wire [7:0]PDTA;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(976[10:14])
    
    wire n9507, n8778, n9496, n485, n9506, n9510, Clk_enable_285, 
        n9509, n2222, n2220, n483, n9502, n484, n9499, n486, 
        n9508, n9505, n9511, n9495;
    
    LUT4 i5440_2_lut_3_lut (.A(SR3[0]), .B(FH[0]), .C(FH[1]), .Z(n74[3])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1006[8] 1007[63])
    defparam i5440_2_lut_3_lut.init = 16'h8080;
    LUT4 i31_3_lut_4_lut_else_3_lut (.A(FH[1]), .B(SR1[7]), .C(SR1[5]), 
         .Z(n9494)) /* synthesis lut_function=(A (C)+!A (B)) */ ;
    defparam i31_3_lut_4_lut_else_3_lut.init = 16'he4e4;
    LUT4 i31_3_lut_4_lut_then_3_lut (.A(FH[1]), .B(SR3[4]), .C(SR3[6]), 
         .Z(n9498)) /* synthesis lut_function=(A (B)+!A (C)) */ ;
    defparam i31_3_lut_4_lut_then_3_lut.init = 16'hd8d8;
    LUT4 i31_3_lut_4_lut_else_3_lut_adj_417 (.A(FH[1]), .B(SR3[7]), .C(SR3[5]), 
         .Z(n9497)) /* synthesis lut_function=(A (C)+!A (B)) */ ;
    defparam i31_3_lut_4_lut_else_3_lut_adj_417.init = 16'he4e4;
    LUT4 i31_3_lut_4_lut_then_3_lut_adj_418 (.A(FH[1]), .B(SR2[4]), .C(SR2[6]), 
         .Z(n9501)) /* synthesis lut_function=(A (B)+!A (C)) */ ;
    defparam i31_3_lut_4_lut_then_3_lut_adj_418.init = 16'hd8d8;
    LUT4 i31_3_lut_4_lut_else_3_lut_adj_419 (.A(FH[1]), .B(SR2[7]), .C(SR2[5]), 
         .Z(n9500)) /* synthesis lut_function=(A (C)+!A (B)) */ ;
    defparam i31_3_lut_4_lut_else_3_lut_adj_419.init = 16'he4e4;
    LUT4 i31_3_lut_4_lut_then_3_lut_adj_420 (.A(FH[1]), .B(SR0[4]), .C(SR0[6]), 
         .Z(n9504)) /* synthesis lut_function=(A (B)+!A (C)) */ ;
    defparam i31_3_lut_4_lut_then_3_lut_adj_420.init = 16'hd8d8;
    LUT4 i31_3_lut_4_lut_else_3_lut_adj_421 (.A(FH[1]), .B(SR0[7]), .C(SR0[5]), 
         .Z(n9503)) /* synthesis lut_function=(A (C)+!A (B)) */ ;
    defparam i31_3_lut_4_lut_else_3_lut_adj_421.init = 16'he4e4;
    LUT4 i5277_2_lut_3_lut (.A(SR0[0]), .B(FH[0]), .C(FH[1]), .Z(n74[0])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1006[8] 1007[63])
    defparam i5277_2_lut_3_lut.init = 16'h8080;
    FD1P3AX PDAT_i0_i0 (.D(PD_out_0), .SP(PD_SEL), .CK(Clk), .Q(PDAT[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDAT_i0_i0.GSR = "ENABLED";
    LUT4 nPCLK_I_0_154_2_lut_2_lut (.A(PCLK_c), .B(\Hnn[0] ), .Z(PD_SR_N_805)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(991[17:29])
    defparam nPCLK_I_0_154_2_lut_2_lut.init = 16'h4444;
    LUT4 PD_SR_N_805_I_0_153_2_lut_3_lut (.A(PCLK_c), .B(\Hnn[0] ), .C(F_AT_LATCH), 
         .Z(PD_SEL)) /* synthesis lut_function=(!(A+!(B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(990[17:42])
    defparam PD_SR_N_805_I_0_153_2_lut_3_lut.init = 16'h4040;
    FD1P3AX ATR_i0_i0 (.D(ATRO[0]), .SP(PCLK_c), .CK(Clk), .Q(ATR[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam ATR_i0_i0.GSR = "ENABLED";
    FD1P3AX BGC2_i0_i0 (.D(BGC1[0]), .SP(PCLK_c), .CK(Clk), .Q(BGC2[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam BGC2_i0_i0.GSR = "ENABLED";
    FD1P3AX SR0_i0_i0 (.D(FSR0[0]), .SP(PCLK_c), .CK(Clk), .Q(SR0[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR0_i0_i0.GSR = "ENABLED";
    FD1P3AX SR1_i0_i0 (.D(FSR1[0]), .SP(PCLK_c), .CK(Clk), .Q(SR1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR1_i0_i0.GSR = "ENABLED";
    FD1P3AX SR2_i0_i0 (.D(FSR2[0]), .SP(PCLK_c), .CK(Clk), .Q(SR2[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR2_i0_i0.GSR = "ENABLED";
    FD1P3AX SR3_i0_i0 (.D(FSR3[0]), .SP(PCLK_c), .CK(Clk), .Q(SR3[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR3_i0_i0.GSR = "ENABLED";
    FD1P3AX FSR0_i0_i0 (.D(n17[7]), .SP(STEP2), .CK(Clk), .Q(FSR0[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR0_i0_i0.GSR = "ENABLED";
    FD1P3AX FSR1_i0_i0 (.D(n17_adj_1724[7]), .SP(STEP2), .CK(Clk), .Q(FSR1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR1_i0_i0.GSR = "ENABLED";
    FD1P3AX FSR2_i0_i0 (.D(ATR[0]), .SP(STEP2), .CK(Clk), .Q(FSR2[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR2_i0_i0.GSR = "ENABLED";
    FD1P3AX FSR3_i0_i0 (.D(ATR[1]), .SP(STEP2), .CK(Clk), .Q(FSR3[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR3_i0_i0.GSR = "ENABLED";
    FD1P3AX BGC1_i0_i0 (.D(BGC_POS[0]), .SP(nPCLK), .CK(Clk), .Q(BGC1[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam BGC1_i0_i0.GSR = "ENABLED";
    FD1P3AX PDTA_i0_i0 (.D(PD_out_0), .SP(PD_SR), .CK(Clk), .Q(PDTA[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDTA_i0_i0.GSR = "ENABLED";
    LUT4 i1_2_lut_then_4_lut (.A(SRLOAD), .B(PDAT[3]), .C(TVO1), .D(PDAT[7]), 
         .Z(n9507)) /* synthesis lut_function=(A (B ((D)+!C)+!B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(991[17:36])
    defparam i1_2_lut_then_4_lut.init = 16'ha808;
    LUT4 i8468_2_lut_3_lut_4_lut (.A(PCLK_c), .B(NFO_OUT), .C(STEP_N_807), 
         .D(SRLOAD), .Z(n8778)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;
    defparam i8468_2_lut_3_lut_4_lut.init = 16'h0001;
    LUT4 i29_3_lut (.A(n9496), .B(n485), .C(FH[2]), .Z(BGC_POS[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(999[23] 1007[63])
    defparam i29_3_lut.init = 16'hcaca;
    LUT4 i1_2_lut_else_4_lut (.A(SRLOAD), .B(PDAT[1]), .C(TVO1), .Z(n9506)) /* synthesis lut_function=(!(((C)+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(991[17:36])
    defparam i1_2_lut_else_4_lut.init = 16'h0808;
    LUT4 i1_2_lut_then_4_lut_adj_422 (.A(SRLOAD), .B(PDAT[2]), .C(TVO1), 
         .D(PDAT[6]), .Z(n9510)) /* synthesis lut_function=(A (B ((D)+!C)+!B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(991[17:36])
    defparam i1_2_lut_then_4_lut_adj_422.init = 16'ha808;
    LUT4 i1_2_lut_3_lut_4_lut (.A(PCLK_c), .B(NFO_OUT), .C(STEP_N_807), 
         .D(SRLOAD), .Z(Clk_enable_285)) /* synthesis lut_function=(A (D)+!A (B (D)+!B ((D)+!C))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'hff01;
    LUT4 i1_2_lut_else_4_lut_adj_423 (.A(SRLOAD), .B(PDAT[0]), .C(TVO1), 
         .Z(n9509)) /* synthesis lut_function=(!(((C)+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(991[17:36])
    defparam i1_2_lut_else_4_lut_adj_423.init = 16'h0808;
    LUT4 i5438_2_lut_3_lut (.A(SR1[0]), .B(FH[0]), .C(FH[1]), .Z(n74[1])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1006[8] 1007[63])
    defparam i5438_2_lut_3_lut.init = 16'h8080;
    FD1P3AX CLPB_LATCH_135 (.D(nCLPB_N_121), .SP(PCLK_c), .CK(Clk), .Q(CLPB_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam CLPB_LATCH_135.GSR = "ENABLED";
    FD1P3AX F_AT_LATCH_136 (.D(F_AT), .SP(PCLK_c), .CK(Clk), .Q(F_AT_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam F_AT_LATCH_136.GSR = "ENABLED";
    FD1P3AX THO1R_137 (.D(\THO[1] ), .SP(PCLK_c), .CK(Clk), .Q(THO1R));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam THO1R_137.GSR = "ENABLED";
    MUX41 mux_784 (.D0(SR3[3]), .D1(SR3[2]), .D2(n74[3]), .D3(SR3[1]), 
          .SD1(n2222), .SD2(n2220), .Z(n483));
    LUT4 i29_3_lut_adj_424 (.A(n9502), .B(n484), .C(FH[2]), .Z(BGC_POS[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(999[23] 1007[63])
    defparam i29_3_lut_adj_424.init = 16'hcaca;
    LUT4 i29_3_lut_adj_425 (.A(n9499), .B(n483), .C(FH[2]), .Z(BGC_POS[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(999[23] 1007[63])
    defparam i29_3_lut_adj_425.init = 16'hcaca;
    LUT4 i5439_2_lut_3_lut (.A(SR2[0]), .B(FH[0]), .C(FH[1]), .Z(n74[2])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1006[8] 1007[63])
    defparam i5439_2_lut_3_lut.init = 16'h8080;
    LUT4 i6_2_lut (.A(TV_IN), .B(\TVO[0] ), .Z(CNT1_N_1080)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1129[11:14])
    defparam i6_2_lut.init = 16'h6666;
    MUX41 mux_783 (.D0(SR2[3]), .D1(SR2[2]), .D2(n74[2]), .D3(SR2[1]), 
          .SD1(n2222), .SD2(n2220), .Z(n484));
    MUX41 mux_782 (.D0(SR1[3]), .D1(SR1[2]), .D2(n74[1]), .D3(SR1[1]), 
          .SD1(n2222), .SD2(n2220), .Z(n485));
    MUX41 mux_781 (.D0(SR0[3]), .D1(SR0[2]), .D2(n74[0]), .D3(SR0[1]), 
          .SD1(n2222), .SD2(n2220), .Z(n486));
    FD1P3IX FH__i2 (.D(\DBIN[2] ), .SP(Clk_enable_280), .CD(RC), .CK(Clk), 
            .Q(FH[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FH__i2.GSR = "ENABLED";
    FD1P3IX FH__i1 (.D(\DBIN[1] ), .SP(Clk_enable_280), .CD(RC), .CK(Clk), 
            .Q(FH[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FH__i1.GSR = "ENABLED";
    FD1P3AX PDAT_i0_i1 (.D(PD_out_1), .SP(PD_SEL), .CK(Clk), .Q(PDAT[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDAT_i0_i1.GSR = "ENABLED";
    FD1P3AX PDAT_i0_i2 (.D(PD_out_2), .SP(PD_SEL), .CK(Clk), .Q(PDAT[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDAT_i0_i2.GSR = "ENABLED";
    FD1P3AX PDAT_i0_i3 (.D(PD_out_3), .SP(PD_SEL), .CK(Clk), .Q(PDAT[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDAT_i0_i3.GSR = "ENABLED";
    FD1P3AX PDAT_i0_i4 (.D(PD_out_4), .SP(PD_SEL), .CK(Clk), .Q(\PDAT[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDAT_i0_i4.GSR = "ENABLED";
    FD1P3AX PDAT_i0_i5 (.D(PD_out_5), .SP(PD_SEL), .CK(Clk), .Q(\PDAT[5] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDAT_i0_i5.GSR = "ENABLED";
    FD1P3AX PDAT_i0_i6 (.D(PD_out_6), .SP(PD_SEL), .CK(Clk), .Q(PDAT[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDAT_i0_i6.GSR = "ENABLED";
    FD1P3AX PDAT_i0_i7 (.D(PD_out_7), .SP(PD_SEL), .CK(Clk), .Q(PDAT[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDAT_i0_i7.GSR = "ENABLED";
    FD1P3AX ATR_i0_i1 (.D(ATRO[1]), .SP(PCLK_c), .CK(Clk), .Q(ATR[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam ATR_i0_i1.GSR = "ENABLED";
    FD1P3AX BGC2_i0_i1 (.D(BGC1[1]), .SP(PCLK_c), .CK(Clk), .Q(BGC2[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam BGC2_i0_i1.GSR = "ENABLED";
    FD1P3AX BGC2_i0_i2 (.D(BGC1[2]), .SP(PCLK_c), .CK(Clk), .Q(BGC2[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam BGC2_i0_i2.GSR = "ENABLED";
    FD1P3AX BGC2_i0_i3 (.D(BGC1[3]), .SP(PCLK_c), .CK(Clk), .Q(BGC2[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam BGC2_i0_i3.GSR = "ENABLED";
    FD1P3AX SR0_i0_i1 (.D(FSR0[1]), .SP(PCLK_c), .CK(Clk), .Q(SR0[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR0_i0_i1.GSR = "ENABLED";
    FD1P3AX SR0_i0_i2 (.D(FSR0[2]), .SP(PCLK_c), .CK(Clk), .Q(SR0[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR0_i0_i2.GSR = "ENABLED";
    FD1P3AX SR0_i0_i3 (.D(FSR0[3]), .SP(PCLK_c), .CK(Clk), .Q(SR0[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR0_i0_i3.GSR = "ENABLED";
    FD1P3AX SR0_i0_i4 (.D(FSR0[4]), .SP(PCLK_c), .CK(Clk), .Q(SR0[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR0_i0_i4.GSR = "ENABLED";
    FD1P3AX SR0_i0_i5 (.D(FSR0[5]), .SP(PCLK_c), .CK(Clk), .Q(SR0[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR0_i0_i5.GSR = "ENABLED";
    FD1P3AX SR0_i0_i6 (.D(FSR0[6]), .SP(PCLK_c), .CK(Clk), .Q(SR0[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR0_i0_i6.GSR = "ENABLED";
    FD1P3AX SR0_i0_i7 (.D(FSR0[7]), .SP(PCLK_c), .CK(Clk), .Q(SR0[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR0_i0_i7.GSR = "ENABLED";
    FD1P3AX SR1_i0_i1 (.D(FSR1[1]), .SP(PCLK_c), .CK(Clk), .Q(SR1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR1_i0_i1.GSR = "ENABLED";
    FD1P3AX SR1_i0_i2 (.D(FSR1[2]), .SP(PCLK_c), .CK(Clk), .Q(SR1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR1_i0_i2.GSR = "ENABLED";
    FD1P3AX SR1_i0_i3 (.D(FSR1[3]), .SP(PCLK_c), .CK(Clk), .Q(SR1[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR1_i0_i3.GSR = "ENABLED";
    FD1P3AX SR1_i0_i4 (.D(FSR1[4]), .SP(PCLK_c), .CK(Clk), .Q(SR1[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR1_i0_i4.GSR = "ENABLED";
    FD1P3AX SR1_i0_i5 (.D(FSR1[5]), .SP(PCLK_c), .CK(Clk), .Q(SR1[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR1_i0_i5.GSR = "ENABLED";
    FD1P3AX SR1_i0_i6 (.D(FSR1[6]), .SP(PCLK_c), .CK(Clk), .Q(SR1[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR1_i0_i6.GSR = "ENABLED";
    FD1P3AX SR1_i0_i7 (.D(FSR1[7]), .SP(PCLK_c), .CK(Clk), .Q(SR1[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR1_i0_i7.GSR = "ENABLED";
    FD1P3AX SR2_i0_i1 (.D(FSR2[1]), .SP(PCLK_c), .CK(Clk), .Q(SR2[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR2_i0_i1.GSR = "ENABLED";
    FD1P3AX SR2_i0_i2 (.D(FSR2[2]), .SP(PCLK_c), .CK(Clk), .Q(SR2[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR2_i0_i2.GSR = "ENABLED";
    FD1P3AX SR2_i0_i3 (.D(FSR2[3]), .SP(PCLK_c), .CK(Clk), .Q(SR2[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR2_i0_i3.GSR = "ENABLED";
    FD1P3AX SR2_i0_i4 (.D(FSR2[4]), .SP(PCLK_c), .CK(Clk), .Q(SR2[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR2_i0_i4.GSR = "ENABLED";
    FD1P3AX SR2_i0_i5 (.D(FSR2[5]), .SP(PCLK_c), .CK(Clk), .Q(SR2[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR2_i0_i5.GSR = "ENABLED";
    FD1P3AX SR2_i0_i6 (.D(FSR2[6]), .SP(PCLK_c), .CK(Clk), .Q(SR2[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR2_i0_i6.GSR = "ENABLED";
    FD1P3AX SR2_i0_i7 (.D(FSR2[7]), .SP(PCLK_c), .CK(Clk), .Q(SR2[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR2_i0_i7.GSR = "ENABLED";
    FD1P3AX SR3_i0_i1 (.D(FSR3[1]), .SP(PCLK_c), .CK(Clk), .Q(SR3[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR3_i0_i1.GSR = "ENABLED";
    FD1P3AX SR3_i0_i2 (.D(FSR3[2]), .SP(PCLK_c), .CK(Clk), .Q(SR3[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR3_i0_i2.GSR = "ENABLED";
    FD1P3AX SR3_i0_i3 (.D(FSR3[3]), .SP(PCLK_c), .CK(Clk), .Q(SR3[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR3_i0_i3.GSR = "ENABLED";
    FD1P3AX SR3_i0_i4 (.D(FSR3[4]), .SP(PCLK_c), .CK(Clk), .Q(SR3[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR3_i0_i4.GSR = "ENABLED";
    FD1P3AX SR3_i0_i5 (.D(FSR3[5]), .SP(PCLK_c), .CK(Clk), .Q(SR3[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR3_i0_i5.GSR = "ENABLED";
    FD1P3AX SR3_i0_i6 (.D(FSR3[6]), .SP(PCLK_c), .CK(Clk), .Q(SR3[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR3_i0_i6.GSR = "ENABLED";
    FD1P3AX SR3_i0_i7 (.D(FSR3[7]), .SP(PCLK_c), .CK(Clk), .Q(SR3[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam SR3_i0_i7.GSR = "ENABLED";
    FD1P3AX FSR0_i0_i1 (.D(SR0[0]), .SP(STEP2), .CK(Clk), .Q(FSR0[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR0_i0_i1.GSR = "ENABLED";
    FD1P3AX FSR0_i0_i2 (.D(SR0[1]), .SP(STEP2), .CK(Clk), .Q(FSR0[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR0_i0_i2.GSR = "ENABLED";
    FD1P3AX FSR0_i0_i3 (.D(SR0[2]), .SP(STEP2), .CK(Clk), .Q(FSR0[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR0_i0_i3.GSR = "ENABLED";
    FD1P3AX FSR0_i0_i4 (.D(SR0[3]), .SP(STEP2), .CK(Clk), .Q(FSR0[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR0_i0_i4.GSR = "ENABLED";
    FD1P3AX FSR0_i0_i5 (.D(SR0[4]), .SP(STEP2), .CK(Clk), .Q(FSR0[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR0_i0_i5.GSR = "ENABLED";
    FD1P3AX FSR0_i0_i6 (.D(SR0[5]), .SP(STEP2), .CK(Clk), .Q(FSR0[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR0_i0_i6.GSR = "ENABLED";
    FD1P3AX FSR0_i0_i7 (.D(SR0[6]), .SP(STEP2), .CK(Clk), .Q(FSR0[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR0_i0_i7.GSR = "ENABLED";
    FD1P3AX FSR1_i0_i1 (.D(SR1[0]), .SP(STEP2), .CK(Clk), .Q(FSR1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR1_i0_i1.GSR = "ENABLED";
    FD1P3AX FSR1_i0_i2 (.D(SR1[1]), .SP(STEP2), .CK(Clk), .Q(FSR1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR1_i0_i2.GSR = "ENABLED";
    FD1P3AX FSR1_i0_i3 (.D(SR1[2]), .SP(STEP2), .CK(Clk), .Q(FSR1[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR1_i0_i3.GSR = "ENABLED";
    FD1P3AX FSR1_i0_i4 (.D(SR1[3]), .SP(STEP2), .CK(Clk), .Q(FSR1[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR1_i0_i4.GSR = "ENABLED";
    FD1P3AX FSR1_i0_i5 (.D(SR1[4]), .SP(STEP2), .CK(Clk), .Q(FSR1[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR1_i0_i5.GSR = "ENABLED";
    FD1P3AX FSR1_i0_i6 (.D(SR1[5]), .SP(STEP2), .CK(Clk), .Q(FSR1[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR1_i0_i6.GSR = "ENABLED";
    FD1P3AX FSR1_i0_i7 (.D(SR1[6]), .SP(STEP2), .CK(Clk), .Q(FSR1[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR1_i0_i7.GSR = "ENABLED";
    FD1P3AX FSR2_i0_i1 (.D(SR2[0]), .SP(STEP2), .CK(Clk), .Q(FSR2[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR2_i0_i1.GSR = "ENABLED";
    FD1P3AX FSR2_i0_i2 (.D(SR2[1]), .SP(STEP2), .CK(Clk), .Q(FSR2[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR2_i0_i2.GSR = "ENABLED";
    FD1P3AX FSR2_i0_i3 (.D(SR2[2]), .SP(STEP2), .CK(Clk), .Q(FSR2[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR2_i0_i3.GSR = "ENABLED";
    FD1P3AX FSR2_i0_i4 (.D(SR2[3]), .SP(STEP2), .CK(Clk), .Q(FSR2[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR2_i0_i4.GSR = "ENABLED";
    FD1P3AX FSR2_i0_i5 (.D(SR2[4]), .SP(STEP2), .CK(Clk), .Q(FSR2[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR2_i0_i5.GSR = "ENABLED";
    FD1P3AX FSR2_i0_i6 (.D(SR2[5]), .SP(STEP2), .CK(Clk), .Q(FSR2[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR2_i0_i6.GSR = "ENABLED";
    FD1P3AX FSR2_i0_i7 (.D(SR2[6]), .SP(STEP2), .CK(Clk), .Q(FSR2[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR2_i0_i7.GSR = "ENABLED";
    FD1P3AX FSR3_i0_i1 (.D(SR3[0]), .SP(STEP2), .CK(Clk), .Q(FSR3[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR3_i0_i1.GSR = "ENABLED";
    FD1P3AX FSR3_i0_i2 (.D(SR3[1]), .SP(STEP2), .CK(Clk), .Q(FSR3[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR3_i0_i2.GSR = "ENABLED";
    FD1P3AX FSR3_i0_i3 (.D(SR3[2]), .SP(STEP2), .CK(Clk), .Q(FSR3[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR3_i0_i3.GSR = "ENABLED";
    FD1P3AX FSR3_i0_i4 (.D(SR3[3]), .SP(STEP2), .CK(Clk), .Q(FSR3[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR3_i0_i4.GSR = "ENABLED";
    FD1P3AX FSR3_i0_i5 (.D(SR3[4]), .SP(STEP2), .CK(Clk), .Q(FSR3[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR3_i0_i5.GSR = "ENABLED";
    FD1P3AX FSR3_i0_i6 (.D(SR3[5]), .SP(STEP2), .CK(Clk), .Q(FSR3[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR3_i0_i6.GSR = "ENABLED";
    FD1P3AX FSR3_i0_i7 (.D(SR3[6]), .SP(STEP2), .CK(Clk), .Q(FSR3[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FSR3_i0_i7.GSR = "ENABLED";
    FD1P3AX BGC1_i0_i1 (.D(BGC_POS[1]), .SP(nPCLK), .CK(Clk), .Q(BGC1[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam BGC1_i0_i1.GSR = "ENABLED";
    FD1P3AX BGC1_i0_i2 (.D(BGC_POS[2]), .SP(nPCLK), .CK(Clk), .Q(BGC1[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam BGC1_i0_i2.GSR = "ENABLED";
    FD1P3AX BGC1_i0_i3 (.D(BGC_POS[3]), .SP(nPCLK), .CK(Clk), .Q(BGC1[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam BGC1_i0_i3.GSR = "ENABLED";
    FD1P3AX PDTA_i0_i1 (.D(PD_out_1), .SP(PD_SR), .CK(Clk), .Q(PDTA[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDTA_i0_i1.GSR = "ENABLED";
    FD1P3AX PDTA_i0_i2 (.D(PD_out_2), .SP(PD_SR), .CK(Clk), .Q(PDTA[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDTA_i0_i2.GSR = "ENABLED";
    FD1P3AX PDTA_i0_i3 (.D(PD_out_3), .SP(PD_SR), .CK(Clk), .Q(PDTA[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDTA_i0_i3.GSR = "ENABLED";
    FD1P3AX PDTA_i0_i4 (.D(PD_out_4), .SP(PD_SR), .CK(Clk), .Q(PDTA[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDTA_i0_i4.GSR = "ENABLED";
    FD1P3AX PDTA_i0_i5 (.D(PD_out_5), .SP(PD_SR), .CK(Clk), .Q(PDTA[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDTA_i0_i5.GSR = "ENABLED";
    FD1P3AX PDTA_i0_i6 (.D(PD_out_6), .SP(PD_SR), .CK(Clk), .Q(PDTA[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDTA_i0_i6.GSR = "ENABLED";
    FD1P3AX PDTA_i0_i7 (.D(PD_out_7), .SP(PD_SR), .CK(Clk), .Q(PDTA[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam PDTA_i0_i7.GSR = "ENABLED";
    FD1P3JX ATRO_i0_i1 (.D(ATSEL_1__N_798[1]), .SP(SRLOAD), .PD(n9508), 
            .CK(Clk), .Q(ATRO[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam ATRO_i0_i1.GSR = "ENABLED";
    LUT4 i11_3_lut_2_lut (.A(FH[0]), .B(FH[1]), .Z(n2222)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1004[10:24])
    defparam i11_3_lut_2_lut.init = 16'h6666;
    LUT4 i8285_2_lut_3_lut_1_lut (.A(FH[1]), .Z(n2220)) /* synthesis lut_function=(A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1004[10:24])
    defparam i8285_2_lut_3_lut_1_lut.init = 16'haaaa;
    LUT4 i8397_2_lut (.A(PCLK_c), .B(NFO_OUT), .Z(STEP2)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i8397_2_lut.init = 16'h1111;
    LUT4 i29_3_lut_adj_426 (.A(n9505), .B(n486), .C(FH[2]), .Z(BGC_POS[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(999[23] 1007[63])
    defparam i29_3_lut_adj_426.init = 16'hcaca;
    PFUMX i8691 (.BLUT(n9509), .ALUT(n9510), .C0(THO1R), .Z(n9511));
    PFUMX i8689 (.BLUT(n9506), .ALUT(n9507), .C0(THO1R), .Z(n9508));
    PFUMX i8687 (.BLUT(n9503), .ALUT(n9504), .C0(FH[0]), .Z(n9505));
    PFUMX i8685 (.BLUT(n9500), .ALUT(n9501), .C0(FH[0]), .Z(n9502));
    PFUMX i8683 (.BLUT(n9497), .ALUT(n9498), .C0(FH[0]), .Z(n9499));
    PFUMX i8681 (.BLUT(n9494), .ALUT(n9495), .C0(FH[0]), .Z(n9496));
    LUT4 i31_3_lut_4_lut_then_3_lut_adj_427 (.A(FH[1]), .B(SR1[4]), .C(SR1[6]), 
         .Z(n9495)) /* synthesis lut_function=(A (B)+!A (C)) */ ;
    defparam i31_3_lut_4_lut_then_3_lut_adj_427.init = 16'hd8d8;
    FD1P3IX FH__i0 (.D(\DBIN[0] ), .SP(Clk_enable_280), .CD(RC), .CK(Clk), 
            .Q(FH[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam FH__i0.GSR = "ENABLED";
    FD1P3JX ATRO_i0_i0 (.D(ATSEL_1__N_798[0]), .SP(SRLOAD), .PD(n9511), 
            .CK(Clk), .Q(ATRO[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=298, LSE_RLINE=315 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1014[8] 1040[11])
    defparam ATRO_i0_i0.GSR = "ENABLED";
    SHIFTREG_U41 SREG_TB (.PD_out_1(PD_out_1), .SRLOAD(SRLOAD), .PD_out_2(PD_out_2), 
            .PD_out_3(PD_out_3), .PD_out_4(PD_out_4), .PD_out_5(PD_out_5), 
            .PD_out_6(PD_out_6), .PD_out_7(PD_out_7), .Clk(Clk), .PCLK_c(PCLK_c), 
            .QTB(n17_adj_1724[7]), .Clk_enable_285(Clk_enable_285), .n8778(n8778), 
            .PD_out_0(PD_out_0)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1011[10:60])
    SHIFTREG_U42 SREG_TA (.PDTA({PDTA}), .SRLOAD(SRLOAD), .Clk(Clk), .PCLK_c(PCLK_c), 
            .QTA(n17[7]), .Clk_enable_285(Clk_enable_285), .n8778(n8778)) /* synthesis syn_module_defined=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1010[10:60])
    
endmodule
//
// Verilog Description of module SHIFTREG_U41
//

module SHIFTREG_U41 (PD_out_1, SRLOAD, PD_out_2, PD_out_3, PD_out_4, 
            PD_out_5, PD_out_6, PD_out_7, Clk, PCLK_c, QTB, Clk_enable_285, 
            n8778, PD_out_0) /* synthesis syn_module_defined=1 */ ;
    input PD_out_1;
    input SRLOAD;
    input PD_out_2;
    input PD_out_3;
    input PD_out_4;
    input PD_out_5;
    input PD_out_6;
    input PD_out_7;
    input Clk;
    input PCLK_c;
    output QTB;
    input Clk_enable_285;
    input n8778;
    input PD_out_0;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2741, n2743, n2745, n2747, n2749, n2751, n2753;
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    LUT4 i2153_3_lut (.A(QS[0]), .B(PD_out_1), .C(SRLOAD), .Z(n2741)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam i2153_3_lut.init = 16'hcaca;
    LUT4 i2155_3_lut (.A(QS[1]), .B(PD_out_2), .C(SRLOAD), .Z(n2743)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam i2155_3_lut.init = 16'hcaca;
    LUT4 i2157_3_lut (.A(QS[2]), .B(PD_out_3), .C(SRLOAD), .Z(n2745)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam i2157_3_lut.init = 16'hcaca;
    LUT4 i2159_3_lut (.A(QS[3]), .B(PD_out_4), .C(SRLOAD), .Z(n2747)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam i2159_3_lut.init = 16'hcaca;
    LUT4 i2161_3_lut (.A(QS[4]), .B(PD_out_5), .C(SRLOAD), .Z(n2749)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam i2161_3_lut.init = 16'hcaca;
    LUT4 i2163_3_lut (.A(QS[5]), .B(PD_out_6), .C(SRLOAD), .Z(n2751)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam i2163_3_lut.init = 16'hcaca;
    LUT4 i2165_3_lut (.A(QS[6]), .B(PD_out_7), .C(SRLOAD), .Z(n2753)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam i2165_3_lut.init = 16'hcaca;
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(PCLK_c), .CK(Clk), .Q(QS[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(PCLK_c), .CK(Clk), .Q(QS[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(PCLK_c), .CK(Clk), .Q(QS[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(PCLK_c), .CK(Clk), .Q(QS[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(PCLK_c), .CK(Clk), .Q(QS[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(PCLK_c), .CK(Clk), .Q(QS[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(PCLK_c), .CK(Clk), .Q(QS[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(PCLK_c), .CK(Clk), .Q(QTB)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2741), .SP(Clk_enable_285), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2743), .SP(Clk_enable_285), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2745), .SP(Clk_enable_285), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2747), .SP(Clk_enable_285), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2749), .SP(Clk_enable_285), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2751), .SP(Clk_enable_285), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2753), .SP(Clk_enable_285), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    FD1P3IX QS_IN_i0_i0 (.D(PD_out_0), .SP(Clk_enable_285), .CD(n8778), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1011, LSE_RLINE=1011 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module SHIFTREG_U42
//

module SHIFTREG_U42 (PDTA, SRLOAD, Clk, PCLK_c, QTA, Clk_enable_285, 
            n8778) /* synthesis syn_module_defined=1 */ ;
    input [7:0]PDTA;
    input SRLOAD;
    input Clk;
    input PCLK_c;
    output QTA;
    input Clk_enable_285;
    input n8778;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]QS;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1550[10:12])
    
    wire n2763, n2765, n2767;
    wire [7:0]QS_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1551[10:15])
    
    wire n2755, n2757, n2759, n2761;
    
    LUT4 i2175_3_lut (.A(QS[4]), .B(PDTA[5]), .C(SRLOAD), .Z(n2763)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam i2175_3_lut.init = 16'hcaca;
    LUT4 i2177_3_lut (.A(QS[5]), .B(PDTA[6]), .C(SRLOAD), .Z(n2765)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam i2177_3_lut.init = 16'hcaca;
    LUT4 i2179_3_lut (.A(QS[6]), .B(PDTA[7]), .C(SRLOAD), .Z(n2767)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam i2179_3_lut.init = 16'hcaca;
    FD1P3AX QS_i0_i0 (.D(QS_IN[0]), .SP(PCLK_c), .CK(Clk), .Q(QS[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i0.GSR = "ENABLED";
    FD1P3AX QS_i0_i1 (.D(QS_IN[1]), .SP(PCLK_c), .CK(Clk), .Q(QS[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_i0_i2 (.D(QS_IN[2]), .SP(PCLK_c), .CK(Clk), .Q(QS[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_i0_i3 (.D(QS_IN[3]), .SP(PCLK_c), .CK(Clk), .Q(QS[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_i0_i4 (.D(QS_IN[4]), .SP(PCLK_c), .CK(Clk), .Q(QS[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_i0_i5 (.D(QS_IN[5]), .SP(PCLK_c), .CK(Clk), .Q(QS[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_i0_i6 (.D(QS_IN[6]), .SP(PCLK_c), .CK(Clk), .Q(QS[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_i0_i7 (.D(QS_IN[7]), .SP(PCLK_c), .CK(Clk), .Q(QTA)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_i0_i7.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i1 (.D(n2755), .SP(Clk_enable_285), .CK(Clk), .Q(QS_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i2 (.D(n2757), .SP(Clk_enable_285), .CK(Clk), .Q(QS_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i3 (.D(n2759), .SP(Clk_enable_285), .CK(Clk), .Q(QS_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i4 (.D(n2761), .SP(Clk_enable_285), .CK(Clk), .Q(QS_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i5 (.D(n2763), .SP(Clk_enable_285), .CK(Clk), .Q(QS_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i6 (.D(n2765), .SP(Clk_enable_285), .CK(Clk), .Q(QS_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX QS_IN_i0_i7 (.D(n2767), .SP(Clk_enable_285), .CK(Clk), .Q(QS_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i7.GSR = "ENABLED";
    LUT4 i2167_3_lut (.A(QS[0]), .B(PDTA[1]), .C(SRLOAD), .Z(n2755)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam i2167_3_lut.init = 16'hcaca;
    FD1P3IX QS_IN_i0_i0 (.D(PDTA[0]), .SP(Clk_enable_285), .CD(n8778), 
            .CK(Clk), .Q(QS_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=60, LSE_LLINE=1010, LSE_RLINE=1010 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam QS_IN_i0_i0.GSR = "ENABLED";
    LUT4 i2169_3_lut (.A(QS[1]), .B(PDTA[2]), .C(SRLOAD), .Z(n2757)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam i2169_3_lut.init = 16'hcaca;
    LUT4 i2171_3_lut (.A(QS[2]), .B(PDTA[3]), .C(SRLOAD), .Z(n2759)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam i2171_3_lut.init = 16'hcaca;
    LUT4 i2173_3_lut (.A(QS[3]), .B(PDTA[4]), .C(SRLOAD), .Z(n2761)) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1555[8] 1558[26])
    defparam i2173_3_lut.init = 16'hcaca;
    
endmodule
//
// Verilog Description of module OBJ_EVAL
//

module OBJ_EVAL (PD_FIFO, Clk, PD_FIFO_N_1103, DO_COPY_N_1126, SPR0_EV, 
            PAR_O, PCLK_c, OMFG_N_1097, OMFG, nPCLK, nVIS, I_OAM2, 
            SPR_OV, \Hnn[0] , OMSTEP2_N_1188, S_EV, PD_FIFO2, PD_SR_N_805, 
            Vo, OB_R, GND_net, OV, O8_16, OMFG_N_1096) /* synthesis syn_module_defined=1 */ ;
    output PD_FIFO;
    input Clk;
    output PD_FIFO_N_1103;
    output DO_COPY_N_1126;
    output SPR0_EV;
    input PAR_O;
    input PCLK_c;
    output OMFG_N_1097;
    output OMFG;
    input nPCLK;
    input nVIS;
    input I_OAM2;
    input SPR_OV;
    input \Hnn[0] ;
    output OMSTEP2_N_1188;
    input S_EV;
    input PD_FIFO2;
    input PD_SR_N_805;
    input [7:0]Vo;
    input [7:0]OB_R;
    input GND_net;
    output [3:0]OV;
    input O8_16;
    output OMFG_N_1096;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire PD_FIFO1_N_1101, SPR0_EV1, SPR0_EV1_N_1108, n1961, PD_FIFO1, 
        OVZ;
    wire [5:0]CLATCH;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1230[10:16])
    
    wire n8229, n8230, n8232;
    wire [7:0]OVS;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1234[11:14])
    
    wire n8231, n11, n9;
    
    FD1P3AX PD_FIFO_58 (.D(PD_FIFO1_N_1101), .SP(PD_FIFO_N_1103), .CK(Clk), 
            .Q(PD_FIFO));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1243[8] 1263[25])
    defparam PD_FIFO_58.GSR = "ENABLED";
    FD1P3AX SPR0_EV1_59 (.D(DO_COPY_N_1126), .SP(SPR0_EV1_N_1108), .CK(Clk), 
            .Q(SPR0_EV1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1243[8] 1263[25])
    defparam SPR0_EV1_59.GSR = "ENABLED";
    LUT4 i1383_4_lut_4_lut (.A(SPR0_EV), .B(SPR0_EV1), .C(PAR_O), .D(PCLK_c), 
         .Z(n1961)) /* synthesis lut_function=(A (((D)+!C)+!B)+!A !(B+((D)+!C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1243[8] 1263[25])
    defparam i1383_4_lut_4_lut.init = 16'haa3a;
    FD1S3AX SPR0_EV_60 (.D(n1961), .CK(Clk), .Q(SPR0_EV));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1243[8] 1263[25])
    defparam SPR0_EV_60.GSR = "ENABLED";
    LUT4 OMFG_I_0_1_lut_2_lut (.A(OMFG_N_1097), .B(DO_COPY_N_1126), .Z(OMFG)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1240[15:66])
    defparam OMFG_I_0_1_lut_2_lut.init = 16'h1111;
    FD1P3AX PD_FIFO1_56 (.D(OVZ), .SP(nPCLK), .CK(Clk), .Q(PD_FIFO1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1243[8] 1263[25])
    defparam PD_FIFO1_56.GSR = "ENABLED";
    LUT4 i8409_3_lut_4_lut (.A(nVIS), .B(I_OAM2), .C(SPR_OV), .D(OVZ), 
         .Z(DO_COPY_N_1126)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1239[21:34])
    defparam i8409_3_lut_4_lut.init = 16'h0001;
    LUT4 i8423_2_lut_3_lut (.A(nVIS), .B(I_OAM2), .C(\Hnn[0] ), .Z(OMSTEP2_N_1188)) /* synthesis lut_function=(A+(B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1239[21:34])
    defparam i8423_2_lut_3_lut.init = 16'hefef;
    LUT4 S_EV_I_0_2_lut_2_lut (.A(S_EV), .B(PCLK_c), .Z(SPR0_EV1_N_1108)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1256[14:27])
    defparam S_EV_I_0_2_lut_2_lut.init = 16'h2222;
    LUT4 i8549_2_lut (.A(PCLK_c), .B(PD_FIFO2), .Z(PD_FIFO_N_1103)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1255[15:35])
    defparam i8549_2_lut.init = 16'h2222;
    FD1P3AX CLATCH_i0 (.D(DO_COPY_N_1126), .SP(PD_SR_N_805), .CK(Clk), 
            .Q(CLATCH[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=356, LSE_RLINE=374 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1243[8] 1263[25])
    defparam CLATCH_i0.GSR = "ENABLED";
    CCU2D V_7__I_0_add_2_3 (.A0(Vo[1]), .B0(OB_R[1]), .C0(GND_net), .D0(GND_net), 
          .A1(Vo[2]), .B1(OB_R[2]), .C1(GND_net), .D1(GND_net), .CIN(n8229), 
          .COUT(n8230), .S0(OV[1]), .S1(OV[2]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1235[19:40])
    defparam V_7__I_0_add_2_3.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_3.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_3.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_3.INJECT1_1 = "NO";
    CCU2D V_7__I_0_add_2_9 (.A0(Vo[7]), .B0(OB_R[7]), .C0(GND_net), .D0(GND_net), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n8232), 
          .S0(OVS[7]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1235[19:40])
    defparam V_7__I_0_add_2_9.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_9.INIT1 = 16'h0000;
    defparam V_7__I_0_add_2_9.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_9.INJECT1_1 = "NO";
    CCU2D V_7__I_0_add_2_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(Vo[0]), .B1(OB_R[0]), .C1(GND_net), .D1(GND_net), 
          .COUT(n8229), .S1(OV[0]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1235[19:40])
    defparam V_7__I_0_add_2_1.INIT0 = 16'h0000;
    defparam V_7__I_0_add_2_1.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_1.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_1.INJECT1_1 = "NO";
    CCU2D V_7__I_0_add_2_7 (.A0(Vo[5]), .B0(OB_R[5]), .C0(GND_net), .D0(GND_net), 
          .A1(Vo[6]), .B1(OB_R[6]), .C1(GND_net), .D1(GND_net), .CIN(n8231), 
          .COUT(n8232), .S0(OVS[5]), .S1(OVS[6]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1235[19:40])
    defparam V_7__I_0_add_2_7.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_7.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_7.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_7.INJECT1_1 = "NO";
    CCU2D V_7__I_0_add_2_5 (.A0(Vo[3]), .B0(OB_R[3]), .C0(GND_net), .D0(GND_net), 
          .A1(Vo[4]), .B1(OB_R[4]), .C1(GND_net), .D1(GND_net), .CIN(n8230), 
          .COUT(n8231), .S0(OV[3]), .S1(OVS[4]));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1235[19:40])
    defparam V_7__I_0_add_2_5.INIT0 = 16'h5999;
    defparam V_7__I_0_add_2_5.INIT1 = 16'h5999;
    defparam V_7__I_0_add_2_5.INJECT1_0 = "NO";
    defparam V_7__I_0_add_2_5.INJECT1_1 = "NO";
    FD1P3AX CLATCH_i1 (.D(CLATCH[0]), .SP(PCLK_c), .CK(Clk), .Q(CLATCH[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=356, LSE_RLINE=374 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1243[8] 1263[25])
    defparam CLATCH_i1.GSR = "ENABLED";
    FD1P3AX CLATCH_i2 (.D(CLATCH[1]), .SP(PD_SR_N_805), .CK(Clk), .Q(CLATCH[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=356, LSE_RLINE=374 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1243[8] 1263[25])
    defparam CLATCH_i2.GSR = "ENABLED";
    FD1P3AX CLATCH_i3 (.D(CLATCH[2]), .SP(PCLK_c), .CK(Clk), .Q(CLATCH[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=356, LSE_RLINE=374 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1243[8] 1263[25])
    defparam CLATCH_i3.GSR = "ENABLED";
    FD1P3AX CLATCH_i4 (.D(CLATCH[3]), .SP(PD_SR_N_805), .CK(Clk), .Q(CLATCH[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=356, LSE_RLINE=374 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1243[8] 1263[25])
    defparam CLATCH_i4.GSR = "ENABLED";
    FD1P3AX CLATCH_i5 (.D(CLATCH[4]), .SP(PCLK_c), .CK(Clk), .Q(CLATCH[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=10, LSE_RCOL=2, LSE_LLINE=356, LSE_RLINE=374 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1243[8] 1263[25])
    defparam CLATCH_i5.GSR = "ENABLED";
    LUT4 PD_FIFO1_I_0_1_lut (.A(PD_FIFO1), .Z(PD_FIFO1_N_1101)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1255[48:57])
    defparam PD_FIFO1_I_0_1_lut.init = 16'h5555;
    LUT4 i6_4_lut (.A(n11), .B(n9), .C(OVS[5]), .D(OVS[7]), .Z(OVZ)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1237[14:135])
    defparam i6_4_lut.init = 16'hfffe;
    LUT4 i4_4_lut (.A(OVS[6]), .B(OMFG_N_1097), .C(OB_R[7]), .D(Vo[7]), 
         .Z(n11)) /* synthesis lut_function=(A+(B+!((D)+!C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1237[14:135])
    defparam i4_4_lut.init = 16'heefe;
    LUT4 i2_3_lut (.A(O8_16), .B(OVS[4]), .C(OV[3]), .Z(n9)) /* synthesis lut_function=(A (B)+!A (B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1237[14:135])
    defparam i2_3_lut.init = 16'hdcdc;
    LUT4 OMFG_I_280_2_lut (.A(OMFG_N_1097), .B(DO_COPY_N_1126), .Z(OMFG_N_1096)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1240[16:66])
    defparam OMFG_I_280_2_lut.init = 16'heeee;
    LUT4 i2_3_lut_adj_416 (.A(CLATCH[5]), .B(CLATCH[3]), .C(CLATCH[1]), 
         .Z(OMFG_N_1097)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1240[17:54])
    defparam i2_3_lut_adj_416.init = 16'hfefe;
    
endmodule
//
// Verilog Description of module PUR
// module not written out since it is a black-box. 
//

//
// Verilog Description of module CLK_DIV
//

module CLK_DIV (MCLK_c, SUBCLK_c, MCLK_N_9, PCLK_c, nPCLK, nRES_c, 
            MODE_c) /* synthesis syn_module_defined=1 */ ;
    input MCLK_c;
    output SUBCLK_c;
    input MCLK_N_9;
    output PCLK_c;
    output nPCLK;
    input nRES_c;
    input MODE_c;
    
    wire MCLK_c /* synthesis is_clock=1, SET_AS_NETWORK=MCLK_c */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(36[11:15])
    wire MCLK_N_9 /* synthesis is_inv_clock=1 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(471[10:16])
    wire [1:0]SUB;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(472[10:13])
    
    wire SUB_1__N_17;
    wire [3:0]PCLK_P;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(471[10:16])
    
    wire PCLK_P_0__N_11;
    wire [1:0]PCLK_N;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(470[10:16])
    
    wire PCLK_N_1__N_4;
    
    FD1S3AX SUB_i0 (.D(SUB_1__N_17), .CK(MCLK_c), .Q(SUB[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=156, LSE_RLINE=163 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(477[8] 488[27])
    defparam SUB_i0.GSR = "ENABLED";
    FD1S3AX PCLK_P_2__31 (.D(PCLK_P[1]), .CK(MCLK_c), .Q(PCLK_P[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=156, LSE_RLINE=163 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(477[8] 488[27])
    defparam PCLK_P_2__31.GSR = "ENABLED";
    FD1S3AX PCLK_P_1__32 (.D(PCLK_P[0]), .CK(MCLK_c), .Q(PCLK_P[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=156, LSE_RLINE=163 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(477[8] 488[27])
    defparam PCLK_P_1__32.GSR = "ENABLED";
    FD1S3AX PCLK_P_0__33 (.D(PCLK_P_0__N_11), .CK(MCLK_c), .Q(PCLK_P[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=156, LSE_RLINE=163 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(477[8] 488[27])
    defparam PCLK_P_0__33.GSR = "ENABLED";
    FD1S3AX PCLK_N_i0 (.D(PCLK_N_1__N_4), .CK(MCLK_c), .Q(PCLK_N[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=156, LSE_RLINE=163 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(477[8] 488[27])
    defparam PCLK_N_i0.GSR = "ENABLED";
    FD1S3AX SUBCLK_35 (.D(SUB[1]), .CK(MCLK_c), .Q(SUBCLK_c)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=156, LSE_RLINE=163 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(477[8] 488[27])
    defparam SUBCLK_35.GSR = "ENABLED";
    FD1S3AX PCLK_P_3__36 (.D(PCLK_P[1]), .CK(MCLK_N_9), .Q(PCLK_P[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=156, LSE_RLINE=163 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(489[8] 491[28])
    defparam PCLK_P_3__36.GSR = "ENABLED";
    FD1S3AX PCLK_N_i1 (.D(PCLK_N[0]), .CK(MCLK_c), .Q(PCLK_N[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=156, LSE_RLINE=163 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(477[8] 488[27])
    defparam PCLK_N_i1.GSR = "ENABLED";
    FD1S3AX SUB_i1 (.D(SUB[0]), .CK(MCLK_c), .Q(SUB[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=156, LSE_RLINE=163 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(477[8] 488[27])
    defparam SUB_i1.GSR = "ENABLED";
    LUT4 PCLK_I_0_1_lut (.A(PCLK_c), .Z(nPCLK)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(475[16:52])
    defparam PCLK_I_0_1_lut.init = 16'h5555;
    LUT4 i2_3_lut (.A(PCLK_P[3]), .B(PCLK_P[2]), .C(PCLK_N[1]), .Z(PCLK_c)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(474[18:51])
    defparam i2_3_lut.init = 16'hfefe;
    LUT4 i8275_2_lut (.A(SUBCLK_c), .B(nRES_c), .Z(SUB_1__N_17)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(485[24:44])
    defparam i8275_2_lut.init = 16'h4444;
    LUT4 i8273_4_lut (.A(nRES_c), .B(PCLK_P[1]), .C(MODE_c), .D(PCLK_P[2]), 
         .Z(PCLK_P_0__N_11)) /* synthesis lut_function=(!((B+((D)+!C))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(481[24:69])
    defparam i8273_4_lut.init = 16'h0020;
    LUT4 i8271_3_lut (.A(PCLK_N[1]), .B(MODE_c), .C(nRES_c), .Z(PCLK_N_1__N_4)) /* synthesis lut_function=(!(A+(B+!(C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(479[18:48])
    defparam i8271_3_lut.init = 16'h1010;
    
endmodule
//
// Verilog Description of module READBUSMUX
//

module READBUSMUX (DBIN, D, OB_R, Clk, PCLK_c, OB, R2, R7, R4, 
            XRB_N_650, RPIX, R2DB, PIX, TH_MUX, Clk_enable_297, 
            RC, PD_out_1, PD_out_2, PD_out_3, PD_out_4, PD_out_5, 
            PD_out_6, PD_out_7, RnWR, nDBER, R_EN, PD_out_0) /* synthesis syn_module_defined=1 */ ;
    input [7:0]DBIN;
    output [7:0]D;
    output [7:0]OB_R;
    input Clk;
    input PCLK_c;
    input [7:0]OB;
    input R2;
    input R7;
    input R4;
    input XRB_N_650;
    input RPIX;
    input [2:0]R2DB;
    input [5:0]PIX;
    input TH_MUX;
    input Clk_enable_297;
    input RC;
    input PD_out_1;
    input PD_out_2;
    input PD_out_3;
    input PD_out_4;
    input PD_out_5;
    input PD_out_6;
    input PD_out_7;
    input RnWR;
    input nDBER;
    output R_EN;
    input PD_out_0;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]Do;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(648[10:12])
    
    wire D_7__N_162, n4;
    wire [7:0]n83;
    wire [7:0]PD_R;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(646[10:14])
    
    wire n4_adj_1718, n4_adj_1719, n4_adj_1720, n4_adj_1721, n6, n5, 
        n4_adj_1722;
    wire [7:0]n101;
    
    wire n4_adj_1723;
    
    LUT4 DBIN_7__I_0_i7_3_lut (.A(DBIN[6]), .B(Do[6]), .C(D_7__N_162), 
         .Z(D[6])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(651[17:63])
    defparam DBIN_7__I_0_i7_3_lut.init = 16'hcaca;
    FD1P3AX OB_R_i0_i0 (.D(OB[0]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam OB_R_i0_i0.GSR = "ENABLED";
    FD1S3JX Do_i0 (.D(n83[0]), .CK(Clk), .PD(n4), .Q(Do[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam Do_i0.GSR = "ENABLED";
    LUT4 i3_4_lut_4_lut (.A(R2), .B(R7), .C(R4), .Z(D_7__N_162)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(651[17:41])
    defparam i3_4_lut_4_lut.init = 16'hfefe;
    LUT4 i1_4_lut (.A(R4), .B(XRB_N_650), .C(OB_R[1]), .D(PD_R[1]), 
         .Z(n4_adj_1718)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[20:130])
    defparam i1_4_lut.init = 16'hb3a0;
    LUT4 i1_4_lut_adj_409 (.A(R4), .B(XRB_N_650), .C(OB_R[2]), .D(PD_R[2]), 
         .Z(n4_adj_1719)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[20:130])
    defparam i1_4_lut_adj_409.init = 16'hb3a0;
    LUT4 i1_4_lut_adj_410 (.A(R4), .B(XRB_N_650), .C(OB_R[3]), .D(PD_R[3]), 
         .Z(n4_adj_1720)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[20:130])
    defparam i1_4_lut_adj_410.init = 16'hb3a0;
    LUT4 i1_4_lut_adj_411 (.A(R4), .B(XRB_N_650), .C(OB_R[4]), .D(PD_R[4]), 
         .Z(n4_adj_1721)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[20:130])
    defparam i1_4_lut_adj_411.init = 16'hb3a0;
    LUT4 i2_4_lut (.A(R2), .B(RPIX), .C(R2DB[0]), .D(PIX[5]), .Z(n6)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[20:130])
    defparam i2_4_lut.init = 16'heca0;
    LUT4 i1_4_lut_adj_412 (.A(R4), .B(XRB_N_650), .C(OB_R[5]), .D(PD_R[5]), 
         .Z(n5)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[20:130])
    defparam i1_4_lut_adj_412.init = 16'hb3a0;
    LUT4 and_36_i1_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[0]), .Z(n83[0])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[44:73])
    defparam and_36_i1_2_lut_3_lut.init = 16'h8080;
    LUT4 DBIN_7__I_0_i8_3_lut (.A(DBIN[7]), .B(Do[7]), .C(D_7__N_162), 
         .Z(D[7])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(651[17:63])
    defparam DBIN_7__I_0_i8_3_lut.init = 16'hcaca;
    LUT4 i1_4_lut_adj_413 (.A(R4), .B(XRB_N_650), .C(OB_R[6]), .D(PD_R[6]), 
         .Z(n4_adj_1722)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[20:130])
    defparam i1_4_lut_adj_413.init = 16'hb3a0;
    LUT4 and_38_i7_2_lut (.A(R2), .B(R2DB[1]), .Z(n101[6])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[76:105])
    defparam and_38_i7_2_lut.init = 16'h8888;
    LUT4 i1_4_lut_adj_414 (.A(R4), .B(XRB_N_650), .C(OB_R[7]), .D(PD_R[7]), 
         .Z(n4_adj_1723)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[20:130])
    defparam i1_4_lut_adj_414.init = 16'hb3a0;
    LUT4 i1_4_lut_adj_415 (.A(R4), .B(XRB_N_650), .C(OB_R[0]), .D(PD_R[0]), 
         .Z(n4)) /* synthesis lut_function=(A (B (C)+!B (C+(D)))+!A !(B+!(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[20:130])
    defparam i1_4_lut_adj_415.init = 16'hb3a0;
    LUT4 and_38_i8_2_lut (.A(R2), .B(R2DB[2]), .Z(n101[7])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[76:105])
    defparam and_38_i8_2_lut.init = 16'h8888;
    LUT4 and_36_i5_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[4]), .Z(n83[4])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[44:73])
    defparam and_36_i5_2_lut_3_lut.init = 16'h8080;
    LUT4 and_36_i4_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[3]), .Z(n83[3])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[44:73])
    defparam and_36_i4_2_lut_3_lut.init = 16'h8080;
    LUT4 and_36_i3_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[2]), .Z(n83[2])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[44:73])
    defparam and_36_i3_2_lut_3_lut.init = 16'h8080;
    LUT4 and_36_i2_2_lut_3_lut (.A(R7), .B(TH_MUX), .C(PIX[1]), .Z(n83[1])) /* synthesis lut_function=(A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(658[44:73])
    defparam and_36_i2_2_lut_3_lut.init = 16'h8080;
    FD1P3AX OB_R_i0_i1 (.D(OB[1]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam OB_R_i0_i1.GSR = "ENABLED";
    FD1P3AX OB_R_i0_i2 (.D(OB[2]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam OB_R_i0_i2.GSR = "ENABLED";
    FD1P3AX OB_R_i0_i3 (.D(OB[3]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam OB_R_i0_i3.GSR = "ENABLED";
    FD1P3AX OB_R_i0_i4 (.D(OB[4]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam OB_R_i0_i4.GSR = "ENABLED";
    FD1P3AX OB_R_i0_i5 (.D(OB[5]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam OB_R_i0_i5.GSR = "ENABLED";
    FD1P3AX OB_R_i0_i6 (.D(OB[6]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam OB_R_i0_i6.GSR = "ENABLED";
    FD1P3AX OB_R_i0_i7 (.D(OB[7]), .SP(PCLK_c), .CK(Clk), .Q(OB_R[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam OB_R_i0_i7.GSR = "ENABLED";
    FD1S3JX Do_i1 (.D(n83[1]), .CK(Clk), .PD(n4_adj_1718), .Q(Do[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam Do_i1.GSR = "ENABLED";
    FD1S3JX Do_i2 (.D(n83[2]), .CK(Clk), .PD(n4_adj_1719), .Q(Do[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam Do_i2.GSR = "ENABLED";
    FD1S3JX Do_i3 (.D(n83[3]), .CK(Clk), .PD(n4_adj_1720), .Q(Do[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam Do_i3.GSR = "ENABLED";
    FD1S3JX Do_i4 (.D(n83[4]), .CK(Clk), .PD(n4_adj_1721), .Q(Do[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam Do_i4.GSR = "ENABLED";
    FD1S3JX Do_i5 (.D(n5), .CK(Clk), .PD(n6), .Q(Do[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam Do_i5.GSR = "ENABLED";
    FD1S3JX Do_i6 (.D(n101[6]), .CK(Clk), .PD(n4_adj_1722), .Q(Do[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam Do_i6.GSR = "ENABLED";
    FD1S3JX Do_i7 (.D(n101[7]), .CK(Clk), .PD(n4_adj_1723), .Q(Do[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam Do_i7.GSR = "ENABLED";
    LUT4 DBIN_7__I_0_i1_3_lut (.A(DBIN[0]), .B(Do[0]), .C(D_7__N_162), 
         .Z(D[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(651[17:63])
    defparam DBIN_7__I_0_i1_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i2_3_lut (.A(DBIN[1]), .B(Do[1]), .C(D_7__N_162), 
         .Z(D[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(651[17:63])
    defparam DBIN_7__I_0_i2_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i3_3_lut (.A(DBIN[2]), .B(Do[2]), .C(D_7__N_162), 
         .Z(D[2])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(651[17:63])
    defparam DBIN_7__I_0_i3_3_lut.init = 16'hcaca;
    IFS1P3IX PD_R__i1 (.D(PD_out_1), .SP(Clk_enable_297), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam PD_R__i1.GSR = "ENABLED";
    IFS1P3IX PD_R__i2 (.D(PD_out_2), .SP(Clk_enable_297), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam PD_R__i2.GSR = "ENABLED";
    IFS1P3IX PD_R__i3 (.D(PD_out_3), .SP(Clk_enable_297), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam PD_R__i3.GSR = "ENABLED";
    IFS1P3IX PD_R__i4 (.D(PD_out_4), .SP(Clk_enable_297), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam PD_R__i4.GSR = "ENABLED";
    IFS1P3IX PD_R__i5 (.D(PD_out_5), .SP(Clk_enable_297), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam PD_R__i5.GSR = "ENABLED";
    IFS1P3IX PD_R__i6 (.D(PD_out_6), .SP(Clk_enable_297), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam PD_R__i6.GSR = "ENABLED";
    IFS1P3IX PD_R__i7 (.D(PD_out_7), .SP(Clk_enable_297), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam PD_R__i7.GSR = "ENABLED";
    LUT4 DBIN_7__I_0_i4_3_lut (.A(DBIN[3]), .B(Do[3]), .C(D_7__N_162), 
         .Z(D[3])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(651[17:63])
    defparam DBIN_7__I_0_i4_3_lut.init = 16'hcaca;
    LUT4 DBIN_7__I_0_i5_3_lut (.A(DBIN[4]), .B(Do[4]), .C(D_7__N_162), 
         .Z(D[4])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(651[17:63])
    defparam DBIN_7__I_0_i5_3_lut.init = 16'hcaca;
    LUT4 i8530_2_lut (.A(RnWR), .B(nDBER), .Z(R_EN)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(652[8:10])
    defparam i8530_2_lut.init = 16'hdddd;
    LUT4 DBIN_7__I_0_i6_3_lut (.A(DBIN[5]), .B(Do[5]), .C(D_7__N_162), 
         .Z(D[5])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(651[17:63])
    defparam DBIN_7__I_0_i6_3_lut.init = 16'hcaca;
    IFS1P3IX PD_R__i0 (.D(PD_out_0), .SP(Clk_enable_297), .SCLK(Clk), 
            .CD(RC), .Q(PD_R[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=12, LSE_RCOL=2, LSE_LLINE=215, LSE_RLINE=231 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(654[8] 659[26])
    defparam PD_R__i0.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module ADDRESS_BUS_CONTROL
//

module ADDRESS_BUS_CONTROL (PCLK_c, Hn0, ALE_N_645, BLNK, ALE_c, W7_Q2, 
            W7_Q4, TH_MUX, nWR_c, R7, Clk, nPCLK, PD_DIR_c, nRD_c, 
            TSTEP_LATCH, TSTEP, \Hnn[0] , RC, Clk_enable_297, W7, 
            XRB_N_650, PA_c_3, PA_c_4, PA_c_0, PA_c_5, PA_c_1, PA_c_2, 
            DB_PAR_N_634) /* synthesis syn_module_defined=1 */ ;
    input PCLK_c;
    input Hn0;
    output ALE_N_645;
    input BLNK;
    output ALE_c;
    output W7_Q2;
    output W7_Q4;
    output TH_MUX;
    output nWR_c;
    input R7;
    input Clk;
    input nPCLK;
    output PD_DIR_c;
    output nRD_c;
    input TSTEP_LATCH;
    output TSTEP;
    input \Hnn[0] ;
    input RC;
    output Clk_enable_297;
    input W7;
    output XRB_N_650;
    input PA_c_3;
    input PA_c_4;
    input PA_c_0;
    input PA_c_5;
    input PA_c_1;
    input PA_c_2;
    output DB_PAR_N_634;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire n4, n1697, BLNK_LATCH, R7_Q3, R7_Q2, W7_Q3, R7_Q5, R7_Q4_N_629, 
        W7_Q5, W7_Q4_N_673, R7_Q1, W7_Q1, R7_Q4, Clk_enable_42, 
        R7_Q3_N_632, W7_Q3_N_641, Clk_enable_36, W7_FF, n12, R7_FF, 
        n1695;
    
    LUT4 nPCLK_I_0_2_lut_2_lut (.A(PCLK_c), .B(Hn0), .Z(ALE_N_645)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(918[61:72])
    defparam nPCLK_I_0_2_lut_2_lut.init = 16'hdddd;
    LUT4 i2_3_lut_4_lut (.A(PCLK_c), .B(Hn0), .C(n4), .D(BLNK), .Z(ALE_c)) /* synthesis lut_function=(A (B (C)+!B (C+!(D)))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(918[14:81])
    defparam i2_3_lut_4_lut.init = 16'hf0f2;
    LUT4 DB_PAR_N_634_I_0_2_lut_3_lut (.A(W7_Q2), .B(W7_Q4), .C(TH_MUX), 
         .Z(nWR_c)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(915[14:30])
    defparam DB_PAR_N_634_I_0_2_lut_3_lut.init = 16'hfefe;
    LUT4 i1150_2_lut (.A(R7), .B(PCLK_c), .Z(n1697)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam i1150_2_lut.init = 16'h8888;
    FD1P3AX BLNK_LATCH_78 (.D(BLNK), .SP(PCLK_c), .CK(Clk), .Q(BLNK_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam BLNK_LATCH_78.GSR = "ENABLED";
    FD1P3AX R7_Q3_82 (.D(R7_Q2), .SP(PCLK_c), .CK(Clk), .Q(R7_Q3));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam R7_Q3_82.GSR = "ENABLED";
    FD1P3AX W7_Q3_83 (.D(W7_Q2), .SP(PCLK_c), .CK(Clk), .Q(W7_Q3));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam W7_Q3_83.GSR = "ENABLED";
    FD1P3AX R7_Q5_84 (.D(R7_Q4_N_629), .SP(PCLK_c), .CK(Clk), .Q(R7_Q5));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam R7_Q5_84.GSR = "ENABLED";
    FD1P3AX W7_Q5_85 (.D(W7_Q4_N_673), .SP(PCLK_c), .CK(Clk), .Q(W7_Q5));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam W7_Q5_85.GSR = "ENABLED";
    FD1P3AX R7_Q2_86 (.D(R7_Q1), .SP(nPCLK), .CK(Clk), .Q(R7_Q2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam R7_Q2_86.GSR = "ENABLED";
    FD1P3AX W7_Q2_87 (.D(W7_Q1), .SP(nPCLK), .CK(Clk), .Q(W7_Q2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam W7_Q2_87.GSR = "ENABLED";
    LUT4 i1_2_lut_2_lut (.A(R7), .B(R7_Q4), .Z(Clk_enable_42)) /* synthesis lut_function=(A+!(B)) */ ;
    defparam i1_2_lut_2_lut.init = 16'hbbbb;
    FD1P3AX R7_Q4_88 (.D(R7_Q3_N_632), .SP(nPCLK), .CK(Clk), .Q(R7_Q4));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam R7_Q4_88.GSR = "ENABLED";
    FD1P3AX W7_Q4_89 (.D(W7_Q3_N_641), .SP(nPCLK), .CK(Clk), .Q(W7_Q4));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam W7_Q4_89.GSR = "ENABLED";
    LUT4 nRD_I_0_1_lut (.A(PD_DIR_c), .Z(nRD_c)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(916[14:42])
    defparam nRD_I_0_1_lut.init = 16'h5555;
    LUT4 PD_RB_I_0_94_2_lut_3_lut (.A(R7_Q5), .B(R7_Q3), .C(TSTEP_LATCH), 
         .Z(TSTEP)) /* synthesis lut_function=(A ((C)+!B)+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(913[18:36])
    defparam PD_RB_I_0_94_2_lut_3_lut.init = 16'hf2f2;
    LUT4 PD_RB_I_0_3_lut_4_lut (.A(R7_Q5), .B(R7_Q3), .C(BLNK), .D(\Hnn[0] ), 
         .Z(PD_DIR_c)) /* synthesis lut_function=(!(A (B (C+!(D)))+!A (C+!(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(913[18:36])
    defparam PD_RB_I_0_3_lut_4_lut.init = 16'h2f22;
    LUT4 i1_2_lut_3_lut (.A(R7_Q5), .B(R7_Q3), .C(RC), .Z(Clk_enable_297)) /* synthesis lut_function=(A ((C)+!B)+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(913[18:36])
    defparam i1_2_lut_3_lut.init = 16'hf2f2;
    LUT4 i1_2_lut_2_lut_adj_408 (.A(W7), .B(W7_Q4), .Z(Clk_enable_36)) /* synthesis lut_function=(A+!(B)) */ ;
    defparam i1_2_lut_2_lut_adj_408.init = 16'hbbbb;
    LUT4 i1_4_lut (.A(W7_Q3), .B(R7_Q3), .C(W7_Q5), .D(R7_Q5), .Z(n4)) /* synthesis lut_function=(!(A (B (C (D))+!B (C))+!A ((D)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(918[14:81])
    defparam i1_4_lut.init = 16'h0ace;
    FD1P3AX W7_FF_77 (.D(W7_Q4), .SP(Clk_enable_36), .CK(Clk), .Q(W7_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam W7_FF_77.GSR = "ENABLED";
    LUT4 XRB_I_206_2_lut (.A(R7), .B(TH_MUX), .Z(XRB_N_650)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(917[15:31])
    defparam XRB_I_206_2_lut.init = 16'hdddd;
    LUT4 i6_4_lut (.A(PA_c_3), .B(n12), .C(PA_c_4), .D(PA_c_0), .Z(TH_MUX)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(911[17:85])
    defparam i6_4_lut.init = 16'h8000;
    LUT4 i5_4_lut (.A(PA_c_5), .B(PA_c_1), .C(PA_c_2), .D(BLNK_LATCH), 
         .Z(n12)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(911[17:85])
    defparam i5_4_lut.init = 16'h8000;
    FD1P3AX R7_FF_76 (.D(R7_Q4), .SP(Clk_enable_42), .CK(Clk), .Q(R7_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam R7_FF_76.GSR = "ENABLED";
    LUT4 i1147_2_lut (.A(W7), .B(PCLK_c), .Z(n1695)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam i1147_2_lut.init = 16'h8888;
    LUT4 R7_Q3_I_0_1_lut (.A(R7_Q3), .Z(R7_Q3_N_632)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(918[17:23])
    defparam R7_Q3_I_0_1_lut.init = 16'h5555;
    LUT4 W7_Q3_I_0_1_lut (.A(W7_Q3), .Z(W7_Q3_N_641)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(918[39:45])
    defparam W7_Q3_I_0_1_lut.init = 16'h5555;
    FD1P3IX R7_Q1_80 (.D(R7_FF), .SP(PCLK_c), .CD(n1697), .CK(Clk), 
            .Q(R7_Q1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam R7_Q1_80.GSR = "ENABLED";
    LUT4 i8392_2_lut (.A(W7_Q2), .B(W7_Q4), .Z(DB_PAR_N_634)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(914[17:35])
    defparam i8392_2_lut.init = 16'h1111;
    LUT4 R7_Q4_I_0_1_lut (.A(R7_Q4), .Z(R7_Q4_N_629)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(932[13:19])
    defparam R7_Q4_I_0_1_lut.init = 16'h5555;
    LUT4 W7_Q4_I_0_1_lut (.A(W7_Q4), .Z(W7_Q4_N_673)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(933[13:19])
    defparam W7_Q4_I_0_1_lut.init = 16'h5555;
    FD1P3IX W7_Q1_81 (.D(W7_FF), .SP(PCLK_c), .CD(n1695), .CK(Clk), 
            .Q(W7_Q1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(920[8] 941[27])
    defparam W7_Q1_81.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module TIMING_GENERATOR
//

module TIMING_GENERATOR (Vo, Clk, nPCLK, S_EV, PCLK_c, F_AT, Hnn, 
            NFO_OUT, PD_SR, nRES_c, nF_NT, RESCL, Hn0, MODE_c, 
            BLNK_FF, RC, CLIP_OUT, BLNK, O_HPOS, nEVAL, E_EV, 
            I_OAM2, PAR_O, SYNC_c, nVIS, SRLOAD, N_HB, STEP_N_807, 
            DENDY_c, VBL_EN, INT_c, BGCLIP, CLIP_B_N_277, R2, \Hn[1] , 
            \Hn[2] , nPICTURE, \R2DB[2] , Clk_enable_290) /* synthesis syn_module_defined=1 */ ;
    output [7:0]Vo;
    input Clk;
    input nPCLK;
    output S_EV;
    input PCLK_c;
    output F_AT;
    output [5:0]Hnn;
    output NFO_OUT;
    output PD_SR;
    input nRES_c;
    output nF_NT;
    output RESCL;
    output Hn0;
    input MODE_c;
    output BLNK_FF;
    output RC;
    output CLIP_OUT;
    input BLNK;
    output O_HPOS;
    output nEVAL;
    output E_EV;
    output I_OAM2;
    output PAR_O;
    output SYNC_c;
    output nVIS;
    output SRLOAD;
    output N_HB;
    output STEP_N_807;
    input DENDY_c;
    input VBL_EN;
    output INT_c;
    input BGCLIP;
    output CLIP_B_N_277;
    input R2;
    output \Hn[1] ;
    output \Hn[2] ;
    output nPICTURE;
    output \R2DB[2] ;
    input Clk_enable_290;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire V_LINE0P_N_570, n7;
    wire [8:0]H;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(709[10:11])
    
    wire n8752, HIN5, n9429, VC_LATCH_N_367;
    wire [8:0]HCarry;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(745[11:17])
    wire [8:0]V;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(710[10:11])
    
    wire V_8__N_573, FTB_IN, FTB_IN_N_406, SEV_IN, H_LINE2_N_504, 
        HC, HC_N_356, CLIP1, CLIP1_N_389, ODDEVEN1, ODDEVEN1_N_361, 
        FAT_IN, NFO1, NFO2;
    wire [8:0]H_IN_8__N_255;
    
    wire VC_LATCH, n9512;
    wire [8:0]V_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(712[10:14])
    wire [8:0]n438;
    
    wire FTA_OUT;
    wire [8:0]VCarry;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(747[11:17])
    wire [8:0]V_IN_8__N_264;
    
    wire Clk_enable_110, nRES_N_7, H_0__N_443, FNT_IN_N_308, FTB_OUT, 
        FTB_IN_N_412, FTA_IN_N_418, NFO_OUT_N_318, HSYNC, FPORCH_FF_N_447, 
        VSYNC, VSYNC_N_450, PICT1, BPORCH_FF, PICT2, PEN_FF, VSET2, 
        VSET1_N_485, CLIP2, CLIP2_N_386, HPOS_IN, H_LINE5_N_511, EVAL_IN, 
        H_LINE6_N_518, EEV_IN, H_LINE7_N_526, IOAM2_IN, IOAM2_IN_N_398, 
        n8, PARO_IN, PARO_IN_N_402, NVIS_IN, NVIS_IN_N_291, Clk_enable_8, 
        V_LINE3P_N_596, VB_FF, Clk_enable_9, VB_FF_N_298, n8708, n4, 
        n9646, Clk_enable_22, VSET3, VSET2_N_488, CLIP_OUT_N_381, 
        nEVAL_N_281, FNT_IN, FNT_IN_N_311, n6172, NVIS_IN_N_292, n6174, 
        FTA_IN, FTA_IN_N_415, NVIS_IN_N_288, V_LINE0N_N_545, n9409, 
        NFO1_N_421, FAT_IN_N_324, ODDEVEN2;
    wire [8:0]H_IN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(711[10:14])
    
    wire IOAM2_IN_N_399, n3623, n3704, FPORCH_FF, Clk_enable_21, H_LINE0_N_499, 
        n3616, Clk_enable_23, BPORCH_FF_N_467, VSYNC_FF, Clk_enable_24, 
        VSYNC_FF_N_452, n9410, n9406, n9408, n3645, n6, n3633, 
        n8748, PEN_FF_N_470, V_LINE3N_N_591, H_LINE23_N_536, n4587, 
        n8802, n3686, n3683, n3701, n9412, INT_FF, N_HB_N_343, 
        PARO_IN_N_404, n6097, n9404, Clk_enable_39, INT_FF_N_493, 
        n9402, n9562, n9563, n14, Clk_enable_48, VSET1;
    wire [5:0]Hn;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(716[10:12])
    
    wire n17, n7_adj_1717, n9216;
    wire [8:0]n417;
    
    wire n9403, n9428, n3639, n9561;
    
    LUT4 i2_2_lut_3_lut (.A(V_LINE0P_N_570), .B(Vo[5]), .C(Vo[4]), .Z(n7)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(774[22:51])
    defparam i2_2_lut_3_lut.init = 16'hfefe;
    LUT4 i3_4_lut (.A(H[1]), .B(H[4]), .C(H[3]), .D(n8752), .Z(HIN5)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(744[15:47])
    defparam i3_4_lut.init = 16'h8000;
    LUT4 Vo_4__bdd_2_lut (.A(Vo[0]), .B(n9429), .Z(VC_LATCH_N_367)) /* synthesis lut_function=(A (B)) */ ;
    defparam Vo_4__bdd_2_lut.init = 16'h8888;
    LUT4 H_8__I_0_664_i6_2_lut (.A(H[5]), .B(HIN5), .Z(HCarry[5])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(746[22:69])
    defparam H_8__I_0_664_i6_2_lut.init = 16'h8888;
    LUT4 V_8__I_0_1_lut (.A(V[8]), .Z(V_8__N_573)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(774[22:27])
    defparam V_8__I_0_1_lut.init = 16'h5555;
    FD1P3AX FTB_IN_649 (.D(FTB_IN_N_406), .SP(nPCLK), .CK(Clk), .Q(FTB_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam FTB_IN_649.GSR = "ENABLED";
    FD1P3AX SEV_IN_639 (.D(H_LINE2_N_504), .SP(nPCLK), .CK(Clk), .Q(SEV_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam SEV_IN_639.GSR = "ENABLED";
    FD1P3AX HC_636 (.D(HC_N_356), .SP(nPCLK), .CK(Clk), .Q(HC));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam HC_636.GSR = "ENABLED";
    FD1P3AX S_EV_615 (.D(SEV_IN), .SP(PCLK_c), .CK(Clk), .Q(S_EV));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam S_EV_615.GSR = "ENABLED";
    FD1P3AX CLIP1_640 (.D(CLIP1_N_389), .SP(nPCLK), .CK(Clk), .Q(CLIP1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam CLIP1_640.GSR = "ENABLED";
    LUT4 ODDEVEN1_I_0_1_lut (.A(ODDEVEN1), .Z(ODDEVEN1_N_361)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(803[30:39])
    defparam ODDEVEN1_I_0_1_lut.init = 16'h5555;
    LUT4 i5253_2_lut_3_lut (.A(FAT_IN), .B(NFO1), .C(NFO2), .Z(F_AT)) /* synthesis lut_function=(A (B+(C))) */ ;
    defparam i5253_2_lut_3_lut.init = 16'ha8a8;
    LUT4 xor_443_i7_2_lut_3_lut (.A(H[6]), .B(H[5]), .C(HIN5), .Z(H_IN_8__N_255[6])) /* synthesis lut_function=(!(A (B (C))+!A !(B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(838[23:70])
    defparam xor_443_i7_2_lut_3_lut.init = 16'h6a6a;
    FD1P3AX VC_LATCH_637 (.D(VC_LATCH_N_367), .SP(nPCLK), .CK(Clk), .Q(VC_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam VC_LATCH_637.GSR = "ENABLED";
    LUT4 n3616_bdd_4_lut (.A(H[2]), .B(H[0]), .C(H[1]), .D(H[4]), .Z(n9512)) /* synthesis lut_function=(A (B (C (D)))+!A !(B+(C+(D)))) */ ;
    defparam n3616_bdd_4_lut.init = 16'h8001;
    LUT4 and_403_i9_2_lut_3_lut (.A(HC), .B(VC_LATCH), .C(V_IN[8]), .Z(n438[8])) /* synthesis lut_function=(A (C)+!A !(B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(750[13:27])
    defparam and_403_i9_2_lut_3_lut.init = 16'hb0b0;
    LUT4 i1_3_lut_4_lut_4_lut (.A(PCLK_c), .B(Hnn[0]), .C(NFO_OUT), .D(FTA_OUT), 
         .Z(PD_SR)) /* synthesis lut_function=(!(A+((C+(D))+!B))) */ ;
    defparam i1_3_lut_4_lut_4_lut.init = 16'h0004;
    LUT4 xor_443_i3_2_lut_3_lut (.A(H[2]), .B(H[1]), .C(H[0]), .Z(H_IN_8__N_255[2])) /* synthesis lut_function=(!(A (B (C))+!A !(B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(838[23:70])
    defparam xor_443_i3_2_lut_3_lut.init = 16'h6a6a;
    LUT4 xor_444_i4_2_lut (.A(Vo[3]), .B(VCarry[2]), .Z(V_IN_8__N_264[3])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(839[20:52])
    defparam xor_444_i4_2_lut.init = 16'h6666;
    LUT4 i1_2_lut (.A(V[8]), .B(nRES_c), .Z(Clk_enable_110)) /* synthesis lut_function=(A+!(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam i1_2_lut.init = 16'hbbbb;
    LUT4 nRES_I_0_1_lut (.A(nRES_c), .Z(nRES_N_7)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(481[27:32])
    defparam nRES_I_0_1_lut.init = 16'h5555;
    LUT4 H_0__I_0_1_lut (.A(H[0]), .Z(H_0__N_443)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(764[94:99])
    defparam H_0__I_0_1_lut.init = 16'h5555;
    LUT4 xor_443_i4_2_lut_3_lut_4_lut (.A(H[2]), .B(H[1]), .C(H[0]), .D(H[3]), 
         .Z(H_IN_8__N_255[3])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(746[22:69])
    defparam xor_443_i4_2_lut_3_lut_4_lut.init = 16'h7f80;
    LUT4 and_403_i6_2_lut_3_lut (.A(HC), .B(VC_LATCH), .C(V_IN[5]), .Z(n438[5])) /* synthesis lut_function=(A (C)+!A !(B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(750[13:27])
    defparam and_403_i6_2_lut_3_lut.init = 16'hb0b0;
    FD1P3AX nF_NT_623 (.D(FNT_IN_N_308), .SP(PCLK_c), .CK(Clk), .Q(nF_NT));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam nF_NT_623.GSR = "ENABLED";
    FD1P3AX FTB_OUT_624 (.D(FTB_IN_N_412), .SP(PCLK_c), .CK(Clk), .Q(FTB_OUT));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam FTB_OUT_624.GSR = "ENABLED";
    FD1P3AX FTA_OUT_625 (.D(FTA_IN_N_418), .SP(PCLK_c), .CK(Clk), .Q(FTA_OUT));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam FTA_OUT_625.GSR = "ENABLED";
    FD1P3AX NFO_OUT_626 (.D(NFO_OUT_N_318), .SP(PCLK_c), .CK(Clk), .Q(NFO_OUT));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam NFO_OUT_626.GSR = "ENABLED";
    FD1P3AX HSYNC_628 (.D(FPORCH_FF_N_447), .SP(PCLK_c), .CK(Clk), .Q(HSYNC));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam HSYNC_628.GSR = "ENABLED";
    FD1P3AX VSYNC_629 (.D(VSYNC_N_450), .SP(PCLK_c), .CK(Clk), .Q(VSYNC));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam VSYNC_629.GSR = "ENABLED";
    FD1P3AX PICT1_630 (.D(BPORCH_FF), .SP(PCLK_c), .CK(Clk), .Q(PICT1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam PICT1_630.GSR = "ENABLED";
    FD1P3AX PICT2_631 (.D(PEN_FF), .SP(PCLK_c), .CK(Clk), .Q(PICT2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam PICT2_631.GSR = "ENABLED";
    FD1P3AX RESCL_632 (.D(VC_LATCH), .SP(PCLK_c), .CK(Clk), .Q(RESCL));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam RESCL_632.GSR = "ENABLED";
    FD1P3AX VSET2_633 (.D(VSET1_N_485), .SP(PCLK_c), .CK(Clk), .Q(VSET2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam VSET2_633.GSR = "ENABLED";
    FD1P3AX Hn__i0 (.D(H[0]), .SP(nPCLK), .CK(Clk), .Q(Hn0)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam Hn__i0.GSR = "ENABLED";
    FD1P3AX CLIP2_641 (.D(CLIP2_N_386), .SP(nPCLK), .CK(Clk), .Q(CLIP2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam CLIP2_641.GSR = "ENABLED";
    FD1P3AX HPOS_IN_642 (.D(H_LINE5_N_511), .SP(nPCLK), .CK(Clk), .Q(HPOS_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam HPOS_IN_642.GSR = "ENABLED";
    FD1P3AX EVAL_IN_643 (.D(H_LINE6_N_518), .SP(nPCLK), .CK(Clk), .Q(EVAL_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam EVAL_IN_643.GSR = "ENABLED";
    FD1P3AX EEV_IN_644 (.D(H_LINE7_N_526), .SP(nPCLK), .CK(Clk), .Q(EEV_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam EEV_IN_644.GSR = "ENABLED";
    FD1P3AX IOAM2_IN_645 (.D(IOAM2_IN_N_398), .SP(nPCLK), .CK(Clk), .Q(IOAM2_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam IOAM2_IN_645.GSR = "ENABLED";
    LUT4 i2_2_lut_3_lut_adj_391 (.A(MODE_c), .B(Vo[0]), .C(V[8]), .Z(n8)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i2_2_lut_3_lut_adj_391.init = 16'h8080;
    LUT4 xor_444_i7_2_lut (.A(Vo[6]), .B(VCarry[5]), .Z(V_IN_8__N_264[6])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(839[20:52])
    defparam xor_444_i7_2_lut.init = 16'h6666;
    FD1P3AX PARO_IN_646 (.D(PARO_IN_N_402), .SP(nPCLK), .CK(Clk), .Q(PARO_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam PARO_IN_646.GSR = "ENABLED";
    FD1P3AX NVIS_IN_647 (.D(NVIS_IN_N_291), .SP(nPCLK), .CK(Clk), .Q(NVIS_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam NVIS_IN_647.GSR = "ENABLED";
    FD1P3AX BLNK_FF_659 (.D(V_LINE3P_N_596), .SP(Clk_enable_8), .CK(Clk), 
            .Q(BLNK_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam BLNK_FF_659.GSR = "ENABLED";
    FD1P3AX VB_FF_660 (.D(VB_FF_N_298), .SP(Clk_enable_9), .CK(Clk), .Q(VB_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam VB_FF_660.GSR = "ENABLED";
    FD1P3AX Hnn_i0_i0 (.D(Hn0), .SP(PCLK_c), .CK(Clk), .Q(Hnn[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam Hnn_i0_i0.GSR = "ENABLED";
    FD1S3AX RC_609 (.D(n8708), .CK(Clk), .Q(RC)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam RC_609.GSR = "ENABLED";
    FD1P3AX V_IN_i0_i0 (.D(V_IN_8__N_264[0]), .SP(nPCLK), .CK(Clk), .Q(V_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V_IN_i0_i0.GSR = "ENABLED";
    LUT4 and_403_i8_2_lut_3_lut (.A(HC), .B(VC_LATCH), .C(V_IN[7]), .Z(n438[7])) /* synthesis lut_function=(A (C)+!A !(B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(750[13:27])
    defparam and_403_i8_2_lut_3_lut.init = 16'hb0b0;
    LUT4 PCLK_c_bdd_4_lut (.A(PCLK_c), .B(n4), .C(H[4]), .D(n9646), 
         .Z(Clk_enable_22)) /* synthesis lut_function=(!(A+(B+!(C (D))))) */ ;
    defparam PCLK_c_bdd_4_lut.init = 16'h1000;
    LUT4 i5263_2_lut (.A(H[2]), .B(H[1]), .Z(FTB_IN_N_406)) /* synthesis lut_function=(A (B)) */ ;
    defparam i5263_2_lut.init = 16'h8888;
    FD1P3AX VSET3_663 (.D(VSET2_N_488), .SP(nPCLK), .CK(Clk), .Q(VSET3));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam VSET3_663.GSR = "ENABLED";
    FD1P3AX CLIP_OUT_616 (.D(CLIP_OUT_N_381), .SP(PCLK_c), .CK(Clk), .Q(CLIP_OUT));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam CLIP_OUT_616.GSR = "ENABLED";
    LUT4 i8528_3_lut_4_lut (.A(Vo[0]), .B(n9429), .C(PCLK_c), .D(V_LINE3P_N_596), 
         .Z(Clk_enable_8)) /* synthesis lut_function=(!(A (B (C)+!B (C+!(D)))+!A (C+!(D)))) */ ;
    defparam i8528_3_lut_4_lut.init = 16'h0f08;
    LUT4 i8356_2_lut_3_lut (.A(BLNK), .B(H[8]), .C(VB_FF), .Z(NVIS_IN_N_291)) /* synthesis lut_function=(!(A+(B+!(C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(851[20:46])
    defparam i8356_2_lut_3_lut.init = 16'h1010;
    FD1P3AX O_HPOS_617 (.D(HPOS_IN), .SP(PCLK_c), .CK(Clk), .Q(O_HPOS));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam O_HPOS_617.GSR = "ENABLED";
    FD1P3AX nEVAL_618 (.D(nEVAL_N_281), .SP(PCLK_c), .CK(Clk), .Q(nEVAL));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam nEVAL_618.GSR = "ENABLED";
    FD1P3AX FNT_IN_648 (.D(FNT_IN_N_311), .SP(nPCLK), .CK(Clk), .Q(FNT_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam FNT_IN_648.GSR = "ENABLED";
    LUT4 i1_2_lut_4_lut (.A(H[4]), .B(H[1]), .C(H[2]), .D(H[0]), .Z(n6172)) /* synthesis lut_function=(A (B (C (D)))) */ ;
    defparam i1_2_lut_4_lut.init = 16'h8000;
    LUT4 i8299_2_lut_4_lut (.A(NVIS_IN_N_292), .B(H[7]), .C(H[6]), .D(n6174), 
         .Z(H_LINE6_N_518)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(765[19:101])
    defparam i8299_2_lut_4_lut.init = 16'h0200;
    FD1P3AX FTA_IN_650 (.D(FTA_IN_N_415), .SP(nPCLK), .CK(Clk), .Q(FTA_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam FTA_IN_650.GSR = "ENABLED";
    LUT4 i8361_2_lut (.A(H[2]), .B(H[1]), .Z(FTA_IN_N_415)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(854[20:37])
    defparam i8361_2_lut.init = 16'h2222;
    FD1P3AX E_EV_619 (.D(EEV_IN), .SP(PCLK_c), .CK(Clk), .Q(E_EV));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam E_EV_619.GSR = "ENABLED";
    FD1P3AX I_OAM2_620 (.D(IOAM2_IN), .SP(PCLK_c), .CK(Clk), .Q(I_OAM2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam I_OAM2_620.GSR = "ENABLED";
    FD1P3AX PAR_O_621 (.D(PARO_IN), .SP(PCLK_c), .CK(Clk), .Q(PAR_O));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam PAR_O_621.GSR = "ENABLED";
    LUT4 HSYNC_I_0_697_2_lut (.A(HSYNC), .B(VSYNC), .Z(SYNC_c)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(794[15:28])
    defparam HSYNC_I_0_697_2_lut.init = 16'heeee;
    LUT4 i1_2_lut_3_lut (.A(V[8]), .B(Vo[7]), .C(Vo[6]), .Z(V_LINE0P_N_570)) /* synthesis lut_function=((B+(C))+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(774[22:43])
    defparam i1_2_lut_3_lut.init = 16'hfdfd;
    LUT4 xor_443_i8_2_lut_3_lut_4_lut (.A(H[6]), .B(H[5]), .C(HIN5), .D(H[7]), 
         .Z(H_IN_8__N_255[7])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(746[22:69])
    defparam xor_443_i8_2_lut_3_lut_4_lut.init = 16'h7f80;
    LUT4 i8354_2_lut_3_lut_4_lut (.A(BLNK), .B(H[8]), .C(H[7]), .D(H[6]), 
         .Z(PARO_IN_N_402)) /* synthesis lut_function=(!(A+((C+(D))+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(764[23:43])
    defparam i8354_2_lut_3_lut_4_lut.init = 16'h0004;
    FD1P3AX nVIS_622 (.D(NVIS_IN_N_288), .SP(PCLK_c), .CK(Clk), .Q(nVIS));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam nVIS_622.GSR = "ENABLED";
    LUT4 Vo_3__bdd_4_lut_8647 (.A(V_LINE0N_N_545), .B(Vo[1]), .C(Vo[0]), 
         .D(Vo[2]), .Z(n9409)) /* synthesis lut_function=(!(A+!(B (C (D))+!B !(C+!(D))))) */ ;
    defparam Vo_3__bdd_4_lut_8647.init = 16'h4100;
    FD1P3AX NFO1_651 (.D(NFO1_N_421), .SP(nPCLK), .CK(Clk), .Q(NFO1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam NFO1_651.GSR = "ENABLED";
    FD1P3AX FAT_IN_653 (.D(FAT_IN_N_324), .SP(nPCLK), .CK(Clk), .Q(FAT_IN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam FAT_IN_653.GSR = "ENABLED";
    FD1P3AX ODDEVEN2_607 (.D(ODDEVEN1_N_361), .SP(V_8__N_573), .CK(Clk), 
            .Q(ODDEVEN2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam ODDEVEN2_607.GSR = "ENABLED";
    FD1P3AX H_IN_i0_i0 (.D(H_0__N_443), .SP(nPCLK), .CK(Clk), .Q(H_IN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H_IN_i0_i0.GSR = "ENABLED";
    LUT4 PCLK_c_bdd_4_lut_8737 (.A(H[2]), .B(H[5]), .C(H[1]), .D(H[0]), 
         .Z(n9646)) /* synthesis lut_function=(!(A (B+!(C (D)))+!A ((C+(D))+!B))) */ ;
    defparam PCLK_c_bdd_4_lut_8737.init = 16'h2004;
    LUT4 PD_SR_N_805_I_0_2_lut_3_lut_4_lut (.A(FTB_OUT), .B(NFO_OUT), .C(PCLK_c), 
         .D(Hnn[0]), .Z(SRLOAD)) /* synthesis lut_function=(!(A+(B+(C+!(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(787[16:37])
    defparam PD_SR_N_805_I_0_2_lut_3_lut_4_lut.init = 16'h0100;
    LUT4 and_403_i5_2_lut_3_lut (.A(HC), .B(VC_LATCH), .C(V_IN[4]), .Z(n438[4])) /* synthesis lut_function=(A (C)+!A !(B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(750[13:27])
    defparam and_403_i5_2_lut_3_lut.init = 16'hb0b0;
    LUT4 i8294_4_lut (.A(IOAM2_IN_N_399), .B(H[1]), .C(H[4]), .D(n3623), 
         .Z(H_LINE2_N_504)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(763[19:101])
    defparam i8294_4_lut.init = 16'h0001;
    LUT4 xor_444_i8_2_lut_3_lut (.A(Vo[6]), .B(VCarry[5]), .C(Vo[7]), 
         .Z(V_IN_8__N_264[7])) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(748[22:54])
    defparam xor_444_i8_2_lut_3_lut.init = 16'h7878;
    LUT4 i2_3_lut (.A(H[2]), .B(n3704), .C(H[0]), .Z(n3623)) /* synthesis lut_function=(A+(B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(763[20:101])
    defparam i2_3_lut.init = 16'hefef;
    FD1P3AX FPORCH_FF_654 (.D(H_LINE0_N_499), .SP(Clk_enable_21), .CK(Clk), 
            .Q(FPORCH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam FPORCH_FF_654.GSR = "ENABLED";
    LUT4 xor_444_i9_3_lut_4_lut (.A(Vo[6]), .B(VCarry[5]), .C(Vo[7]), 
         .D(V[8]), .Z(V_IN_8__N_264[8])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(748[22:54])
    defparam xor_444_i9_3_lut_4_lut.init = 16'h7f80;
    LUT4 V_8__I_0_665_i6_2_lut_3_lut_4_lut (.A(Vo[3]), .B(VCarry[2]), .C(Vo[5]), 
         .D(Vo[4]), .Z(VCarry[5])) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(748[22:54])
    defparam V_8__I_0_665_i6_2_lut_3_lut_4_lut.init = 16'h8000;
    LUT4 xor_444_i6_2_lut_3_lut_4_lut (.A(Vo[3]), .B(VCarry[2]), .C(Vo[5]), 
         .D(Vo[4]), .Z(V_IN_8__N_264[5])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(748[22:54])
    defparam xor_444_i6_2_lut_3_lut_4_lut.init = 16'h78f0;
    LUT4 i2_2_lut (.A(H[5]), .B(n4), .Z(n3616)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(761[20:93])
    defparam i2_2_lut.init = 16'heeee;
    LUT4 xor_444_i5_2_lut_3_lut (.A(Vo[3]), .B(VCarry[2]), .C(Vo[4]), 
         .Z(V_IN_8__N_264[4])) /* synthesis lut_function=(!(A (B (C)+!B !(C))+!A !(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(748[22:54])
    defparam xor_444_i5_2_lut_3_lut.init = 16'h7878;
    FD1P3AX N_HB_656 (.D(H_LINE0_N_499), .SP(Clk_enable_22), .CK(Clk), 
            .Q(N_HB));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam N_HB_656.GSR = "ENABLED";
    FD1P3AX BPORCH_FF_657 (.D(BPORCH_FF_N_467), .SP(Clk_enable_23), .CK(Clk), 
            .Q(BPORCH_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam BPORCH_FF_657.GSR = "ENABLED";
    FD1P3AX VSYNC_FF_608 (.D(VSYNC_FF_N_452), .SP(Clk_enable_24), .CK(Clk), 
            .Q(VSYNC_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam VSYNC_FF_608.GSR = "ENABLED";
    LUT4 N_HB_bdd_2_lut_8651 (.A(N_HB), .B(n9410), .Z(Clk_enable_24)) /* synthesis lut_function=(A (B)) */ ;
    defparam N_HB_bdd_2_lut_8651.init = 16'h8888;
    LUT4 n9407_bdd_2_lut_4_lut (.A(V_LINE0P_N_570), .B(Vo[5]), .C(n9406), 
         .D(Vo[1]), .Z(n9408)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;
    defparam n9407_bdd_2_lut_4_lut.init = 16'h0010;
    LUT4 i1_3_lut_4_lut (.A(Vo[3]), .B(n3645), .C(Vo[0]), .D(Vo[5]), 
         .Z(n6)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(773[22:59])
    defparam i1_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_3_lut_4_lut_adj_392 (.A(Vo[7]), .B(Vo[6]), .C(Vo[5]), .D(n3633), 
         .Z(V_LINE0N_N_545)) /* synthesis lut_function=((((D)+!C)+!B)+!A) */ ;
    defparam i1_3_lut_4_lut_adj_392.init = 16'hff7f;
    LUT4 Hnn0_I_0_2_lut_3_lut (.A(FTB_OUT), .B(NFO_OUT), .C(Hnn[0]), .Z(STEP_N_807)) /* synthesis lut_function=(!(A+(B+!(C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(787[16:37])
    defparam Hnn0_I_0_2_lut_3_lut.init = 16'h1010;
    LUT4 i2_3_lut_4_lut (.A(Vo[7]), .B(Vo[6]), .C(Vo[4]), .D(DENDY_c), 
         .Z(n8748)) /* synthesis lut_function=(!((((D)+!C)+!B)+!A)) */ ;
    defparam i2_3_lut_4_lut.init = 16'h0080;
    LUT4 i8369_2_lut (.A(BLNK), .B(H[8]), .Z(NVIS_IN_N_292)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(856[20:37])
    defparam i8369_2_lut.init = 16'h1111;
    LUT4 and_403_i4_2_lut_3_lut (.A(HC), .B(VC_LATCH), .C(V_IN[3]), .Z(n438[3])) /* synthesis lut_function=(A (C)+!A !(B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(750[13:27])
    defparam and_403_i4_2_lut_3_lut.init = 16'hb0b0;
    LUT4 i1_3_lut_4_lut_adj_393 (.A(V_LINE0N_N_545), .B(n3645), .C(Vo[0]), 
         .D(MODE_c), .Z(PEN_FF_N_470)) /* synthesis lut_function=(!(A+(B+(C (D)+!C !(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(779[22:75])
    defparam i1_3_lut_4_lut_adj_393.init = 16'h0110;
    LUT4 i8311_3_lut_4_lut (.A(V_LINE0N_N_545), .B(n3645), .C(Vo[0]), 
         .D(MODE_c), .Z(V_LINE3N_N_591)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(779[22:75])
    defparam i8311_3_lut_4_lut.init = 16'h0010;
    LUT4 V_8__I_0_665_i3_2_lut_3_lut_4_lut (.A(Vo[0]), .B(H_LINE23_N_536), 
         .C(Vo[2]), .D(Vo[1]), .Z(VCarry[2])) /* synthesis lut_function=(!((B+!(C (D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(748[22:54])
    defparam V_8__I_0_665_i3_2_lut_3_lut_4_lut.init = 16'h2000;
    LUT4 xor_444_i3_2_lut_3_lut_4_lut (.A(Vo[0]), .B(H_LINE23_N_536), .C(Vo[2]), 
         .D(Vo[1]), .Z(V_IN_8__N_264[2])) /* synthesis lut_function=(A (B (C)+!B !(C (D)+!C !(D)))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(748[22:54])
    defparam xor_444_i3_2_lut_3_lut_4_lut.init = 16'hd2f0;
    FD1P3IX V__i9 (.D(n438[8]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(V[8])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V__i9.GSR = "ENABLED";
    FD1P3IX V__i8 (.D(n438[7]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(Vo[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V__i8.GSR = "ENABLED";
    LUT4 xor_444_i2_2_lut_3_lut (.A(Vo[0]), .B(H_LINE23_N_536), .C(Vo[1]), 
         .Z(V_IN_8__N_264[1])) /* synthesis lut_function=(A (B (C)+!B !(C))+!A (C)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(748[22:54])
    defparam xor_444_i2_2_lut_3_lut.init = 16'hd2d2;
    LUT4 i8338_4_lut (.A(H_LINE23_N_536), .B(H_LINE5_N_511), .C(n8802), 
         .D(RESCL), .Z(HC_N_356)) /* synthesis lut_function=(A ((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(840[20:74])
    defparam i8338_4_lut.init = 16'ha2aa;
    FD1P3IX V__i7 (.D(n438[6]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(Vo[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V__i7.GSR = "ENABLED";
    FD1P3IX V__i6 (.D(n438[5]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(Vo[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V__i6.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut_adj_394 (.A(H[1]), .B(H[0]), .C(H[4]), .Z(n3686)) /* synthesis lut_function=(A+(B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(762[20:93])
    defparam i1_2_lut_3_lut_adj_394.init = 16'hefef;
    LUT4 i8202_2_lut (.A(ODDEVEN1), .B(MODE_c), .Z(n8802)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i8202_2_lut.init = 16'heeee;
    LUT4 PCLK_c_bdd_4_lut_8736 (.A(n3683), .B(H[8]), .C(n3701), .D(n3616), 
         .Z(n9412)) /* synthesis lut_function=(!(A+(B (D)+!B (C (D))))) */ ;
    defparam PCLK_c_bdd_4_lut_8736.init = 16'h0155;
    FD1P3IX V__i5 (.D(n438[4]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(Vo[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V__i5.GSR = "ENABLED";
    LUT4 VBL_EN_I_0_2_lut (.A(VBL_EN), .B(INT_FF), .Z(INT_c)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(798[14:29])
    defparam VBL_EN_I_0_2_lut.init = 16'h8888;
    FD1P3AX NFO2_652 (.D(NVIS_IN_N_292), .SP(nPCLK), .CK(Clk), .Q(NFO2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam NFO2_652.GSR = "ENABLED";
    LUT4 i3_4_lut_adj_395 (.A(N_HB_N_343), .B(H[2]), .C(n3686), .D(n3704), 
         .Z(H_LINE23_N_536)) /* synthesis lut_function=(A+((C+(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(772[20:93])
    defparam i3_4_lut_adj_395.init = 16'hfffb;
    LUT4 i8316_2_lut_3_lut_4_lut (.A(V_LINE0N_N_545), .B(Vo[1]), .C(Vo[2]), 
         .D(Vo[0]), .Z(V_LINE3P_N_596)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(779[22:75])
    defparam i8316_2_lut_3_lut_4_lut.init = 16'h0001;
    LUT4 and_403_i7_2_lut_3_lut (.A(HC), .B(VC_LATCH), .C(V_IN[6]), .Z(n438[6])) /* synthesis lut_function=(A (C)+!A !(B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(750[13:27])
    defparam and_403_i7_2_lut_3_lut.init = 16'hb0b0;
    LUT4 NVIS_IN_N_292_I_0_694_2_lut_3_lut (.A(BLNK), .B(H[8]), .C(H[7]), 
         .Z(IOAM2_IN_N_399)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(763[23:43])
    defparam NVIS_IN_N_292_I_0_694_2_lut_3_lut.init = 16'hfefe;
    LUT4 i8297_3_lut_4_lut (.A(PARO_IN_N_404), .B(H[7]), .C(n6097), .D(n3623), 
         .Z(H_LINE5_N_511)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(764[23:43])
    defparam i8297_3_lut_4_lut.init = 16'h0010;
    FD1P3IX V__i4 (.D(n438[3]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(Vo[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V__i4.GSR = "ENABLED";
    LUT4 i5499_2_lut (.A(H[4]), .B(H[1]), .Z(n6097)) /* synthesis lut_function=(A (B)) */ ;
    defparam i5499_2_lut.init = 16'h8888;
    LUT4 Vo_1__bdd_3_lut_8676 (.A(Vo[1]), .B(Vo[2]), .C(n9404), .Z(VSYNC_FF_N_452)) /* synthesis lut_function=(!(A+!(B (C)))) */ ;
    defparam Vo_1__bdd_3_lut_8676.init = 16'h4040;
    LUT4 PCLK_c_bdd_3_lut_4_lut (.A(H[0]), .B(H[1]), .C(n9412), .D(PCLK_c), 
         .Z(Clk_enable_23)) /* synthesis lut_function=(!(A+(((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(767[20:93])
    defparam PCLK_c_bdd_3_lut_4_lut.init = 16'h0040;
    FD1P3AX INT_FF_610 (.D(INT_FF_N_493), .SP(Clk_enable_39), .CK(Clk), 
            .Q(INT_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam INT_FF_610.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut_adj_396 (.A(H[3]), .B(H[5]), .C(H[6]), .Z(n3704)) /* synthesis lut_function=(A+(B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(844[21:57])
    defparam i1_2_lut_3_lut_adj_396.init = 16'hefef;
    LUT4 i2_3_lut_4_lut_adj_397 (.A(H[3]), .B(H[5]), .C(H[6]), .D(H[7]), 
         .Z(n3701)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(844[21:57])
    defparam i2_3_lut_4_lut_adj_397.init = 16'hfffe;
    LUT4 BLNK_I_0_715_2_lut (.A(BLNK), .B(H[8]), .Z(PARO_IN_N_404)) /* synthesis lut_function=(A+!(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(764[23:35])
    defparam BLNK_I_0_715_2_lut.init = 16'hbbbb;
    LUT4 N_HB_I_54_2_lut (.A(H[8]), .B(H[7]), .Z(N_HB_N_343)) /* synthesis lut_function=((B)+!A) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(772[22:35])
    defparam N_HB_I_54_2_lut.init = 16'hdddd;
    FD1P3IX V__i3 (.D(n438[2]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(Vo[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V__i3.GSR = "ENABLED";
    LUT4 Vo_3__bdd_3_lut (.A(Vo[3]), .B(Vo[0]), .C(n7), .Z(n9402)) /* synthesis lut_function=(!(((C)+!B)+!A)) */ ;
    defparam Vo_3__bdd_3_lut.init = 16'h0808;
    LUT4 i8288_2_lut (.A(CLIP_OUT), .B(BGCLIP), .Z(CLIP_B_N_277)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(755[17:39])
    defparam i8288_2_lut.init = 16'h1111;
    LUT4 i8351_2_lut_3_lut_4_lut (.A(BLNK), .B(H[8]), .C(H[7]), .D(H[6]), 
         .Z(IOAM2_IN_N_398)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(849[20:53])
    defparam i8351_2_lut_3_lut_4_lut.init = 16'h0001;
    LUT4 Vo_3__bdd_4_lut_8635 (.A(Vo[3]), .B(Vo[4]), .C(Vo[0]), .D(Vo[2]), 
         .Z(n9406)) /* synthesis lut_function=(!(A (B+!(C (D)))+!A ((C+(D))+!B))) */ ;
    defparam Vo_3__bdd_4_lut_8635.init = 16'h2004;
    LUT4 and_403_i3_2_lut_3_lut (.A(HC), .B(VC_LATCH), .C(V_IN[2]), .Z(n438[2])) /* synthesis lut_function=(A (C)+!A !(B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(750[13:27])
    defparam and_403_i3_2_lut_3_lut.init = 16'hb0b0;
    LUT4 i8345_2_lut (.A(H[4]), .B(n3701), .Z(CLIP1_N_389)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(844[20:57])
    defparam i8345_2_lut.init = 16'h1111;
    PFUMX i8703 (.BLUT(n9562), .ALUT(VB_FF_N_298), .C0(MODE_c), .Z(n9563));
    LUT4 i2_3_lut_4_lut_adj_398 (.A(Vo[4]), .B(DENDY_c), .C(Vo[7]), .D(Vo[6]), 
         .Z(n14)) /* synthesis lut_function=(!(A+((C+(D))+!B))) */ ;
    defparam i2_3_lut_4_lut_adj_398.init = 16'h0004;
    FD1P3AX PEN_FF_658 (.D(PEN_FF_N_470), .SP(Clk_enable_48), .CK(Clk), 
            .Q(PEN_FF));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam PEN_FF_658.GSR = "ENABLED";
    FD1P3IX V__i2 (.D(n438[1]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(Vo[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V__i2.GSR = "ENABLED";
    LUT4 i8374_2_lut_3_lut_4_lut (.A(n3616), .B(n3683), .C(H[1]), .D(H[0]), 
         .Z(BPORCH_FF_N_467)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(762[22:75])
    defparam i8374_2_lut_3_lut_4_lut.init = 16'h0010;
    LUT4 i1_4_lut (.A(VSET3), .B(INT_FF_N_493), .C(VSET1), .D(PCLK_c), 
         .Z(Clk_enable_39)) /* synthesis lut_function=(!(A (B)+!A !((C (D))+!B))) */ ;
    defparam i1_4_lut.init = 16'h7333;
    LUT4 xor_443_i9_3_lut_4_lut (.A(H[6]), .B(HCarry[5]), .C(H[7]), .D(H[8]), 
         .Z(H_IN_8__N_255[8])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(746[22:69])
    defparam xor_443_i9_3_lut_4_lut.init = 16'h7f80;
    LUT4 i8328_2_lut (.A(RESCL), .B(R2), .Z(INT_FF_N_493)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam i8328_2_lut.init = 16'h1111;
    LUT4 i1_2_lut_adj_399 (.A(H[2]), .B(H[4]), .Z(n3683)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(762[22:75])
    defparam i1_2_lut_adj_399.init = 16'heeee;
    LUT4 and_403_i2_2_lut_3_lut (.A(HC), .B(VC_LATCH), .C(V_IN[1]), .Z(n438[1])) /* synthesis lut_function=(A (C)+!A !(B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(750[13:27])
    defparam and_403_i2_2_lut_3_lut.init = 16'hb0b0;
    FD1P3AX Hn__i1 (.D(H[1]), .SP(nPCLK), .CK(Clk), .Q(\Hn[1] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam Hn__i1.GSR = "ENABLED";
    FD1P3AX Hn__i2 (.D(H[2]), .SP(nPCLK), .CK(Clk), .Q(\Hn[2] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam Hn__i2.GSR = "ENABLED";
    FD1P3AX Hn__i3 (.D(H[3]), .SP(nPCLK), .CK(Clk), .Q(Hn[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam Hn__i3.GSR = "ENABLED";
    FD1P3AX Hn__i4 (.D(H[4]), .SP(nPCLK), .CK(Clk), .Q(Hn[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam Hn__i4.GSR = "ENABLED";
    FD1P3AX Hn__i5 (.D(H[5]), .SP(nPCLK), .CK(Clk), .Q(Hn[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam Hn__i5.GSR = "ENABLED";
    FD1P3AX Hnn_i0_i1 (.D(\Hn[1] ), .SP(PCLK_c), .CK(Clk), .Q(Hnn[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam Hnn_i0_i1.GSR = "ENABLED";
    LUT4 i1130_2_lut (.A(PCLK_c), .B(nRES_c), .Z(n4587)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam i1130_2_lut.init = 16'h2222;
    FD1P3AX Hnn_i0_i2 (.D(\Hn[2] ), .SP(PCLK_c), .CK(Clk), .Q(Hnn[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam Hnn_i0_i2.GSR = "ENABLED";
    FD1P3AX Hnn_i0_i3 (.D(Hn[3]), .SP(PCLK_c), .CK(Clk), .Q(Hnn[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam Hnn_i0_i3.GSR = "ENABLED";
    FD1P3AX Hnn_i0_i4 (.D(Hn[4]), .SP(PCLK_c), .CK(Clk), .Q(Hnn[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam Hnn_i0_i4.GSR = "ENABLED";
    FD1P3AX Hnn_i0_i5 (.D(Hn[5]), .SP(PCLK_c), .CK(Clk), .Q(Hnn[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam Hnn_i0_i5.GSR = "ENABLED";
    FD1P3AX V_IN_i0_i1 (.D(V_IN_8__N_264[1]), .SP(nPCLK), .CK(Clk), .Q(V_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V_IN_i0_i1.GSR = "ENABLED";
    FD1P3AX V_IN_i0_i2 (.D(V_IN_8__N_264[2]), .SP(nPCLK), .CK(Clk), .Q(V_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX V_IN_i0_i3 (.D(V_IN_8__N_264[3]), .SP(nPCLK), .CK(Clk), .Q(V_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX V_IN_i0_i4 (.D(V_IN_8__N_264[4]), .SP(nPCLK), .CK(Clk), .Q(V_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX V_IN_i0_i5 (.D(V_IN_8__N_264[5]), .SP(nPCLK), .CK(Clk), .Q(V_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX V_IN_i0_i6 (.D(V_IN_8__N_264[6]), .SP(nPCLK), .CK(Clk), .Q(V_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX V_IN_i0_i7 (.D(V_IN_8__N_264[7]), .SP(nPCLK), .CK(Clk), .Q(V_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V_IN_i0_i7.GSR = "ENABLED";
    FD1P3AX V_IN_i0_i8 (.D(V_IN_8__N_264[8]), .SP(nPCLK), .CK(Clk), .Q(V_IN[8])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V_IN_i0_i8.GSR = "ENABLED";
    LUT4 i5_4_lut (.A(n17), .B(n7_adj_1717), .C(Vo[2]), .D(n8), .Z(n9216)) /* synthesis lut_function=(!(((C+!(D))+!B)+!A)) */ ;
    defparam i5_4_lut.init = 16'h0800;
    LUT4 i1_3_lut (.A(Vo[5]), .B(PCLK_c), .C(Vo[3]), .Z(n7_adj_1717)) /* synthesis lut_function=(!((B+(C))+!A)) */ ;
    defparam i1_3_lut.init = 16'h0202;
    LUT4 and_400_i1_2_lut (.A(HC), .B(H_IN[0]), .Z(n417[0])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(814[37:60])
    defparam and_400_i1_2_lut.init = 16'h8888;
    LUT4 i1_2_lut_adj_400 (.A(Vo[3]), .B(Vo[4]), .Z(n3633)) /* synthesis lut_function=(A+!(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(773[22:59])
    defparam i1_2_lut_adj_400.init = 16'hbbbb;
    FD1P3AX H_IN_i0_i1 (.D(H_IN_8__N_255[1]), .SP(nPCLK), .CK(Clk), .Q(H_IN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H_IN_i0_i1.GSR = "ENABLED";
    FD1P3IX H__i8 (.D(n417[8]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(H[8])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H__i8.GSR = "ENABLED";
    PFUMX i8633 (.BLUT(n9403), .ALUT(n9402), .C0(MODE_c), .Z(n9404));
    FD1P3IX H__i7 (.D(n417[7]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(H[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H__i7.GSR = "ENABLED";
    FD1P3IX H__i6 (.D(n417[6]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(H[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H__i6.GSR = "ENABLED";
    FD1P3IX H__i5 (.D(n417[5]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(H[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H__i5.GSR = "ENABLED";
    FD1P3IX H__i4 (.D(n417[4]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(H[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H__i4.GSR = "ENABLED";
    FD1P3IX H__i3 (.D(n417[3]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(H[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H__i3.GSR = "ENABLED";
    LUT4 Vo_4__bdd_4_lut_8655 (.A(Vo[2]), .B(V_LINE0P_N_570), .C(Vo[3]), 
         .D(n9428), .Z(n9429)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;
    defparam Vo_4__bdd_4_lut_8655.init = 16'h0200;
    FD1P3IX H__i2 (.D(n417[2]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(H[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H__i2.GSR = "ENABLED";
    FD1P3IX H__i1 (.D(n417[1]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(H[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H__i1.GSR = "ENABLED";
    LUT4 and_403_i1_2_lut_3_lut (.A(HC), .B(VC_LATCH), .C(V_IN[0]), .Z(n438[0])) /* synthesis lut_function=(A (C)+!A !(B+!(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(750[13:27])
    defparam and_403_i1_2_lut_3_lut.init = 16'hb0b0;
    LUT4 n3616_bdd_3_lut_4_lut (.A(H[5]), .B(n4), .C(PCLK_c), .D(n9512), 
         .Z(Clk_enable_21)) /* synthesis lut_function=(!(A+(B+(C+!(D))))) */ ;
    defparam n3616_bdd_3_lut_4_lut.init = 16'h0100;
    LUT4 i1_2_lut_adj_401 (.A(Vo[7]), .B(Vo[6]), .Z(n3639)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(774[22:43])
    defparam i1_2_lut_adj_401.init = 16'heeee;
    LUT4 xor_443_i2_2_lut (.A(H[1]), .B(H[0]), .Z(H_IN_8__N_255[1])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(838[23:70])
    defparam xor_443_i2_2_lut.init = 16'h6666;
    LUT4 and_400_i9_2_lut (.A(HC), .B(H_IN[8]), .Z(n417[8])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(814[37:60])
    defparam and_400_i9_2_lut.init = 16'h8888;
    LUT4 and_400_i8_2_lut (.A(HC), .B(H_IN[7]), .Z(n417[7])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(814[37:60])
    defparam and_400_i8_2_lut.init = 16'h8888;
    LUT4 and_400_i7_2_lut (.A(HC), .B(H_IN[6]), .Z(n417[6])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(814[37:60])
    defparam and_400_i7_2_lut.init = 16'h8888;
    LUT4 FNT_IN_I_0_1_lut (.A(FNT_IN), .Z(FNT_IN_N_308)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(825[20:27])
    defparam FNT_IN_I_0_1_lut.init = 16'h5555;
    LUT4 FTB_IN_I_0_1_lut (.A(FTB_IN), .Z(FTB_IN_N_412)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(826[20:27])
    defparam FTB_IN_I_0_1_lut.init = 16'h5555;
    FD1P3AX H_IN_i0_i2 (.D(H_IN_8__N_255[2]), .SP(nPCLK), .CK(Clk), .Q(H_IN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H_IN_i0_i2.GSR = "ENABLED";
    FD1P3AX H_IN_i0_i3 (.D(H_IN_8__N_255[3]), .SP(nPCLK), .CK(Clk), .Q(H_IN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H_IN_i0_i3.GSR = "ENABLED";
    FD1P3AX H_IN_i0_i4 (.D(H_IN_8__N_255[4]), .SP(nPCLK), .CK(Clk), .Q(H_IN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H_IN_i0_i4.GSR = "ENABLED";
    FD1P3AX H_IN_i0_i5 (.D(H_IN_8__N_255[5]), .SP(nPCLK), .CK(Clk), .Q(H_IN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H_IN_i0_i5.GSR = "ENABLED";
    FD1P3AX H_IN_i0_i6 (.D(H_IN_8__N_255[6]), .SP(nPCLK), .CK(Clk), .Q(H_IN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H_IN_i0_i6.GSR = "ENABLED";
    FD1P3AX H_IN_i0_i7 (.D(H_IN_8__N_255[7]), .SP(nPCLK), .CK(Clk), .Q(H_IN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H_IN_i0_i7.GSR = "ENABLED";
    FD1P3AX H_IN_i0_i8 (.D(H_IN_8__N_255[8]), .SP(nPCLK), .CK(Clk), .Q(H_IN[8])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H_IN_i0_i8.GSR = "ENABLED";
    LUT4 FTA_IN_I_0_1_lut (.A(FTA_IN), .Z(FTA_IN_N_418)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(827[20:27])
    defparam FTA_IN_I_0_1_lut.init = 16'h5555;
    LUT4 i8321_2_lut (.A(NFO1), .B(NFO2), .Z(NFO_OUT_N_318)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(790[28:44])
    defparam i8321_2_lut.init = 16'h1111;
    LUT4 FPORCH_FF_I_0_1_lut (.A(FPORCH_FF), .Z(FPORCH_FF_N_447)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(830[20:30])
    defparam FPORCH_FF_I_0_1_lut.init = 16'h5555;
    LUT4 and_400_i6_2_lut (.A(HC), .B(H_IN[5]), .Z(n417[5])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(814[37:60])
    defparam and_400_i6_2_lut.init = 16'h8888;
    LUT4 i8336_2_lut (.A(N_HB), .B(VSYNC_FF), .Z(VSYNC_N_450)) /* synthesis lut_function=(!(A+(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(831[20:40])
    defparam i8336_2_lut.init = 16'h1111;
    LUT4 and_400_i5_2_lut (.A(HC), .B(H_IN[4]), .Z(n417[4])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(814[37:60])
    defparam and_400_i5_2_lut.init = 16'h8888;
    LUT4 VSET1_I_0_1_lut (.A(VSET1), .Z(VSET1_N_485)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(811[25:31])
    defparam VSET1_I_0_1_lut.init = 16'h5555;
    LUT4 i8347_2_lut (.A(H[8]), .B(VB_FF), .Z(CLIP2_N_386)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(845[20:38])
    defparam i8347_2_lut.init = 16'h4444;
    LUT4 i2_3_lut_adj_402 (.A(H[3]), .B(n6172), .C(H[5]), .Z(n6174)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i2_3_lut_adj_402.init = 16'h8080;
    LUT4 and_400_i4_2_lut (.A(HC), .B(H_IN[3]), .Z(n417[3])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(814[37:60])
    defparam and_400_i4_2_lut.init = 16'h8888;
    LUT4 i1_2_lut_adj_403 (.A(H[2]), .B(H[0]), .Z(n8752)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(744[15:47])
    defparam i1_2_lut_adj_403.init = 16'h8888;
    LUT4 i8301_4_lut (.A(BLNK), .B(H[6]), .C(H[7]), .D(n6174), .Z(H_LINE7_N_526)) /* synthesis lut_function=(!(A+!(B (C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(766[19:93])
    defparam i8301_4_lut.init = 16'h4000;
    LUT4 Vo_3__bdd_2_lut (.A(Vo[0]), .B(V_LINE0N_N_545), .Z(n9403)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam Vo_3__bdd_2_lut.init = 16'h1111;
    LUT4 and_400_i3_2_lut (.A(HC), .B(H_IN[2]), .Z(n417[2])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(814[37:60])
    defparam and_400_i3_2_lut.init = 16'h8888;
    LUT4 i1_2_lut_adj_404 (.A(Vo[1]), .B(Vo[2]), .Z(n3645)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(779[22:75])
    defparam i1_2_lut_adj_404.init = 16'heeee;
    LUT4 and_400_i2_2_lut (.A(HC), .B(H_IN[1]), .Z(n417[1])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(814[37:60])
    defparam and_400_i2_2_lut.init = 16'h8888;
    LUT4 i8524_3_lut (.A(V_LINE3P_N_596), .B(PCLK_c), .C(VB_FF_N_298), 
         .Z(Clk_enable_9)) /* synthesis lut_function=(!(A (B)+!A (B+!(C)))) */ ;
    defparam i8524_3_lut.init = 16'h3232;
    LUT4 i8382_4_lut (.A(n3639), .B(Vo[4]), .C(V[8]), .D(n6), .Z(VB_FF_N_298)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(871[10:40])
    defparam i8382_4_lut.init = 16'h0001;
    PFUMX i8636 (.BLUT(n9409), .ALUT(n9408), .C0(MODE_c), .Z(n9410));
    LUT4 i1_3_lut_adj_405 (.A(RC), .B(nRES_c), .C(RESCL), .Z(n8708)) /* synthesis lut_function=(!(A (B (C))+!A (B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam i1_3_lut_adj_405.init = 16'h3b3b;
    LUT4 i1_2_lut_adj_406 (.A(Vo[0]), .B(H_LINE23_N_536), .Z(V_IN_8__N_264[0])) /* synthesis lut_function=(A (B)+!A !(B)) */ ;
    defparam i1_2_lut_adj_406.init = 16'h9999;
    FD1P3IX ODDEVEN1_606 (.D(ODDEVEN2), .SP(Clk_enable_110), .CD(nRES_N_7), 
            .CK(Clk), .Q(ODDEVEN1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam ODDEVEN1_606.GSR = "ENABLED";
    LUT4 PEN_FF_N_470_bdd_3_lut_8709 (.A(PEN_FF_N_470), .B(nPCLK), .C(n9563), 
         .Z(Clk_enable_48)) /* synthesis lut_function=(A (B)+!A (B (C))) */ ;
    defparam PEN_FF_N_470_bdd_3_lut_8709.init = 16'hc8c8;
    LUT4 VSET2_I_0_1_lut (.A(VSET2), .Z(VSET2_N_488)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(874[19:25])
    defparam VSET2_I_0_1_lut.init = 16'h5555;
    LUT4 i8330_2_lut (.A(CLIP1), .B(CLIP2), .Z(CLIP_OUT_N_381)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(818[20:39])
    defparam i8330_2_lut.init = 16'h4444;
    LUT4 n9561_bdd_2_lut (.A(n9561), .B(Vo[1]), .Z(n9562)) /* synthesis lut_function=(!((B)+!A)) */ ;
    defparam n9561_bdd_2_lut.init = 16'h2222;
    PFUMX i28 (.BLUT(n8748), .ALUT(n14), .C0(Vo[1]), .Z(n17));
    LUT4 Vo_1__bdd_4_lut_8706 (.A(Vo[2]), .B(n7), .C(Vo[3]), .D(Vo[0]), 
         .Z(n9561)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;
    defparam Vo_1__bdd_4_lut_8706.init = 16'h0200;
    LUT4 xor_443_i5_3_lut_4_lut (.A(H[2]), .B(HCarry[1]), .C(H[3]), .D(H[4]), 
         .Z(H_IN_8__N_255[4])) /* synthesis lut_function=(!(A (B (C (D)+!C !(D))+!B !(D))+!A !(D))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(746[22:69])
    defparam xor_443_i5_3_lut_4_lut.init = 16'h7f80;
    LUT4 i8333_3_lut (.A(EEV_IN), .B(EVAL_IN), .C(HPOS_IN), .Z(nEVAL_N_281)) /* synthesis lut_function=(!(A+(B+(C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(820[20:51])
    defparam i8333_3_lut.init = 16'h0101;
    LUT4 i8359_3_lut (.A(H[1]), .B(H[2]), .C(BLNK), .Z(FNT_IN_N_311)) /* synthesis lut_function=(!(A+(B+(C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(852[20:45])
    defparam i8359_3_lut.init = 16'h0101;
    LUT4 Vo_4__bdd_4_lut_8646 (.A(Vo[4]), .B(Vo[5]), .C(Vo[1]), .D(MODE_c), 
         .Z(n9428)) /* synthesis lut_function=(A (B (C (D)))+!A !(B+(C+(D)))) */ ;
    defparam Vo_4__bdd_4_lut_8646.init = 16'h8001;
    LUT4 H_8__I_0_664_i2_2_lut (.A(H[1]), .B(H[0]), .Z(HCarry[1])) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(746[22:69])
    defparam H_8__I_0_664_i2_2_lut.init = 16'h8888;
    LUT4 xor_443_i6_2_lut (.A(H[5]), .B(HIN5), .Z(H_IN_8__N_255[5])) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(838[23:70])
    defparam xor_443_i6_2_lut.init = 16'h6666;
    LUT4 NVIS_IN_I_0_1_lut (.A(NVIS_IN), .Z(NVIS_IN_N_288)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(824[20:28])
    defparam NVIS_IN_I_0_1_lut.init = 16'h5555;
    LUT4 i8364_4_lut (.A(PARO_IN_N_404), .B(H[4]), .C(H[5]), .D(H[6]), 
         .Z(NFO1_N_421)) /* synthesis lut_function=(!(A+(B+(C+!(D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(855[20:58])
    defparam i8364_4_lut.init = 16'h0100;
    LUT4 i8371_2_lut (.A(H[2]), .B(H[1]), .Z(FAT_IN_N_324)) /* synthesis lut_function=(!(A+!(B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(857[20:37])
    defparam i8371_2_lut.init = 16'h4444;
    LUT4 PICT1_I_0_705_2_lut (.A(PICT1), .B(PICT2), .Z(nPICTURE)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(795[19:32])
    defparam PICT1_I_0_705_2_lut.init = 16'heeee;
    LUT4 i1_3_lut_4_lut_adj_407 (.A(H[3]), .B(H[8]), .C(H[7]), .D(H[6]), 
         .Z(n4)) /* synthesis lut_function=(A+((C+(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(761[20:93])
    defparam i1_3_lut_4_lut_adj_407.init = 16'hfffb;
    LUT4 i8290_2_lut_4_lut (.A(H[5]), .B(n4), .C(n6097), .D(n8752), 
         .Z(H_LINE0_N_499)) /* synthesis lut_function=(!(A+(B+!(C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(761[19:93])
    defparam i8290_2_lut_4_lut.init = 16'h1000;
    FD1P3IX V__i1 (.D(n438[0]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(Vo[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam V__i1.GSR = "ENABLED";
    FD1P3AX R2DB7_611 (.D(INT_FF), .SP(Clk_enable_290), .CK(Clk), .Q(\R2DB[2] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam R2DB7_611.GSR = "ENABLED";
    FD1P3JX VSET1_662 (.D(V_LINE3N_N_591), .SP(nPCLK), .PD(n9216), .CK(Clk), 
            .Q(VSET1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam VSET1_662.GSR = "ENABLED";
    FD1P3IX H__i0 (.D(n417[0]), .SP(PCLK_c), .CD(n4587), .CK(Clk), .Q(H[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=18, LSE_RCOL=2, LSE_LLINE=234, LSE_RLINE=274 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(800[8] 876[26])
    defparam H__i0.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module REGISTER_SELECT
//

module REGISTER_SELECT (W0, Clk, nDBER, W1, R2, RnWR, VCC_net, 
            GND_net, RnW_c, DB_OE_CONTROL_c_c, DBIN, DB_out_4, W6_2, 
            W5_1, RC, Clk_enable_292, W6_1, W5_2, DB_DIR_c, W3, 
            R4, W4, R7, W7, A_c_0, A_c_1, DB_out_0, DB_out_1, 
            Clk_enable_290, Clk_enable_33, DB_out_2, DB_out_3, DB_out_5, 
            DB_out_6, DB_out_7, Clk_enable_14, A_c_2) /* synthesis syn_module_defined=1 */ ;
    output W0;
    input Clk;
    output nDBER;
    output W1;
    output R2;
    output RnWR;
    input VCC_net;
    input GND_net;
    input RnW_c;
    input DB_OE_CONTROL_c_c;
    output [7:0]DBIN;
    input DB_out_4;
    output W6_2;
    output W5_1;
    input RC;
    output Clk_enable_292;
    output W6_1;
    output W5_2;
    output DB_DIR_c;
    output W3;
    output R4;
    output W4;
    output R7;
    output W7;
    input A_c_0;
    input A_c_1;
    input DB_out_0;
    input DB_out_1;
    output Clk_enable_290;
    output Clk_enable_33;
    input DB_out_2;
    input DB_out_3;
    input DB_out_5;
    input DB_out_6;
    input DB_out_7;
    output Clk_enable_14;
    input A_c_2;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    wire W0_N_36, W1_N_48, R2_N_51, DBIN_7__N_28, DWR2_N_72, W3_N_55, 
        R4_N_62;
    wire [2:0]ADR;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(520[10:13])
    
    wire W6_1_N_79, W6_1_N_76, W4_N_58, DWR2_N_69, W5_1_N_64, DWR2, 
        R7_N_85, W7_N_82, Clk_enable_294, Clk_enable_295, W4_N_60, 
        DWR1;
    
    FD1S3IX W0_134 (.D(W0_N_36), .CK(Clk), .CD(nDBER), .Q(W0));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam W0_134.GSR = "ENABLED";
    FD1S3IX W1_135 (.D(W1_N_48), .CK(Clk), .CD(nDBER), .Q(W1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam W1_135.GSR = "ENABLED";
    FD1S3IX R2_136 (.D(R2_N_51), .CK(Clk), .CD(nDBER), .Q(R2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam R2_136.GSR = "ENABLED";
    IFS1P3DX RnWR_132 (.D(RnW_c), .SP(VCC_net), .SCLK(Clk), .CD(GND_net), 
            .Q(RnWR)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=166, LSE_RLINE=186 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam RnWR_132.GSR = "ENABLED";
    IFS1P3DX nDBER_133 (.D(DB_OE_CONTROL_c_c), .SP(VCC_net), .SCLK(Clk), 
            .CD(GND_net), .Q(nDBER)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=166, LSE_RLINE=186 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam nDBER_133.GSR = "ENABLED";
    IFS1P3DX DBIN_i0_i4 (.D(DB_out_4), .SP(DBIN_7__N_28), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=166, LSE_RLINE=186 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam DBIN_i0_i4.GSR = "ENABLED";
    LUT4 i1_2_lut_3_lut (.A(W6_2), .B(W5_1), .C(RC), .Z(Clk_enable_292)) /* synthesis lut_function=(A+(B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(545[11:36])
    defparam i1_2_lut_3_lut.init = 16'hfefe;
    LUT4 i2_3_lut_4_lut (.A(W6_2), .B(W5_1), .C(W6_1), .D(W5_2), .Z(DWR2_N_72)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(545[11:36])
    defparam i2_3_lut_4_lut.init = 16'hfffe;
    LUT4 RnW_I_0_1_lut (.A(RnW_c), .Z(DB_DIR_c)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(141[17:21])
    defparam RnW_I_0_1_lut.init = 16'h5555;
    FD1S3IX W3_137 (.D(W3_N_55), .CK(Clk), .CD(nDBER), .Q(W3));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam W3_137.GSR = "ENABLED";
    FD1S3IX R4_138 (.D(R4_N_62), .CK(Clk), .CD(nDBER), .Q(R4));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam R4_138.GSR = "ENABLED";
    LUT4 i2_3_lut_4_lut_adj_386 (.A(RnWR), .B(ADR[0]), .C(W6_1_N_79), 
         .D(nDBER), .Z(W6_1_N_76)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;
    defparam i2_3_lut_4_lut_adj_386.init = 16'h0010;
    FD1S3IX W4_139 (.D(W4_N_58), .CK(Clk), .CD(nDBER), .Q(W4));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam W4_139.GSR = "ENABLED";
    FD1S3IX W5_1_140 (.D(W5_1_N_64), .CK(Clk), .CD(DWR2_N_69), .Q(W5_1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam W5_1_140.GSR = "ENABLED";
    FD1S3IX W5_2_141 (.D(W5_1_N_64), .CK(Clk), .CD(DWR2), .Q(W5_2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam W5_2_141.GSR = "ENABLED";
    FD1S3IX W6_1_142 (.D(W6_1_N_76), .CK(Clk), .CD(DWR2_N_69), .Q(W6_1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam W6_1_142.GSR = "ENABLED";
    FD1S3IX W6_2_143 (.D(W6_1_N_76), .CK(Clk), .CD(DWR2), .Q(W6_2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam W6_2_143.GSR = "ENABLED";
    FD1S3IX R7_144 (.D(R7_N_85), .CK(Clk), .CD(nDBER), .Q(R7));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam R7_144.GSR = "ENABLED";
    FD1S3IX W7_145 (.D(W7_N_82), .CK(Clk), .CD(nDBER), .Q(W7));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam W7_145.GSR = "ENABLED";
    LUT4 ADR_2__I_0_2_lut (.A(ADR[2]), .B(ADR[1]), .Z(W6_1_N_79)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(539[16:32])
    defparam ADR_2__I_0_2_lut.init = 16'h8888;
    LUT4 W7_I_21_2_lut_3_lut_4_lut (.A(ADR[2]), .B(ADR[1]), .C(ADR[0]), 
         .D(RnWR), .Z(W7_N_82)) /* synthesis lut_function=(!((((D)+!C)+!B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(542[16:42])
    defparam W7_I_21_2_lut_3_lut_4_lut.init = 16'h0080;
    LUT4 W7_N_83_I_0_2_lut_3_lut_4_lut (.A(ADR[2]), .B(ADR[1]), .C(ADR[0]), 
         .D(RnWR), .Z(R7_N_85)) /* synthesis lut_function=(A (B (C (D)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(542[16:42])
    defparam W7_N_83_I_0_2_lut_3_lut_4_lut.init = 16'h8000;
    LUT4 i1_2_lut_3_lut_4_lut (.A(ADR[2]), .B(ADR[1]), .C(ADR[0]), .D(RnWR), 
         .Z(W1_N_48)) /* synthesis lut_function=(!(A+(B+((D)+!C)))) */ ;
    defparam i1_2_lut_3_lut_4_lut.init = 16'h0010;
    LUT4 i8590_2_lut_3_lut_4_lut (.A(ADR[2]), .B(ADR[1]), .C(ADR[0]), 
         .D(RnWR), .Z(W0_N_36)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;
    defparam i8590_2_lut_3_lut_4_lut.init = 16'h0001;
    LUT4 W4_I_12_2_lut_3_lut_4_lut (.A(ADR[2]), .B(ADR[1]), .C(ADR[0]), 
         .D(RnWR), .Z(W4_N_58)) /* synthesis lut_function=(!((B+(C+(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(536[16:42])
    defparam W4_I_12_2_lut_3_lut_4_lut.init = 16'h0002;
    LUT4 W4_N_59_I_0_2_lut_3_lut_4_lut (.A(ADR[2]), .B(ADR[1]), .C(ADR[0]), 
         .D(RnWR), .Z(R4_N_62)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(536[16:42])
    defparam W4_N_59_I_0_2_lut_3_lut_4_lut.init = 16'h0200;
    LUT4 i8278_2_lut (.A(DB_OE_CONTROL_c_c), .B(RnW_c), .Z(DBIN_7__N_28)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i8278_2_lut.init = 16'h1111;
    IFS1P3DX ADR_i0 (.D(A_c_0), .SP(VCC_net), .SCLK(Clk), .CD(GND_net), 
            .Q(ADR[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=166, LSE_RLINE=186 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam ADR_i0.GSR = "ENABLED";
    IFS1P3DX ADR_i1 (.D(A_c_1), .SP(VCC_net), .SCLK(Clk), .CD(GND_net), 
            .Q(ADR[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=166, LSE_RLINE=186 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam ADR_i1.GSR = "ENABLED";
    IFS1P3DX DBIN_i0_i0 (.D(DB_out_0), .SP(DBIN_7__N_28), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=166, LSE_RLINE=186 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam DBIN_i0_i0.GSR = "ENABLED";
    IFS1P3DX DBIN_i0_i1 (.D(DB_out_1), .SP(DBIN_7__N_28), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=166, LSE_RLINE=186 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam DBIN_i0_i1.GSR = "ENABLED";
    LUT4 i3905_1_lut (.A(R2), .Z(Clk_enable_290)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam i3905_1_lut.init = 16'h5555;
    LUT4 i1_2_lut (.A(DWR2_N_72), .B(R2), .Z(Clk_enable_294)) /* synthesis lut_function=((B)+!A) */ ;
    defparam i1_2_lut.init = 16'hdddd;
    LUT4 i1_2_lut_adj_387 (.A(DWR2_N_72), .B(R2), .Z(Clk_enable_295)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i1_2_lut_adj_387.init = 16'heeee;
    LUT4 i1_2_lut_3_lut_4_lut_adj_388 (.A(ADR[2]), .B(ADR[1]), .C(ADR[0]), 
         .D(RnWR), .Z(W3_N_55)) /* synthesis lut_function=(!(A+(((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(533[15:32])
    defparam i1_2_lut_3_lut_4_lut_adj_388.init = 16'h0040;
    LUT4 i2_3_lut_4_lut_adj_389 (.A(ADR[2]), .B(ADR[1]), .C(ADR[0]), .D(RnWR), 
         .Z(R2_N_51)) /* synthesis lut_function=(!(A+((C+!(D))+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(533[15:32])
    defparam i2_3_lut_4_lut_adj_389.init = 16'h0400;
    LUT4 i2_3_lut_4_lut_adj_390 (.A(RnWR), .B(ADR[0]), .C(W4_N_60), .D(nDBER), 
         .Z(W5_1_N_64)) /* synthesis lut_function=(!(A+(((D)+!C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(532[15:50])
    defparam i2_3_lut_4_lut_adj_390.init = 16'h0040;
    LUT4 i731_1_lut (.A(W0), .Z(Clk_enable_33)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam i731_1_lut.init = 16'h5555;
    IFS1P3DX DBIN_i0_i2 (.D(DB_out_2), .SP(DBIN_7__N_28), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=166, LSE_RLINE=186 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam DBIN_i0_i2.GSR = "ENABLED";
    IFS1P3DX DBIN_i0_i3 (.D(DB_out_3), .SP(DBIN_7__N_28), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=166, LSE_RLINE=186 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam DBIN_i0_i3.GSR = "ENABLED";
    IFS1P3DX DBIN_i0_i5 (.D(DB_out_5), .SP(DBIN_7__N_28), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=166, LSE_RLINE=186 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam DBIN_i0_i5.GSR = "ENABLED";
    IFS1P3DX DBIN_i0_i6 (.D(DB_out_6), .SP(DBIN_7__N_28), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=166, LSE_RLINE=186 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam DBIN_i0_i6.GSR = "ENABLED";
    IFS1P3DX DBIN_i0_i7 (.D(DB_out_7), .SP(DBIN_7__N_28), .SCLK(Clk), 
            .CD(GND_net), .Q(DBIN[7])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=166, LSE_RLINE=186 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam DBIN_i0_i7.GSR = "ENABLED";
    LUT4 ADR_2__I_0_154_2_lut (.A(ADR[2]), .B(ADR[1]), .Z(W4_N_60)) /* synthesis lut_function=(!((B)+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(536[16:32])
    defparam ADR_2__I_0_154_2_lut.init = 16'h2222;
    LUT4 DWR2_I_0_1_lut (.A(DWR2), .Z(DWR2_N_69)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(538[62:67])
    defparam DWR2_I_0_1_lut.init = 16'h5555;
    LUT4 i739_1_lut (.A(W1), .Z(Clk_enable_14)) /* synthesis lut_function=(!(A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam i739_1_lut.init = 16'h5555;
    FD1P3JX DWR2_147 (.D(DWR1), .SP(Clk_enable_294), .PD(R2), .CK(Clk), 
            .Q(DWR2));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam DWR2_147.GSR = "ENABLED";
    FD1P3JX DWR1_146 (.D(DWR2_N_69), .SP(Clk_enable_295), .PD(R2), .CK(Clk), 
            .Q(DWR1));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam DWR1_146.GSR = "ENABLED";
    IFS1P3DX ADR_i2 (.D(A_c_2), .SP(VCC_net), .SCLK(Clk), .CD(GND_net), 
            .Q(ADR[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=17, LSE_RCOL=2, LSE_LLINE=166, LSE_RLINE=186 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(527[8] 549[26])
    defparam ADR_i2.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module PLL
//

module PLL (MCLK_c, Clk, GND_net) /* synthesis NGD_DRC_MASK=1, syn_module_defined=1 */ ;
    input MCLK_c;
    output Clk;
    input GND_net;
    
    wire MCLK_c /* synthesis is_clock=1, SET_AS_NETWORK=MCLK_c */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(36[11:15])
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    
    EHXPLLJ PLLInst_0 (.CLKI(MCLK_c), .CLKFB(Clk), .PHASESEL0(GND_net), 
            .PHASESEL1(GND_net), .PHASEDIR(GND_net), .PHASESTEP(GND_net), 
            .LOADREG(GND_net), .STDBY(GND_net), .PLLWAKESYNC(GND_net), 
            .RST(GND_net), .RESETC(GND_net), .RESETD(GND_net), .RESETM(GND_net), 
            .ENCLKOP(GND_net), .ENCLKOS(GND_net), .ENCLKOS2(GND_net), 
            .ENCLKOS3(GND_net), .PLLCLK(GND_net), .PLLRST(GND_net), .PLLSTB(GND_net), 
            .PLLWE(GND_net), .PLLDATI0(GND_net), .PLLDATI1(GND_net), .PLLDATI2(GND_net), 
            .PLLDATI3(GND_net), .PLLDATI4(GND_net), .PLLDATI5(GND_net), 
            .PLLDATI6(GND_net), .PLLDATI7(GND_net), .PLLADDR0(GND_net), 
            .PLLADDR1(GND_net), .PLLADDR2(GND_net), .PLLADDR3(GND_net), 
            .PLLADDR4(GND_net), .CLKOP(Clk)) /* synthesis FREQUENCY_PIN_CLKOP="42.954540", FREQUENCY_PIN_CLKI="21.477270", ICP_CURRENT="7", LPF_RESISTOR="8", syn_instantiated=1, LSE_LINE_FILE_ID=3, LSE_LCOL=5, LSE_RCOL=17, LSE_LLINE=152, LSE_RLINE=153 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(152[5] 153[17])
    defparam PLLInst_0.CLKI_DIV = 1;
    defparam PLLInst_0.CLKFB_DIV = 2;
    defparam PLLInst_0.CLKOP_DIV = 11;
    defparam PLLInst_0.CLKOS_DIV = 1;
    defparam PLLInst_0.CLKOS2_DIV = 1;
    defparam PLLInst_0.CLKOS3_DIV = 1;
    defparam PLLInst_0.CLKOP_ENABLE = "ENABLED";
    defparam PLLInst_0.CLKOS_ENABLE = "DISABLED";
    defparam PLLInst_0.CLKOS2_ENABLE = "DISABLED";
    defparam PLLInst_0.CLKOS3_ENABLE = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_A0 = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_B0 = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_C0 = "DISABLED";
    defparam PLLInst_0.VCO_BYPASS_D0 = "DISABLED";
    defparam PLLInst_0.CLKOP_CPHASE = 10;
    defparam PLLInst_0.CLKOS_CPHASE = 0;
    defparam PLLInst_0.CLKOS2_CPHASE = 0;
    defparam PLLInst_0.CLKOS3_CPHASE = 0;
    defparam PLLInst_0.CLKOP_FPHASE = 0;
    defparam PLLInst_0.CLKOS_FPHASE = 0;
    defparam PLLInst_0.CLKOS2_FPHASE = 0;
    defparam PLLInst_0.CLKOS3_FPHASE = 0;
    defparam PLLInst_0.FEEDBK_PATH = "CLKOP";
    defparam PLLInst_0.FRACN_ENABLE = "DISABLED";
    defparam PLLInst_0.FRACN_DIV = 0;
    defparam PLLInst_0.CLKOP_TRIM_POL = "RISING";
    defparam PLLInst_0.CLKOP_TRIM_DELAY = 0;
    defparam PLLInst_0.CLKOS_TRIM_POL = "FALLING";
    defparam PLLInst_0.CLKOS_TRIM_DELAY = 0;
    defparam PLLInst_0.PLL_USE_WB = "DISABLED";
    defparam PLLInst_0.PREDIVIDER_MUXA1 = 0;
    defparam PLLInst_0.PREDIVIDER_MUXB1 = 0;
    defparam PLLInst_0.PREDIVIDER_MUXC1 = 0;
    defparam PLLInst_0.PREDIVIDER_MUXD1 = 0;
    defparam PLLInst_0.OUTDIVIDER_MUXA2 = "DIVA";
    defparam PLLInst_0.OUTDIVIDER_MUXB2 = "DIVB";
    defparam PLLInst_0.OUTDIVIDER_MUXC2 = "DIVC";
    defparam PLLInst_0.OUTDIVIDER_MUXD2 = "DIVD";
    defparam PLLInst_0.PLL_LOCK_MODE = 0;
    defparam PLLInst_0.STDBY_ENABLE = "DISABLED";
    defparam PLLInst_0.DPHASE_SOURCE = "DISABLED";
    defparam PLLInst_0.PLLRST_ENA = "DISABLED";
    defparam PLLInst_0.MRST_ENA = "DISABLED";
    defparam PLLInst_0.DCRST_ENA = "DISABLED";
    defparam PLLInst_0.DDRST_ENA = "DISABLED";
    defparam PLLInst_0.INTFB_WAKE = "DISABLED";
    
endmodule
//
// Verilog Description of module REG2000_2001
//

module REG2000_2001 (EMP_G, Clk, Clk_enable_14, nPCLK, nVIS, CLIP_B_N_277, 
            EMPH, EMP_R, n1026, BGSEL, Clk_enable_33, O8_16, BGCLIP, 
            CLIPOR, MODE_c, I1_32, W1, DBIN, VBL_EN, W0, OBSEL, 
            BLNK_FF, BLNK, N_HB, SC_CNT, RC, nCLPB_N_121, B_W, 
            CLIP_OUT) /* synthesis syn_module_defined=1 */ ;
    output EMP_G;
    input Clk;
    input Clk_enable_14;
    input nPCLK;
    input nVIS;
    input CLIP_B_N_277;
    output [2:0]EMPH;
    output EMP_R;
    output n1026;
    output BGSEL;
    input Clk_enable_33;
    output O8_16;
    output BGCLIP;
    output CLIPOR;
    input MODE_c;
    output I1_32;
    input W1;
    input [7:0]DBIN;
    output VBL_EN;
    input W0;
    output OBSEL;
    input BLNK_FF;
    output BLNK;
    input N_HB;
    output SC_CNT;
    input RC;
    output nCLPB_N_121;
    output B_W;
    input CLIP_OUT;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [7:0]W1R;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(583[10:13])
    
    wire nVISR, CLIPBR;
    wire [4:0]W0R;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(582[10:13])
    
    wire OBCLIP, BGE, OBE, CLIPOR_N_129, n4538, n4536;
    
    FD1P3AX EMP_G_70 (.D(W1R[6]), .SP(Clk_enable_14), .CK(Clk), .Q(EMP_G));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam EMP_G_70.GSR = "ENABLED";
    FD1P3AX nVISR_71 (.D(nVIS), .SP(nPCLK), .CK(Clk), .Q(nVISR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam nVISR_71.GSR = "ENABLED";
    FD1P3AX CLIPBR_72 (.D(CLIP_B_N_277), .SP(nPCLK), .CK(Clk), .Q(CLIPBR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam CLIPBR_72.GSR = "ENABLED";
    LUT4 i538_2_lut_3_lut (.A(EMPH[2]), .B(EMP_G), .C(EMP_R), .Z(n1026)) /* synthesis lut_function=(!(A+!(B (C)))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam i538_2_lut_3_lut.init = 16'h4040;
    FD1P3AX BGSEL_63 (.D(W0R[2]), .SP(Clk_enable_33), .CK(Clk), .Q(BGSEL));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam BGSEL_63.GSR = "ENABLED";
    FD1P3AX O8_16_64 (.D(W0R[3]), .SP(Clk_enable_33), .CK(Clk), .Q(O8_16));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam O8_16_64.GSR = "ENABLED";
    FD1P3AX BGCLIP_65 (.D(W1R[1]), .SP(Clk_enable_14), .CK(Clk), .Q(BGCLIP));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam BGCLIP_65.GSR = "ENABLED";
    FD1P3AX OBCLIP_66 (.D(W1R[2]), .SP(Clk_enable_14), .CK(Clk), .Q(OBCLIP));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam OBCLIP_66.GSR = "ENABLED";
    FD1P3AX BGE_67 (.D(W1R[3]), .SP(Clk_enable_14), .CK(Clk), .Q(BGE));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam BGE_67.GSR = "ENABLED";
    FD1P3AX OBE_68 (.D(W1R[4]), .SP(Clk_enable_14), .CK(Clk), .Q(OBE));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam OBE_68.GSR = "ENABLED";
    FD1P3AX CLIPOR_73 (.D(CLIPOR_N_129), .SP(nPCLK), .CK(Clk), .Q(CLIPOR));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam CLIPOR_73.GSR = "ENABLED";
    FD1P3AX EMP_R_69 (.D(W1R[5]), .SP(Clk_enable_14), .CK(Clk), .Q(EMP_R));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam EMP_R_69.GSR = "ENABLED";
    LUT4 EMP_R_I_0_78_3_lut (.A(EMP_R), .B(EMP_G), .C(MODE_c), .Z(EMPH[0])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(595[15:37])
    defparam EMP_R_I_0_78_3_lut.init = 16'hcaca;
    FD1P3AX I1_32_61 (.D(W0R[0]), .SP(Clk_enable_33), .CK(Clk), .Q(I1_32));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam I1_32_61.GSR = "ENABLED";
    FD1P3IX W1R__i7 (.D(DBIN[7]), .SP(W1), .CD(n4538), .CK(Clk), .Q(EMPH[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=189, LSE_RLINE=212 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam W1R__i7.GSR = "ENABLED";
    FD1P3IX W1R__i6 (.D(DBIN[6]), .SP(W1), .CD(n4538), .CK(Clk), .Q(W1R[6])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=189, LSE_RLINE=212 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam W1R__i6.GSR = "ENABLED";
    FD1P3IX W1R__i5 (.D(DBIN[5]), .SP(W1), .CD(n4538), .CK(Clk), .Q(W1R[5])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=189, LSE_RLINE=212 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam W1R__i5.GSR = "ENABLED";
    FD1P3IX W1R__i4 (.D(DBIN[4]), .SP(W1), .CD(n4538), .CK(Clk), .Q(W1R[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=189, LSE_RLINE=212 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam W1R__i4.GSR = "ENABLED";
    FD1P3IX W1R__i3 (.D(DBIN[3]), .SP(W1), .CD(n4538), .CK(Clk), .Q(W1R[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=189, LSE_RLINE=212 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam W1R__i3.GSR = "ENABLED";
    FD1P3IX W1R__i2 (.D(DBIN[2]), .SP(W1), .CD(n4538), .CK(Clk), .Q(W1R[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=189, LSE_RLINE=212 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam W1R__i2.GSR = "ENABLED";
    FD1P3IX W1R__i1 (.D(DBIN[1]), .SP(W1), .CD(n4538), .CK(Clk), .Q(W1R[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=189, LSE_RLINE=212 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam W1R__i1.GSR = "ENABLED";
    FD1P3IX W0R__i4 (.D(DBIN[7]), .SP(W0), .CD(n4536), .CK(Clk), .Q(VBL_EN)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=189, LSE_RLINE=212 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam W0R__i4.GSR = "ENABLED";
    FD1P3IX W0R__i3 (.D(DBIN[5]), .SP(W0), .CD(n4536), .CK(Clk), .Q(W0R[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=189, LSE_RLINE=212 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam W0R__i3.GSR = "ENABLED";
    FD1P3IX W0R__i2 (.D(DBIN[4]), .SP(W0), .CD(n4536), .CK(Clk), .Q(W0R[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=189, LSE_RLINE=212 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam W0R__i2.GSR = "ENABLED";
    FD1P3IX W0R__i1 (.D(DBIN[3]), .SP(W0), .CD(n4536), .CK(Clk), .Q(W0R[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=189, LSE_RLINE=212 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam W0R__i1.GSR = "ENABLED";
    FD1P3AX OBSEL_62 (.D(W0R[1]), .SP(Clk_enable_33), .CK(Clk), .Q(OBSEL));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam OBSEL_62.GSR = "ENABLED";
    LUT4 BLACK_I_0_2_lut_3_lut (.A(BGE), .B(OBE), .C(BLNK_FF), .Z(BLNK)) /* synthesis lut_function=(A (C)+!A ((C)+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(589[17:30])
    defparam BLACK_I_0_2_lut_3_lut.init = 16'hf1f1;
    LUT4 i5255_2_lut_3_lut (.A(BGE), .B(OBE), .C(N_HB), .Z(SC_CNT)) /* synthesis lut_function=(A (C)+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(589[17:30])
    defparam i5255_2_lut_3_lut.init = 16'he0e0;
    LUT4 EMP_G_I_0_79_3_lut (.A(EMP_G), .B(EMP_R), .C(MODE_c), .Z(EMPH[1])) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(596[15:37])
    defparam EMP_G_I_0_79_3_lut.init = 16'hcaca;
    LUT4 i1127_2_lut (.A(W0), .B(RC), .Z(n4536)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam i1127_2_lut.init = 16'h8888;
    LUT4 i8281_3_lut (.A(nVISR), .B(BGE), .C(CLIPBR), .Z(nCLPB_N_121)) /* synthesis lut_function=(!(A+((C)+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(592[16:42])
    defparam i8281_3_lut.init = 16'h0404;
    FD1P3IX W1R__i0 (.D(DBIN[0]), .SP(W1), .CD(n4538), .CK(Clk), .Q(B_W)) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=189, LSE_RLINE=212 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam W1R__i0.GSR = "ENABLED";
    LUT4 i1121_2_lut (.A(W1), .B(RC), .Z(n4538)) /* synthesis lut_function=(A (B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam i1121_2_lut.init = 16'h8888;
    LUT4 i8283_4_lut (.A(nVISR), .B(CLIP_OUT), .C(OBE), .D(OBCLIP), 
         .Z(CLIPOR_N_129)) /* synthesis lut_function=(!(A+!(B (C)+!B (C (D))))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(617[14:40])
    defparam i8283_4_lut.init = 16'h5040;
    FD1P3IX W0R__i0 (.D(DBIN[2]), .SP(W0), .CD(n4536), .CK(Clk), .Q(W0R[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=14, LSE_RCOL=2, LSE_LLINE=189, LSE_RLINE=212 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(601[8] 619[27])
    defparam W0R__i0.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module VID_MUX
//

module VID_MUX (\R2DB[1] , Clk, SPR0HIT_LATCH, SPR0_EV, nVIS, PCLK_c, 
            RESCL, ZCOL, THO_LATCH, THO, nPCLK, BGC2, CLPB_LATCH, 
            \THO_LATCH[4] , \STEP3[4] , TH_MUX, \CGA[3] , \CGA[2] , 
            \CGA[1] , \STEP3[0] , \CGA[0] ) /* synthesis syn_module_defined=1 */ ;
    output \R2DB[1] ;
    input Clk;
    input SPR0HIT_LATCH;
    input SPR0_EV;
    input nVIS;
    input PCLK_c;
    input RESCL;
    input [4:0]ZCOL;
    output [4:0]THO_LATCH;
    input [4:0]THO;
    input nPCLK;
    input [3:0]BGC2;
    input CLPB_LATCH;
    output \THO_LATCH[4] ;
    output \STEP3[4] ;
    input TH_MUX;
    output \CGA[3] ;
    output \CGA[2] ;
    output \CGA[1] ;
    output \STEP3[0] ;
    output \CGA[0] ;
    
    wire Clk /* synthesis is_clock=1, SET_AS_NETWORK=Clk */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(66[6:9])
    wire [4:0]ZCOLN;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1583[10:15])
    
    wire R2DB6_N_1614, OCOL_N_1619, n9515, n9514;
    wire [3:0]STEP2;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1585[10:15])
    wire [3:0]STEP2_3__N_1603;
    
    wire BGC_LATCH, ZCOL_LATCH, ZCOL_LATCH_N_1617, OCOLN;
    wire [4:0]STEP3;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1586[10:15])
    
    wire n4615;
    wire [4:0]THO_LATCH_c;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1584[10:19])
    
    LUT4 i8453_3_lut_4_lut (.A(ZCOLN[1]), .B(ZCOLN[0]), .C(ZCOLN[4]), 
         .D(R2DB6_N_1614), .Z(OCOL_N_1619)) /* synthesis lut_function=(!(A (C (D))+!A ((C (D))+!B))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1590[15:79])
    defparam i8453_3_lut_4_lut.init = 16'h0eee;
    FD1S3AX R2DB6_41 (.D(n9515), .CK(Clk), .Q(\R2DB[1] ));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam R2DB6_41.GSR = "ENABLED";
    LUT4 RESCL_bdd_4_lut_8693 (.A(SPR0HIT_LATCH), .B(SPR0_EV), .C(nVIS), 
         .D(PCLK_c), .Z(n9514)) /* synthesis lut_function=(!((B+(C+(D)))+!A)) */ ;
    defparam RESCL_bdd_4_lut_8693.init = 16'h0002;
    LUT4 RESCL_bdd_4_lut (.A(RESCL), .B(\R2DB[1] ), .C(R2DB6_N_1614), 
         .D(n9514), .Z(n9515)) /* synthesis lut_function=(!(A+!(B+(C (D))))) */ ;
    defparam RESCL_bdd_4_lut.init = 16'h5444;
    FD1P3AX ZCOLN_i0_i0 (.D(ZCOL[0]), .SP(PCLK_c), .CK(Clk), .Q(ZCOLN[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam ZCOLN_i0_i0.GSR = "ENABLED";
    FD1P3AX THO_LATCH_i0_i0 (.D(THO[0]), .SP(PCLK_c), .CK(Clk), .Q(THO_LATCH[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam THO_LATCH_i0_i0.GSR = "ENABLED";
    FD1P3AX STEP2_i0_i0 (.D(STEP2_3__N_1603[0]), .SP(nPCLK), .CK(Clk), 
            .Q(STEP2[0])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam STEP2_i0_i0.GSR = "ENABLED";
    FD1P3AX BGC_LATCH_46 (.D(R2DB6_N_1614), .SP(nPCLK), .CK(Clk), .Q(BGC_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam BGC_LATCH_46.GSR = "ENABLED";
    FD1P3AX ZCOL_LATCH_47 (.D(ZCOL_LATCH_N_1617), .SP(nPCLK), .CK(Clk), 
            .Q(ZCOL_LATCH));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam ZCOL_LATCH_47.GSR = "ENABLED";
    FD1P3AX OCOLN_48 (.D(OCOL_N_1619), .SP(nPCLK), .CK(Clk), .Q(OCOLN));   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam OCOLN_48.GSR = "ENABLED";
    FD1P3IX STEP3_i0_i3 (.D(STEP2[3]), .SP(PCLK_c), .CD(n4615), .CK(Clk), 
            .Q(STEP3[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam STEP3_i0_i3.GSR = "ENABLED";
    FD1P3IX STEP3_i0_i2 (.D(STEP2[2]), .SP(PCLK_c), .CD(n4615), .CK(Clk), 
            .Q(STEP3[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam STEP3_i0_i2.GSR = "ENABLED";
    FD1P3IX STEP3_i0_i1 (.D(STEP2[1]), .SP(PCLK_c), .CD(n4615), .CK(Clk), 
            .Q(STEP3[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam STEP3_i0_i1.GSR = "ENABLED";
    LUT4 mux_25_i2_4_lut (.A(ZCOLN[1]), .B(BGC2[1]), .C(OCOL_N_1619), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1603[1])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1604[18:46])
    defparam mux_25_i2_4_lut.init = 16'haca0;
    LUT4 mux_25_i3_4_lut (.A(ZCOLN[2]), .B(BGC2[2]), .C(OCOL_N_1619), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1603[2])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1604[18:46])
    defparam mux_25_i3_4_lut.init = 16'haca0;
    LUT4 mux_25_i4_4_lut (.A(ZCOLN[3]), .B(BGC2[3]), .C(OCOL_N_1619), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1603[3])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1604[18:46])
    defparam mux_25_i4_4_lut.init = 16'haca0;
    LUT4 i4004_3_lut (.A(PCLK_c), .B(BGC_LATCH), .C(ZCOL_LATCH), .Z(n4615)) /* synthesis lut_function=(!((B+(C))+!A)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam i4004_3_lut.init = 16'h0202;
    FD1P3AX ZCOLN_i0_i1 (.D(ZCOL[1]), .SP(PCLK_c), .CK(Clk), .Q(ZCOLN[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam ZCOLN_i0_i1.GSR = "ENABLED";
    FD1P3AX ZCOLN_i0_i2 (.D(ZCOL[2]), .SP(PCLK_c), .CK(Clk), .Q(ZCOLN[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam ZCOLN_i0_i2.GSR = "ENABLED";
    FD1P3AX ZCOLN_i0_i3 (.D(ZCOL[3]), .SP(PCLK_c), .CK(Clk), .Q(ZCOLN[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam ZCOLN_i0_i3.GSR = "ENABLED";
    FD1P3AX ZCOLN_i0_i4 (.D(ZCOL[4]), .SP(PCLK_c), .CK(Clk), .Q(ZCOLN[4])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam ZCOLN_i0_i4.GSR = "ENABLED";
    FD1P3AX THO_LATCH_i0_i1 (.D(THO[1]), .SP(PCLK_c), .CK(Clk), .Q(THO_LATCH_c[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam THO_LATCH_i0_i1.GSR = "ENABLED";
    FD1P3AX THO_LATCH_i0_i2 (.D(THO[2]), .SP(PCLK_c), .CK(Clk), .Q(THO_LATCH_c[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam THO_LATCH_i0_i2.GSR = "ENABLED";
    FD1P3AX THO_LATCH_i0_i3 (.D(THO[3]), .SP(PCLK_c), .CK(Clk), .Q(THO_LATCH_c[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam THO_LATCH_i0_i3.GSR = "ENABLED";
    FD1P3AX THO_LATCH_i0_i4 (.D(THO[4]), .SP(PCLK_c), .CK(Clk), .Q(\THO_LATCH[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam THO_LATCH_i0_i4.GSR = "ENABLED";
    FD1P3AX STEP3_i0_i4 (.D(OCOLN), .SP(PCLK_c), .CK(Clk), .Q(\STEP3[4] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam STEP3_i0_i4.GSR = "ENABLED";
    FD1P3AX STEP2_i0_i1 (.D(STEP2_3__N_1603[1]), .SP(nPCLK), .CK(Clk), 
            .Q(STEP2[1])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam STEP2_i0_i1.GSR = "ENABLED";
    FD1P3AX STEP2_i0_i2 (.D(STEP2_3__N_1603[2]), .SP(nPCLK), .CK(Clk), 
            .Q(STEP2[2])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam STEP2_i0_i2.GSR = "ENABLED";
    FD1P3AX STEP2_i0_i3 (.D(STEP2_3__N_1603[3]), .SP(nPCLK), .CK(Clk), 
            .Q(STEP2[3])) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam STEP2_i0_i3.GSR = "ENABLED";
    LUT4 mux_25_i1_4_lut (.A(ZCOLN[0]), .B(BGC2[0]), .C(OCOL_N_1619), 
         .D(CLPB_LATCH), .Z(STEP2_3__N_1603[0])) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A !((C+!(D))+!B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1604[18:46])
    defparam mux_25_i1_4_lut.init = 16'haca0;
    LUT4 ZCOLN_1__I_0_2_lut (.A(ZCOLN[1]), .B(ZCOLN[0]), .Z(ZCOL_LATCH_N_1617)) /* synthesis lut_function=(A+(B)) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1590[19:42])
    defparam ZCOLN_1__I_0_2_lut.init = 16'heeee;
    LUT4 STEP3_4__I_0_49_i4_3_lut (.A(STEP3[3]), .B(THO_LATCH_c[3]), .C(TH_MUX), 
         .Z(\CGA[3] )) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1593[19:55])
    defparam STEP3_4__I_0_49_i4_3_lut.init = 16'hcaca;
    LUT4 STEP3_4__I_0_49_i3_3_lut (.A(STEP3[2]), .B(THO_LATCH_c[2]), .C(TH_MUX), 
         .Z(\CGA[2] )) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1593[19:55])
    defparam STEP3_4__I_0_49_i3_3_lut.init = 16'hcaca;
    LUT4 STEP3_4__I_0_49_i2_3_lut (.A(STEP3[1]), .B(THO_LATCH_c[1]), .C(TH_MUX), 
         .Z(\CGA[1] )) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1593[19:55])
    defparam STEP3_4__I_0_49_i2_3_lut.init = 16'hcaca;
    LUT4 i1771_3_lut (.A(CLPB_LATCH), .B(BGC2[0]), .C(BGC2[1]), .Z(R2DB6_N_1614)) /* synthesis lut_function=(A (B+(C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1597[51:70])
    defparam i1771_3_lut.init = 16'ha8a8;
    LUT4 STEP3_4__I_0_49_i1_3_lut (.A(\STEP3[0] ), .B(THO_LATCH[0]), .C(TH_MUX), 
         .Z(\CGA[0] )) /* synthesis lut_function=(A (B+!(C))+!A (B (C))) */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1593[19:55])
    defparam STEP3_4__I_0_49_i1_3_lut.init = 16'hcaca;
    FD1P3IX STEP3_i0_i0 (.D(STEP2[0]), .SP(PCLK_c), .CD(n4615), .CK(Clk), 
            .Q(\STEP3[0] )) /* synthesis LSE_LINE_FILE_ID=3, LSE_LCOL=9, LSE_RCOL=2, LSE_LLINE=418, LSE_RLINE=432 */ ;   // d:/ppu_reverse/fpga/lava_ppu_lite/rp2c02_lite.v(1595[8] 1609[25])
    defparam STEP3_i0_i0.GSR = "ENABLED";
    
endmodule
